use once_cell::sync::OnceCell;
use serde_json::json;
use std::sync::atomic::{AtomicU32, Ordering};
use tauri::{Emitter, WebviewWindow};

pub static MAIN_WINDOW: OnceCell<WebviewWindow> = OnceCell::new();

// Highest progress emitted so far (percent * 100), keeps the bar monotonic.
static PROGRESS_FLOOR: AtomicU32 = AtomicU32::new(0);

// Held (>0) while 3D-preview fetches reuse the generation pipeline, whose
// 9-18% emits would otherwise move the progress bar and pollute the monotonic
// floor. A refcount, not a bool: terrain/land-cover/buildings previews can
// overlap, and the first one finishing must not unmute the rest.
static SUPPRESS_COUNT: AtomicU32 = AtomicU32::new(0);

/// Mutes/unmutes progress emits; used by the 3D terrain preview fetches.
pub fn set_progress_suppressed(suppressed: bool) {
    if suppressed {
        SUPPRESS_COUNT.fetch_add(1, Ordering::Relaxed);
    } else {
        let mut v = SUPPRESS_COUNT.load(Ordering::Relaxed);
        while let Err(now) = SUPPRESS_COUNT.compare_exchange_weak(
            v,
            v.saturating_sub(1),
            Ordering::Relaxed,
            Ordering::Relaxed,
        ) {
            v = now;
        }
    }
}

// Terminal messages always pass: a generation finishing or failing while a
// preview fetch holds the mute must still reach the GUI, or the Generate
// button stays locked forever (main.js re-enables it on "Error!"/"Done!").
fn emits_suppressed(progress: f64, message: &str) -> bool {
    SUPPRESS_COUNT.load(Ordering::Relaxed) > 0 && progress < 100.0 && !message.starts_with("Error!")
}

/// Resets the monotonic progress floor at the start of a generation.
pub fn reset_progress_floor() {
    PROGRESS_FLOOR.store(0, Ordering::Relaxed);
}

/// The progress value that updates the status line and leaves the bar alone.
///
/// Zero is a real position and sends the bar back to the start, so anything
/// that only has something to say has to pass this instead. It matters most to
/// work that runs beside the numbered stages, such as the Mapillary facade
/// pipeline, which reports from a thread of its own while the bar is moving.
pub const MESSAGE_ONLY: f64 = -1.0;

// Error emits (0.0) pass through untouched.
fn clamp_progress(progress: f64) -> f64 {
    if progress <= 0.0 {
        return progress;
    }
    let p = (progress * 100.0) as u32;
    let prev = PROGRESS_FLOOR.fetch_max(p, Ordering::Relaxed);
    f64::from(prev.max(p)) / 100.0
}

pub fn set_main_window(window: WebviewWindow) {
    MAIN_WINDOW.set(window).ok();
}

pub fn get_main_window() -> Option<&'static WebviewWindow> {
    MAIN_WINDOW.get()
}

/// This function checks if the program is running with a GUI window.
/// Returns `true` if a GUI window is initialized, `false` otherwise.
pub fn is_running_with_gui() -> bool {
    get_main_window().is_some()
}

/// This code manages a multi-step process with a progress bar indicating the overall completion.
/// OSM download, Overture and elevation/land cover run in parallel within 1-18%; the shown
/// percentage is kept monotonic by `clamp_progress` since those stages emit out of order:
///
/// Downloading data...        1-10%    (OSM 1-5, Overture 6, land cover 9, elevation fetch 10)
/// Processing elevation...    12-18%   (runs parallel to the OSM download)
/// (parsing, silent)          18.5%
/// Transforming map...        19%
/// Processing data...         19.5%    (flood fills, footprints, road masks, 3D prescan)
/// Generating area...         20-70%
/// Generating ground...       70-90%
/// Saving world...            90-97%    (region writes)
/// Finalizing world...        97-100%   (map item, signage map tiles, world settings)
///
/// The function `emit_gui_progress_update` is used to send real-time progress updates to the UI.
pub fn emit_gui_progress_update(progress: f64, message: &str) {
    if emits_suppressed(progress, message) {
        return;
    }
    if let Some(window) = get_main_window() {
        let payload = json!({
            "progress": clamp_progress(progress),
            "message": message
        });

        if let Err(e) = window.emit("progress-update", payload) {
            eprintln!("Failed to emit progress event: {e}");
        }
    }
}

/// Like `emit_gui_progress_update` but also carries the stream-to-disk regime so
/// the GUI ETA can pick the right time-weight profile (the post-70% tail is
/// ~instant when streaming, a real save otherwise). Additive payload field;
/// only the two terrain emits use it, all other sites stay on the plain fn.
pub fn emit_gui_progress_update_ex(progress: f64, message: &str, streaming: bool) {
    if emits_suppressed(progress, message) {
        return;
    }
    if let Some(window) = get_main_window() {
        let payload = json!({
            "progress": clamp_progress(progress),
            "message": message,
            "streaming": streaming
        });
        if let Err(e) = window.emit("progress-update", payload) {
            eprintln!("Failed to emit progress event: {e}");
        }
    }
}

pub fn emit_gui_error(message: &str) {
    // Truncate by characters (not bytes) to avoid panicking when the GUI
    // status bar receives an error containing multi-byte UTF-8. e.g.
    // localized OS error messages like "Недостаточно системных ресурсов…"
    // where byte 35 lands inside a Cyrillic character.
    const MAX_CHARS: usize = 35;
    let truncated: String = message.chars().take(MAX_CHARS).collect();
    emit_gui_progress_update(0.0, &format!("Error! {truncated}"));
}

/// Emits the final in-game level name (including localized area suffix for Java,
/// or the location-based name for Bedrock) so the GUI can display it.
pub fn emit_world_name_update(name: &str) {
    if let Some(window) = get_main_window() {
        if let Err(e) = window.emit("world-name-update", name) {
            eprintln!("Failed to emit world-name-update event: {e}");
        }
    }
}

/// Emits an event when the world map preview is ready
pub fn emit_map_preview_ready() {
    if let Some(window) = get_main_window() {
        if let Err(e) = window.emit("map-preview-ready", ()) {
            eprintln!("Failed to emit map-preview-ready event: {}", e);
        }
    }
}

/// Emits an event to reveal a file or folder in the system file explorer
pub fn emit_show_in_folder(path: &str) {
    if let Some(window) = get_main_window() {
        if let Err(e) = window.emit("show-in-folder", path) {
            eprintln!("Failed to emit show-in-folder event: {}", e);
        }
    }
}
