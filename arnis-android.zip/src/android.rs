//! Android-only runtime setup.
//!
//! An Android app has no home directory, no Desktop and a read-only temp
//! directory, so everything the desktop build finds through `dirs` and `std::env`
//! has to be pointed at the app's own storage first. `init` does that once at
//! startup; `output_dir` picks the folder generated worlds are written to.

use std::path::{Path, PathBuf};
use std::sync::OnceLock;
use std::{env, fs};

/// Used only if the process name cannot be read.
const FALLBACK_PACKAGE: &str = "com.louisdev.arnis";

/// The app's package id, which Android uses as the process name.
fn package_name() -> &'static str {
    static PACKAGE: OnceLock<String> = OnceLock::new();
    PACKAGE.get_or_init(|| {
        fs::read("/proc/self/cmdline")
            .ok()
            .and_then(|raw| {
                let first = raw.split(|b| *b == 0).next()?.to_vec();
                let name = String::from_utf8(first).ok()?;
                // Secondary processes are named "<package>:<suffix>".
                let name = name.split(':').next()?.to_string();
                (name.contains('.') && !name.contains('/')).then_some(name)
            })
            .unwrap_or_else(|| FALLBACK_PACKAGE.to_string())
    })
}

/// Points HOME, the XDG directories and TMPDIR at the app's private storage,
/// so caches, settings and temporary files land somewhere writable.
pub fn init() {
    let data = PathBuf::from("/data/data").join(package_name());
    let files = data.join("files");
    let cache = data.join("cache");
    let _ = fs::create_dir_all(&files);
    let _ = fs::create_dir_all(&cache);

    // SAFETY: runs first thing in `run`, before any other thread exists.
    unsafe {
        env::set_var("HOME", &files);
        env::set_var("XDG_DATA_HOME", &files);
        env::set_var("XDG_CONFIG_HOME", &files);
        env::set_var("XDG_CACHE_HOME", &cache);
        env::set_var("TMPDIR", &cache);
    }
}

fn is_writable(dir: &Path) -> bool {
    if fs::create_dir_all(dir).is_err() {
        return false;
    }
    let probe = dir.join(".arnis-write-test");
    let ok = fs::write(&probe, b"").is_ok();
    let _ = fs::remove_file(&probe);
    ok
}

/// Where generated worlds go by default: `Download/Arnis` when the app has
/// "All files access" (so Minecraft can open the .mcworld from the Files app),
/// otherwise the app's own folder on shared storage, then its private folder.
pub fn output_dir() -> PathBuf {
    let package = package_name();
    let candidates = [
        PathBuf::from("/storage/emulated/0/Download/Arnis"),
        PathBuf::from(format!("/storage/emulated/0/Android/data/{package}/files/Arnis")),
        PathBuf::from(format!("/data/data/{package}/files/Arnis")),
    ];
    candidates
        .into_iter()
        .find(|dir| is_writable(dir))
        .unwrap_or_else(|| PathBuf::from("."))
}
