use crate::args::Args;
use crate::coordinate_system::cartesian::XZBBox;
use crate::coordinate_system::geographic::LLBBox;
use crate::element_processing::building_facade::BuildingContext;
use crate::element_processing::subprocessor::interior::InteriorUseIndex;
use crate::element_processing::*;
use crate::floodfill_cache::{CoordinateBitmap, FloodFillCache};
use crate::ground::Ground;
use crate::ground_generation;
use crate::map_preview;
use crate::map_renderer::PreviewAccumulator;
use crate::osm_parser::{
    OutlineSuppression, PartGroups, ProcessedElement, ProcessedMemberRole, ProcessedNode,
    ProcessedRelation, ProcessedWay,
};
use crate::progress::{
    emit_gui_progress_update, emit_gui_progress_update_ex, emit_map_preview_ready,
    emit_show_in_folder, MESSAGE_ONLY,
};
#[cfg(feature = "gui")]
use crate::telemetry::{send_log, LogLevel};
use crate::tile;
use crate::world_editor::{FlushWorker, WorldEditor, WorldFormat};
use colored::Colorize;
use fnv::FnvHashMap;
use indicatif::{ProgressBar, ProgressStyle};
use std::collections::{HashMap, HashSet};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicUsize, Ordering};
use std::sync::{Arc, Condvar, Mutex};

/// Generation options that can be passed separately from CLI Args
#[derive(Clone)]
pub struct GenerationOptions {
    pub path: PathBuf,
    pub format: WorldFormat,
    pub level_name: Option<String>,
    pub spawn_point: Option<(i32, i32)>,
    pub luanti_game: Option<crate::luanti_block_map::LuantiGame>,
    pub ground_level: i32,
    /// The Mapillary facade pipeline, started by the caller as soon as it knew
    /// the bbox so that its downloads overlap the OSM, Overture and elevation
    /// fetches. Idle unless the feature is on. Joined below, before the
    /// buildings go up.
    pub facades: crate::mapillary::FacadeJob,
}

/// Shoelace area of a way's projected ring, in blocks squared.
fn ring_area(nodes: &[ProcessedNode]) -> f64 {
    if nodes.len() < 3 {
        return 0.0;
    }
    let mut twice_area = 0.0f64;
    for i in 0..nodes.len() {
        let a = &nodes[i];
        // Wraps to close the ring; an already-closed way contributes a zero term here.
        let b = &nodes[(i + 1) % nodes.len()];
        twice_area += (a.x as f64) * (b.z as f64) - (b.x as f64) * (a.z as f64);
    }
    (twice_area / 2.0).abs()
}

/// Whether a `landuse` value paints ground at all.
/// `generate_landuse` bails on these before placing anything, and they are typically the largest
/// polygons around, so including them would push every real area behind unrelated elements.
fn landuse_paints_ground(tags: &HashMap<String, String>) -> bool {
    !matches!(
        tags.get("landuse").map(String::as_str),
        Some("residential") | Some("commercial")
    )
}

/// Footprint of a ground-filling way, or `None` if it does not reach a ground-fill handler.
/// Mirrors the landuse/natural/leisure/place arms of `process_element`; keep both in sync.
fn way_ground_fill_area(way: &ProcessedWay) -> Option<f64> {
    let tags = &way.tags;
    if tags.contains_key("building")
        || tags.contains_key("building:part")
        || tags.contains_key("highway")
    {
        return None;
    }
    let fills_ground = if tags.contains_key("landuse") {
        landuse_paints_ground(tags)
    } else if let Some(natural) = tags.get("natural") {
        // natural=* + amenity=fountain falls through to the fountain handler.
        tags.get("amenity").map(String::as_str) != Some("fountain") && natural != "tree_row"
    } else if tags.contains_key("amenity") {
        false
    } else if tags.contains_key("leisure") {
        true
    } else {
        // A square paves its footprint and must yield to lawns inside it.
        tags.get("place").map(String::as_str) == Some("square")
    };
    fills_ground.then(|| ring_area(&way.nodes))
}

/// Footprint of a ground-filling relation, or `None` if it does not reach a ground-fill handler.
/// Mirrors the relation arms of `process_element`; keep both in sync.
fn relation_ground_fill_area(rel: &ProcessedRelation) -> Option<f64> {
    let tags = &rel.tags;
    if tags.contains_key("building")
        || tags.contains_key("building:part")
        || tags.get("type").map(String::as_str) == Some("building")
    {
        return None;
    }
    // Water relations render through water_areas, not the ground-fill handlers.
    if tags.contains_key("water")
        || tags
            .get("natural")
            .map(|v| v == "water" || v == "bay")
            .unwrap_or(false)
    {
        return None;
    }
    let fills_ground = tags.contains_key("natural")
        || (tags.contains_key("landuse") && landuse_paints_ground(tags))
        || tags.get("leisure").map(String::as_str) == Some("park");
    if !fills_ground {
        return None;
    }
    // Outer members are each rendered individually, so the footprint is their sum.
    Some(
        rel.members
            .iter()
            .filter(|m| m.role == ProcessedMemberRole::Outer)
            .map(|m| ring_area(&m.way.nodes))
            .sum(),
    )
}

/// Footprint of a ground-filling element, or `None` if it is not one.
fn ground_fill_area(element: &ProcessedElement) -> Option<f64> {
    let area = match element {
        ProcessedElement::Way(way) => way_ground_fill_area(way)?,
        ProcessedElement::Relation(rel) => relation_ground_fill_area(rel)?,
        ProcessedElement::Node(_) => return None,
    };
    // Degenerate rings render nothing; dropping them keeps a zero area from sorting first and winning.
    (area > 0.0).then_some(area)
}

/// Reorders ground-filling areas so smaller ones render first and larger ones fill in around them.
///
/// Ground blocks are only written where nothing stands yet, so the first area to reach a block
/// keeps it. Sorting by ascending footprint makes the smallest (most specific) area win.
///
/// Only the slots already occupied by ground-filling areas are rewritten, so every other element
/// keeps its index. This stays correct across tiles: a tile renders a subsequence of this global
/// order, and an area is assigned to every tile it overlaps, so the smaller area still precedes the
/// larger one inside each tile.
pub(crate) fn sort_ground_fill_areas(elements: &mut [ProcessedElement]) {
    let mut slots: Vec<usize> = Vec::new();
    let mut areas: Vec<f64> = Vec::new();
    for (index, element) in elements.iter().enumerate() {
        if let Some(area) = ground_fill_area(element) {
            slots.push(index);
            areas.push(area);
        }
    }
    let count = slots.len();
    if count < 2 {
        return;
    }

    // src[k] = compact index of the area that belongs in slots[k].
    let mut src: Vec<usize> = (0..count).collect();
    src.sort_by(|&a, &b| {
        areas[a]
            .total_cmp(&areas[b])
            .then_with(|| elements[slots[a]].id().cmp(&elements[slots[b]].id()))
    });

    // Invert into "where does compact element j belong", then apply in place without cloning.
    let mut dest: Vec<usize> = vec![0; count];
    for (k, &j) in src.iter().enumerate() {
        dest[j] = k;
    }
    for k in 0..count {
        while dest[k] != k {
            let target = dest[k];
            elements.swap(slots[k], slots[target]);
            dest.swap(k, target);
        }
    }
}

/// Drops every cached flood fill whose last reader sits at `index`.
/// Group-lifetime extension can point a fill at an index belonging to a
/// different element, so eviction goes by index, not by the current element.
fn release_finished_fills(
    cache: &mut FloodFillCache,
    fills_expiring_at: &HashMap<usize, Vec<u64>>,
    index: usize,
) {
    if let Some(ids) = fills_expiring_at.get(&index) {
        for &id in ids {
            cache.remove_way(id);
        }
    }
}

/// Fill ids each tile can read, and how many tiles read each one. A tile reads the fills of
/// its ways, of its relations' members, and of their building-part siblings, which
/// `get_cached` serves with no recompute fallback, so none of them may be missed.
fn tile_fill_readers(
    tile_assignments: &[Vec<usize>],
    elements: &[ProcessedElement],
    part_groups: &PartGroups,
    group_members: &FnvHashMap<u64, Vec<u64>>,
    cached: impl Fn(u64) -> bool,
) -> (Vec<Vec<u64>>, FnvHashMap<u64, AtomicU32>) {
    let tile_fill_ids: Vec<Vec<u64>> = tile_assignments
        .iter()
        .map(|elems| {
            let mut ids: Vec<u64> = Vec::new();
            let mut add = |id: u64| {
                ids.push(id);
                for seed in [part_groups.get(&id).copied().unwrap_or(id), id] {
                    let key = crate::osm_parser::seed_without_hint(seed);
                    if let Some(members) = group_members.get(&key) {
                        ids.extend_from_slice(members);
                    }
                }
            };
            for &idx in elems {
                match &elements[idx] {
                    ProcessedElement::Way(way) => add(way.id),
                    ProcessedElement::Relation(rel) => {
                        add(rel.id);
                        for member in &rel.members {
                            add(member.way.id);
                        }
                    }
                    ProcessedElement::Node(_) => {}
                }
            }
            ids.retain(|&id| cached(id));
            ids.sort_unstable();
            ids.dedup();
            ids
        })
        .collect();
    let mut counts: FnvHashMap<u64, u32> = FnvHashMap::default();
    for &id in tile_fill_ids.iter().flatten() {
        *counts.entry(id).or_default() += 1;
    }
    let readers = counts
        .into_iter()
        .map(|(id, n)| (id, AtomicU32::new(n)))
        .collect();
    (tile_fill_ids, readers)
}

/// Drops one finished tile's hold on its fills, freeing each fill it was the last to read.
fn release_tile_fills(ids: &[u64], readers: &FnvHashMap<u64, AtomicU32>, cache: &FloodFillCache) {
    for id in ids {
        if readers[id].fetch_sub(1, Ordering::AcqRel) == 1 {
            cache.release(*id);
        }
    }
}

/// Process a single element by dispatching to the appropriate element processor.
///
/// Extracted from the main loop so the same dispatch runs in both the sequential
/// and the parallel tile-based processing paths. Every shared input is an
/// immutable reference (safe to share across rayon tile threads); the only
/// mutable state is the per-tile `editor` and `rail_tunnel_points`.
///
/// Element suppression (3D-model / building-outline) and flood-fill cache
/// eviction are handled by the caller; the cache is shared across tiles in the
/// parallel path and must not be mutated here.
#[allow(clippy::too_many_arguments)]
fn process_element(
    editor: &mut WorldEditor<'_>,
    element: &ProcessedElement,
    args: &Args,
    highway_connectivity: &highways::HighwayConnectivityMap,
    road_markings: &road_markings::RoadMarkingIndex,
    flood_fill_cache: &FloodFillCache,
    building_footprints: &CoordinateBitmap,
    building_passages: &CoordinateBitmap,
    road_mask: &CoordinateBitmap,
    rail_mask: &CoordinateBitmap,
    tunnel_footprint: &CoordinateBitmap,
    xzbbox: &XZBBox,
    big_water_field: &crate::water_depth::BigWaterField,
    bridge_structures: &bridges::BridgeStructureMap,
    bridge_surface: &bridges::BridgeSurfaceMap,
    bridge_outlines: &bridge_styles::BridgeOutlineIndex,
    rail_bridge_internal_endpoints: &railways::RailBridgeInternalEndpoints,
    rail_tunnel_points: &mut Vec<(i32, i32)>,
    tunnel_internal_endpoints: &highways::TunnelInternalEndpoints,
    tunnel_portals: &highways::TunnelPortalMap,
    tunnel_cells: &mut Vec<highways::HighwayTunnelCell>,
    part_groups: &PartGroups,
    group_members: &FnvHashMap<u64, Vec<u64>>,
    still_surfaces: &water_areas::StillWaterSurfaces,
    interior_uses: &InteriorUseIndex,
) {
    let signage = editor.signage_enabled();
    match element {
        ProcessedElement::Way(way) => {
            // Fenced solar farms carry barrier=fence, which would shadow the generator below.
            if way.tags.contains_key("barrier")
                && !way.tags.contains_key("building")
                && way.tags.get("power").map(String::as_str) == Some("generator")
            {
                power::generate_power(
                    editor,
                    element,
                    building_footprints,
                    flood_fill_cache,
                    args.timeout.as_ref(),
                );
            }

            if way.tags.contains_key("building") || way.tags.contains_key("building:part") {
                // parts of one building share a style seed so untagged parts match
                let group_seed = part_groups.get(&way.id).copied().unwrap_or(way.id);
                let ctx = BuildingContext {
                    flood_fill_cache,
                    building_passages,
                    road_mask,
                    building_footprints,
                    group_members,
                    interior_uses,
                };
                let anchor =
                    buildings::generate_buildings(editor, way, args, None, None, &ctx, group_seed);
                if signage {
                    signage::generate_building_signage(editor, way, anchor);
                }
            } else if crate::structures::jetbridge::claims(way) {
                // Ahead of the highway branch, or the corridor tag paints asphalt on the apron.
                crate::structures::jetbridge::generate_jet_bridge(editor, way, building_footprints);
            } else if way.tags.contains_key("highway") {
                highways::generate_highways(
                    editor,
                    element,
                    args,
                    highway_connectivity,
                    flood_fill_cache,
                    road_mask,
                    bridge_structures,
                    bridge_surface,
                    tunnel_internal_endpoints,
                    tunnel_portals,
                    tunnel_footprint,
                    tunnel_cells,
                    road_markings,
                );
                if signage {
                    signage::generate_highway_way_signage(editor, way, building_footprints);
                }
            } else if way.tags.contains_key("landuse") {
                landuse::generate_landuse(
                    editor,
                    way,
                    args,
                    flood_fill_cache,
                    building_footprints,
                    road_mask,
                    bridge_surface,
                );
            } else if way.tags.contains_key("natural")
                && way.tags.get("amenity").map(String::as_str) != Some("fountain")
            {
                // natural=water + amenity=fountain falls through to the fountain handler, not filled as water.
                natural::generate_natural(
                    editor,
                    element,
                    args,
                    flood_fill_cache,
                    building_footprints,
                    bridge_surface,
                );
            } else if way.tags.contains_key("amenity") {
                amenities::generate_amenities(editor, element, args, flood_fill_cache, road_mask);
                if signage && way.tags.get("amenity").map(String::as_str) == Some("parking") {
                    signage::generate_parking_signage(editor, way, road_mask);
                }
            } else if way.tags.contains_key("leisure") {
                leisure::generate_leisure(
                    editor,
                    way,
                    args,
                    flood_fill_cache,
                    building_footprints,
                    bridge_surface,
                );
            } else if way.tags.contains_key("barrier") {
                barriers::generate_barriers(editor, element, bridge_surface);
            } else if let Some(val) = way.tags.get("waterway") {
                if val == "dock" || val == "riverbank" {
                    // docks and (legacy) riverbank areas count as water areas
                    water_areas::generate_water_area_from_way(
                        editor,
                        way,
                        big_water_field,
                        road_mask,
                        tunnel_footprint,
                        bridge_surface,
                        still_surfaces,
                    );
                } else {
                    waterways::generate_waterways(editor, way);
                }
            } else if way.tags.contains_key("railway") {
                railways::generate_railways(
                    editor,
                    way,
                    rail_tunnel_points,
                    rail_bridge_internal_endpoints,
                    bridge_outlines,
                    bridge_structures,
                    bridge_surface,
                    road_mask,
                    building_footprints,
                    rail_mask,
                );
            } else if way.tags.contains_key("roller_coaster") {
                railways::generate_roller_coaster(editor, way);
            } else if way.tags.contains_key("aeroway") || way.tags.contains_key("area:aeroway") {
                highways::generate_aeroway(editor, way, args, building_footprints);
            } else if way.tags.get("service").map(String::as_str) == Some("siding") {
                highways::generate_siding(editor, way, bridge_surface);
            } else if way.tags.get("tomb").map(String::as_str) == Some("pyramid") {
                historic::generate_pyramid(editor, way, args, flood_fill_cache);
            } else if way.tags.contains_key("man_made") {
                man_made::generate_man_made(editor, element, args);
            } else if way.tags.contains_key("power") {
                power::generate_power(
                    editor,
                    element,
                    building_footprints,
                    flood_fill_cache,
                    args.timeout.as_ref(),
                );
                if signage {
                    signage::generate_power_signage(editor, way, road_mask);
                }
            } else if way.tags.contains_key("place") {
                landuse::generate_place(editor, way, args, flood_fill_cache);
            }
        }
        ProcessedElement::Node(node) => {
            if signage {
                signage::generate_node_signage(editor, node, building_footprints, road_mask);
            }
            if node.tags.contains_key("door") || node.tags.contains_key("entrance") {
                doors::generate_doors(editor, node);
            } else if node.tags.get("natural").map(String::as_str) == Some("tree") {
                natural::generate_natural(
                    editor,
                    element,
                    args,
                    flood_fill_cache,
                    building_footprints,
                    bridge_surface,
                );
            } else if node.tags.contains_key("amenity") {
                amenities::generate_amenities(editor, element, args, flood_fill_cache, road_mask);
            } else if node.tags.contains_key("barrier") {
                barriers::generate_barrier_nodes(editor, node, bridge_surface);
            } else if node.tags.contains_key("highway") {
                highways::generate_highways(
                    editor,
                    element,
                    args,
                    highway_connectivity,
                    flood_fill_cache,
                    road_mask,
                    bridge_structures,
                    bridge_surface,
                    tunnel_internal_endpoints,
                    tunnel_portals,
                    tunnel_footprint,
                    tunnel_cells,
                    road_markings,
                );
            } else if node.tags.get("aeroway").map(String::as_str) == Some("helipad") {
                highways::generate_helipad_node(editor, node, args, building_footprints);
            } else if node.tags.contains_key("tourism") {
                tourisms::generate_tourisms(editor, node, road_mask);
            } else if node.tags.contains_key("man_made") {
                man_made::generate_man_made_nodes(editor, node, args);
            } else if node.tags.contains_key("power") {
                power::generate_power_nodes(editor, node);
            } else if node.tags.contains_key("historic") {
                historic::generate_historic(editor, node);
            } else if node.tags.contains_key("emergency") {
                emergency::generate_emergency(editor, node);
            } else if node.tags.contains_key("advertising") {
                advertising::generate_advertising(editor, node, road_mask);
            }
        }
        ProcessedElement::Relation(rel) => {
            let is_building_relation = rel.tags.contains_key("building")
                || rel.tags.contains_key("building:part")
                || rel.tags.get("type").map(|t| t.as_str()) == Some("building");
            if is_building_relation {
                let ctx = BuildingContext {
                    flood_fill_cache,
                    building_passages,
                    road_mask,
                    building_footprints,
                    group_members,
                    interior_uses,
                };
                buildings::generate_building_from_relation(editor, rel, args, &ctx, xzbbox);
            } else if rel.tags.contains_key("water")
                || rel
                    .tags
                    .get("natural")
                    .map(|val| val == "water" || val == "bay")
                    .unwrap_or(false)
            {
                water_areas::generate_water_areas_from_relation(
                    editor,
                    rel,
                    xzbbox,
                    big_water_field,
                    road_mask,
                    tunnel_footprint,
                    bridge_surface,
                    still_surfaces,
                );
            } else if rel.tags.contains_key("natural") {
                natural::generate_natural_from_relation(
                    editor,
                    rel,
                    args,
                    flood_fill_cache,
                    building_footprints,
                    bridge_surface,
                );
            } else if rel.tags.contains_key("landuse") {
                landuse::generate_landuse_from_relation(
                    editor,
                    rel,
                    args,
                    flood_fill_cache,
                    building_footprints,
                    road_mask,
                    bridge_surface,
                );
            } else if rel.tags.get("leisure").map(String::as_str) == Some("park") {
                leisure::generate_leisure_from_relation(
                    editor,
                    rel,
                    args,
                    flood_fill_cache,
                    building_footprints,
                    bridge_surface,
                );
            } else if rel.tags.contains_key("man_made") {
                man_made::generate_man_made(editor, element, args);
            }
        }
    }
}

/// Merged-tile count shared by the tile workers and the merging thread.
type TileGate = (Mutex<usize>, Condvar);

/// Stop the tile workers. Set under the gate's lock so a worker between checking the flag
/// and going to sleep cannot miss the wakeup.
fn abort_tile_pipeline(stop: &AtomicBool, gate: &TileGate) {
    let guard = gate.0.lock().unwrap_or_else(|p| p.into_inner());
    stop.store(true, Ordering::Relaxed);
    drop(guard);
    gate.1.notify_all();
}

/// Aborts the tile pipeline when the worker holding it panics: its tile never arrives, so
/// the others would wait for that merge forever.
struct AbortOnPanic<'a> {
    stop: &'a AtomicBool,
    gate: &'a TileGate,
}

impl Drop for AbortOnPanic<'_> {
    fn drop(&mut self) {
        if std::thread::panicking() {
            abort_tile_pipeline(self.stop, self.gate);
        }
    }
}

/// Whether to stream regions to disk (lower peak RAM) for `num_regions` regions. Auto-enabled
/// when the estimated resident world would crowd available RAM; trades some time for RAM, output
/// unchanged (3D models + subways preserved). `ARNIS_STREAM_TO_DISK=1/0` overrides; constants tunable.
fn should_stream_to_disk(num_regions: usize, available_mb: u64, fillground: bool) -> bool {
    match std::env::var("ARNIS_STREAM_TO_DISK").ok().as_deref() {
        Some("1") => return true,
        Some("0") => return false,
        _ => {}
    }
    const BASE_MB: u64 = 500;
    let est_peak_mb =
        BASE_MB + crate::world_editor::per_region_estimate_mb(fillground) * num_regions as u64;

    // Stream once the estimate would use >55% of available RAM (unknown memory -> fast path).
    available_mb > 0 && est_peak_mb * 100 > available_mb * 55
}

/// Free RAM in MB.
fn available_memory_mb() -> u64 {
    let mut sys = sysinfo::System::new();
    sys.refresh_memory();
    sys.available_memory() / (1024 * 1024)
}

/// Generate world with explicit format options (used by GUI for Bedrock support)
#[allow(clippy::too_many_arguments)]
pub fn generate_world_with_options(
    mut elements: Vec<ProcessedElement>,
    xzbbox: XZBBox,
    llbbox: LLBBox,
    ground: Ground,
    args: &Args,
    options: GenerationOptions,
    outline_suppression: OutlineSuppression,
    part_groups: PartGroups,
) -> Result<PathBuf, String> {
    let output_path = options.path.clone();
    let world_format = options.format;
    let generation_start = args.benchmark.then(std::time::Instant::now);
    // World-wide extras (map item, branding, world settings) belong to the
    // first area of a One World.
    let one_world = args.one_world_run.as_ref();
    let extending = one_world.is_some_and(|run| run.extending);
    let clip_bbox = crate::projection::ProjectionSpec::from_args(args).clip_bbox(&xzbbox);

    // Before anything reads a footprint: nothing is built on a runway.
    let dropped = highways::drop_buildings_on_aircraft_pavement(&mut elements, args.scale);
    if dropped > 0 {
        println!("  Skipped {dropped} building(s) on runways, taxiways and aprons");
    }

    // Create editor with appropriate format
    let mut editor: WorldEditor = if options.format == WorldFormat::LuantiWorld {
        WorldEditor::new_luanti(
            options.path,
            &xzbbox,
            llbbox,
            options
                .luanti_game
                .unwrap_or(crate::luanti_block_map::LuantiGame::Mineclonia),
            options.level_name.clone(),
            options.spawn_point,
            options.ground_level,
        )
    } else {
        WorldEditor::new_with_format_and_name(
            options.path,
            &xzbbox,
            llbbox,
            options.format,
            options.level_name.clone(),
            options.spawn_point,
            args.disable_height_limit,
        )
    };
    // Voxy renders from stored per-voxel light, so an unlit LOD cache would be a
    // black horizon. The toggle implies baked lighting rather than silently
    // producing that.
    let wants_voxy = args.voxy_lod && world_format == WorldFormat::JavaAnvil;
    editor.set_bake_lighting(args.bake_lighting || wants_voxy);
    let void_world =
        world_format == WorldFormat::JavaAnvil && args.world_type == crate::args::WorldType::Void;
    editor.set_void_world(void_world);
    if void_world && !extending {
        // A world made by `create_new_world` starts with the flat template region. The area
        // rewrites it when it reaches that region; one it misses would stay a grass square.
        crate::world_utils::remove_untouched_template_region(&output_path);
    }
    editor.set_place_schematics(args.use_3d);
    editor.set_game_settings(args.gamemode, args.world_time);
    editor.set_start_with_map(args.map_item);
    editor.set_map_decals(world_format == WorldFormat::JavaAnvil);
    editor.set_projection_info(&args.projection.to_string(), args.scale);
    if let Some(run) = one_world {
        editor.set_merge_into_existing(crate::world_utils::WorldLayout::of(&run.world_dir));
        editor.set_climate_anchor(run.origin_lat, run.origin_lon);
        // metadata.json describes the whole world, not this area alone.
        if let Ok(Some(manifest)) = crate::one_world::Manifest::load(&run.world_dir) {
            let union = match manifest.extent() {
                Some(ext) => XZBBox::rect_from_min_max(
                    ext.min_x().min(xzbbox.min_x()),
                    ext.min_z().min(xzbbox.min_z()),
                    ext.max_x().max(xzbbox.max_x()),
                    ext.max_z().max(xzbbox.max_z()),
                )
                .unwrap_or_else(|_| xzbbox.clone()),
                None => xzbbox.clone(),
            };
            if let Ok(ll) = crate::projection::llbbox_for_rect(&manifest.projection(), &union) {
                editor.set_metadata_extent(union, ll);
            }
        }
    }

    // Facade textures: loaded and projected onto the buildings before any tile
    // thread starts, so the wall builder only reads. A folder given on the
    // command line is loaded as it always was, which is how the Python review
    // loop works; otherwise the pipeline that was started as soon as the bbox
    // was known is collected here, at the first point that cannot go on without
    // it, and its export in the cache is what gets loaded.
    let mapillary_start = args.benchmark.then(std::time::Instant::now);
    let pipeline_export = options.facades.join();
    if let Some(t) = mapillary_start {
        eprintln!("[BENCHMARK] mapillary_join_ms={}", t.elapsed().as_millis());
    }
    // The photo panels are Java entities carried by a resource pack. The blocks
    // are ordinary blocks and work on every format, so the feature stays on and
    // says what it dropped rather than dropping it in silence. The CLI refuses
    // the combination outright in `validate_args`; this catches the GUI, which
    // builds `Args` directly.
    if world_format != WorldFormat::JavaAnvil
        && args.mapillary_facade_mode.places_displays()
        && args.mapillary_facades_wanted()
    {
        let other = if world_format == WorldFormat::LuantiWorld {
            "Luanti"
        } else {
            "Bedrock"
        };
        eprintln!(
            "{} Facade photo panels need a Java world; building the {other} facade blocks only.",
            "Warning:".yellow().bold()
        );
        emit_gui_progress_update(MESSAGE_ONLY, "Facades: photo panels need a Java world");
    }
    // A folder is the review loop's override, but an explicit "off" still means
    // off: the GUI toggle sends Some(false), and a `--mapillary-facades-dir`
    // given beside it used to build facades anyway. Some(None) from the CLI
    // keeps working. The GUI has no folder of its own any more, so on that side
    // this is always the pipeline's own export.
    let folder = if args.mapillary_facades == Some(false) {
        None
    } else {
        args.mapillary_facades_dir
            .as_deref()
            .or(pipeline_export.as_deref())
    };
    match folder {
        Some(dir) => crate::mapillary::facades::install(dir, &elements, args, &xzbbox),
        None => crate::mapillary::facades::clear(),
    }
    // Panel candidates collect in a process-wide registry while the buildings
    // are built, are hung before the world is saved and become a pack after
    // it; a run without them must not inherit the previous world's.
    //
    // Preset facades hang on the same display entities and write into the same
    // resource pack, so the display registry is on when either source is. The
    // Mapillary side still decides for itself whether to collect anything: its
    // `collect` also asks the facade store, which is off unless the export
    // asked for the photos mode.
    let java = world_format == WorldFormat::JavaAnvil;
    // The atlas the panels are budgeted against, before anything measures one.
    // Both sources read it, so it is set whichever of them is running.
    crate::mapillary::atlas::set_atlas_side(args.facade_detail.atlas_side());
    crate::building_facades::reset(
        args.building_facades && java,
        args.building_facades_dir.as_deref(),
        args.facade_px,
        args.scale,
    );
    // A panel hangs in the cell in front of its wall, and nothing is written
    // outside the world, so the outermost ring of blocks can carry none. Said
    // after the reset, which clears it, and before any building is built: a
    // wall that cannot be photographed must keep its windows.
    crate::building_facades::set_world_extent(&xzbbox);
    crate::mapillary::displays::reset(
        crate::mapillary::facades::displays_enabled() || crate::building_facades::enabled(),
        args.facade_px,
    );

    // Signage pre-pass: every decal the world needs gets its map id now, so the tile
    // threads only read the registry. Java only; other formats keep banner fallbacks.
    let signage_start = args.benchmark.then(std::time::Instant::now);
    // A One World continues after its last map id.
    let wants_map_item = args.map_item && world_format == WorldFormat::JavaAnvil && !extending;
    let place_branding = world_format == WorldFormat::JavaAnvil && !extending;
    let first_decal_id = if one_world.is_some() {
        let layout = crate::world_utils::WorldLayout::of(&output_path);
        let next = crate::map_item::next_map_id(&layout.maps_dir(&output_path));
        next + if wants_map_item {
            2
        } else if place_branding {
            1
        } else {
            0
        }
    } else {
        crate::decals::registry::DecalRegistry::FIRST_ID
    };
    let signage_ctx: Option<Arc<signage::SignageContext>> = (world_format
        == WorldFormat::JavaAnvil)
        .then(|| signage::build_context(&elements, args, llbbox, &xzbbox, first_decal_id))
        .flatten()
        .map(Arc::new);
    if let (Some(t), Some(_)) = (signage_start, signage_ctx.as_ref()) {
        eprintln!("[BENCHMARK] signage_prepass_ms={}", t.elapsed().as_millis());
    }
    if let Some(ctx) = &signage_ctx {
        editor.set_signage(Arc::clone(ctx));
        println!(
            "  Signage: {} distinct decals ({} map tiles), {} named intersections",
            ctx.registry.len(),
            ctx.registry.tile_count(),
            ctx.intersections.len()
        );
    }
    let wants_local_maps = signage_ctx.as_ref().is_some_and(|c| {
        c.registry
            .iter()
            .any(|(k, _)| matches!(k, crate::decals::DecalKey::LocalMap { .. }))
    });

    // Map preview accumulator, fed as regions are saved/flushed (Java/Bedrock).
    let preview_epoch = map_preview::begin_preview_epoch();
    // The map item consumes the same accumulator, so either feature enables it.
    // Without the PNG the map item only needs 128px, so a small frame suffices
    // (512 = 4x supersampling) instead of the full-resolution preview buffer.
    let wants_png = args.map_preview && world_format != WorldFormat::LuantiWorld;
    let preview = (wants_png || wants_map_item || wants_local_maps).then(|| {
        Arc::new(if wants_png && one_world.is_some() {
            // Every area of a One World is sent to the map overlay at once.
            PreviewAccumulator::new_capped(&xzbbox, 2048)
        } else if wants_png {
            PreviewAccumulator::new(&xzbbox)
        } else if wants_local_maps {
            // "You are here" boards crop this, so give them a little more resolution.
            PreviewAccumulator::new_capped(&xzbbox, 1024)
        } else {
            PreviewAccumulator::new_capped(&xzbbox, 512)
        })
    });
    if let Some(p) = &preview {
        editor.set_preview(Arc::clone(p));
    }

    // Voxy LOD cache, fed alongside the region files as they are written.
    if wants_voxy {
        match crate::voxy::VoxyWriter::create(&output_path) {
            Ok(Some(writer)) => editor.set_voxy(Arc::new(writer)),
            Ok(None) => eprintln!(
                "Skipping the Voxy LOD cache: could not read the world seed from level.dat."
            ),
            Err(e) => eprintln!("Skipping the Voxy LOD cache: {e}"),
        }
    }

    if let (Some(run), Some(affine)) = (one_world, ground.elevation_affine()) {
        crate::one_world::remember_elevation(run, affine)?;
    }
    if let Some(run) = one_world.filter(|run| run.replaced_chunks > 0) {
        emit_gui_progress_update(
            MESSAGE_ONLY,
            &format!("Replacing {} existing chunks", run.replaced_chunks),
        );
    }

    let ground = Arc::new(ground);
    let mut bench = crate::bench::Bench::new(args.benchmark);
    crate::world_editor::reset_section_counters(args.benchmark);
    // Materialize the lazy water-blend mask now, before world memory peaks.
    ground.warm_water_blend();
    bench.mark("ground_warm");
    // Load the schematic tree pack once (None keeps procedural trees); shared with tile editors.
    // Uses the area's floor, not args: the montane check measures blocks above it, and the
    // base sinks when the relief needs the extended floor. Its blocks-per-metre turns those
    // blocks back into metres, which compression makes far smaller than args.scale.
    let tree_pack = crate::trees::tree_pack::load(
        args,
        llbbox,
        args.scale,
        crate::ground::area_floor_for(&ground, args),
        ground.blocks_per_meter(),
        ground.ecoregion_map(),
    )
    .map(Arc::new);
    bench.reset();

    // Per-cell water depth field from the LC_WATER mask; empty without land cover.
    let big_water_field = crate::water_depth::compute_big_water_field(&ground, &xzbbox);
    // Resolved once here: a body spanning many tiles must not be measured per tile.
    let still_surfaces = water_areas::prescan_still_surfaces(&elements, &ground, &xzbbox);

    println!("{} Processing data...", "[4/7]".bold());
    emit_gui_progress_update(19.5, "Processing data...");

    // Build highway connectivity map once before processing
    let highway_connectivity = highways::build_highway_connectivity_map(&elements);
    let road_markings = road_markings::RoadMarkingIndex::build(
        &elements,
        args.scale,
        crate::decals::region::SignRegion::detect(
            (llbbox.min().lat() + llbbox.max().lat()) / 2.0,
            (llbbox.min().lng() + llbbox.max().lng()) / 2.0,
        ),
    );

    // Collect underground railway centerline points for post-ground-fill air carving (phase 2).
    let mut rail_tunnel_points: Vec<(i32, i32)> = Vec::new();
    let mut tunnel_cells: Vec<highways::HighwayTunnelCell> = Vec::new();

    // Set ground reference in the editor to enable elevation-aware block placement
    editor.set_ground(Arc::clone(&ground));
    if let Some(ref tp) = tree_pack {
        editor.set_tree_pack(Arc::clone(tp));
    }

    // Nested areas render correctly only if the smallest one writes first.
    sort_ground_fill_areas(&mut elements);

    // Pre-compute all flood fills in parallel for better CPU utilization
    let mut flood_fill_cache = FloodFillCache::precompute(&elements, args.timeout.as_ref());

    // Collect building footprints to prevent trees from spawning inside buildings
    // Uses a memory-efficient bitmap (~1 bit per coordinate) instead of a HashSet (~24 bytes per coordinate)
    let building_footprints = flood_fill_cache.collect_building_footprints(&elements, &xzbbox);

    // Tenants and surrounding areas per building, for interiors furnished by use.
    let interior_uses = if args.interior {
        InteriorUseIndex::build(&elements, &clip_bbox)
    } else {
        InteriorUseIndex::default()
    };

    // Collect coordinates covered by tunnel=building_passage highways so that
    // building generation can cut ground-level openings through walls and floors.
    let building_passages =
        highways::collect_building_passage_coords(&elements, &xzbbox, args.scale);

    // Pre-build a bitmap of every (x, z) block coordinate covered by a rendered
    // road or path surface. Uses the same Bresenham + block_range geometry as
    // generate_highways_internal, so the bitmap is a 1:1 match of what gets placed.
    // Amenity processors use this for O(1) nearest-road-block lookups.
    let road_mask = Arc::new(highways::collect_road_surface_coords(
        &elements, &editor, &xzbbox, args.scale,
    ));

    // Roads plus every paved area footprint, resolved before anything is placed so
    // vegetation passes can tell a man-made surface from natural ground. With no
    // paved area in the bbox the road mask already is the answer, so it is shared
    // instead of copied: one bitmap is a bit per world column and that adds up on
    // a several-hundred-square-kilometre run.
    let sealed_surface = match flood_fill_cache.collect_sealed_surfaces(&elements, &road_mask) {
        Some(mask) => Arc::new(mask),
        None => Arc::clone(&road_mask),
    };
    editor.set_sealed_surface(Arc::clone(&sealed_surface));

    let mapped_trunks = Arc::new(crate::trees::mapped::MappedTrunks::collect(
        &elements, args.scale,
    ));
    editor.set_mapped_trunks(Arc::clone(&mapped_trunks));

    // Sibling index keyed on the hint-free seed: parts of one building can
    // carry different packed style-hint bits and must still find each other.
    let group_members: FnvHashMap<u64, Vec<u64>> = {
        let mut map: FnvHashMap<u64, Vec<u64>> = FnvHashMap::default();
        for (&way_id, &seed) in part_groups.iter() {
            map.entry(crate::osm_parser::seed_without_hint(seed))
                .or_default()
                .push(way_id);
        }
        map.retain(|_, v| v.len() >= 2);
        for v in map.values_mut() {
            v.sort_unstable();
        }
        map
    };

    let bridge_outlines =
        crate::element_processing::bridge_styles::BridgeOutlineIndex::build(&elements);
    let bridge_structures =
        bridges::BridgeStructureMap::build(&elements, &editor, &bridge_outlines, args.scale);
    let bridge_surface =
        bridges::BridgeSurfaceMap::build(&elements, &bridge_structures, args.scale);

    let rail_bridge_internal_endpoints =
        railways::collect_rail_bridge_internal_endpoints(&elements);

    // Rail centerlines, used to keep catenary masts off neighbouring tracks.
    let rail_mask = railways::collect_at_grade_rail_mask(&elements, &xzbbox);

    let tunnel_internal_endpoints = highways::collect_tunnel_internal_endpoints(&elements, &xzbbox);

    // Tunnel bore footprints, so the water depth-carve and vegetation stay off them.
    let mut tunnel_footprint = highways::collect_tunnel_footprint(
        &elements,
        &editor,
        &tunnel_internal_endpoints,
        &xzbbox,
        args.scale,
    );
    railways::add_tunnel_footprint(&elements, &xzbbox, &mut tunnel_footprint);
    let tunnel_portals = highways::collect_tunnel_portals(
        &elements,
        &editor,
        &bridge_structures,
        &tunnel_internal_endpoints,
        args.scale,
    );

    // Resolved before the 3D archetypes so they never claim a landmark's element.
    let landmarks = crate::landmarks::prescan(&elements, &xzbbox, llbbox, args);

    // Runway segments merge across ways, so planes prescan here and stamp after the merge.
    let planes = crate::structures::plane::prescan(&elements, args);

    // 3D model pipeline pre-scan: elements rendered as 3D models instead of
    // voxels are recorded here and skipped by the element loop below.
    let models_3d_pipeline = args.use_3d.then(|| {
        crate::models_3d::Models3dPipeline::prescan(&elements, args, landmarks.suppressed())
    });
    let empty_suppressed: HashSet<(&'static str, u64)> = HashSet::new();
    let models_3d_suppressed: &HashSet<(&'static str, u64)> = models_3d_pipeline
        .as_ref()
        .map(|p| p.suppressed())
        .unwrap_or(&empty_suppressed);
    // Still honoured without a 3D pipeline; the flag keeps this a bool test.
    let landmark_suppressed: &HashSet<(&'static str, u64)> = landmarks.suppressed();
    let has_landmarks = !landmark_suppressed.is_empty();

    bench.mark("precompute");

    println!("{} Generating area...", "[5/7]".bold());
    emit_gui_progress_update(20.0, "Generating area...");

    // Stream-to-disk eviction state (populated in the parallel branch below).
    let mut eviction_active = false;
    let hash_check = std::env::var_os("ARNIS_BLOCK_HASH").is_some();
    let mut hash_acc: u64 = 0;
    let mut real_regions: HashSet<(i32, i32)> = HashSet::new();
    let mut evicted_regions: HashSet<(i32, i32)> = HashSet::new();
    // Background writer for eviction; None unless eviction is active.
    let mut flush_worker: Option<FlushWorker> = None;
    // The spawn's region is kept resident (never evicted) so the finalize map-item lands on
    // real ground. Resolved exactly like the finalize call; spawn doesn't change during generation.
    // An explicit spawn wins over level.dat, which the CLI only updates after generation.
    let spawn_region: Option<(i32, i32)> = place_branding.then(|| {
        let (sx, sz) = options
            .spawn_point
            .or_else(|| crate::map_item::read_spawn_xz(&output_path))
            .unwrap_or((xzbbox.min_x() + 1, xzbbox.min_z() + 1));
        (sx >> 9, sz >> 9)
    });

    // Decide between sequential and parallel processing based on world size.
    // Tile subdivision is aligned to 512-block Minecraft region boundaries.
    let tiles = tile::create_tiles(&xzbbox, tile::DEFAULT_TILE_SIZE);

    // Tile editors are created as JavaAnvil (WorldEditor::new), so their
    // format-dependent block-entity schema (banners) only matches Java output.
    // Restrict the parallel tile path to Java; Bedrock/Luanti large worlds use
    // the sequential path (correct, just not tile-parallel).
    let use_parallel_tiles = tiles.len() >= 3 && matches!(world_format, WorldFormat::JavaAnvil);

    if use_parallel_tiles {
        // Large area: process tiles in parallel using rayon.
        // Each tile gets its own WorldEditor with an expanded bounding box (64-block
        // halo) so that elements whose centroid falls inside the tile can render blocks
        // that extend slightly beyond the strict tile boundary (e.g., wide buildings).
        // After each batch finishes, their WorldToModify results are merged back into the
        // main editor using authoritative bounds (strict tile area overwrites; halo
        // writes only if the target position is still AIR).
        //
        // Tiles are processed in batches (one tile per rayon thread) to cap peak memory.
        // Without batching, all tile WorldToModify structs would be in memory at once,
        // which can exceed RAM for large areas and cause disk thrashing.
        let tile_batch_size = rayon::current_num_threads().max(1);
        println!(
            "  Processing {} tiles across {tile_batch_size} threads...",
            tiles.len()
        );

        let tile_assignments = tile::assign_elements_to_tiles(&elements, &tiles, args.scale);

        let (tile_fill_ids, fill_readers) = tile_fill_readers(
            &tile_assignments,
            &elements,
            &part_groups,
            &group_members,
            |id| flood_fill_cache.contains(id),
        );

        // Stream-to-disk: flush+evict each region once its owner + 8 neighbour tiles merge,
        // auto-enabled when the resident world would crowd available RAM. Java only; 3D models
        // are kept via region deferral.
        // Read at the decision point: the precompute above allocates heavily, and an
        // optimistic figure would skip streaming in exactly the runs that need it.
        let available_mb = available_memory_mb();
        eviction_active = matches!(world_format, WorldFormat::JavaAnvil)
            && should_stream_to_disk(tiles.len(), available_mb, args.fillground);

        // Regions any 3D placement may write to: kept resident (not evicted in-loop)
        // so the post-merge placement pass lands in RAM, then flushed at finalize.
        let model_regions: HashSet<(i32, i32)> = if eviction_active {
            let mut regions: HashSet<(i32, i32)> = models_3d_pipeline
                .as_ref()
                .map(|p| p.deferred_region_keys(args.scale))
                .unwrap_or_default();
            regions.extend(landmarks.deferred_region_keys(args.scale));
            regions.extend(planes.deferred_region_keys());
            regions
        } else {
            HashSet::new()
        };

        if eviction_active {
            let (flush_threads, flush_queue) = crate::world_editor::flush_pool_params(
                tile_batch_size,
                available_mb,
                args.fillground,
            );
            if args.benchmark {
                eprintln!("[BENCHMARK] flush_threads={flush_threads} flush_queue={flush_queue}");
            }
            flush_worker = Some(FlushWorker::spawn(
                editor.region_write_ctx(),
                flush_queue,
                flush_threads,
                args.benchmark,
            ));
        }

        let mut indexed_tiles: Vec<(usize, &tile::TileBounds)> = tiles.iter().enumerate().collect();
        // ARNIS_NO_BAND forces LPT order even under eviction (debug: isolates ordering effects).
        let band = eviction_active && std::env::var_os("ARNIS_NO_BAND").is_none();
        if band {
            // Row-major bands (LPT within a row) so the seal frontier sweeps top-to-bottom.
            indexed_tiles.sort_by(|a, b| {
                let za = a.1.min_z >> 9;
                let zb = b.1.min_z >> 9;
                za.cmp(&zb).then_with(|| {
                    tile_assignments[b.0]
                        .len()
                        .cmp(&tile_assignments[a.0].len())
                })
            });
        } else {
            // LPT scheduling: dense tiles first so a straggler doesn't block the pipeline.
            indexed_tiles.sort_by(|a, b| {
                tile_assignments[b.0]
                    .len()
                    .cmp(&tile_assignments[a.0].len())
            });
        }

        let region_of_tile: Vec<(i32, i32)> =
            tiles.iter().map(|t| (t.min_x >> 9, t.min_z >> 9)).collect();
        real_regions = region_of_tile.iter().copied().collect();
        // remaining[R] = 1 (owner) + count of R's in-grid region neighbours; R is
        // flushable when this reaches 0 (owner + all neighbour tiles merged).
        let mut remaining: HashMap<(i32, i32), u32> = HashMap::new();
        if eviction_active {
            for &r in &real_regions {
                let mut c = 1u32;
                for dz in -1..=1 {
                    for dx in -1..=1 {
                        if (dx, dz) != (0, 0) && real_regions.contains(&(r.0 + dx, r.1 + dz)) {
                            c += 1;
                        }
                    }
                }
                remaining.insert(r, c);
            }
        }

        let mut merge_dur = std::time::Duration::ZERO;
        let total_tiles = indexed_tiles.len().max(1);
        // Counted per tile, not per element: measured per-tile cost is near flat
        // (the area work dominates), so tile count tracks time despite LPT order.
        let mut tiles_merged = 0usize;
        let mut last_emitted_pct = 20.0_f64;
        // Placement-side ticks so the bar moves before the first tile merges.
        let tiles_placed = std::sync::atomic::AtomicUsize::new(0);
        // Phase 1: build one tile on its own editor.
        let process_tile = |&(tile_idx, tile_bounds): &(usize, &tile::TileBounds)| {
            // max_* are exclusive; rect_from_min_max treats max as inclusive,
            // so subtract 1. Clamp to the world bbox so edge-tile halos don't
            // extend past world bounds.
            let tile_xzbbox = XZBBox::rect_from_min_max(
                (tile_bounds.min_x - tile::TILE_EDITOR_HALO).max(xzbbox.min_x()),
                (tile_bounds.min_z - tile::TILE_EDITOR_HALO).max(xzbbox.min_z()),
                (tile_bounds.max_x - 1 + tile::TILE_EDITOR_HALO).min(xzbbox.max_x()),
                (tile_bounds.max_z - 1 + tile::TILE_EDITOR_HALO).min(xzbbox.max_z()),
            )
            .expect("Failed to create tile XZBBox");

            let mut tile_editor = WorldEditor::new(PathBuf::new(), &tile_xzbbox, llbbox);
            tile_editor.set_ground(Arc::clone(&ground));
            tile_editor.set_ground_origin(xzbbox.min_x(), xzbbox.min_z());
            // Ground generation runs on tile editors, so they need the real scale.
            tile_editor.set_projection_info(&args.projection.to_string(), args.scale);
            tile_editor.set_place_schematics(args.use_3d);
            tile_editor.set_map_decals(world_format == WorldFormat::JavaAnvil);
            if let Some(ref tp) = tree_pack {
                tile_editor.set_tree_pack(Arc::clone(tp));
            }
            tile_editor.set_sealed_surface(Arc::clone(&sealed_surface));
            tile_editor.set_mapped_trunks(Arc::clone(&mapped_trunks));
            if let Some(ctx) = &signage_ctx {
                tile_editor.set_signage(Arc::clone(ctx));
            }
            tile_editor.set_strict_bounds(
                tile_bounds.min_x,
                tile_bounds.min_z,
                tile_bounds.max_x - 1,
                tile_bounds.max_z - 1,
            );

            let mut tile_rail_tunnel_points: Vec<(i32, i32)> = Vec::new();
            let mut tile_tunnel_cells: Vec<highways::HighwayTunnelCell> = Vec::new();

            for &elem_idx in &tile_assignments[tile_idx] {
                let element = &elements[elem_idx];
                let suppression_key = (element.kind(), element.id());
                if models_3d_suppressed.contains(&suppression_key)
                    || (has_landmarks && landmark_suppressed.contains(&suppression_key))
                    || outline_suppression.contains(&suppression_key)
                {
                    continue;
                }
                process_element(
                    &mut tile_editor,
                    element,
                    args,
                    &highway_connectivity,
                    &road_markings,
                    &flood_fill_cache,
                    &building_footprints,
                    &building_passages,
                    &road_mask,
                    &rail_mask,
                    &tunnel_footprint,
                    // World bbox (not tile) for relation/area ring clipping: clipping to
                    // the tile can drop a relation whose ring fails to close. The tile
                    // editor still bounds the actual writes.
                    &clip_bbox,
                    &big_water_field,
                    &bridge_structures,
                    &bridge_surface,
                    &bridge_outlines,
                    &rail_bridge_internal_endpoints,
                    &mut tile_rail_tunnel_points,
                    &tunnel_internal_endpoints,
                    &tunnel_portals,
                    &mut tile_tunnel_cells,
                    &part_groups,
                    &group_members,
                    &still_surfaces,
                    &interior_uses,
                );
            }

            release_tile_fills(&tile_fill_ids[tile_idx], &fill_readers, &flood_fill_cache);

            // Per-tile ground + ore + ESA-water over strict bounds (parallel);
            // neighbour reads use the editor halo from intersection assignment.
            let g_min_x = tile_bounds.min_x.max(xzbbox.min_x());
            let g_max_x = (tile_bounds.max_x - 1).min(xzbbox.max_x());
            let g_min_z = tile_bounds.min_z.max(xzbbox.min_z());
            let g_max_z = (tile_bounds.max_z - 1).min(xzbbox.max_z());
            ground_generation::generate_ground_region(
                &mut tile_editor,
                ground.as_ref(),
                args,
                &xzbbox,
                &building_footprints,
                &tunnel_footprint,
                &bridge_surface,
                g_min_x,
                g_max_x,
                g_min_z,
                g_max_z,
                false,
            );
            // Caves bring their own vanilla ore table, placed after the carve so no
            // vein hangs in a cave; the plain veins only fill caveless ground.
            if args.caves {
                crate::caves::carve_region(
                    &mut tile_editor,
                    args,
                    &xzbbox,
                    g_min_x,
                    g_max_x,
                    g_min_z,
                    g_max_z,
                );
            } else if args.fillground {
                crate::ore_generation::generate_ores_region(
                    &mut tile_editor,
                    g_min_x,
                    g_max_x,
                    g_min_z,
                    g_max_z,
                    false,
                );
            }
            crate::water_depth::carve_lc_water_region(
                &mut tile_editor,
                ground.as_ref(),
                &xzbbox,
                &big_water_field,
                &road_mask,
                &tunnel_footprint,
                &bridge_surface,
                g_min_x,
                g_max_x,
                g_min_z,
                g_max_z,
            );

            // Under eviction the post-merge rail-tunnel carve can't run (regions get freed),
            // so carve in-tile now, after ground/fill so the interior isn't refilled.
            if eviction_active {
                railways::carve_rail_tunnel_interior(&mut tile_editor, &tile_rail_tunnel_points);
                highways::carve_highway_tunnel_interior(&mut tile_editor, &tile_tunnel_cells);
            }
            // Seal floating water/lava last: the water-depth carve and the tunnel carves
            // above can each undercut a water body over a cave. Under eviction this tile
            // flushes soon, so it happens here; otherwise once after the merge.
            if args.caves && eviction_active {
                crate::caves::seal_floating_fluid_region(
                    &mut tile_editor,
                    g_min_x,
                    g_max_x,
                    g_min_z,
                    g_max_z,
                );
            }

            let tile_road_overrides = tile_editor.take_road_surface_overrides();

            // Emit on whole-percent steps only; the monotonic clamp
            // reconciles these with the merge-side emits.
            let placed = tiles_placed.fetch_add(1, std::sync::atomic::Ordering::Relaxed) + 1;
            if (placed * 50 / total_tiles) != ((placed - 1) * 50 / total_tiles) {
                let pct = 20.0 + (placed as f64 / total_tiles as f64) * 50.0;
                emit_gui_progress_update_ex(pct, "Generating area...", eviction_active);
            }

            (
                tile_idx,
                tile_editor.into_world(),
                tile_rail_tunnel_points,
                tile_tunnel_cells,
                tile_road_overrides,
            )
        };

        // Tiles merge in list order: outside its own bounds a tile only fills air, so the
        // first writer wins there, and the flush bookkeeping counts merges. Workers take
        // tiles in that order and run at most `tile_batch_size` ahead of the merge, which
        // is what one batch used to hold at once, so the peak stays where it was. The merge
        // then runs beside the placement instead of idling every thread at each batch end.
        let window = tile_batch_size;
        let next_tile = AtomicUsize::new(0);
        let stop = AtomicBool::new(false);
        let gate: TileGate = (Mutex::new(0), Condvar::new());
        let place_start = std::time::Instant::now();
        std::thread::scope(|scope| -> Result<(), String> {
            let (tx, rx) = std::sync::mpsc::channel();
            for _ in 0..window.min(indexed_tiles.len()) {
                let tx = tx.clone();
                let (process_tile, indexed_tiles) = (&process_tile, &indexed_tiles);
                let (next_tile, stop, gate) = (&next_tile, &stop, &gate);
                scope.spawn(move || {
                    // A worker that panics must not leave the rest waiting on its tile.
                    let _abort = AbortOnPanic { stop, gate };
                    loop {
                        let i = next_tile.fetch_add(1, Ordering::Relaxed);
                        let Some(entry) = indexed_tiles.get(i) else {
                            break;
                        };
                        let mut merged = gate.0.lock().unwrap_or_else(|p| p.into_inner());
                        while i >= *merged + window && !stop.load(Ordering::Relaxed) {
                            merged = gate.1.wait(merged).unwrap_or_else(|p| p.into_inner());
                        }
                        drop(merged);
                        if stop.load(Ordering::Relaxed)
                            || tx.send((i, process_tile(entry))).is_err()
                        {
                            break;
                        }
                    }
                });
            }
            drop(tx);
            // Likewise the merge: a panic here would leave the workers parked on the window.
            let _abort = AbortOnPanic {
                stop: &stop,
                gate: &gate,
            };

            // Phase 2: merge into the main editor in list order as tiles arrive (sequential).
            let mut pending = std::collections::BTreeMap::new();
            let mut next_merge = 0usize;
            let merged = (|| -> Result<(), String> {
                for (i, result) in &rx {
                    pending.insert(i, result);
                    while let Some((
                        tile_idx,
                        tile_world,
                        tile_rail_tunnel_points,
                        tile_tunnel_cells,
                        tile_road_overrides,
                    )) = pending.remove(&next_merge)
                    {
                        let merge_start = std::time::Instant::now();
                        editor.merge_world(
                            tile_world,
                            tiles[tile_idx].min_x,
                            tiles[tile_idx].min_z,
                            tiles[tile_idx].max_x - 1,
                            tiles[tile_idx].max_z - 1,
                        );
                        // Carry road-surface overrides to the main editor so the post-merge 3D-model
                        // pass stays road-aware. Under eviction keep only the deferred 3D regions'
                        // overrides (the rest are evicted; this caps the extra resident RAM).
                        if eviction_active {
                            editor.merge_road_surface_overrides_in_regions(
                                tile_road_overrides,
                                &model_regions,
                            );
                        } else {
                            editor.merge_road_surface_overrides(tile_road_overrides);
                        }

                        if eviction_active {
                            // This tile contributes to its own region and its 8 neighbours;
                            // flush each non-deferred region whose contributors are all merged.
                            // (Rail tunnels are carved in-tile above, so they don't defer regions.)
                            let rt = region_of_tile[tile_idx];
                            for dz in -1..=1 {
                                for dx in -1..=1 {
                                    let d = (rt.0 + dx, rt.1 + dz);
                                    if let Some(c) = remaining.get_mut(&d) {
                                        *c -= 1;
                                        if *c == 0
                                            && !evicted_regions.contains(&d)
                                            && !model_regions.contains(&d)
                                            && Some(d) != spawn_region
                                        {
                                            if hash_check {
                                                hash_acc = hash_acc.wrapping_add(
                                                    editor.region_content_hash(d.0, d.1),
                                                );
                                            }
                                            // Facade panels check the region's final blocks
                                            // and must be in before it leaves memory.
                                            crate::mapillary::displays::flush_region(
                                                &mut editor,
                                                d.0,
                                                d.1,
                                            );
                                            crate::building_facades::flush_region(
                                                &mut editor,
                                                d.0,
                                                d.1,
                                            );
                                            if let Some(w) = flush_worker.as_ref() {
                                                editor.flush_region_via(w, d.0, d.1)?;
                                            }
                                            evicted_regions.insert(d);
                                        }
                                    }
                                }
                            }
                        }

                        // Under eviction the in-tile carve already ran, and nothing reads
                        // these afterwards, so don't retain the points or the cells.
                        if !eviction_active {
                            rail_tunnel_points.extend(tile_rail_tunnel_points);
                            tunnel_cells.extend(tile_tunnel_cells);
                        }

                        // Step 20%->70% per merged tile, throttled to whole-percent steps.
                        tiles_merged += 1;
                        let pct = 20.0 + (tiles_merged as f64 / total_tiles as f64) * 50.0;
                        if pct - last_emitted_pct >= 1.0 {
                            emit_gui_progress_update_ex(pct, "Generating area...", eviction_active);
                            last_emitted_pct = pct;
                        }
                        merge_dur += merge_start.elapsed();

                        next_merge += 1;
                        *gate.0.lock().unwrap_or_else(|p| p.into_inner()) = next_merge;
                        gate.1.notify_all();
                    }
                }
                Ok(())
            })();
            if merged.is_err() {
                abort_tile_pipeline(&stop, &gate);
            }
            merged
        })?;
        let place_dur = place_start.elapsed();
        bench.report("element_placement", place_dur);
        bench.report("tile_merge", merge_dur);
        bench.reset();

        if eviction_active && args.benchmark {
            eprintln!(
                "[BENCHMARK] evicted_in_loop={} model_deferred={} real_regions={}",
                evicted_regions.len(),
                model_regions.len(),
                real_regions.len()
            );
        }

        emit_gui_progress_update_ex(70.0, "", eviction_active);
        // Elements were only borrowed by the tile loop; free them before save.
        drop(elements);
    } else {
        // Small area: sequential processing along the original code path.
        let elements_count: usize = elements.len();
        // A way's flood fill is read by the way itself and by every relation
        // listing it as a member, and sort_ground_fill_areas interleaves both
        // kinds, so neither one is reliably last. Record the position of the
        // final reader and evict only there; dropping the entry earlier makes
        // the remaining readers refill the same polygon.
        let mut last_fill_use: HashMap<u64, usize> = HashMap::new();
        for (index, element) in elements.iter().enumerate() {
            match element {
                ProcessedElement::Way(way) => {
                    last_fill_use.insert(way.id, index);
                }
                ProcessedElement::Relation(rel) => {
                    for member in &rel.members {
                        last_fill_use.insert(member.way.id, index);
                    }
                }
                ProcessedElement::Node(_) => {}
            }
        }
        // Group fills must live until the last member of the group renders.
        for members in group_members.values() {
            if let Some(max_idx) = members
                .iter()
                .filter_map(|id| last_fill_use.get(id))
                .max()
                .copied()
            {
                for id in members {
                    last_fill_use.insert(*id, max_idx);
                }
            }
        }
        let mut fills_expiring_at: HashMap<usize, Vec<u64>> = HashMap::new();
        for (&id, &idx) in last_fill_use.iter() {
            fills_expiring_at.entry(idx).or_default().push(id);
        }
        let process_pb: ProgressBar = ProgressBar::new(elements_count as u64);
        process_pb.set_style(ProgressStyle::default_bar()
            .template("{spinner:.green} [{elapsed_precise}] [{bar:45.white/black}] {pos}/{len} elements ({eta}) {msg}")
            .unwrap()
            .progress_chars("█▓░"));

        let progress_increment_prcs: f64 = 50.0 / elements_count as f64;
        let mut current_progress_prcs: f64 = 20.0;
        let mut last_emitted_progress: f64 = current_progress_prcs;
        let desired_updates: u64 = 500;
        let pb_batch_size: u64 = (elements_count as u64 / desired_updates).max(1);
        let mut element_counter: u64 = 0;

        for (index, element) in elements.into_iter().enumerate() {
            element_counter += 1;
            let suppression_key = (element.kind(), element.id());
            if models_3d_suppressed.contains(&suppression_key)
                || (has_landmarks && landmark_suppressed.contains(&suppression_key))
                || outline_suppression.contains(&suppression_key)
            {
                // Still the last reader on record, so release its fills.
                release_finished_fills(&mut flood_fill_cache, &fills_expiring_at, index);
                continue;
            }
            if element_counter.is_multiple_of(pb_batch_size) {
                process_pb.inc(pb_batch_size);
            }
            current_progress_prcs += progress_increment_prcs;
            if (current_progress_prcs - last_emitted_progress).abs() > 0.25 {
                emit_gui_progress_update(current_progress_prcs, "");
                last_emitted_progress = current_progress_prcs;
            }

            if args.debug {
                process_pb.set_message(format!(
                    "(Element ID: {} / Type: {})",
                    element.id(),
                    element.kind()
                ));
            } else {
                // Clear on every non-debug iteration so any transient warning
                // message set by downstream element processing (missing nodes,
                // etc.) doesn't stick for the rest of the run.
                process_pb.set_message("");
            }

            process_element(
                &mut editor,
                &element,
                args,
                &highway_connectivity,
                &road_markings,
                &flood_fill_cache,
                &building_footprints,
                &building_passages,
                &road_mask,
                &rail_mask,
                &tunnel_footprint,
                &clip_bbox,
                &big_water_field,
                &bridge_structures,
                &bridge_surface,
                &bridge_outlines,
                &rail_bridge_internal_endpoints,
                &mut rail_tunnel_points,
                &tunnel_internal_endpoints,
                &tunnel_portals,
                &mut tunnel_cells,
                &part_groups,
                &group_members,
                &still_surfaces,
                &interior_uses,
            );

            // Release flood fill cache entries for memory optimization.
            // (The parallel path releases per tile instead.)
            release_finished_fills(&mut flood_fill_cache, &fills_expiring_at, index);
            // Element is dropped here, freeing its memory immediately.
        }

        process_pb.inc(element_counter % pb_batch_size);
        process_pb.finish();
        bench.mark("elements_sequential");
    }

    // Keep road_mask alive for the LC_WATER carve below.
    drop(highway_connectivity);
    drop(road_markings);
    drop(flood_fill_cache);

    // True when ground (and the ore/water post-passes) run on the merged editor:
    // the small-area sequential path, or the whole-bbox-ground override. The
    // parallel per-tile path already did ground + ore + water inside the closure.
    let ground_on_merged = !use_parallel_tiles;

    if ground_on_merged {
        ground_generation::generate_ground_layer(
            &mut editor,
            ground.as_ref(),
            args,
            &xzbbox,
            &building_footprints,
            &tunnel_footprint,
            &bridge_surface,
        )?;
    }
    bench.mark("ground_gen");

    if ground_on_merged {
        if args.caves {
            println!("{} Carving caves...", "[6b/7]".bold());
            emit_gui_progress_update(89.0, "Carving caves...");
            crate::caves::carve(&mut editor, args, &xzbbox);
        } else if args.fillground {
            crate::ore_generation::generate_ores(&mut editor, &xzbbox);
        }
        // Carve depth into ESA water cells (water_areas.rs only covers OSM polygons).
        crate::water_depth::carve_lc_water_pass(
            &mut editor,
            ground.as_ref(),
            &xzbbox,
            &big_water_field,
            &road_mask,
            &tunnel_footprint,
            &bridge_surface,
        );
    }

    // Free everything the save phase doesn't need; it often sits at the process peak.
    // The editor holds its own handle on the sealed-surface mask, and that mask is the
    // road mask itself when nothing else was sealed, so releasing it here is what
    // actually frees the bitmap.
    editor.release_sealed_surface();
    drop(sealed_surface);
    drop(road_mask);
    drop(tunnel_footprint);
    drop(rail_mask);
    drop(big_water_field);
    drop(building_footprints);
    drop(building_passages);
    drop(bridge_structures);
    drop(bridge_surface);
    drop(bridge_outlines);
    drop(rail_bridge_internal_endpoints);

    // Carve railway tunnel interiors now that underground is filled with stone.
    // Under eviction this already ran in-tile (regions get freed before here).
    if !eviction_active && !rail_tunnel_points.is_empty() {
        railways::carve_rail_tunnel_interior(&mut editor, &rail_tunnel_points);
    }
    if !eviction_active && !tunnel_cells.is_empty() {
        highways::carve_highway_tunnel_interior(&mut editor, &tunnel_cells);
    }
    // Seal floating water/lava as the final underground pass; eviction tiles did it in-tile.
    if args.caves && !eviction_active {
        crate::caves::seal_floating_fluid_region(
            &mut editor,
            xzbbox.min_x(),
            xzbbox.max_x(),
            xzbbox.min_z(),
            xzbbox.max_z(),
        );
    }

    // Run after ground generation so anchor Y reflects the final terrain.
    if let Some(p) = models_3d_pipeline.as_ref() {
        p.place(&mut editor, args);
    }
    crate::structures::plane::place_plane_models(&mut editor, &planes);
    // Last, because they clear their own footprint.
    let landmarks_start = args.benchmark.then(std::time::Instant::now);
    landmarks.place(&mut editor, args);
    if let Some(t) = landmarks_start {
        bench.report("landmark_place", t.elapsed());
    }
    bench.mark("post_passes");

    if eviction_active {
        // Flush deferred (rail-tunnel-touched) regions now the global carve has run on them.
        // The spawn region stays resident so the map-item still lands on real ground.
        let drain_start = args.benchmark.then(std::time::Instant::now);
        let mut leftover: Vec<(i32, i32)> = real_regions
            .difference(&evicted_regions)
            .copied()
            .filter(|r| Some(*r) != spawn_region)
            .collect();
        leftover.sort_unstable();
        for (rx, rz) in leftover {
            if hash_check {
                hash_acc = hash_acc.wrapping_add(editor.region_content_hash(rx, rz));
            }
            crate::mapillary::displays::flush_region(&mut editor, rx, rz);
            crate::building_facades::flush_region(&mut editor, rx, rz);
            if let Some(w) = flush_worker.as_ref() {
                editor.flush_region_via(w, rx, rz)?;
            }
            evicted_regions.insert((rx, rz));
        }
        // Hash remaining (out-of-bbox halo) regions so hash_acc == the whole-world hash.
        if hash_check {
            for (rx, rz) in editor.resident_region_keys() {
                hash_acc = hash_acc.wrapping_add(editor.region_content_hash(rx, rz));
            }
        }
        if let Some(t) = drain_start {
            bench.report("leftover_drain", t.elapsed());
        }
        // Wait for all background writes to land (and surface any I/O error) before save.
        let join_start = args.benchmark.then(std::time::Instant::now);
        if let Some(w) = flush_worker.take() {
            w.finish()?;
        }
        if let Some(t) = join_start {
            bench.report("flush_join", t.elapsed());
        }
    }

    if hash_check {
        let h = if eviction_active {
            hash_acc
        } else {
            editor.content_hash()
        };
        eprintln!("[BENCHMARK] block_hash={:016x}", h);
    }

    // Map id 0 is the first map; branding is id 1 with the preview on, else id 0.
    if place_branding {
        let (sx, sz) = options
            .spawn_point
            .or_else(|| crate::map_item::read_spawn_xz(&output_path))
            .unwrap_or((xzbbox.min_x() + 1, xzbbox.min_z() + 1));
        if wants_map_item {
            editor.place_map_item_frame(sx, sz, 0, 1);
        } else {
            editor.place_branding_map_only(sx, sz, 0);
        }
    }

    // Facade panels: every candidate recorded while the walls went up is
    // checked against the finished blocks and hung now, before the save. Under
    // eviction most were settled as their regions were flushed; this hangs the
    // rest and reports the outcome.
    if world_format == WorldFormat::JavaAnvil {
        if let Some(report) = crate::mapillary::displays::finalize(&mut editor) {
            println!("{report}");
        }
        if let Some(report) = crate::building_facades::finalize(&mut editor) {
            println!("{report}");
        }
    }

    // Save world
    if let Err(e) = editor.save() {
        // The panels were waiting for the pack this save was going to make a
        // world for; without one they are only memory.
        crate::mapillary::displays::discard();
        return Err(e.to_string());
    }
    bench.mark("save");

    if args.benchmark {
        let (built, slow) = crate::world_editor::section_counters();
        eprintln!("[BENCHMARK] sections_built={built} sections_slow_path={slow}");
    }

    // Map item, signage tiles and world settings are often longer than the region
    // write, so they get their own band instead of a frozen bar at the end of save.
    emit_gui_progress_update(97.0, "Finalizing world...");

    if wants_map_item {
        if let Some(p) = preview.as_ref() {
            match crate::map_item::write_map_item(&output_path, p, &xzbbox) {
                Ok(()) => println!("World map item added to the player inventory."),
                Err(e) => eprintln!("Warning: Failed to create world map item: {e}"),
            }
        }
    } else if place_branding {
        if let Err(e) = crate::map_item::write_branding_map_only(&output_path) {
            eprintln!("Warning: Failed to create arnismc.com map: {e}");
        }
    }

    if let Some(ctx) = &signage_ctx {
        let t = args.benchmark.then(std::time::Instant::now);
        match crate::map_item::write_decal_maps(&output_path, &ctx.registry, preview.as_deref()) {
            Ok(n) => println!("Wrote {n} signage map tiles."),
            Err(e) => eprintln!("Warning: Failed to create signage maps: {e}"),
        }
        if let Some(t) = t {
            eprintln!("[BENCHMARK] signage_maps_ms={}", t.elapsed().as_millis());
        }
        println!("{}", ctx.summary(args.debug));
    }

    // Facade panels: their textures and models are the world's resource pack,
    // which wants the world folder to exist, and it does by now.
    if world_format == WorldFormat::JavaAnvil {
        match crate::mapillary::displays::write_packs(&output_path) {
            Ok(Some(report)) => println!("{report}"),
            Ok(None) => {}
            Err(e) => eprintln!("Warning: Failed to write facade panels: {e}"),
        }
        // The Mapillary walls have no reader past this point, and in the GUI
        // the process lives on with the next generation: every exported wall's
        // image would otherwise stay resident until that one installs its own.
        crate::mapillary::facades::clear();
    }

    // Write the preview PNG; off-thread in GUI mode so "Done" isn't delayed.
    // A One World records the area only after its PNG is written.
    if let Some(p) = preview.filter(|_| args.map_preview) {
        let png_path = match one_world {
            Some(run) => run.preview_path(),
            None => map_preview::preview_output_path(&output_path, world_format),
        };
        if let Some(parent) = png_path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        let result = map_preview::PreviewResult {
            png_path: png_path.clone(),
            min_lat: llbbox.min().lat(),
            max_lat: llbbox.max().lat(),
            min_lon: llbbox.min().lng(),
            max_lon: llbbox.max().lng(),
            min_mc_x: xzbbox.min_x(),
            max_mc_x: xzbbox.max_x(),
            min_mc_z: xzbbox.min_z(),
            max_mc_z: xzbbox.max_z(),
        };
        let finalize = move || {
            // Skip if a newer generation already started.
            if !map_preview::epoch_is_current(preview_epoch) {
                return;
            }
            match p.finalize(&png_path) {
                Ok(path) => {
                    if map_preview::record_preview_result(preview_epoch, result) {
                        println!("Map preview saved to: {}", path.display());
                        emit_map_preview_ready();
                    }
                }
                Err(e) => eprintln!("Warning: Failed to generate map preview: {e}"),
            }
        };
        if crate::progress::is_running_with_gui() && one_world.is_none() {
            std::thread::spawn(finalize);
        } else {
            finalize();
        }
    }
    bench.mark("map_preview");

    if let Some(run) = one_world {
        let png = run.preview_path();
        let preview_path = png.is_file().then_some(png.as_path());
        crate::one_world::record_area(
            run,
            &llbbox,
            &xzbbox,
            ground.elevation_affine(),
            preview_path,
        )
        .map_err(|e| format!("The area was written but could not be recorded: {e}"))?;
        println!("One World: area #{} recorded.", run.area_id);
        if let Err(e) = crate::world_utils::touch_last_played(&run.world_dir) {
            eprintln!("Warning: Failed to update LastPlayed: {e}");
        }
    }

    if let Some(start) = generation_start {
        let gen_ms = start.elapsed().as_millis();
        eprintln!("[BENCHMARK] generation_time_ms={gen_ms}");
    }

    emit_gui_progress_update(99.5, "Finalizing world...");

    if world_format == WorldFormat::JavaAnvil && !extending {
        if let Err(e) = crate::world_utils::apply_java_world_settings(
            &output_path,
            args.gamemode,
            args.world_time,
            args.world_type,
        ) {
            eprintln!("Warning: Failed to apply world settings: {e}");
        }
    }

    // An extended One World moves the spawn only to a marker inside this area.
    if extending {
        if let Some((sx, sz)) = options.spawn_point.filter(|&(x, z)| {
            xzbbox.contains(&crate::coordinate_system::cartesian::XZPoint::new(x, z))
        }) {
            let rel = crate::coordinate_system::cartesian::XZPoint::new(
                sx - xzbbox.min_x(),
                sz - xzbbox.min_z(),
            );
            let sy = ground.level(rel) + 3;
            match crate::world_utils::set_spawn_in_level_dat(&output_path, sx, sy, sz) {
                Ok(()) => println!("Spawn point moved to {sx}, {sy}, {sz}."),
                Err(e) => eprintln!("Warning: Failed to move the spawn point: {e}"),
            }
        }
    }

    // Update player spawn Y coordinate based on terrain height after generation
    #[cfg(feature = "gui")]
    if world_format == WorldFormat::JavaAnvil && !extending {
        use crate::gui::update_player_spawn_y_after_generation;

        // Always update spawn Y since we now always set a spawn point (user-selected or default).
        // Use output_path (the actual "Arnis World N" folder holding level.dat), not args.path —
        // for CLI runs args.path is the parent --output-dir, so level.dat sits one level deeper.
        // `xzbbox` is post-rotation, which is what `ground` is indexed against.
        if let Err(e) =
            update_player_spawn_y_after_generation(&output_path, &xzbbox, ground.as_ref())
        {
            let warning_msg = format!("Failed to update spawn point Y coordinate: {}", e);
            eprintln!("Warning: {}", warning_msg);
            #[cfg(feature = "gui")]
            send_log(LogLevel::Warning, &warning_msg);
        }
    }

    // For Bedrock format, emit event to open the mcworld file
    if world_format == WorldFormat::BedrockMcWorld {
        if let Some(path_str) = output_path.to_str() {
            emit_show_in_folder(path_str);
        }
    }

    // For Java worlds saved to the Desktop (GUI falls back there when .minecraft/saves
    // is missing), open the folder in the file explorer so the user can find the world.
    if world_format == WorldFormat::JavaAnvil {
        if let Some(desktop) = dirs::desktop_dir() {
            if output_path.starts_with(&desktop) {
                if let Some(path_str) = output_path.to_str() {
                    emit_show_in_folder(path_str);
                }
            }
        }
    }

    Ok(output_path)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::osm_parser::ProcessedMember;

    fn square(id: u64, size: i32, tags: &[(&str, &str)]) -> ProcessedWay {
        let corners = [(0, 0), (size, 0), (size, size), (0, size)];
        ProcessedWay {
            id,
            nodes: corners
                .iter()
                .map(|&(x, z)| ProcessedNode {
                    id: 0,
                    tags: HashMap::new(),
                    x,
                    z,
                })
                .collect(),
            tags: tags
                .iter()
                .map(|(k, v)| (k.to_string(), v.to_string()))
                .collect(),
        }
    }

    fn way(id: u64, size: i32, tags: &[(&str, &str)]) -> ProcessedElement {
        ProcessedElement::Way(square(id, size, tags))
    }

    fn relation(id: u64, size: i32, tags: &[(&str, &str)]) -> ProcessedElement {
        ProcessedElement::Relation(ProcessedRelation {
            id,
            tags: tags
                .iter()
                .map(|(k, v)| (k.to_string(), v.to_string()))
                .collect(),
            members: vec![ProcessedMember {
                role: ProcessedMemberRole::Outer,
                way: Arc::new(square(id + 1000, size, &[])),
            }],
        })
    }

    fn building(id: u64) -> ProcessedElement {
        way(id, 10, &[("building", "yes")])
    }

    /// Releases tiles in order and reports, after each, which of `watch` are still cached.
    fn release_in_order(
        elements: &[ProcessedElement],
        assignments: &[Vec<usize>],
        part_groups: &PartGroups,
        group_members: &FnvHashMap<u64, Vec<u64>>,
        watch: &[u64],
    ) -> Vec<Vec<bool>> {
        let cache = FloodFillCache::precompute(elements, None);
        let (tile_ids, readers) =
            tile_fill_readers(assignments, elements, part_groups, group_members, |id| {
                cache.contains(id)
            });
        (0..assignments.len())
            .map(|t| {
                release_tile_fills(&tile_ids[t], &readers, &cache);
                watch
                    .iter()
                    .map(|&id| cache.get_cached(id).is_some())
                    .collect()
            })
            .collect()
    }

    #[test]
    fn fill_shared_by_tiles_survives_until_last_tile() {
        let elements = vec![building(1), building(2)];
        let states = release_in_order(
            &elements,
            &[vec![0, 1], vec![0], vec![]],
            &PartGroups::new(),
            &FnvHashMap::default(),
            &[1, 2],
        );
        assert_eq!(
            states,
            vec![vec![true, false], vec![false, false], vec![false, false]]
        );
    }

    #[test]
    fn relation_member_fill_counts_the_relation_tile() {
        // Way 1001 is both its own element and the relation's outer member.
        let mut member = building(1001);
        let rel = relation(1, 10, &[("type", "multipolygon"), ("landuse", "grass")]);
        if let (ProcessedElement::Way(w), ProcessedElement::Relation(r)) = (&mut member, &rel) {
            w.nodes = r.members[0].way.nodes.clone();
        }
        let elements = vec![member, rel];
        let states = release_in_order(
            &elements,
            &[vec![0], vec![1]],
            &PartGroups::new(),
            &FnvHashMap::default(),
            &[1001],
        );
        assert_eq!(states, vec![vec![true], vec![false]]);
    }

    #[test]
    fn part_sibling_fill_waits_for_every_sibling_tile() {
        // Parts 10 and 11 of one building in different tiles each read the other's fill.
        let seed = 77u64;
        let part_groups: PartGroups = [(10, seed), (11, seed)].into_iter().collect();
        let mut group_members: FnvHashMap<u64, Vec<u64>> = FnvHashMap::default();
        group_members.insert(crate::osm_parser::seed_without_hint(seed), vec![10, 11]);
        let elements = vec![building(10), building(11)];
        let states = release_in_order(
            &elements,
            &[vec![0], vec![1]],
            &part_groups,
            &group_members,
            &[10, 11],
        );
        assert_eq!(states, vec![vec![true, true], vec![false, false]]);
    }

    fn ids(elements: &[ProcessedElement]) -> Vec<u64> {
        elements.iter().map(|e| e.id()).collect()
    }

    #[test]
    fn ring_area_of_square_is_side_squared() {
        assert_eq!(ring_area(&square(1, 10, &[]).nodes), 100.0);
    }

    #[test]
    fn ring_area_is_orientation_independent() {
        let mut w = square(1, 10, &[]);
        w.nodes.reverse();
        assert_eq!(ring_area(&w.nodes), 100.0);
    }

    #[test]
    fn degenerate_ring_has_zero_area() {
        let mut w = square(1, 10, &[]);
        w.nodes.truncate(2);
        assert_eq!(ring_area(&w.nodes), 0.0);
    }

    #[test]
    fn buildings_and_highways_are_not_ground_fill() {
        assert!(ground_fill_area(&way(1, 10, &[("building", "yes")])).is_none());
        assert!(ground_fill_area(&way(2, 10, &[("highway", "pedestrian")])).is_none());
        assert!(
            ground_fill_area(&way(3, 10, &[("landuse", "grass"), ("building", "yes")])).is_none()
        );
    }

    #[test]
    fn amenity_shadows_leisure_but_not_landuse_or_natural() {
        // Dispatch checks landuse and natural before amenity, and leisure after it.
        assert!(
            ground_fill_area(&way(1, 10, &[("leisure", "park"), ("amenity", "parking")])).is_none()
        );
        assert!(
            ground_fill_area(&way(2, 10, &[("landuse", "grass"), ("amenity", "parking")]))
                .is_some()
        );
        assert!(
            ground_fill_area(&way(3, 10, &[("natural", "scrub"), ("amenity", "parking")]))
                .is_some()
        );
        // natural + amenity=fountain falls through to the fountain handler.
        assert!(ground_fill_area(&way(
            4,
            10,
            &[("natural", "water"), ("amenity", "fountain")]
        ))
        .is_none());
    }

    #[test]
    fn water_relations_are_excluded() {
        assert!(ground_fill_area(&relation(1, 10, &[("natural", "water")])).is_none());
        assert!(ground_fill_area(&relation(2, 10, &[("water", "lake")])).is_none());
        assert!(ground_fill_area(&relation(3, 10, &[("natural", "wood")])).is_some());
        // Only leisure=park relations reach a ground-fill handler.
        assert!(ground_fill_area(&relation(4, 10, &[("leisure", "garden")])).is_none());
        assert!(ground_fill_area(&relation(5, 10, &[("leisure", "park")])).is_some());
    }

    #[test]
    fn landuse_values_that_paint_nothing_are_excluded() {
        // generate_landuse returns early for these, and they are usually the largest polygons.
        assert!(ground_fill_area(&way(1, 10, &[("landuse", "residential")])).is_none());
        assert!(ground_fill_area(&way(2, 10, &[("landuse", "commercial")])).is_none());
        assert!(ground_fill_area(&relation(3, 10, &[("landuse", "residential")])).is_none());
        assert!(ground_fill_area(&way(4, 10, &[("landuse", "grass")])).is_some());
    }

    #[test]
    fn no_op_landuse_does_not_displace_real_areas() {
        // The residential polygon is the largest, but must not take the last area slot.
        let mut elements = vec![
            way(1, 100, &[("leisure", "park")]),
            way(2, 500, &[("landuse", "residential")]),
            way(3, 10, &[("leisure", "pitch")]),
        ];
        sort_ground_fill_areas(&mut elements);
        assert_eq!(ids(&elements), vec![3, 2, 1]);
    }

    #[test]
    fn degenerate_area_is_not_treated_as_smallest() {
        let mut w = square(1, 10, &[("landuse", "grass")]);
        w.nodes.truncate(2);
        assert!(ground_fill_area(&ProcessedElement::Way(w)).is_none());
    }

    #[test]
    fn smaller_area_renders_before_larger_one() {
        let mut elements = vec![
            way(1, 100, &[("landuse", "forest")]),
            way(2, 10, &[("leisure", "park")]),
        ];
        sort_ground_fill_areas(&mut elements);
        assert_eq!(ids(&elements), vec![2, 1]);
    }

    #[test]
    fn a_square_yields_to_the_lawns_inside_it() {
        // Parse order puts the older square first; the lawn must still claim its ground.
        let mut elements = vec![
            way(1, 60, &[("place", "square")]),
            way(2, 10, &[("landuse", "grass")]),
        ];
        sort_ground_fill_areas(&mut elements);
        assert_eq!(ids(&elements), vec![2, 1]);
        assert!(ground_fill_area(&way(3, 10, &[("place", "neighbourhood")])).is_none());
    }

    #[test]
    fn tree_rows_are_not_ground_fill() {
        assert!(ground_fill_area(&way(1, 10, &[("natural", "tree_row")])).is_none());
    }

    #[test]
    fn non_area_elements_keep_their_slots() {
        let mut elements = vec![
            way(1, 10, &[("leisure", "park")]),
            way(2, 50, &[("building", "yes")]),
            way(3, 100, &[("landuse", "forest")]),
            way(4, 50, &[("highway", "residential")]),
            way(5, 30, &[("natural", "wood")]),
        ];
        sort_ground_fill_areas(&mut elements);
        // Slots 0, 2, 4 held areas; 1 and 3 must not move.
        assert_eq!(ids(&elements), vec![1, 2, 5, 4, 3]);
    }

    #[test]
    fn relations_participate_in_the_ordering() {
        // A small relation must go ahead of a big way even though relations parse last.
        let mut elements = vec![
            way(1, 100, &[("landuse", "forest")]),
            relation(2, 10, &[("landuse", "meadow")]),
        ];
        sort_ground_fill_areas(&mut elements);
        assert_eq!(ids(&elements), vec![2, 1]);
    }

    #[test]
    fn equal_areas_break_ties_by_id() {
        let mut elements = vec![
            way(9, 10, &[("landuse", "grass")]),
            way(4, 10, &[("landuse", "meadow")]),
        ];
        sort_ground_fill_areas(&mut elements);
        assert_eq!(ids(&elements), vec![4, 9]);
    }

    #[test]
    fn sorting_is_idempotent() {
        let mut elements = vec![
            way(1, 10, &[("leisure", "park")]),
            way(2, 100, &[("landuse", "residential")]),
            way(3, 30, &[("natural", "wood")]),
        ];
        sort_ground_fill_areas(&mut elements);
        let once = ids(&elements);
        sort_ground_fill_areas(&mut elements);
        assert_eq!(ids(&elements), once);
    }
}
