//! Generic Sponge .schem loader keeping full blocks + states, for stamping props.

use std::collections::HashMap;
use std::io::Read;
use std::sync::Arc;

use fastnbt::Value;

use crate::block_definitions::*;
use crate::trees::schematic::rotate_xz;
use crate::world_editor::WorldEditor;

/// Parsed structure: voxels with block-states, plus the tallest column as anchor.
pub struct StructureSchematic {
    pub width: i32,
    pub length: i32,
    pub voxels: Vec<(i32, i32, i32, BlockWithProperties)>,
    pub anchor_x: i32,
    pub anchor_z: i32,
    // Max horizontal distance from the anchor to any voxel, precomputed for the halo guard.
    pub max_extent: i32,
}

// Max Chebyshev distance from (ax, az) to any voxel. Rotation-invariant, so it holds for any rot.
fn extent_from_anchor(voxels: &[(i32, i32, i32, BlockWithProperties)], ax: i32, az: i32) -> i32 {
    voxels
        .iter()
        .map(|&(vx, _, vz, _)| (vx - ax).abs().max((vz - az).abs()))
        .max()
        .unwrap_or(0)
}

impl StructureSchematic {
    /// Re-anchor on the footprint centre, for models whose base fills the full footprint.
    pub fn centered(mut self) -> Self {
        self.anchor_x = self.width / 2;
        self.anchor_z = self.length / 2;
        self.max_extent = extent_from_anchor(&self.voxels, self.anchor_x, self.anchor_z);
        self
    }

    /// Re-anchor on the centroid of the lowest layer, for tall models with a wide top.
    pub fn base_anchored(mut self) -> Self {
        let (mut sx, mut sz, mut n) = (0i64, 0i64, 0i64);
        for &(vx, vy, vz, _) in &self.voxels {
            if vy == 0 {
                sx += vx as i64;
                sz += vz as i64;
                n += 1;
            }
        }
        if n > 0 {
            self.anchor_x = (sx / n) as i32;
            self.anchor_z = (sz / n) as i32;
        }
        self.max_extent = extent_from_anchor(&self.voxels, self.anchor_x, self.anchor_z);
        self
    }
}

/// Map a Minecraft block-state string to a block + parsed properties; None for air/unmodeled.
fn map_structure_block(name: &str) -> Option<BlockWithProperties> {
    let base = name
        .split('[')
        .next()
        .unwrap_or(name)
        .trim_start_matches("minecraft:");
    let block = match base {
        "sandstone" => SANDSTONE,
        "smooth_sandstone" => SMOOTH_SANDSTONE,
        "smooth_sandstone_stairs" => SMOOTH_SANDSTONE_STAIRS,
        "cut_sandstone_slab" => CUT_SANDSTONE_SLAB,
        "sandstone_wall" => SANDSTONE_WALL,
        "andesite" => ANDESITE,
        "andesite_wall" => ANDESITE_WALL,
        "diorite_wall" => DIORITE_WALL,
        "stone" => STONE,
        "stone_slab" => STONE_BLOCK_SLAB,
        "smooth_quartz_slab" => SMOOTH_QUARTZ_SLAB,
        "smooth_quartz_stairs" => SMOOTH_QUARTZ_STAIRS,
        "blackstone_stairs" => BLACKSTONE_STAIRS,
        "blackstone_wall" => BLACKSTONE_WALL,
        "iron_bars" => IRON_BARS,
        // Chain axis is carried through properties; either const serialises to "chain".
        "iron_chain" | "chain" => CHAIN_X,
        "glass" => GLASS,
        "ladder" => LADDER,
        "lever" => LEVER,
        "scaffolding" => SCAFFOLDING,
        "white_carpet" => WHITE_CARPET,
        "anvil" | "chipped_anvil" => ANVIL,
        "black_wall_banner" => BLACK_WALL_BANNER,
        "birch_trapdoor" => BIRCH_TRAPDOOR,
        "dark_oak_trapdoor" => DARK_OAK_TRAPDOOR,
        "iron_trapdoor" => IRON_TRAPDOOR,
        "jungle_trapdoor" => JUNGLE_TRAPDOOR,
        "birch_fence" => BIRCH_FENCE,
        "jungle_fence" => JUNGLE_FENCE,
        "birch_fence_gate" => BIRCH_FENCE_GATE,
        "dark_oak_fence_gate" => DARK_OAK_FENCE_GATE,
        "birch_door" => BIRCH_DOOR,
        "birch_pressure_plate" => BIRCH_PRESSURE_PLATE,
        "stone_pressure_plate" => STONE_PRESSURE_PLATE,
        "blast_furnace" => BLAST_FURNACE,
        "dispenser" => DISPENSER,
        "hopper" => HOPPER,
        "grindstone" => GRINDSTONE,
        "lantern" => LANTERN,
        "lodestone" => LODESTONE,
        "redstone_torch" => REDSTONE_TORCH,
        // Excavator blocks.
        "grass" => GRASS,
        "oak_log" => OAK_LOG,
        "stone_brick_wall" => STONE_BRICK_WALL,
        "mossy_stone_brick_wall" => MOSSY_STONE_BRICK_WALL,
        "end_stone_brick_wall" => END_STONE_BRICK_WALL,
        "polished_deepslate_wall" => POLISHED_DEEPSLATE_WALL,
        "polished_deepslate_slab" => POLISHED_DEEPSLATE_SLAB,
        "smooth_stone_slab" => SMOOTH_STONE_SLAB,
        "polished_andesite_slab" => POLISHED_ANDESITE_SLAB,
        "polished_andesite_stairs" => POLISHED_ANDESITE_STAIRS,
        "bamboo_stairs" => BAMBOO_STAIRS,
        "bamboo_slab" => BAMBOO_SLAB,
        "yellow_terracotta" => YELLOW_TERRACOTTA,
        "black_stained_glass" => BLACK_STAINED_GLASS,
        "chiseled_polished_blackstone" => CHISELED_POLISHED_BLACKSTONE,
        "chiseled_deepslate" => CHISELED_DEEPSLATE,
        "stone_button" => STONE_BUTTON,
        "lightning_rod" => LIGHTNING_ROD,
        // Playground blocks.
        "short_grass" => GRASS,
        "chest" => CHEST,
        "glowstone" => GLOWSTONE,
        "spruce_log" => SPRUCE_LOG,
        "dark_oak_log" => DARK_OAK_LOG,
        "dark_oak_planks" => DARK_OAK_PLANKS,
        "cobblestone_stairs" => COBBLESTONE_STAIRS,
        "cobblestone_slab" => COBBLESTONE_SLAB,
        "jungle_stairs" => JUNGLE_STAIRS,
        "jungle_slab" => JUNGLE_SLAB,
        "dark_oak_slab" => DARK_OAK_SLAB,
        "spruce_slab" => SPRUCE_SLAB,
        "oak_slab" => OAK_SLAB,
        "oak_fence" => OAK_FENCE,
        "spruce_fence" => SPRUCE_FENCE,
        "nether_brick_fence" => NETHER_BRICK_FENCE,
        "oak_trapdoor" => OAK_TRAPDOOR,
        "oak_button" => OAK_BUTTON,
        "birch_button" => BIRCH_BUTTON,
        "powered_rail" => POWERED_RAIL,
        // Boat + tractor blocks. Block-entity/invisible blocks (barriers, skulls, signs) are dropped.
        "andesite_slab" => ANDESITE_SLAB,
        "cobbled_deepslate_slab" => COBBLED_DEEPSLATE_SLAB,
        "cobbled_deepslate_stairs" => COBBLED_DEEPSLATE_STAIRS,
        "cyan_terracotta" => CYAN_TERRACOTTA,
        "dark_oak_fence" => DARK_OAK_FENCE,
        "dark_oak_stairs" => DARK_OAK_STAIRS,
        "dark_oak_pressure_plate" => DARK_OAK_PRESSURE_PLATE,
        "oak_pressure_plate" => OAK_PRESSURE_PLATE,
        "oak_fence_gate" => OAK_FENCE_GATE,
        "spruce_stairs" => SPRUCE_STAIRS,
        "spruce_trapdoor" => SPRUCE_TRAPDOOR,
        "spruce_button" => SPRUCE_BUTTON,
        "spruce_fence_gate" => SPRUCE_FENCE_GATE,
        "end_rod" => END_ROD,
        "flower_pot" => EMPTY_FLOWER_POT,
        "sea_pickle" => SEA_PICKLE,
        "gray_concrete_powder" => GRAY_CONCRETE_POWDER,
        "gray_stained_glass_pane" => GRAY_STAINED_GLASS_PANE,
        "gray_wall_banner" => GRAY_WALL_BANNER,
        "gray_wool" => GRAY_WOOL,
        "nether_wart_block" => NETHER_WART_BLOCK,
        "polished_basalt" => POLISHED_BASALT,
        "polished_blackstone_button" => POLISHED_BLACKSTONE_BUTTON,
        "polished_blackstone_pressure_plate" => POLISHED_BLACKSTONE_PRESSURE_PLATE,
        "red_nether_brick_slab" => RED_NETHER_BRICK_SLAB,
        "red_nether_brick_stairs" => RED_NETHER_BRICK_STAIRS,
        "stone_brick_slab" => STONE_BRICK_SLAB,
        // Lighthouse blocks (vanilla; modded furniture is dropped by the no-match arm).
        "stone_bricks" => STONE_BRICKS,
        "cracked_stone_bricks" => CRACKED_STONE_BRICKS,
        "mossy_stone_bricks" => MOSSY_STONE_BRICKS,
        "stone_brick_stairs" => STONE_BRICK_STAIRS,
        "end_stone_bricks" => END_STONE_BRICKS,
        "end_stone_brick_slab" => END_STONE_BRICK_SLAB,
        "smooth_red_sandstone" => SMOOTH_RED_SANDSTONE,
        "smooth_red_sandstone_slab" => SMOOTH_RED_SANDSTONE_SLAB,
        "nether_brick_stairs" => NETHER_BRICK_STAIRS,
        "nether_brick_wall" => NETHER_BRICK_WALL,
        "glass_pane" => GLASS_PANE,
        "spruce_planks" => SPRUCE_PLANKS,
        "oak_door" => OAK_DOOR,
        "acacia_trapdoor" => ACACIA_TRAPDOOR,
        "dark_oak_button" => DARK_OAK_BUTTON,
        "barrel" => BARREL,
        "composter" => COMPOSTER,
        "smoker" => SMOKER,
        "crafting_table" => CRAFTING_TABLE,
        "cyan_carpet" => CYAN_CARPET,
        "green_carpet" => GREEN_CARPET,
        "light_blue_carpet" => LIGHT_BLUE_CARPET,
        "potted_oxeye_daisy" => FLOWER_POT,
        "tall_grass" => GRASS,
        // Fountain blocks. Water makes the basin; player_head (block entity) is dropped.
        "water" => WATER,
        "cobblestone" => COBBLESTONE,
        "cobblestone_wall" => COBBLESTONE_WALL,
        "chiseled_stone_bricks" => CHISELED_STONE_BRICKS,
        "stone_stairs" => STONE_STAIRS,
        "coarse_dirt" => COARSE_DIRT,
        "mossy_cobblestone" => MOSSY_COBBLESTONE,
        "mossy_cobblestone_slab" => MOSSY_COBBLESTONE_SLAB,
        "mossy_stone_brick_slab" => MOSSY_STONE_BRICK_SLAB,
        "polished_andesite" => POLISHED_ANDESITE,
        "light_gray_concrete" => LIGHT_GRAY_CONCRETE,
        "light_gray_carpet" => LIGHT_GRAY_CARPET,
        "cyan_wool" => CYAN_WOOL,
        "prismarine" => PRISMARINE,
        "blue_stained_glass_pane" => BLUE_STAINED_GLASS_PANE,
        "tripwire_hook" => TRIPWIRE_HOOK,
        "oak_leaves" => OAK_LEAVES,
        "poppy" => RED_FLOWER,
        "red_tulip" => RED_FLOWER,
        "dandelion" => YELLOW_FLOWER,
        "potted_azalea_bush" | "potted_flowering_azalea_bush" => FLOWER_POT,
        // Tombstone blocks. Skeleton skulls are dropped by the no-match arm.
        "gravel" => GRAVEL,
        "podzol" => PODZOL,
        "dirt" => DIRT,
        "potted_allium" | "potted_cornflower" => FLOWER_POT,
        "spruce_wall_sign" => SPRUCE_WALL_SIGN,
        "mossy_cobblestone_stairs" => MOSSY_COBBLESTONE_STAIRS,
        "mossy_stone_brick_stairs" => MOSSY_STONE_BRICK_STAIRS,
        "granite_stairs" => GRANITE_STAIRS,
        "diorite_stairs" => DIORITE_STAIRS,
        "cobbled_deepslate" => COBBLED_DEEPSLATE,
        "deepslate_tiles" => DEEPSLATE_TILES,
        "deepslate_tile_slab" => DEEPSLATE_TILE_SLAB,
        "deepslate_tile_wall" => DEEPSLATE_TILE_WALL,
        "polished_blackstone" => POLISHED_BLACKSTONE,
        "polished_blackstone_slab" => POLISHED_BLACKSTONE_SLAB,
        "polished_deepslate" => POLISHED_DEEPSLATE,
        "polished_diorite" => POLISHED_DIORITE,
        "polished_diorite_slab" => POLISHED_DIORITE_SLAB,
        "soul_lantern" => SOUL_LANTERN,
        "chiseled_quartz_block" => CHISELED_QUARTZ_BLOCK,
        // Helicopter blocks.
        "white_concrete" => WHITE_CONCRETE,
        // Starship blocks. Bedrock is remapped so schems never place unbreakable blocks.
        "blackstone" => BLACKSTONE,
        "clay" => CLAY,
        "furnace" => FURNACE,
        "polished_blackstone_bricks" => POLISHED_BLACKSTONE_BRICKS,
        "polished_deepslate_stairs" => POLISHED_DEEPSLATE_STAIRS,
        "polished_blackstone_stairs" => BLACKSTONE_STAIRS,
        "observer" => BLAST_FURNACE,
        "light_gray_wool" => LIGHT_GRAY_CONCRETE,
        "light_gray_stained_glass_pane" => GRAY_STAINED_GLASS_PANE,
        "tuff" => TUFF,
        "polished_tuff" => POLISHED_ANDESITE,
        "tuff_wall" | "polished_tuff_wall" | "granite_wall" => ANDESITE_WALL,
        "mud_brick_wall" => BRICK_WALL,
        "deepslate_brick_wall" => DEEPSLATE_TILE_WALL,
        "polished_blackstone_wall" => BLACKSTONE_WALL,
        "reinforced_deepslate" => CHISELED_DEEPSLATE,
        "netherite_block" => NETHERITE_BLOCK,
        "bedrock" => POLISHED_BLACKSTONE,
        // Car blocks. Substitutions keep the shape class (slab/stairs/pane) over exact color.
        "black_concrete" | "black_concrete_powder" => BLACK_CONCRETE,
        "black_stained_glass_pane" => GRAY_STAINED_GLASS_PANE,
        "white_stained_glass_pane" => GLASS_PANE,
        "white_stained_glass" => WHITE_STAINED_GLASS,
        "cyan_concrete" => CYAN_CONCRETE,
        "orange_concrete" => ORANGE_CONCRETE,
        "pink_concrete" => RED_CONCRETE,
        "smooth_quartz" => SMOOTH_QUARTZ,
        "smooth_stone" => SMOOTH_STONE,
        "quartz_bricks" => QUARTZ_BRICKS,
        "iron_block" => IRON_BLOCK,
        "gray_carpet" => LIGHT_GRAY_CARPET,
        "snow" => SNOW_LAYER,
        "mangrove_slab" => RED_NETHER_BRICK_SLAB,
        "deepslate_brick_slab" => POLISHED_DEEPSLATE_SLAB,
        "warped_slab" => WARPED_SLAB,
        "warped_stairs" => WARPED_STAIRS,
        "warped_trapdoor" => WARPED_TRAPDOOR,
        "polished_diorite_stairs" => POLISHED_DIORITE_STAIRS,
        "acacia_stairs" => GRANITE_STAIRS,
        "acacia_button" | "bamboo_button" | "mangrove_button" | "warped_button" => STONE_BUTTON,
        "light_gray_candle" | "gray_candle" => END_ROD,
        "polished_blackstone_brick_wall" => BLACKSTONE_WALL,
        "black_wool" => BLACK_WOOL,
        "blue_carpet" => LIGHT_BLUE_CARPET,
        "nether_brick_slab" => RED_NETHER_BRICK_SLAB,
        "mossy_cobblestone_wall" => MOSSY_STONE_BRICK_WALL,
        // Bridge segment blocks. Wall signs are block entities and stay dropped.
        "sandstone_stairs" => SMOOTH_SANDSTONE_STAIRS,
        "sandstone_slab" => CUT_SANDSTONE_SLAB,
        "cut_sandstone" => SMOOTH_SANDSTONE,
        "sea_lantern" | "beacon" => SEA_LANTERN,
        "stripped_warped_stem" => STRIPPED_WARPED_STEM,
        "stripped_warped_hyphae" => STRIPPED_WARPED_HYPHAE,
        "warped_fence_gate" => SPRUCE_FENCE_GATE,
        // Wind-turbine blocks.
        "quartz_block" => QUARTZ_BLOCK,
        "quartz_pillar" => QUARTZ_PILLAR,
        "quartz_slab" => QUARTZ_SLAB_TOP,
        "quartz_stairs" => QUARTZ_STAIRS,
        "red_concrete" => RED_CONCRETE,
        "redstone_wall_torch" => REDSTONE_WALL_TORCH,
        // Landmark blocks.
        "green_wool" => GREEN_WOOL,
        "green_terracotta" => GREEN_STAINED_HARDENED_CLAY,
        "red_terracotta" => RED_TERRACOTTA,
        "gray_concrete" => GRAY_CONCRETE,
        "diorite" => DIORITE,
        "snow_block" => SNOW_BLOCK,
        "acacia_log" => ACACIA_LOG,
        // No cracked/glazed variants exist; nearest match.
        "cracked_polished_blackstone_bricks" => POLISHED_BLACKSTONE_BRICKS,
        "brown_glazed_terracotta" => BROWN_TERRACOTTA,
        "cut_red_sandstone" => SMOOTH_RED_SANDSTONE,
        "andesite_stairs" => ANDESITE_STAIRS,
        // Olympiahalle palette. All already carry through to Bedrock and Luanti.
        "mud" => MUD,
        "brown_stained_glass" => BROWN_STAINED_GLASS,
        "nether_bricks" => NETHER_BRICK,
        "black_terracotta" => BLACK_TERRACOTTA,
        "tinted_glass" => TINTED_GLASS,
        // Aeroplane liveries differ only in the accent material, so no substitutions here.
        "purpur_block" => PURPUR_BLOCK,
        "purpur_slab" => PURPUR_SLAB,
        "purpur_stairs" => PURPUR_STAIRS,
        "crimson_planks" => CRIMSON_PLANKS,
        "crimson_slab" => CRIMSON_SLAB,
        "crimson_stairs" => CRIMSON_STAIRS,
        "cherry_planks" => CHERRY_PLANKS,
        "cherry_slab" => CHERRY_SLAB,
        "cherry_stairs" => CHERRY_STAIRS,
        "dark_prismarine" => DARK_PRISMARINE,
        "dark_prismarine_slab" => DARK_PRISMARINE_SLAB,
        "dark_prismarine_stairs" => DARK_PRISMARINE_STAIRS,
        "waxed_exposed_cut_copper" => WAXED_EXPOSED_CUT_COPPER,
        "waxed_exposed_cut_copper_slab" => WAXED_EXPOSED_CUT_COPPER_SLAB,
        "waxed_exposed_cut_copper_stairs" => WAXED_EXPOSED_CUT_COPPER_STAIRS,
        "pale_oak_trapdoor" => PALE_OAK_TRAPDOOR,
        // Jetbridge blocks. Hanging signs stay dropped by the no-match arm.
        "coal_block" => COAL_BLOCK,
        "blackstone_slab" => BLACKSTONE_SLAB,
        "iron_door" => IRON_DOOR,
        _ => return None,
    };
    Some(BlockWithProperties::new(block, parse_state(name)))
}

/// Parse the `[k=v,...]` suffix into an NBT compound (values as strings); None if no state.
fn parse_state(name: &str) -> Option<Value> {
    let start = name.find('[')?;
    let end = name.rfind(']')?;
    if end <= start + 1 {
        return None;
    }
    let mut props: HashMap<String, Value> = HashMap::new();
    for kv in name[start + 1..end].split(',') {
        if let Some((k, v)) = kv.split_once('=') {
            props.insert(k.trim().to_string(), Value::String(v.trim().to_string()));
        }
    }
    if props.is_empty() {
        None
    } else {
        Some(Value::Compound(props))
    }
}

/// Decode a Sponge `Data` byte stream: LEB128 varint palette indices. Lazy, so
/// a large model needs no `Vec<i32>` four times the size of its block data.
fn varint_indices(data: &[i8]) -> impl Iterator<Item = i32> + '_ {
    let mut i = 0usize;
    std::iter::from_fn(move || {
        if i >= data.len() {
            return None;
        }
        let mut val: i32 = 0;
        let mut shift = 0u32;
        loop {
            let byte = data[i] as u8;
            i += 1;
            if shift < 32 {
                val |= i32::from(byte & 0x7F) << shift;
            }
            if byte & 0x80 == 0 {
                break;
            }
            shift += 7;
            if i >= data.len() {
                break;
            }
        }
        Some(val)
    })
}

/// Decode a Sponge `Data`/`BlockData` byte stream: LEB128 varint palette indices.
#[cfg(test)]
fn decode_varints(data: &[u8]) -> Vec<i32> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < data.len() {
        let mut val: i32 = 0;
        let mut shift = 0u32;
        loop {
            let byte = data[i];
            i += 1;
            if shift < 32 {
                val |= i32::from(byte & 0x7F) << shift;
            }
            if byte & 0x80 == 0 {
                break;
            }
            shift += 7;
            if i >= data.len() {
                break;
            }
        }
        out.push(val);
    }
    out
}

fn as_compound(v: &Value) -> Option<&HashMap<String, Value>> {
    match v {
        Value::Compound(c) => Some(c),
        _ => None,
    }
}

fn short_field(c: &HashMap<String, Value>, k: &str) -> Result<i32, String> {
    match c.get(k) {
        Some(Value::Short(s)) => Ok(i32::from(*s)),
        Some(Value::Int(i)) => Ok(*i),
        _ => Err(format!("schem: missing short field {k}")),
    }
}

/// A parsed `.schem` still referring to its blocks by palette index. One byte
/// per voxel, which at landmark size costs a quarter of expanded blocks.
pub struct PalettizedSchematic {
    pub width: i32,
    pub length: i32,
    /// One entry per accepted palette id; index with a voxel's `.3`.
    pub palette: Vec<BlockWithProperties>,
    /// (x, y, z, palette index), y floored so the lowest layer is 0.
    pub voxels: Vec<(i16, i16, i16, u8)>,
}

/// Load a gzipped Sponge `.schem` keeping palette indices. Unmapped entries are
/// dropped, so the palette is dense and fits a `u8`.
pub fn load_palettized(gz_bytes: &[u8]) -> Result<PalettizedSchematic, String> {
    // Scoped so the decompressed NBT is freed before the voxel list grows.
    let root: Value = {
        let mut raw = Vec::new();
        flate2::read::GzDecoder::new(gz_bytes)
            .read_to_end(&mut raw)
            .map_err(|e| format!("schem: gunzip failed: {e}"))?;
        fastnbt::from_bytes(&raw).map_err(|e| format!("schem: nbt parse: {e}"))?
    };
    let root_c = as_compound(&root).ok_or("schem: root not a compound")?;
    let scm = root_c
        .get("Schematic")
        .and_then(as_compound)
        .unwrap_or(root_c);

    let width = short_field(scm, "Width")?;
    let height = short_field(scm, "Height")?;
    let length = short_field(scm, "Length")?;
    if width <= 0 || height <= 0 || length <= 0 {
        return Err("schem: non-positive dimensions".into());
    }
    if width > i32::from(i16::MAX) || height > i32::from(i16::MAX) || length > i32::from(i16::MAX) {
        return Err("schem: dimensions exceed the i16 voxel coordinate range".into());
    }

    let (palette_v, data_v) = match scm.get("Blocks").and_then(as_compound) {
        Some(blocks) => (blocks.get("Palette"), blocks.get("Data")),
        None => (scm.get("Palette"), scm.get("BlockData")),
    };
    let palette_c = palette_v
        .and_then(as_compound)
        .ok_or("schem: missing Palette")?;

    // Compacted so the per-voxel index stays a byte however sparse the source is.
    let mut palette: Vec<BlockWithProperties> = Vec::new();
    let mut idx_to_slot: HashMap<i32, u8> = HashMap::new();
    for (name, v) in palette_c {
        if let Value::Int(i) = v {
            if let Some(bwp) = map_structure_block(name) {
                if palette.len() >= 256 {
                    return Err("schem: more than 256 rendered palette entries".into());
                }
                idx_to_slot.insert(*i, palette.len() as u8);
                palette.push(bwp);
            }
        }
    }

    let Some(Value::ByteArray(data)) = data_v else {
        return Err("schem: missing BlockData".into());
    };

    // Sponge requires exactly Width*Height*Length entries. A stream that runs long
    // or short is corrupt, and would otherwise fold into out-of-range coordinates.
    let volume = i64::from(width) * i64::from(height) * i64::from(length);
    if volume > i64::from(i32::MAX) {
        return Err("schem: volume exceeds the supported range".into());
    }
    let volume = volume as usize;

    let wl = width * length;
    let mut voxels: Vec<(i16, i16, i16, u8)> = Vec::new();
    let mut min_y = i32::MAX;
    let mut seen = 0usize;
    for (i, idx) in varint_indices(data.iter().as_slice()).enumerate() {
        if i >= volume {
            return Err("schem: BlockData longer than Width*Height*Length".into());
        }
        seen = i + 1;
        if let Some(&slot) = idx_to_slot.get(&idx) {
            let i = i as i32;
            let y = i / wl;
            min_y = min_y.min(y);
            voxels.push((
                (i % width) as i16,
                y as i16,
                ((i / width) % length) as i16,
                slot,
            ));
        }
    }
    if seen != volume {
        return Err(format!(
            "schem: BlockData has {seen} entries, expected {volume}"
        ));
    }

    // Drop empty layers below so the model's lowest block sits at y=0.
    if min_y != i32::MAX && min_y != 0 {
        let min_y = min_y as i16;
        for v in &mut voxels {
            v.1 -= min_y;
        }
    }
    voxels.shrink_to_fit();

    Ok(PalettizedSchematic {
        width,
        length,
        palette,
        voxels,
    })
}

/// Load a gzipped Sponge `.schem` (v2 or v3) keeping all mapped blocks + states.
pub fn load_structure(gz_bytes: &[u8]) -> Result<StructureSchematic, String> {
    let p = load_palettized(gz_bytes)?;
    let (width, length) = (p.width, p.length);
    let voxels: Vec<(i32, i32, i32, BlockWithProperties)> = p
        .voxels
        .iter()
        .map(|&(x, y, z, slot)| {
            (
                i32::from(x),
                i32::from(y),
                i32::from(z),
                p.palette[slot as usize].clone(),
            )
        })
        .collect();

    // Anchor on the tallest column (the mast) so callers can place it precisely.
    let mut anchor = (0, 0);
    let mut best = -1;
    for &(x, y, z, _) in &voxels {
        if y > best {
            best = y;
            anchor = (x, z);
        }
    }

    let max_extent = extent_from_anchor(&voxels, anchor.0, anchor.1);
    Ok(StructureSchematic {
        width,
        length,
        voxels,
        anchor_x: anchor.0,
        anchor_z: anchor.1,
        max_extent,
    })
}

/// Rotate a cardinal direction string by `k` clockwise quarter-turns.
fn rotate_dir(d: &str, k: u8) -> &'static str {
    const ORDER: [&str; 4] = ["north", "east", "south", "west"];
    match ORDER.iter().position(|&x| x == d) {
        Some(i) => ORDER[(i + k as usize) & 3],
        None => match d {
            "up" => "up",
            "down" => "down",
            _ => "north",
        },
    }
}

/// Rotate a rail `shape` by `k` quarter-turns; stairs shapes carry no absolute dir, returned as-is.
fn rotate_rail_shape(s: &str, k: u8) -> String {
    match s {
        "north_south" | "east_west" => if k & 1 == 1 {
            if s == "north_south" {
                "east_west"
            } else {
                "north_south"
            }
        } else {
            s
        }
        .to_string(),
        _ if s.starts_with("ascending_") => format!("ascending_{}", rotate_dir(&s[10..], k)),
        "north_east" | "north_west" | "south_east" | "south_west" => {
            let mut it = s.split('_');
            let a = rotate_dir(it.next().unwrap_or("north"), k);
            let b = rotate_dir(it.next().unwrap_or("east"), k);
            let (ns, ew) = if a == "north" || a == "south" {
                (a, b)
            } else {
                (b, a)
            };
            format!("{ns}_{ew}")
        }
        _ => s.to_string(),
    }
}

/// Rotate a block-state compound by `k` quarter-turns: facing, connection sides, rail shape, axis.
pub(crate) fn rotate_props(props: &Value, k: u8) -> Value {
    let Value::Compound(c) = props else {
        return props.clone();
    };
    let mut out: HashMap<String, Value> = HashMap::with_capacity(c.len());
    for (key, val) in c {
        match (key.as_str(), val) {
            ("north" | "south" | "east" | "west", _) => {
                out.insert(rotate_dir(key, k).to_string(), val.clone());
            }
            ("facing", Value::String(s)) => {
                out.insert("facing".into(), Value::String(rotate_dir(s, k).to_string()));
            }
            ("shape", Value::String(s)) => {
                out.insert("shape".into(), Value::String(rotate_rail_shape(s, k)));
            }
            ("axis", Value::String(s)) if k & 1 == 1 => {
                let a = match s.as_str() {
                    "x" => "z",
                    "z" => "x",
                    o => o,
                };
                out.insert("axis".into(), Value::String(a.to_string()));
            }
            _ => {
                out.insert(key.clone(), val.clone());
            }
        }
    }
    Value::Compound(out)
}

/// A schematic laid out for stamping at a free yaw, voxels sorted so each column is contiguous.
/// For props that follow a real bearing instead of snapping to a quarter turn.
pub struct ColumnSchematic {
    pub width: i32,
    pub length: i32,
    palette: Vec<BlockWithProperties>,
    /// (x, y, z, palette slot), sorted by (x, z, y); y floored so the lowest layer is 0.
    voxels: Vec<(i16, i16, i16, u8)>,
    /// (offset, len) into `voxels`, indexed by `z * width + x`.
    columns: Vec<(u32, u32)>,
}

impl ColumnSchematic {
    pub fn load(gz_bytes: &[u8]) -> Result<Self, String> {
        let p = load_palettized(gz_bytes)?;
        let mut voxels = p.voxels;
        if voxels.is_empty() {
            return Err("no mapped blocks".to_string());
        }
        voxels.sort_unstable_by_key(|v| (v.0, v.2, v.1));

        let (w, l) = (p.width, p.length);
        let mut columns = vec![(0u32, 0u32); (w * l) as usize];
        let mut i = 0usize;
        while i < voxels.len() {
            let (x, _, z, _) = voxels[i];
            let mut j = i + 1;
            while j < voxels.len() && voxels[j].0 == x && voxels[j].2 == z {
                j += 1;
            }
            columns[(i32::from(z) * w + i32::from(x)) as usize] = (i as u32, (j - i) as u32);
            i = j;
        }
        Ok(Self {
            width: w,
            length: l,
            palette: p.palette,
            voxels,
            columns,
        })
    }

    fn column(&self, x: i32, z: i32) -> Option<&[(i16, i16, i16, u8)]> {
        if x < 0 || z < 0 || x >= self.width || z >= self.length {
            return None;
        }
        let (off, len) = self.columns[(z * self.width + x) as usize];
        (len > 0).then(|| &self.voxels[off as usize..(off + len) as usize])
    }

    /// Highest occupied layer. Only the asset tests need it.
    #[cfg(test)]
    pub fn height(&self) -> i32 {
        self.voxels
            .iter()
            .map(|v| i32::from(v.1))
            .max()
            .unwrap_or(0)
            + 1
    }
}

/// Per Z lift that tilts the model nose up. A shear, not a rotation, so each slice moves whole
/// and no block is lost or resampled. Nose is -Z, so slices ahead of the centre rise.
pub(crate) fn pitch_lift(length: i32, z: i32, pitch_degrees: f64) -> i32 {
    if pitch_degrees == 0.0 {
        return 0;
    }
    let centre = f64::from(length - 1) / 2.0;
    ((centre - f64::from(z)) * pitch_degrees.to_radians().tan()).round() as i32
}

/// Sine and cosine of a yaw, exact on quarter turns. cos(90 deg) comes back as 6.1e-17, which is
/// harmless in a rotation but under floor it tips boundary samples into the next cell.
fn yaw_sin_cos(yaw_degrees: f64) -> (f64, f64) {
    let quarters = yaw_degrees / 90.0;
    if (quarters - quarters.round()).abs() < 1e-9 {
        return match (quarters.round() as i64).rem_euclid(4) {
            0 => (0.0, 1.0),
            1 => (1.0, 0.0),
            2 => (0.0, -1.0),
            _ => (-1.0, 0.0),
        };
    }
    yaw_degrees.to_radians().sin_cos()
}

/// Model cell sampled by the world cell `(dx, dz)` blocks from the anchor.
/// Both sides use corner coordinates, so the offset stays an exact integer at a quarter turn.
#[inline]
fn sample_model_cell(w: i32, l: i32, dx: i32, dz: i32, sin_t: f64, cos_t: f64) -> (i32, i32) {
    let (dx, dz) = (f64::from(dx), f64::from(dz));
    (
        (f64::from(w) / 2.0 + dx * cos_t + dz * sin_t).floor() as i32,
        (f64::from(l) / 2.0 - dx * sin_t + dz * cos_t).floor() as i32,
    )
}

/// Stamps `schem` centred on (base_x, base_z), lowest block at `base_y`, yawed so its -Z face
/// points along `yaw_degrees` and tilted nose up by `pitch_degrees`.
/// Samples the destination grid, which stays hole free at any angle, like landmarks does.
/// Block states only rotate in quarter turns, so they snap to the nearest cardinal.
pub fn place_structure_yaw(
    editor: &mut WorldEditor,
    schem: &ColumnSchematic,
    base_x: i32,
    base_z: i32,
    base_y: i32,
    yaw_degrees: f64,
    pitch_degrees: f64,
) {
    let (w, l) = (schem.width, schem.length);
    let (cx, cz) = (f64::from(w) / 2.0, f64::from(l) / 2.0);
    let (sin_t, cos_t) = yaw_sin_cos(yaw_degrees);

    // Rotate states once per palette entry rather than once per voxel.
    let quarter = (yaw_degrees / 90.0).round().rem_euclid(4.0) as u8;
    let palette: Vec<BlockWithProperties> = if quarter == 0 {
        schem.palette.clone()
    } else {
        schem
            .palette
            .iter()
            .map(|b| {
                let props = b
                    .properties
                    .as_ref()
                    .map(|p| intern_props(rotate_props(p, quarter)));
                BlockWithProperties::from_arc(b.block, props)
            })
            .collect()
    };

    // Re-floor on the sheared extent so base_y stays the lowest block whatever the pitch.
    let lift_floor = schem
        .voxels
        .iter()
        .map(|&(_, y, z, _)| i32::from(y) + pitch_lift(l, i32::from(z), pitch_degrees))
        .min()
        .unwrap_or(0);

    // World AABB of the yawed footprint: transform its four corners.
    let (mut min_x, mut max_x, mut min_z, mut max_z) = (i32::MAX, i32::MIN, i32::MAX, i32::MIN);
    for (mx, mz) in [
        (0.0, 0.0),
        (f64::from(w), 0.0),
        (0.0, f64::from(l)),
        (f64::from(w), f64::from(l)),
    ] {
        let (dx, dz) = (mx - cx, mz - cz);
        let wx = f64::from(base_x) + dx * cos_t - dz * sin_t;
        let wz = f64::from(base_z) + dx * sin_t + dz * cos_t;
        min_x = min_x.min(wx.floor() as i32);
        max_x = max_x.max(wx.ceil() as i32);
        min_z = min_z.min(wz.floor() as i32);
        max_z = max_z.max(wz.ceil() as i32);
    }

    for wz in min_z..=max_z {
        for wx in min_x..=max_x {
            let (mx, mz) = sample_model_cell(w, l, wx - base_x, wz - base_z, sin_t, cos_t);
            let Some(column) = schem.column(mx, mz) else {
                continue;
            };
            let lift = pitch_lift(l, mz, pitch_degrees) - lift_floor;
            for &(_, vy, _, slot) in column {
                // Empty blacklist forces overwrites so blocks land over water/terrain too.
                editor.set_block_with_properties_absolute(
                    palette[slot as usize].clone(),
                    wx,
                    base_y + i32::from(vy) + lift,
                    wz,
                    None,
                    Some(&[]),
                );
            }
        }
    }
}

/// Stamp anchor at (base_x, base_z), lowest voxel at base_y, rotated by `rot`; `ground` fills under each column. Keep half-extent under TILE_EDITOR_HALO (64) or it clips at tile seams.
pub fn place_structure(
    editor: &mut WorldEditor,
    schem: &StructureSchematic,
    base_x: i32,
    base_z: i32,
    base_y: i32,
    rot: u8,
    ground: Option<Block>,
) {
    let k = rot & 3;
    let (w, l) = (schem.width, schem.length);
    // Skip if any voxel sits farther from the anchor than the tile halo, else it clips at seams.
    if schem.max_extent > crate::tile::TILE_EDITOR_HALO {
        eprintln!(
            "structure extent {} exceeds tile halo {}; skipping to avoid seam clipping",
            schem.max_extent,
            crate::tile::TILE_EDITOR_HALO
        );
        return;
    }
    let (ax, az) = rotate_xz(schem.anchor_x, schem.anchor_z, w, l, k);
    // Voxels share their states, so each distinct one is rotated once per placement.
    let mut rotated: Vec<(*const Value, Arc<Value>)> = Vec::new();
    for (vx, vy, vz, bwp) in &schem.voxels {
        let (rx, rz) = rotate_xz(*vx, *vz, w, l, k);
        let wx = base_x + rx - ax;
        let wz = base_z + rz - az;
        let placed = if k == 0 {
            bwp.clone()
        } else {
            let props = bwp.properties.as_ref().map(|p| {
                match rotated
                    .iter()
                    .find(|(src, _)| std::ptr::eq(*src, Arc::as_ptr(p)))
                {
                    Some((_, r)) => Arc::clone(r),
                    None => {
                        let r = intern_props(rotate_props(p, k));
                        rotated.push((Arc::as_ptr(p), Arc::clone(&r)));
                        r
                    }
                }
            });
            BlockWithProperties::from_arc(bwp.block, props)
        };
        // Empty blacklist forces overwrites so blocks land over water/terrain too.
        editor.set_block_with_properties_absolute(placed, wx, base_y + vy, wz, None, Some(&[]));
        if let Some(g) = ground {
            editor.set_block_absolute(g, wx, base_y - 1, wz, None, Some(&[]));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A quarter turn has to be an exact permutation. A half cell offset between the two
    /// conventions used to stamp every other row twice and stretch the model.
    #[test]
    fn quarter_turns_sample_each_model_cell_exactly_once() {
        let (w, l) = (45, 40);
        for quarter in 0..4 {
            let (sin_t, cos_t) = yaw_sin_cos(f64::from(quarter * 90));
            let mut seen = vec![0u32; (w * l) as usize];
            // Sweep a window comfortably larger than the yawed footprint.
            let r = w + l;
            for dz in -r..=r {
                for dx in -r..=r {
                    let (mx, mz) = sample_model_cell(w, l, dx, dz, sin_t, cos_t);
                    if (0..w).contains(&mx) && (0..l).contains(&mz) {
                        seen[(mz * w + mx) as usize] += 1;
                    }
                }
            }
            assert!(
                seen.iter().all(|&n| n == 1),
                "quarter turn {quarter}: {} cells missed, {} sampled twice or more",
                seen.iter().filter(|&&n| n == 0).count(),
                seen.iter().filter(|&&n| n > 1).count(),
            );
        }
    }

    /// Off axis yaws alias, which is fine on a hull, but the stamped area must still match the
    /// model or it is being stretched rather than resampled.
    #[test]
    fn oblique_yaw_keeps_coverage_close_to_the_model_area() {
        let (w, l) = (45, 40);
        for yaw in [17.0_f64, 33.5, 45.0, 61.0, 128.0, 213.7, 301.0] {
            let (sin_t, cos_t) = yaw_sin_cos(yaw);
            let mut hit = vec![false; (w * l) as usize];
            let r = w + l;
            let mut stamped = 0usize;
            for dz in -r..=r {
                for dx in -r..=r {
                    let (mx, mz) = sample_model_cell(w, l, dx, dz, sin_t, cos_t);
                    if (0..w).contains(&mx) && (0..l).contains(&mz) {
                        hit[(mz * w + mx) as usize] = true;
                        stamped += 1;
                    }
                }
            }
            let area = (w * l) as usize;
            let missed = hit.iter().filter(|&&h| !h).count();
            // Worst case is 45 degrees, which skips about a sixth of the columns.
            assert!(
                missed * 4 < area,
                "yaw {yaw}: {missed}/{area} model columns never sampled"
            );
            assert!(
                stamped.abs_diff(area) * 20 < area,
                "yaw {yaw}: stamped {stamped} cells for a {area}-cell model"
            );
        }
    }

    #[test]
    fn varint_decode() {
        assert_eq!(decode_varints(&[0xAC, 0x02]), vec![300]);
        assert_eq!(decode_varints(&[0x01, 0x80, 0x01]), vec![1, 128]);
    }

    #[test]
    fn parse_state_reads_properties() {
        let v = parse_state("minecraft:sandstone_wall[east=low,up=true]").unwrap();
        match v {
            Value::Compound(c) => {
                assert_eq!(c.get("east"), Some(&Value::String("low".to_string())));
                assert_eq!(c.get("up"), Some(&Value::String("true".to_string())));
            }
            _ => panic!("expected compound"),
        }
        assert!(parse_state("minecraft:stone").is_none());
    }

    #[test]
    fn maps_known_blocks_drops_unknown() {
        assert!(map_structure_block("minecraft:sandstone").is_some());
        assert!(map_structure_block("minecraft:iron_bars[north=true]").is_some());
        assert!(map_structure_block("minecraft:air").is_none());
        assert!(map_structure_block("minecraft:diamond_block").is_none());
    }

    /// Gzipped Sponge v2 with `entries` single-byte indices, all sandstone.
    fn schem_bytes(width: i16, height: i16, length: i16, entries: usize) -> Vec<u8> {
        use std::io::Write;
        let mut palette = HashMap::new();
        palette.insert("minecraft:sandstone".to_string(), Value::Int(0));
        let mut root = HashMap::new();
        root.insert("Width".to_string(), Value::Short(width));
        root.insert("Height".to_string(), Value::Short(height));
        root.insert("Length".to_string(), Value::Short(length));
        root.insert("Palette".to_string(), Value::Compound(palette));
        root.insert(
            "BlockData".to_string(),
            Value::ByteArray(fastnbt::ByteArray::new(vec![0i8; entries])),
        );
        let nbt = fastnbt::to_bytes(&Value::Compound(root)).unwrap();
        let mut out = Vec::new();
        let mut enc = flate2::write::GzEncoder::new(&mut out, flate2::Compression::fast());
        enc.write_all(&nbt).unwrap();
        enc.finish().unwrap();
        out
    }

    // BlockData must match the declared volume. A stream that runs long or short
    // would otherwise fold into out-of-range Y instead of failing.
    #[test]
    fn block_data_length_must_match_the_volume() {
        let p = load_palettized(&schem_bytes(2, 3, 2, 12)).expect("exact volume loads");
        assert_eq!(p.voxels.len(), 12);
        for &(_, y, _, _) in &p.voxels {
            assert!((0..3).contains(&y), "y {y} outside the declared height");
        }
        assert!(
            load_palettized(&schem_bytes(2, 3, 2, 13)).is_err(),
            "too long"
        );
        assert!(
            load_palettized(&schem_bytes(2, 3, 2, 11)).is_err(),
            "too short"
        );
    }
}
