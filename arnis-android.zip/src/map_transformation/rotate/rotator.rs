use super::Operator;
use crate::coordinate_system::cartesian::{XZBBox, XZBBoxRect, XZPoint};
use crate::elevation::MAX_ELEVATION_GRID_DIM;
use crate::ground::{Ground, RotationMask};
use crate::land_cover::LC_WATER;
use crate::osm_parser::ProcessedElement;
use serde::Deserialize;
use std::collections::HashMap;
use std::sync::Arc;

/// Rotates the entire map (elements, bounding box, elevation) by a given angle
/// around the center of the current bounding box.
#[derive(Debug, Deserialize, PartialEq)]
pub struct Rotator {
    /// Clockwise rotation angle in degrees (as seen on a map)
    pub angle_degrees: f64,
}

impl Operator for Rotator {
    fn operate(
        &self,
        elements: &mut Vec<ProcessedElement>,
        xzbbox: &mut XZBBox,
        ground: &mut Ground,
    ) {
        if let Err(e) = rotate_world(self.angle_degrees, elements, xzbbox, ground) {
            eprintln!("Rotation failed: {e}");
        }
    }

    fn repr(&self) -> String {
        format!("rotate {}°", self.angle_degrees)
    }
}

/// Create a Rotator from JSON config
pub fn rotator_from_json(config: &serde_json::Value) -> Result<Box<dyn Operator>, String> {
    let result: Result<Box<Rotator>, _> = serde_json::from_value(config.clone())
        .map(Box::new)
        .map_err(|e| e.to_string());
    result
        .map(|o| o as Box<dyn Operator>)
        .map_err(|e| format!("Rotator config format error:\n{e}"))
}

/// Tag keys holding an absolute compass bearing, which must turn with the map.
/// Excludes `direction`, already offset by models_3d, and `roof:orientation`.
const BEARING_TAGS: [&str; 1] = ["roof:direction"];

/// Parses a 16-point abbreviation, cardinal name or degrees into degrees from north.
fn compass_bearing_degrees(value: &str) -> Option<f64> {
    let deg = match value.trim().to_ascii_lowercase().as_str() {
        "n" | "north" => 0.0,
        "nne" => 22.5,
        "ne" => 45.0,
        "ene" => 67.5,
        "e" | "east" => 90.0,
        "ese" => 112.5,
        "se" => 135.0,
        "sse" => 157.5,
        "s" | "south" => 180.0,
        "ssw" => 202.5,
        "sw" => 225.0,
        "wsw" => 247.5,
        "w" | "west" => 270.0,
        "wnw" => 292.5,
        "nw" => 315.0,
        "nnw" => 337.5,
        other => other.parse::<f64>().ok()?,
    };
    deg.is_finite().then_some(deg)
}

/// Turns bearing tags with the map. Positive is clockwise for both, so the angle adds.
fn rotate_bearing_tags(tags: &mut HashMap<String, String>, angle_degrees: f64) {
    for key in BEARING_TAGS {
        if let Some(value) = tags.get_mut(key) {
            if let Some(deg) = compass_bearing_degrees(value) {
                // Whole degrees suffice; the consumer rounds to a cardinal anyway.
                let turned = (deg + angle_degrees).rem_euclid(360.0).round() as i64 % 360;
                *value = turned.to_string();
            }
        }
    }
}

/// Apply rotation to all world data: elements, bounding box, and ground/elevation.
pub fn rotate_world(
    angle_degrees: f64,
    elements: &mut [ProcessedElement],
    xzbbox: &mut XZBBox,
    ground: &mut Ground,
) -> Result<(), String> {
    if angle_degrees.abs() < f64::EPSILON {
        return Ok(()); // No rotation needed
    }

    // Negate: the user-facing convention is positive = clockwise on the map,
    // but the internal XZ rotation formula is counterclockwise.
    let rad = (-angle_degrees).to_radians();
    let sin_r = rad.sin();
    let cos_r = rad.cos();

    // Center of rotation = center of current bounding box
    let cx = (xzbbox.min_x() + xzbbox.max_x()) as f64 / 2.0;
    let cz = (xzbbox.min_z() + xzbbox.max_z()) as f64 / 2.0;

    // Store the original bbox extents for the rotation mask and elevation sampling
    let orig_min_x = xzbbox.min_x();
    let orig_max_x = xzbbox.max_x();
    let orig_min_z = xzbbox.min_z();
    let orig_max_z = xzbbox.max_z();
    let orig_width = (orig_max_x - orig_min_x + 1) as usize;
    let orig_height = (orig_max_z - orig_min_z + 1) as usize;

    // --- 1. Compute new axis-aligned bounding box after rotation ---
    let corners = [
        (xzbbox.min_x() as f64, xzbbox.min_z() as f64),
        (xzbbox.min_x() as f64, xzbbox.max_z() as f64),
        (xzbbox.max_x() as f64, xzbbox.min_z() as f64),
        (xzbbox.max_x() as f64, xzbbox.max_z() as f64),
    ];

    let mut rotated_xs = Vec::with_capacity(4);
    let mut rotated_zs = Vec::with_capacity(4);
    for &(x, z) in &corners {
        let (rx, rz) = rotate_point(x, z, cx, cz, sin_r, cos_r);
        rotated_xs.push(rx);
        rotated_zs.push(rz);
    }

    let new_min_x = rotated_xs
        .iter()
        .cloned()
        .fold(f64::INFINITY, f64::min)
        .floor() as i32;
    let new_max_x = rotated_xs
        .iter()
        .cloned()
        .fold(f64::NEG_INFINITY, f64::max)
        .ceil() as i32;
    let new_min_z = rotated_zs
        .iter()
        .cloned()
        .fold(f64::INFINITY, f64::min)
        .floor() as i32;
    let new_max_z = rotated_zs
        .iter()
        .cloned()
        .fold(f64::NEG_INFINITY, f64::max)
        .ceil() as i32;

    *xzbbox = XZBBox::Rect(XZBBoxRect::new(
        XZPoint {
            x: new_min_x,
            z: new_min_z,
        },
        XZPoint {
            x: new_max_x,
            z: new_max_z,
        },
    )?);

    // --- 2. Rotate all elements ---
    for elem in elements.iter_mut() {
        match elem {
            ProcessedElement::Node(node) => {
                let (rx, rz) = rotate_point(node.x as f64, node.z as f64, cx, cz, sin_r, cos_r);
                node.x = rx.round() as i32;
                node.z = rz.round() as i32;
                rotate_bearing_tags(&mut node.tags, angle_degrees);
            }
            ProcessedElement::Way(way) => {
                for node in way.nodes.iter_mut() {
                    let (rx, rz) = rotate_point(node.x as f64, node.z as f64, cx, cz, sin_r, cos_r);
                    node.x = rx.round() as i32;
                    node.z = rz.round() as i32;
                }
                rotate_bearing_tags(&mut way.tags, angle_degrees);
            }
            ProcessedElement::Relation(rel) => {
                for member in rel.members.iter_mut() {
                    let way = Arc::make_mut(&mut member.way);
                    for node in way.nodes.iter_mut() {
                        let (rx, rz) =
                            rotate_point(node.x as f64, node.z as f64, cx, cz, sin_r, cos_r);
                        node.x = rx.round() as i32;
                        node.z = rz.round() as i32;
                    }
                    rotate_bearing_tags(&mut way.tags, angle_degrees);
                }
                rotate_bearing_tags(&mut rel.tags, angle_degrees);
            }
        }
    }

    // --- 3. Rotate elevation and land-cover data ---
    rotate_ground_data(
        ground,
        xzbbox,
        orig_min_x,
        orig_min_z,
        orig_width,
        orig_height,
        cx,
        cz,
        sin_r,
        cos_r,
    );

    // --- 4. Set rotation mask so ground generation skips out-of-bounds blocks ---
    ground.set_rotation_mask(RotationMask {
        cx,
        cz,
        neg_sin: -sin_r,
        cos: cos_r,
        orig_min_x,
        orig_max_x,
        orig_min_z,
        orig_max_z,
    });

    Ok(())
}

/// Rotate a single (x, z) point around center (cx, cz).
/// Counterclockwise rotation in the XZ plane.
#[inline]
fn rotate_point(x: f64, z: f64, cx: f64, cz: f64, sin_r: f64, cos_r: f64) -> (f64, f64) {
    let dx = x - cx;
    let dz = z - cz;
    let rx = dx * cos_r + dz * sin_r + cx;
    let rz = -dx * sin_r + dz * cos_r + cz;
    (rx, rz)
}

/// Rotate a single integer (x, z) point by `angle_degrees` around the center of `xzbbox`.
/// Used by CLI and GUI to rotate spawn points to match the rotated world.
pub fn rotate_xz_point(x: i32, z: i32, angle_degrees: f64, xzbbox: &XZBBox) -> (i32, i32) {
    if angle_degrees.abs() < f64::EPSILON {
        return (x, z);
    }
    let rad = (-angle_degrees).to_radians();
    let cx = (xzbbox.min_x() + xzbbox.max_x()) as f64 / 2.0;
    let cz = (xzbbox.min_z() + xzbbox.max_z()) as f64 / 2.0;
    let (rx, rz) = rotate_point(x as f64, z as f64, cx, cz, rad.sin(), rad.cos());
    (rx.round() as i32, rz.round() as i32)
}

/// Rotate elevation grid and land-cover data, applying Laplacian smoothing to
/// reduce jagged edges from coordinate discretization during rotation.
#[allow(clippy::too_many_arguments)]
fn rotate_ground_data(
    ground: &mut Ground,
    xzbbox: &XZBBox,
    orig_min_x: i32,
    orig_min_z: i32,
    orig_width: usize,
    orig_height: usize,
    cx: f64,
    cz: f64,
    sin_r: f64,
    cos_r: f64,
) {
    let new_world_w = (xzbbox.max_x() - xzbbox.min_x() + 1) as usize;
    let new_world_h = (xzbbox.max_z() - xzbbox.min_z() + 1) as usize;

    if let Some(map) = ground.ecoregion_map() {
        let rotated = map.resample(new_world_w, new_world_h, |x, z| {
            let (wx, wz) = ((xzbbox.min_x() + x) as f64, (xzbbox.min_z() + z) as f64);
            let (ox, oz) = rotate_point(wx, wz, cx, cz, -sin_r, cos_r);
            (
                ox.round() as i32 - orig_min_x,
                oz.round() as i32 - orig_min_z,
            )
        });
        ground.set_ecoregion_map(rotated);
    }

    // Nothing to rotate without elevation, land cover or canopy; bail before cloning.
    // Flat land-cover mode still needs its grid rotated so the sea stays aligned.
    if !ground.elevation_enabled && !ground.has_land_cover() && !ground.has_canopy() {
        return;
    }

    let original_ground = ground.clone();

    // Cap the rotation grid using the same constant as elevation
    // fetching (`crate::elevation::MAX_ELEVATION_GRID_DIM`). Having two
    // local copies of the number would let them silently drift, so we
    // import the shared source of truth — if you tune one, the other
    // follows.
    let new_w = new_world_w.min(MAX_ELEVATION_GRID_DIM);
    let new_h = new_world_h.min(MAX_ELEVATION_GRID_DIM);

    // For each cell in the new grid, inverse-rotate to find the source cell
    let neg_sin_r = -sin_r; // Inverse rotation
                            // Flat land-cover mode has no elevation, so skip the height grids to avoid a large wasted allocation.
    let elevation_enabled = ground.elevation_enabled;
    let cap = if elevation_enabled { new_h } else { 0 };
    let mut new_heights: Vec<Vec<f64>> = Vec::with_capacity(cap);
    let mut has_data: Vec<Vec<bool>> = Vec::with_capacity(cap);

    // Also rotate land-cover grids if present
    let has_land_cover = original_ground.has_land_cover();
    let mut new_cover: Option<Vec<Vec<u8>>> = has_land_cover.then(|| Vec::with_capacity(new_h));
    let mut new_water: Option<Vec<Vec<u8>>> = has_land_cover.then(|| Vec::with_capacity(new_h));
    // Canopy shares the land-cover grid, so it rides the same samples.
    let has_canopy = original_ground.has_canopy();
    let mut new_canopy: Option<Vec<u8>> =
        has_canopy.then(|| Vec::with_capacity(new_w.saturating_mul(new_h)));

    for z_idx in 0..new_h {
        let mut height_row: Option<Vec<f64>> = elevation_enabled.then(|| Vec::with_capacity(new_w));
        let mut data_row: Option<Vec<bool>> = elevation_enabled.then(|| Vec::with_capacity(new_w));
        let mut cover_row: Option<Vec<u8>> = has_land_cover.then(|| Vec::with_capacity(new_w));
        let mut water_row: Option<Vec<u8>> = has_land_cover.then(|| Vec::with_capacity(new_w));

        for x_idx in 0..new_w {
            // Map grid index to world coordinate (accounts for grid being smaller than world)
            let world_x = xzbbox.min_x()
                + (x_idx as f64 / (new_w - 1).max(1) as f64 * (new_world_w - 1) as f64).round()
                    as i32;
            let world_z = xzbbox.min_z()
                + (z_idx as f64 / (new_h - 1).max(1) as f64 * (new_world_h - 1) as f64).round()
                    as i32;

            // Inverse-rotate this world coordinate back to original space
            let (orig_x, orig_z) =
                rotate_point(world_x as f64, world_z as f64, cx, cz, neg_sin_r, cos_r);

            // Convert to coordinates relative to the original bbox origin,
            // which is what Ground::level / cover_class / water_distance expect
            let rel_x = orig_x.round() as i32 - orig_min_x;
            let rel_z = orig_z.round() as i32 - orig_min_z;

            // Full bounds check: both lower AND upper against original grid dimensions
            let in_original = rel_x >= 0
                && rel_z >= 0
                && (rel_x as usize) < orig_width
                && (rel_z as usize) < orig_height;

            let coord = XZPoint::new(rel_x, rel_z);
            if let Some(ref mut hr) = height_row {
                hr.push(original_ground.level(coord) as f64);
            }
            if let Some(ref mut dr) = data_row {
                dr.push(in_original);
            }

            if let Some(ref mut cr) = cover_row {
                cr.push(original_ground.cover_class(coord));
            }
            if let Some(ref mut wr) = water_row {
                wr.push(original_ground.water_distance(coord));
            }
            if let Some(ref mut ch) = new_canopy {
                ch.push(
                    original_ground
                        .canopy_height_m(coord)
                        .unwrap_or(crate::canopy::CANOPY_NODATA),
                );
            }
        }
        if let Some(hr) = height_row {
            new_heights.push(hr);
        }
        if let Some(dr) = data_row {
            has_data.push(dr);
        }
        if let Some(ref mut cg) = new_cover {
            cg.push(cover_row.unwrap());
        }
        if let Some(ref mut wd) = new_water {
            wd.push(water_row.unwrap());
        }
    }

    // Apply Laplacian smoothing (3 iterations) to reduce jagged edges
    // from coordinate discretization during rotation. Skip cells that are
    // LC_WATER or that touch an LC_WATER neighbor — the water surface was
    // flattened (by apply_land_cover_repair pre-rotation) and smoothing
    // across that boundary would lift the water toward adjacent land
    // heights and drag the shore down toward the water, creating a 1-3 m
    // rounded rim at every rotated coastline. The `new_cover` grid was
    // populated in the main loop above with the rotated land-cover
    // classification, so we can check water-adjacency per cell.
    // Smoothing only shapes elevation; skip it in flat land-cover mode where the height grid is empty.
    let smooth_iterations = if elevation_enabled { 3 } else { 0 };
    for _ in 0..smooth_iterations {
        let prev = new_heights.clone();
        for z_idx in 1..new_h.saturating_sub(1) {
            for x_idx in 1..new_w.saturating_sub(1) {
                if !has_data[z_idx][x_idx] {
                    continue; // Don't smooth padding areas
                }
                if let Some(ref cover) = new_cover {
                    // If this cell or any 4-neighbour is water, skip.
                    // Preserves the flat water surface and the natural
                    // crispness of the shoreline through rotation.
                    if cover[z_idx][x_idx] == LC_WATER
                        || cover[z_idx - 1][x_idx] == LC_WATER
                        || cover[z_idx + 1][x_idx] == LC_WATER
                        || cover[z_idx][x_idx - 1] == LC_WATER
                        || cover[z_idx][x_idx + 1] == LC_WATER
                    {
                        continue;
                    }
                }
                let neighbors_sum = prev[z_idx - 1][x_idx]
                    + prev[z_idx + 1][x_idx]
                    + prev[z_idx][x_idx - 1]
                    + prev[z_idx][x_idx + 1];
                let avg = neighbors_sum / 4.0;
                // Blend: 70% original + 30% neighbor average
                new_heights[z_idx][x_idx] = 0.7 * prev[z_idx][x_idx] + 0.3 * avg;
            }
        }
    }

    // Update ground with rotated elevation (grid may be smaller than world)
    ground.set_elevation_data(new_heights, new_w, new_h, new_world_w, new_world_h);

    // Keep the flat-mode world dims in sync; set_elevation_data is a no-op without elevation data.
    ground.set_world_dims(new_world_w, new_world_h);

    // Update land cover with rotated data
    if let (Some(cover_grid), Some(water_dist)) = (new_cover, new_water) {
        ground.set_land_cover_data(cover_grid, water_dist, new_w, new_h);
    }
    if let Some(canopy_grid) = new_canopy {
        ground.set_canopy_data(canopy_grid, new_w, new_h);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // A skillion sheds toward a compass bearing, so rotation must carry it along.
    #[test]
    fn bearing_tags_turn_with_the_map() {
        use crate::osm_parser::{ProcessedNode, ProcessedWay};

        let way = |dir: &str| {
            let mut tags = HashMap::new();
            tags.insert("building".to_string(), "house".to_string());
            tags.insert("roof:direction".to_string(), dir.to_string());
            tags.insert("roof:orientation".to_string(), "along".to_string());
            ProcessedElement::Way(ProcessedWay {
                id: 1,
                nodes: vec![ProcessedNode {
                    id: 1,
                    tags: HashMap::new(),
                    x: 10,
                    z: 10,
                }],
                tags,
            })
        };

        // (input bearing, rotation, expected bearing)
        let cases = [
            ("north", 90.0, "90"),
            ("0", 90.0, "90"),
            ("270", 180.0, "90"),
            ("SE", -45.0, "90"),
            ("45", -90.0, "315"),
            ("350", 45.0, "35"),
        ];

        for (input, angle, expected) in cases {
            let mut elements = vec![way(input)];
            let mut xzbbox = XZBBox::rect_from_xz_lengths(100.0, 100.0).unwrap();
            let mut ground = Ground::new_flat(-62);
            rotate_world(angle, &mut elements, &mut xzbbox, &mut ground).unwrap();

            let ProcessedElement::Way(w) = &elements[0] else {
                panic!("element kind changed");
            };
            assert_eq!(
                w.tags.get("roof:direction").map(String::as_str),
                Some(expected),
                "roof:direction {input:?} rotated by {angle}"
            );
            // Footprint-relative values must not be touched.
            assert_eq!(
                w.tags.get("roof:orientation").map(String::as_str),
                Some("along"),
                "roof:orientation is relative to the footprint, not the compass"
            );
        }
    }

    // An unparseable bearing is left alone so the consumer's fallback still runs.
    #[test]
    fn unparseable_bearing_is_left_alone() {
        assert_eq!(compass_bearing_degrees("up-ish"), None);
        assert_eq!(compass_bearing_degrees("NaN"), None);
        assert_eq!(compass_bearing_degrees("inf"), None);
        assert_eq!(compass_bearing_degrees(" NNE "), Some(22.5));
        assert_eq!(compass_bearing_degrees("180"), Some(180.0));
    }

    #[test]
    fn test_zero_rotation_is_noop() {
        let mut elements = Vec::new();
        let mut xzbbox = XZBBox::rect_from_xz_lengths(100.0, 100.0).unwrap();
        let mut ground = Ground::new_flat(-62);

        let original_bbox = xzbbox.clone();
        rotate_world(0.0, &mut elements, &mut xzbbox, &mut ground).unwrap();

        assert_eq!(xzbbox.min_x(), original_bbox.min_x());
        assert_eq!(xzbbox.max_x(), original_bbox.max_x());
    }

    // Flat mode with land cover but no elevation must still rotate its grid and resync world dims.
    #[test]
    fn flat_land_cover_rotation_rotates_grid_and_syncs_dims() {
        use crate::land_cover::{LandCoverData, LC_WATER};

        let mut xzbbox = XZBBox::rect_from_xz_lengths(6.0, 2.0).unwrap();
        let w = (xzbbox.max_x() - xzbbox.min_x() + 1) as usize;
        let h = (xzbbox.max_z() - xzbbox.min_z() + 1) as usize;
        // West half water, east half land, with a 1:1 grid-to-world mapping.
        let row = |water: u8, land: u8| {
            (0..w)
                .map(|x| if x < w / 2 { water } else { land })
                .collect::<Vec<u8>>()
        };
        let lc = LandCoverData {
            grid: (0..h).map(|_| row(LC_WATER, 10)).collect(),
            water_distance: (0..h).map(|_| row(1, 0)).collect(),
            water_blend_cache: once_cell::sync::OnceCell::new(),
            width: w,
            height: h,
            cells_per_meter: 1.0,
        };
        let mut ground = Ground::new_flat_land_cover_test(lc, w, h);
        let mut elements = Vec::new();

        rotate_world(90.0, &mut elements, &mut xzbbox, &mut ground).unwrap();

        // set_world_dims kept the stored dims aligned with the enlarged rotated bbox.
        let (ww, wh) = ground.world_dims();
        assert_eq!(ww, (xzbbox.max_x() - xzbbox.min_x() + 1) as usize);
        assert_eq!(wh, (xzbbox.max_z() - xzbbox.min_z() + 1) as usize);

        // The grid was actually rotated (not skipped by the early return): water survives.
        let mut saw_water = false;
        for x in xzbbox.min_x()..=xzbbox.max_x() {
            for z in xzbbox.min_z()..=xzbbox.max_z() {
                if ground.cover_class(XZPoint::new(x - xzbbox.min_x(), z - xzbbox.min_z()))
                    == LC_WATER
                {
                    saw_water = true;
                }
            }
        }
        assert!(
            saw_water,
            "rotated flat land cover should still contain water"
        );
    }

    #[test]
    fn test_rotate_point_90_degrees() {
        let rad = 90.0_f64.to_radians();
        let (rx, rz) = rotate_point(10.0, 0.0, 0.0, 0.0, rad.sin(), rad.cos());
        // 90° CCW: (10, 0) -> (0, -10)
        assert!((rx - 0.0).abs() < 1e-10);
        assert!((rz - (-10.0)).abs() < 1e-10);
    }

    #[test]
    fn test_bbox_expands_on_45deg_rotation() {
        let mut elements = Vec::new();
        let mut xzbbox = XZBBox::rect_from_xz_lengths(100.0, 100.0).unwrap();
        let mut ground = Ground::new_flat(-62);

        let orig_area = xzbbox.bounding_rect().total_blocks();
        rotate_world(45.0, &mut elements, &mut xzbbox, &mut ground).unwrap();
        let new_area = xzbbox.bounding_rect().total_blocks();

        // 45° rotation of a square produces a larger bounding rect
        assert!(new_area > orig_area);
    }

    // Elevation on, no land cover: the height grid must be rotated, not dropped.
    #[test]
    fn elevation_only_rotation_keeps_a_varied_height_grid() {
        let n = 5usize;
        let heights: Vec<Vec<f32>> = (0..n)
            .map(|_| (0..n).map(|x| (x * 4) as f32).collect())
            .collect();
        let mut ground = Ground::new_elevation_test(heights, n, n);
        let mut xzbbox = XZBBox::rect_from_xz_lengths((n - 1) as f64, (n - 1) as f64).unwrap();
        let mut elements = Vec::new();

        rotate_world(90.0, &mut elements, &mut xzbbox, &mut ground).unwrap();

        assert!(
            ground.elevation_enabled,
            "elevation stays enabled through rotation"
        );
        let (mut lo, mut hi) = (i32::MAX, i32::MIN);
        for x in xzbbox.min_x()..=xzbbox.max_x() {
            for z in xzbbox.min_z()..=xzbbox.max_z() {
                let h = ground.level(XZPoint::new(x - xzbbox.min_x(), z - xzbbox.min_z()));
                lo = lo.min(h);
                hi = hi.max(h);
            }
        }
        assert!(hi - lo >= 4, "rotated elevation still varies: {lo}..{hi}");
    }
}
