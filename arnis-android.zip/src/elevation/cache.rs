use std::path::PathBuf;

/// Subdirectory name for tile cache within the OS cache directory
const TILE_CACHE_DIR_NAME: &str = "arnis-tile-cache";

/// Maximum age for cached tiles in days before they are cleaned up.
/// Elevation sources update on multi-year cycles, so a month is conservative.
/// Also bounds the staleness of Mapterhorn's negative 404 markers.
const TILE_CACHE_MAX_AGE_DAYS: u64 = 30;

/// Returns the tile cache directory path for a specific provider.
/// Uses the OS-standard cache directory (e.g. AppData/Local on Windows, ~/.cache on Linux).
/// Falls back to ./arnis-tile-cache if the OS cache directory is unavailable.
pub fn get_cache_dir(provider_name: &str) -> PathBuf {
    let base = if let Some(cache_dir) = dirs::cache_dir() {
        cache_dir.join(TILE_CACHE_DIR_NAME)
    } else {
        PathBuf::from(format!("./{TILE_CACHE_DIR_NAME}"))
    };
    base.join(provider_name)
}

/// Returns the base tile cache directory path (without provider subdirectory).
pub fn get_base_cache_dir() -> PathBuf {
    if let Some(cache_dir) = dirs::cache_dir() {
        cache_dir.join(TILE_CACHE_DIR_NAME)
    } else {
        PathBuf::from(format!("./{TILE_CACHE_DIR_NAME}"))
    }
}

/// Summary of a cache-clear operation, returned to the GUI so it can
/// report "cleared N files, freed X MB" to the user.
#[derive(Clone, Copy, Debug, Default)]
pub struct CacheClearStats {
    pub files_deleted: u64,
    pub bytes_freed: u64,
    pub errors: u64,
}

impl CacheClearStats {
    /// Combine two stats values — used when we clean multiple caches
    /// (elevation + land-cover) in one UI operation.
    pub fn combined(self, other: Self) -> Self {
        Self {
            files_deleted: self.files_deleted + other.files_deleted,
            bytes_freed: self.bytes_freed + other.bytes_freed,
            errors: self.errors + other.errors,
        }
    }
}

/// Bytes held by every regular file under `dir`, symlinks counted but not
/// followed, so the number cannot run off into a directory the cache merely
/// points at. A missing directory is zero rather than an error: the settings
/// panel asks for this before anything has ever been cached.
pub fn dir_size_bytes(dir: &std::path::Path) -> u64 {
    // The root gets the same refusal `clear_cache_dir` gives it: `read_dir`
    // follows a symlinked root, so a cache directory that is itself a link
    // would have this reporting the size of somewhere else entirely. Entries
    // below are already safe, `file_type` does not follow.
    match std::fs::symlink_metadata(dir) {
        Ok(meta) if meta.file_type().is_dir() => {}
        _ => return 0,
    }
    let Ok(entries) = std::fs::read_dir(dir) else {
        return 0;
    };
    let mut total = 0u64;
    for entry in entries.flatten() {
        let Ok(kind) = entry.file_type() else {
            continue;
        };
        if kind.is_dir() {
            total = total.saturating_add(dir_size_bytes(&entry.path()));
        } else if let Ok(meta) = entry.metadata() {
            // `DirEntry::metadata` carries the same no-traverse guarantee as
            // `symlink_metadata`, and on Windows it is answered from the
            // directory record `read_dir` already read, where naming the path
            // again reopens the file. Spelling the guarantee out in the call
            // read better and cost one extra stat per file: over the 43k files
            // these caches reach on a machine that has generated a few worlds,
            // 4.2s against 0.2s for the same byte count.
            total = total.saturating_add(meta.len());
        }
    }
    total
}

/// The same size as a short human string, so the settings panel can say
/// "812 MB" rather than a byte count.
pub fn format_size(bytes: u64) -> String {
    const KB: f64 = 1024.0;
    const MB: f64 = KB * 1024.0;
    const GB: f64 = MB * 1024.0;
    let b = bytes as f64;
    if b >= GB {
        format!("{:.1} GB", b / GB)
    } else if b >= MB {
        format!("{:.0} MB", b / MB)
    } else if b >= KB {
        format!("{:.0} KB", b / KB)
    } else {
        format!("{bytes} B")
    }
}

/// Recursively remove everything inside `dir`, leaving `dir` itself in
/// place (so subsequent cache writes don't need to recreate the root
/// handle). Missing directory is a no-op.
///
/// Safety considerations implemented here:
///
/// - Symlinks are removed but not followed. We never recurse into an
///   arbitrary filesystem the user may have pointed at with a stray
///   symlink inside the cache.
/// - Unreadable entries contribute to the error count instead of
///   propagating, and the GUI surfaces the error count as a warning.
/// - No panics: every fs call is matched; transient errors (e.g. a
///   file busy-locked by another reader) just increment `errors`.
pub fn clear_cache_dir(dir: &std::path::Path) -> CacheClearStats {
    let mut stats = CacheClearStats::default();
    // Use `symlink_metadata` so a symlink pointing to another directory
    // doesn't trick us into recursing through it — `read_dir` follows
    // symlinks, so even though `clear_recursive` doesn't walk across
    // individual symlinked children, an entire symlinked *root* would
    // still traverse a foreign filesystem. A non-existent root is a
    // no-op; any other error is counted and surfaced.
    let meta = match std::fs::symlink_metadata(dir) {
        Ok(m) => m,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return stats,
        Err(_) => {
            stats.errors += 1;
            return stats;
        }
    };
    if meta.file_type().is_symlink() {
        // Refuse to clear when the root itself is a symlink — we'd be
        // operating on whatever lives at the target, which may be far
        // outside the cache directory the user thinks they're wiping.
        stats.errors += 1;
        return stats;
    }
    clear_recursive(dir, &mut stats);
    stats
}

fn clear_recursive(dir: &std::path::Path, stats: &mut CacheClearStats) {
    let entries = match std::fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => {
            stats.errors += 1;
            return;
        }
    };
    // Intentionally NOT using `.flatten()`, which would silently swallow
    // Err iterator items and under-report failures. The doc comment on
    // `clear_cache_dir` promises unreadable entries count as errors,
    // so we match each entry explicitly.
    for entry_result in entries {
        let entry = match entry_result {
            Ok(e) => e,
            Err(_) => {
                stats.errors += 1;
                continue;
            }
        };
        let path = entry.path();
        // Use `entry.file_type()` (never follows symlinks, cross-platform)
        // before any call to `std::fs::metadata`, which DOES follow
        // symlinks and could otherwise make a link-to-directory look
        // like a real directory and cause us to recurse outside the
        // cache — the exact scenario this branch is guarding against.
        let file_type = match entry.file_type() {
            Ok(t) => t,
            Err(_) => {
                stats.errors += 1;
                continue;
            }
        };
        if file_type.is_symlink() {
            // Remove the link itself; never traverse into its target.
            if std::fs::remove_file(&path).is_err() {
                stats.errors += 1;
            }
            continue;
        }
        if file_type.is_dir() {
            clear_recursive(&path, stats);
            // `remove_dir` only succeeds once the directory is empty;
            // if a nested clear left something behind that's already
            // reflected in `errors` so we just note another failure.
            if std::fs::remove_dir(&path).is_err() {
                stats.errors += 1;
            }
            continue;
        }
        if file_type.is_file() {
            // Only look up size *after* confirming this is a regular
            // file — symlink_metadata avoids accidentally resolving
            // anything surprising between the type check and the read.
            let size = std::fs::symlink_metadata(&path)
                .map(|m| m.len())
                .unwrap_or(0);
            match std::fs::remove_file(&path) {
                Ok(()) => {
                    stats.files_deleted += 1;
                    stats.bytes_freed += size;
                }
                Err(_) => stats.errors += 1,
            }
        }
    }
}

/// Clear every cached elevation tile across all providers. The root
/// cache directory itself is left in place.
pub fn clear_all_cached_tiles() -> CacheClearStats {
    clear_cache_dir(&get_base_cache_dir())
}

/// Stamp file marking the last started sweep; throttles startup sweeps.
const CLEANUP_STAMP_FILE: &str = ".last-cleanup";

/// Minimum interval between age-based sweeps.
const CLEANUP_INTERVAL_SECS: u64 = 24 * 60 * 60;

/// True when no sweep ran within the throttle interval. Touches the stamp
/// when due so concurrent launches don't double-sweep.
fn sweep_due(base_dir: &std::path::Path, now: std::time::SystemTime) -> bool {
    let stamp = base_dir.join(CLEANUP_STAMP_FILE);
    match std::fs::symlink_metadata(&stamp) {
        Ok(meta) if meta.file_type().is_symlink() => {
            // Never write through a symlinked stamp; replace it.
            let _ = std::fs::remove_file(&stamp);
        }
        Ok(meta) if meta.is_file() => {
            if let Ok(modified) = meta.modified() {
                if let Ok(age) = now.duration_since(modified) {
                    if age.as_secs() < CLEANUP_INTERVAL_SECS {
                        return false;
                    }
                }
                // Future-dated stamp (clock rollback) falls through and is rewritten.
            }
        }
        _ => {}
    }
    // Unwritable stamp means the sweep could not delete anything either;
    // skip instead of walking the cache on every launch.
    std::fs::write(&stamp, b"").is_ok()
}

/// Runs the age-based sweep on a detached background thread, at most once
/// per day. Startup must not block on the cache walk (large warm caches
/// took seconds before the window appeared).
pub fn spawn_throttled_cleanup() {
    let base_dir = get_base_cache_dir();
    match std::fs::symlink_metadata(&base_dir) {
        Ok(m) if m.is_dir() && !m.file_type().is_symlink() => {}
        _ => return,
    }
    if !sweep_due(&base_dir, std::time::SystemTime::now()) {
        return;
    }
    std::thread::spawn(cleanup_old_cached_files);
}

/// Cleans up old cached files from all provider cache directories.
/// Only deletes files older than TILE_CACHE_MAX_AGE_DAYS.
pub fn cleanup_old_cached_files() {
    let base_dir = get_base_cache_dir();

    // Mirror the `clear_cache_dir` safety check: refuse to walk when
    // the root is itself a symlink, since `read_dir` would follow it
    // out of the cache root. Missing directory is a silent no-op (the
    // startup path runs this best-effort on every launch).
    let meta = match std::fs::symlink_metadata(&base_dir) {
        Ok(m) => m,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return,
        Err(e) => {
            eprintln!("Warning: cannot stat cache dir {}: {e}", base_dir.display());
            return;
        }
    };
    if !meta.is_dir() || meta.file_type().is_symlink() {
        return;
    }

    let max_age = std::time::Duration::from_secs(TILE_CACHE_MAX_AGE_DAYS * 24 * 60 * 60);
    let now = std::time::SystemTime::now();
    let mut deleted_count = 0;
    let mut error_count = 0;

    // Walk all files in the cache directory tree
    cleanup_dir_recursive(
        &base_dir,
        max_age,
        now,
        &mut deleted_count,
        &mut error_count,
    );

    if deleted_count > 0 {
        println!(
            "Cleaned up {deleted_count} old cached elevation files (older than {TILE_CACHE_MAX_AGE_DAYS} days)"
        );
    }
    if error_count > 1 {
        eprintln!("Warning: Failed to delete {error_count} old cached files");
    }
}

fn cleanup_dir_recursive(
    dir: &std::path::Path,
    max_age: std::time::Duration,
    now: std::time::SystemTime,
    deleted_count: &mut u32,
    error_count: &mut u32,
) {
    let entries = match std::fs::read_dir(dir) {
        Ok(entries) => entries,
        Err(_) => return,
    };

    // Same reasoning as `clear_recursive`: `DirEntry::file_type()`
    // never follows symlinks on any platform, while `Path::is_dir()` /
    // `is_file()` DO. Following a symlink here could make a link-to-
    // directory look like a real directory and cause us to age-delete
    // files outside the cache root entirely.
    for entry_result in entries {
        let entry = match entry_result {
            Ok(e) => e,
            Err(_) => continue,
        };
        let path = entry.path();
        let file_type = match entry.file_type() {
            Ok(t) => t,
            Err(_) => continue,
        };

        if file_type.is_symlink() {
            // Don't touch symlinks from the aging-cleanup path. The
            // explicit "Clear Tile Cache" button is the one place we
            // remove cache entries that happen to be links; from here
            // it's safer to leave them alone.
            continue;
        }

        if file_type.is_dir() {
            cleanup_dir_recursive(&path, max_age, now, deleted_count, error_count);
            continue;
        }

        if !file_type.is_file() {
            continue;
        }

        let metadata = match std::fs::symlink_metadata(&path) {
            Ok(m) => m,
            Err(_) => continue,
        };

        let modified = match metadata.modified() {
            Ok(time) => time,
            Err(_) => continue,
        };

        let age = match now.duration_since(modified) {
            Ok(duration) => duration,
            Err(_) => continue,
        };

        if age > max_age {
            match std::fs::remove_file(&path) {
                Ok(()) => *deleted_count += 1,
                Err(e) => {
                    if *error_count == 0 {
                        eprintln!(
                            "Warning: Failed to delete old cached file {}: {e}",
                            path.display()
                        );
                    }
                    *error_count += 1;
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sweep_due_without_stamp_then_throttled() {
        let tmp = tempfile::tempdir().unwrap();
        let now = std::time::SystemTime::now();
        assert!(sweep_due(tmp.path(), now));
        assert!(tmp.path().join(CLEANUP_STAMP_FILE).is_file());
        let shortly_after = now + std::time::Duration::from_secs(60);
        assert!(!sweep_due(tmp.path(), shortly_after));
    }

    #[test]
    fn sweep_due_again_after_interval() {
        let tmp = tempfile::tempdir().unwrap();
        let now = std::time::SystemTime::now();
        assert!(sweep_due(tmp.path(), now));
        let later = now + std::time::Duration::from_secs(CLEANUP_INTERVAL_SECS + 60);
        assert!(sweep_due(tmp.path(), later));
    }

    #[test]
    fn sweep_due_replaces_symlinked_stamp() {
        let tmp = tempfile::tempdir().unwrap();
        let target = tmp.path().join("target");
        std::fs::write(&target, b"x").unwrap();
        #[cfg(unix)]
        std::os::unix::fs::symlink(&target, tmp.path().join(CLEANUP_STAMP_FILE)).unwrap();
        let now = std::time::SystemTime::now();
        assert!(sweep_due(tmp.path(), now));
        let meta = std::fs::symlink_metadata(tmp.path().join(CLEANUP_STAMP_FILE)).unwrap();
        assert!(meta.is_file());
        assert!(!meta.file_type().is_symlink());
    }

    #[test]
    fn clear_missing_dir_is_noop() {
        let stats = clear_cache_dir(std::path::Path::new("this/path/does/not/exist/ever"));
        assert_eq!(stats.files_deleted, 0);
        assert_eq!(stats.bytes_freed, 0);
        assert_eq!(stats.errors, 0);
    }

    #[test]
    fn clear_populated_dir_counts_and_frees() {
        let tmp = tempfile::tempdir().unwrap();
        let root = tmp.path();
        let sub = root.join("provider");
        std::fs::create_dir_all(&sub).unwrap();
        std::fs::write(sub.join("a.bin"), b"hello").unwrap();
        std::fs::write(sub.join("b.bin"), b"world!").unwrap();
        std::fs::write(root.join("c.bin"), b"x").unwrap();

        let stats = clear_cache_dir(root);
        assert_eq!(stats.files_deleted, 3);
        assert_eq!(stats.bytes_freed, 5 + 6 + 1);
        assert_eq!(stats.errors, 0);
        // Root itself must still exist; only its contents were wiped.
        assert!(root.exists());
        assert!(!sub.exists());
    }

    /// The root directory being a symlink is rejected wholesale, even
    /// if it happens to point at another valid cache-shaped directory.
    /// Regression: prior implementation would have happily `read_dir`ed
    /// the target, which is outside the cache root the caller named.
    /// Symlink creation on Windows usually requires dev-mode / admin,
    /// so this test is Unix-only.
    #[cfg(unix)]
    #[test]
    fn clear_refuses_symlink_root() {
        let tmp = tempfile::tempdir().unwrap();
        let real = tmp.path().join("real");
        std::fs::create_dir(&real).unwrap();
        std::fs::write(real.join("important.txt"), b"dont delete me").unwrap();
        let link = tmp.path().join("link");
        std::os::unix::fs::symlink(&real, &link).unwrap();

        let stats = clear_cache_dir(&link);
        assert_eq!(stats.errors, 1);
        assert_eq!(stats.files_deleted, 0);
        // Target must be untouched.
        assert!(real.join("important.txt").exists());
    }

    /// A symlink must contribute its own size, never the target's, or the
    /// settings panel would report bytes that live outside the cache. Skipped
    /// where the platform will not let a test create a symlink at all.
    #[test]
    fn a_symlink_is_counted_but_not_followed() {
        let base = std::env::temp_dir().join(format!("arnis-symsize-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&base);
        let outside = base.join("outside");
        let counted = base.join("counted");
        std::fs::create_dir_all(&outside).unwrap();
        std::fs::create_dir_all(&counted).unwrap();

        let target = outside.join("big.bin");
        std::fs::write(&target, vec![0u8; 100_000]).unwrap();
        std::fs::write(counted.join("small.bin"), vec![0u8; 1_000]).unwrap();

        let link = counted.join("link.bin");
        #[cfg(windows)]
        let made = std::os::windows::fs::symlink_file(&target, &link).is_ok();
        #[cfg(unix)]
        let made = std::os::unix::fs::symlink(&target, &link).is_ok();
        if !made {
            let _ = std::fs::remove_dir_all(&base);
            return; // no privilege to create one here
        }

        let total = dir_size_bytes(&counted);
        let _ = std::fs::remove_dir_all(&base);
        assert!(
            total < 100_000,
            "the link's 100 kB target was counted: {total} bytes"
        );
    }
}
