//! World editor module for generating Minecraft worlds.
//!
//! This module provides the `WorldEditor` struct which handles block placement
//! and world saving in both Java Edition (Anvil) and Bedrock Edition (.mcworld) formats.
//!
//! # Module Structure
//!
//! - `common` - Shared data structures for world modification
//! - `java` - Java Edition Anvil format saving
//! - `bedrock` - Bedrock Edition .mcworld format saving

pub(crate) mod common;
pub(crate) mod java;
mod luanti;

pub mod bedrock;

pub(crate) use common::WorldToModify;
#[cfg(test)]
pub(crate) use common::FLOOR_TEST_LOCK;
pub use common::{
    base_chunk_block, base_chunk_y, min_y, set_base_chunk_block, set_base_chunk_y,
    set_terrain_floor_y, set_world_bounds, terrain_floor_y, world_max_y, world_section_range,
    DEFAULT_MAX_Y, DEFAULT_MIN_Y,
};
pub(crate) use common::{
    reset_section_counters, section_counters, BlockStorage, RegionToModify, SectionToModify,
};

pub(crate) use bedrock::{BedrockSaveError, BedrockWriter};

use crate::block_definitions::*;
use crate::coordinate_system::cartesian::{XZBBox, XZPoint};
use crate::coordinate_system::geographic::LLBBox;
use crate::ground::Ground;
use crate::luanti_block_map::LuantiGame;
use crate::progress::emit_gui_progress_update;
use colored::Colorize;
use fastnbt::{IntArray, Value};
use fnv::{FnvHashMap, FnvHashSet};
use serde::Serialize;
use std::collections::{hash_map::Entry, HashMap};
use std::fs::File;
use std::io::Write;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};

#[cfg(feature = "gui")]
use crate::progress::emit_gui_error;
#[cfg(feature = "gui")]
use crate::telemetry::{send_log, LogLevel};

/// Walks the error chain to determine whether a save failure was caused by
/// insufficient disk space.
///
/// Source chain entries (`err.source()` returns `&(dyn Error + 'static)`) are
/// inspected via `io::Error` downcast, checking `ErrorKind::StorageFull` (stable
/// since Rust 1.83) and raw OS error codes (112 = Windows `ERROR_DISK_FULL`,
/// 28 = Unix `ENOSPC`). The top-level error and any entries that cannot be
/// downcast to `io::Error` use Display substring matching as fallback (handles
/// wrappers like `fastanvil::RegionError` that forward the OS message in their
/// Display string but do not expose `io::Error` in the source chain).
fn is_disk_full_error(err: &dyn std::error::Error) -> bool {
    // Fallback string check on the top-level error, which may not be downcastable
    // without a 'static bound on the parameter.
    let s = err.to_string();
    if s.contains("os error 112") || s.contains("os error 28") || s.contains("StorageFull") {
        return true;
    }

    // Walk the source chain. source() yields &(dyn Error + 'static), which
    // allows downcasting to concrete types via the inherent downcast_ref method.
    let mut source = err.source();
    while let Some(e) = source {
        // Primary: downcast to io::Error for structured ErrorKind / OS code checks.
        if let Some(io_err) = e.downcast_ref::<std::io::Error>() {
            if io_err.kind() == std::io::ErrorKind::StorageFull {
                return true;
            }
            if matches!(io_err.raw_os_error(), Some(112) | Some(28)) {
                return true;
            }
        }
        // Fallback: string check for wrappers that don't expose io::Error directly.
        let s = e.to_string();
        if s.contains("os error 112") || s.contains("os error 28") || s.contains("StorageFull") {
            return true;
        }
        source = e.source();
    }

    false
}

/// Ground cover a sign may hang in front of. Matched exactly: `grass_block`, `snow_block`
/// and `flower_pot` are solid despite reading like plants.
fn is_passable_cover(name: &str) -> bool {
    matches!(
        name,
        "grass"
            | "short_grass"
            | "tall_grass"
            | "fern"
            | "large_fern"
            | "dead_bush"
            | "seagrass"
            | "tall_seagrass"
            | "snow"
            | "dandelion"
            | "poppy"
            | "blue_orchid"
            | "azure_bluet"
            | "cornflower"
            | "oxeye_daisy"
            | "allium"
            | "lily_of_the_valley"
            | "sweet_berry_bush"
            | "sunflower"
            | "lilac"
            | "rose_bush"
            | "peony"
            | "brown_mushroom"
            | "red_mushroom"
            | "sugar_cane"
            | "lily_pad"
    ) || name.ends_with("_carpet")
        || name.ends_with("_tulip")
}

/// Quotes `s` as a JSON string literal for a sign text component.
fn json_string(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

/// One placed item frame, as read back by tests.
#[cfg(test)]
pub struct PlacedFrame {
    pub x: i32,
    pub y: i32,
    pub z: i32,
    pub map_id: i32,
}

/// World format to generate
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[allow(dead_code)]
pub enum WorldFormat {
    /// Java Edition Anvil format (.mca region files)
    JavaAnvil,
    /// Bedrock Edition .mcworld format
    BedrockMcWorld,
    /// Luanti/Minetest world (map.sqlite)
    LuantiWorld,
}

/// Metadata saved with the world
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct WorldMetadata {
    pub min_mc_x: i32,
    pub max_mc_x: i32,
    pub min_mc_z: i32,
    pub max_mc_z: i32,

    pub min_geo_lat: f64,
    pub max_geo_lat: f64,
    pub min_geo_lon: f64,
    pub max_geo_lon: f64,

    /// Projection mode used for coordinate mapping ("local" or "web_mercator")
    pub projection: String,
    /// World scale in blocks per meter
    pub scale: f64,
}

/// The main world editor struct for placing blocks and saving worlds.
///
/// The lifetime `'a` is tied to the `XZBBox` reference, which defines
/// the world boundaries and must outlive the WorldEditor instance.
pub struct WorldEditor<'a> {
    world_dir: PathBuf,
    world: WorldToModify,
    xzbbox: &'a XZBBox,
    llbbox: LLBBox,
    ground: Option<Arc<Ground>>,
    /// Loaded region tree pack (None = procedural); shared via Arc across main + tile editors.
    tree_pack: Option<Arc<crate::trees::region::RegionLibrary>>,
    /// Columns owned by a man-made ground cover (roads, paths, pitches, courts,
    /// parking); vegetation stays off them. Shared via Arc with the tile editors.
    sealed_surface: Option<Arc<crate::floodfill_cache::SealedSurfaceBitmap>>,
    /// Mapped tree trunks, shared via Arc with the tile editors.
    mapped_trunks: Option<Arc<crate::trees::mapped::MappedTrunks>>,
    format: WorldFormat,
    /// Per-cell overrides for the effective "ground surface" Y returned by
    /// `get_ground_level` / `get_absolute_y`. Roads that flatten their
    /// cross-section register their chosen Y here so that the later
    /// `ground_generation` pass builds the surface at the road's level —
    /// producing a natural-looking embankment on the low side and a cut on
    /// the high side rather than a floating strip with cliffs at the edges.
    ///
    /// Uses FNV hashing (not SipHash): `get_ground_level` sits on a hot
    /// path (called per-block during placement), so the hash cost matters.
    road_surface_overrides: FnvHashMap<(i32, i32), i32>,
    /// Bridge pier columns and their material, extended to the bed by the water carve.
    support_columns: FnvHashMap<(i32, i32), Block>,
    /// Regions already streamed to disk and evicted; writes to them are dropped
    /// by the set_block guard so eviction can't be resurrected (stream-to-disk).
    flushed_regions: FnvHashSet<(i32, i32)>,
    /// Origin coordinates for ground-level elevation lookups. Defaults to
    /// `xzbbox.min_x()/min_z()`. Tile editors used by the parallel
    /// data-processing path override these to the *main* world's xzbbox
    /// origin so the shared `Ground` elevation grid is indexed correctly
    /// even though each tile has its own (haloed) xzbbox.
    ground_origin_x: i32,
    ground_origin_z: i32,
    /// Projection mode used for this generation ("local" or "web_mercator").
    projection: String,
    /// World scale in blocks per meter.
    scale: f64,
    bedrock_level_name: Option<String>,
    bedrock_spawn_point: Option<(i32, i32)>,
    bedrock_extend_height: bool,
    /// Optional level name for Luanti worlds
    luanti_level_name: Option<String>,
    /// Optional spawn point for Luanti worlds (x, z coordinates)
    luanti_spawn_point: Option<(i32, i32)>,
    /// Ground level for Luanti worlds
    luanti_ground_level: i32,
    /// Luanti game pack
    luanti_game: LuantiGame,
    /// Bake per-chunk lighting (Java) for off-disk LOD renderers; off by default.
    bake_lighting: bool,
    /// Java: leave every chunk outside the area unwritten for the void generator,
    /// instead of filling it with the flat ground plane.
    void_world: bool,
    /// Pre-generated voxy LOD cache, fed as regions are saved/flushed. Java only.
    voxy: Option<Arc<crate::voxy::VoxyWriter>>,
    /// Place bundled schematic props (cars, boats, cranes, ...); off drops them all.
    /// Driven by the same toggle as external 3D models (`args.use_3d`).
    place_schematics: bool,
    /// Map preview accumulator, fed as regions are saved/flushed.
    preview: Option<Arc<crate::map_renderer::PreviewAccumulator>>,
    game_mode: crate::args::GameMode,
    world_time: i64,
    /// Bedrock only: give the player a starting map that reveals the world as they explore.
    start_with_map: bool,
    /// Place bundled map image decals as map item frames. Java only.
    map_decals: bool,
    /// Signage context (decal registry, styles, intersections); shared with tile editors.
    signage: Option<Arc<crate::element_processing::signage::SignageContext>>,
    /// Strict (non-halo) bounds of a tile editor: min_x, min_z, max_x, max_z inclusive.
    /// None for the main editor, which owns everything.
    strict_bounds: Option<(i32, i32, i32, i32)>,
    /// Cells holding a decal frame. Frames are entities, so `set_block` reads them as empty.
    frame_cells: FnvHashSet<(i32, i32, i32)>,
    /// Set for a One World run: merge into the world's existing regions.
    merge_into_existing: Option<crate::world_utils::WorldLayout>,
    climate_anchor: Option<(f64, f64)>,
    metadata_extent: Option<(XZBBox, LLBBox)>,
}

impl<'a> WorldEditor<'a> {
    /// Creates a new WorldEditor with Java Anvil format (default).
    ///
    /// This is the default constructor used by CLI mode.
    #[allow(dead_code)]
    pub fn new(world_dir: PathBuf, xzbbox: &'a XZBBox, llbbox: LLBBox) -> Self {
        Self {
            world_dir,
            world: WorldToModify::default(),
            xzbbox,
            llbbox,
            ground: None,
            tree_pack: None,
            sealed_surface: None,
            mapped_trunks: None,
            format: WorldFormat::JavaAnvil,
            road_surface_overrides: FnvHashMap::default(),
            support_columns: FnvHashMap::default(),
            flushed_regions: FnvHashSet::default(),
            ground_origin_x: xzbbox.min_x(),
            ground_origin_z: xzbbox.min_z(),
            projection: "local".to_string(),
            scale: 1.0,
            bedrock_level_name: None,
            bedrock_spawn_point: None,
            bedrock_extend_height: false,
            luanti_level_name: None,
            luanti_spawn_point: None,
            luanti_ground_level: -62,
            luanti_game: LuantiGame::Mineclonia,
            bake_lighting: false,
            void_world: false,
            place_schematics: true,
            preview: None,
            voxy: None,
            game_mode: crate::args::GameMode::Creative,
            world_time: 6000,
            start_with_map: false,
            map_decals: false,
            signage: None,
            strict_bounds: None,
            frame_cells: FnvHashSet::default(),
            merge_into_existing: None,
            climate_anchor: None,
            metadata_extent: None,
        }
    }

    /// Creates a new WorldEditor with a specific format and optional level name.
    #[allow(dead_code)]
    pub fn new_with_format_and_name(
        world_dir: PathBuf,
        xzbbox: &'a XZBBox,
        llbbox: LLBBox,
        format: WorldFormat,
        bedrock_level_name: Option<String>,
        bedrock_spawn_point: Option<(i32, i32)>,
        bedrock_extend_height: bool,
    ) -> Self {
        Self {
            world_dir,
            world: WorldToModify::default(),
            xzbbox,
            llbbox,
            ground: None,
            tree_pack: None,
            sealed_surface: None,
            mapped_trunks: None,
            format,
            road_surface_overrides: FnvHashMap::default(),
            support_columns: FnvHashMap::default(),
            flushed_regions: FnvHashSet::default(),
            ground_origin_x: xzbbox.min_x(),
            ground_origin_z: xzbbox.min_z(),
            projection: "local".to_string(),
            scale: 1.0,
            bedrock_level_name,
            bedrock_spawn_point,
            bedrock_extend_height,
            luanti_level_name: None,
            luanti_spawn_point: None,
            luanti_ground_level: -62,
            luanti_game: LuantiGame::Mineclonia,
            bake_lighting: false,
            void_world: false,
            place_schematics: true,
            preview: None,
            voxy: None,
            game_mode: crate::args::GameMode::Creative,
            world_time: 6000,
            start_with_map: false,
            map_decals: false,
            signage: None,
            strict_bounds: None,
            frame_cells: FnvHashSet::default(),
            merge_into_existing: None,
            climate_anchor: None,
            metadata_extent: None,
        }
    }

    /// Creates a new WorldEditor configured for Luanti output.
    #[allow(dead_code)]
    pub fn new_luanti(
        world_dir: PathBuf,
        xzbbox: &'a XZBBox,
        llbbox: LLBBox,
        game: LuantiGame,
        level_name: Option<String>,
        spawn_point: Option<(i32, i32)>,
        ground_level: i32,
    ) -> Self {
        Self {
            world_dir,
            world: WorldToModify::default(),
            xzbbox,
            llbbox,
            ground: None,
            tree_pack: None,
            sealed_surface: None,
            mapped_trunks: None,
            format: WorldFormat::LuantiWorld,
            road_surface_overrides: FnvHashMap::default(),
            support_columns: FnvHashMap::default(),
            flushed_regions: FnvHashSet::default(),
            ground_origin_x: xzbbox.min_x(),
            ground_origin_z: xzbbox.min_z(),
            projection: "local".to_string(),
            scale: 1.0,
            bedrock_level_name: None,
            bedrock_spawn_point: None,
            bedrock_extend_height: false,
            luanti_level_name: level_name,
            luanti_spawn_point: spawn_point,
            luanti_ground_level: ground_level,
            luanti_game: game,
            bake_lighting: false,
            void_world: false,
            place_schematics: true,
            preview: None,
            voxy: None,
            game_mode: crate::args::GameMode::Creative,
            world_time: 6000,
            start_with_map: false,
            map_decals: false,
            signage: None,
            strict_bounds: None,
            frame_cells: FnvHashSet::default(),
            merge_into_existing: None,
            climate_anchor: None,
            metadata_extent: None,
        }
    }

    pub fn set_merge_into_existing(&mut self, layout: crate::world_utils::WorldLayout) {
        self.merge_into_existing = Some(layout);
    }

    pub fn set_climate_anchor(&mut self, lat: f64, lon: f64) {
        self.climate_anchor = Some((lat, lon));
    }

    pub fn set_metadata_extent(&mut self, xzbbox: XZBBox, llbbox: LLBBox) {
        self.metadata_extent = Some((xzbbox, llbbox));
    }

    pub(crate) fn climate_lat(&self) -> Option<f64> {
        self.climate_anchor.map(|(lat, _)| lat)
    }

    pub(crate) fn region_write_mode(&self) -> java::RegionWriteMode {
        match self.merge_into_existing {
            Some(layout) => java::RegionWriteMode::Merge {
                min_x: self.xzbbox.min_x(),
                min_z: self.xzbbox.min_z(),
                max_x: self.xzbbox.max_x(),
                max_z: self.xzbbox.max_z(),
                layout,
            },
            None => java::RegionWriteMode::Fresh,
        }
    }

    /// Set the projection and scale metadata for this world.
    pub fn set_projection_info(&mut self, projection: &str, scale: f64) {
        self.projection = projection.to_string();
        self.scale = scale;
    }

    /// World scale in blocks per meter.
    pub fn scale(&self) -> f64 {
        self.scale
    }

    /// Override the ground lookup origin for tile editors.
    ///
    /// By default, ground lookups subtract `xzbbox.min_x/z()`. Tile editors
    /// must call this with the *main* world's xzbbox origin so the shared
    /// elevation grid is indexed correctly.
    pub fn set_ground_origin(&mut self, origin_x: i32, origin_z: i32) {
        self.ground_origin_x = origin_x;
        self.ground_origin_z = origin_z;
    }

    /// Sets the ground reference for elevation-based block placement
    pub fn set_ground(&mut self, ground: Arc<Ground>) {
        self.ground = Some(ground);
    }

    /// Sets the loaded region tree pack (shared across the main and tile editors).
    pub fn set_tree_pack(&mut self, pack: Arc<crate::trees::region::RegionLibrary>) {
        self.tree_pack = Some(pack);
    }

    /// The loaded region tree pack, if any (a cheap Arc clone so the editor borrow is freed).
    pub fn tree_pack(&self) -> Option<Arc<crate::trees::region::RegionLibrary>> {
        self.tree_pack.clone()
    }

    /// Sets the sealed-surface mask (shared across the main and tile editors).
    pub fn set_sealed_surface(&mut self, mask: Arc<crate::floodfill_cache::SealedSurfaceBitmap>) {
        self.sealed_surface = Some(mask);
    }

    /// Drops the sealed-surface mask and the mapped trunks once every vegetation
    /// pass is done, so neither is carried into the save phase.
    pub fn release_sealed_surface(&mut self) {
        self.sealed_surface = None;
        self.mapped_trunks = None;
    }

    /// Sets the mapped tree trunks (shared across the main and tile editors).
    pub fn set_mapped_trunks(&mut self, trunks: Arc<crate::trees::mapped::MappedTrunks>) {
        self.mapped_trunks = Some(trunks);
    }

    /// True under the crown of a tree OSM maps.
    #[inline]
    pub fn under_mapped_crown(&self, x: i32, z: i32) -> bool {
        self.mapped_trunks
            .as_ref()
            .is_some_and(|t| t.under_crown(x, z))
    }

    /// On a paving area's own columns: true where a planted area mapped inside it
    /// owns the column.
    #[inline]
    pub fn nested_area_owns(&self, x: i32, z: i32) -> bool {
        self.sealed_surface
            .as_ref()
            .is_some_and(|m| !m.contains(x, z))
    }

    /// True if a man-made surface owns this column, so scattered vegetation
    /// would land on a road, a pitch or a parking lot.
    #[inline]
    pub fn surface_is_sealed(&self, x: i32, z: i32) -> bool {
        self.sealed_surface
            .as_ref()
            .is_some_and(|m| m.contains(x, z))
    }

    /// ESA land-cover class at (x, z), or 0 where there is no land cover.
    #[inline]
    pub fn cover_class(&self, x: i32, z: i32) -> u8 {
        self.ground
            .as_ref()
            .map_or(0, |g| g.cover_class(self.ground_point(x, z)))
    }

    /// RESOLVE ecoregion at (x, z), if the area has one there.
    #[inline]
    pub fn ecoregion(&self, x: i32, z: i32) -> Option<crate::ecoregion::Ecoregion> {
        self.ground.as_ref()?.ecoregion(self.ground_point(x, z))
    }

    /// True where the land cover keeps (x, z) as land too steep to hold water, like a gorge wall.
    pub fn is_steep_land(&self, x: i32, z: i32) -> bool {
        self.ground.as_ref().is_some_and(|g| {
            let p = self.ground_point(x, z);
            let cover = g.cover_class(p);
            cover != 0 && cover != crate::land_cover::LC_WATER && g.slope(p) > 4
        })
    }

    /// True if (x, z) is an ESA land-cover water cell (predicts water carved after trees).
    pub fn is_lc_water(&self, x: i32, z: i32) -> bool {
        self.ground.as_ref().is_some_and(|g| {
            g.cover_class(crate::coordinate_system::cartesian::XZPoint::new(
                x - self.ground_origin_x,
                z - self.ground_origin_z,
            )) == crate::land_cover::LC_WATER
        })
    }

    /// Whether land cover backs a speculative tree at (x, z), one no tag claims.
    /// Tags that do assert trees, like `landuse=forest`, are authoritative and
    /// must not consult this. True without land cover, so those worlds are unchanged.
    pub fn land_cover_backs_trees(&self, x: i32, z: i32) -> bool {
        let Some(ground) = self.ground.as_ref() else {
            return true;
        };
        let coord = self.ground_point(x, z);
        // A measured crown settles it. The tree-cover class is roughly twice as
        // wide as reality, so it only answers where nothing was measured.
        if ground.has_canopy() {
            if let Some(h) = ground.canopy_height_m(coord) {
                return h >= crate::canopy::CANOPY_MIN_M;
            }
        }
        if !ground.has_land_cover() {
            return true;
        }
        matches!(
            ground.cover_class(coord),
            crate::land_cover::LC_TREE_COVER | crate::land_cover::LC_SHRUBLAND
        )
    }

    /// World (x, z) as a point on the shared `Ground` grid.
    #[inline(always)]
    fn ground_point(&self, x: i32, z: i32) -> crate::coordinate_system::cartesian::XZPoint {
        crate::coordinate_system::cartesian::XZPoint::new(
            x - self.ground_origin_x,
            z - self.ground_origin_z,
        )
    }

    /// Side of the lattice cell that holds at most one trunk.
    #[inline(always)]
    pub fn tree_slot_spacing(&self) -> i32 {
        self.tree_pack.as_ref().map_or(5, |p| p.base_spacing())
    }

    /// Size tier the measured canopy asks for at this column, if it was measured.
    pub fn canopy_size_hint(&self, x: i32, z: i32) -> Option<crate::trees::tree_library::TreeSize> {
        let h = self
            .ground
            .as_ref()?
            .canopy_height_m(self.ground_point(x, z))?;
        (h >= crate::canopy::CANOPY_MIN_M).then(|| crate::trees::tree_library::size_for_canopy_m(h))
    }

    /// ESA distance-to-shore (BFS capped at 15): 0 = non-water or open water past the
    /// cap, 1 = shore, 2..=15 = inward. So `is_lc_water && distance == 0` is the deep
    /// interior of a large body, never a narrow river.
    pub fn water_distance(&self, x: i32, z: i32) -> u8 {
        self.ground.as_ref().map_or(0, |g| {
            g.water_distance(crate::coordinate_system::cartesian::XZPoint::new(
                x - self.ground_origin_x,
                z - self.ground_origin_z,
            ))
        })
    }

    /// Enables baking per-chunk lighting into Java chunks.
    pub fn set_bake_lighting(&mut self, enabled: bool) {
        self.bake_lighting = enabled;
    }

    /// Java: write only the chunks the area touches and leave the rest to a void generator.
    pub fn set_void_world(&mut self, enabled: bool) {
        self.void_world = enabled;
    }

    pub fn set_game_settings(&mut self, mode: crate::args::GameMode, world_time: i64) {
        self.game_mode = mode;
        self.world_time = world_time;
    }

    /// Bedrock only: enable the starting map that reveals the world as the player explores.
    pub fn set_start_with_map(&mut self, enabled: bool) {
        self.start_with_map = enabled;
    }

    /// Enable map image decals (Java only).
    pub fn set_map_decals(&mut self, enabled: bool) {
        self.map_decals = enabled;
    }

    /// Attach the signage context (decal registry, styles, intersections).
    pub fn set_signage(&mut self, ctx: Arc<crate::element_processing::signage::SignageContext>) {
        self.signage = Some(ctx);
    }

    /// Strict bounds of a tile editor (inclusive), used by placements that must run in
    /// exactly one tile even though the element is processed by every tile it overlaps.
    pub fn set_strict_bounds(&mut self, min_x: i32, min_z: i32, max_x: i32, max_z: i32) {
        self.strict_bounds = Some((min_x, min_z, max_x, max_z));
    }

    /// True if this editor is the single owner of (x, z): always for the main editor, and
    /// inside the strict tile bounds for a tile editor.
    #[inline]
    pub fn owns(&self, x: i32, z: i32) -> bool {
        match self.strict_bounds {
            None => true,
            Some((min_x, min_z, max_x, max_z)) => {
                x >= min_x && x <= max_x && z >= min_z && z <= max_z
            }
        }
    }

    /// The signage context, if decals are enabled and a registry was built.
    pub fn signage(&self) -> Option<Arc<crate::element_processing::signage::SignageContext>> {
        if !self.map_decals {
            return None;
        }
        self.signage.clone()
    }

    /// Decals are locked maps in item frames, which only Java reads. Bedrock and Luanti
    /// never build a registry, so every handler is skipped.
    #[inline]
    pub fn signage_enabled(&self) -> bool {
        self.map_decals && self.signage.is_some()
    }

    /// Cell the frame occupies for a decal on the given face of block (bx, abs_y, bz).
    /// facing: 0=down, 1=up, 2=north, 3=south, 4=west, 5=east.
    fn decal_frame_cell(bx: i32, abs_y: i32, bz: i32, facing: i8) -> (i32, i32, i32) {
        match facing {
            0 => (bx, abs_y - 1, bz),
            1 => (bx, abs_y + 1, bz),
            3 => (bx, abs_y, bz + 1),
            4 => (bx - 1, abs_y, bz),
            5 => (bx + 1, abs_y, bz),
            _ => (bx, abs_y, bz - 1),
        }
    }

    /// True if the cell holds nothing a sign could not sit in front of (air, plants, snow).
    pub fn cell_open_at(&self, x: i32, abs_y: i32, z: i32) -> bool {
        self.cell_is_open(x, abs_y, z)
    }

    /// True if a decal frame already hangs here.
    pub fn cell_has_frame(&self, x: i32, abs_y: i32, z: i32) -> bool {
        !self.frame_cells.is_empty() && self.frame_cells.contains(&(x, abs_y, z))
    }

    /// Whether Java entities (item frame decals, facade panels) are written.
    #[inline]
    pub fn map_decals_enabled(&self) -> bool {
        self.map_decals
    }

    /// True if the cell holds nothing a sign could not sit in front of (air, plants, snow).
    fn cell_is_open(&self, x: i32, abs_y: i32, z: i32) -> bool {
        match self.world.get_block(x, abs_y, z) {
            None => true,
            Some(b) if b == AIR => true,
            Some(b) => is_passable_cover(b.name()),
        }
    }

    /// One map decal. facing 0..=5 (down, up, N, S, W, E), rotation in eighth turns.
    /// False when the frame cell is inside terrain, or a block if `require_air`.
    #[allow(clippy::too_many_arguments)]
    pub fn place_map_decal_ex(
        &mut self,
        bx: i32,
        abs_y: i32,
        bz: i32,
        facing: i8,
        map_id: i32,
        rotation: i8,
        glow: bool,
        require_air: bool,
    ) -> bool {
        let (fx, fy, fz) = Self::decal_frame_cell(bx, abs_y, bz, facing);
        if !self.xzbbox.contains(&XZPoint::new(fx, fz)) || self.is_region_flushed(fx, fz) {
            return false;
        }

        // Skip a face whose cell sits in the terrain; that frame would be culled on load.
        let rel_y = fy - self.get_absolute_y(fx, 0, fz);
        if rel_y < 1 {
            return false;
        }
        if require_air && !self.cell_is_open(fx, fy, fz) {
            return false;
        }

        let mut components = HashMap::new();
        components.insert("minecraft:map_id".to_string(), Value::Int(map_id));
        let mut item = HashMap::new();
        item.insert(
            "id".to_string(),
            Value::String("minecraft:filled_map".to_string()),
        );
        item.insert("count".to_string(), Value::Int(1));
        item.insert("components".to_string(), Value::Compound(components));

        let mut extra = HashMap::new();
        extra.insert("Facing".to_string(), Value::Byte(facing));
        extra.insert(
            "ItemRotation".to_string(),
            Value::Byte(rotation.rem_euclid(8)),
        );
        extra.insert("Item".to_string(), Value::Compound(item));
        extra.insert("ItemDropChance".to_string(), Value::Float(0.0));
        extra.insert("Fixed".to_string(), Value::Byte(1));
        extra.insert("Invisible".to_string(), Value::Byte(1));
        extra.insert("TileX".to_string(), Value::Int(fx));
        extra.insert("TileY".to_string(), Value::Int(fy));
        extra.insert("TileZ".to_string(), Value::Int(fz));
        extra.insert(
            "block_pos".to_string(),
            Value::List(vec![Value::Int(fx), Value::Int(fy), Value::Int(fz)]),
        );

        let id = if glow {
            "minecraft:glow_item_frame"
        } else {
            "minecraft:item_frame"
        };
        self.add_entity(id, fx, rel_y, fz, Some(extra));
        self.frame_cells.insert((fx, fy, fz));
        true
    }

    /// One item display entity at an exact position, for the facade photo
    /// panels. Not a hanging entity: it sits wherever `Pos` puts it, which is
    /// a sub-block point off the wall plane, so the caller owns the whole
    /// placement and this only writes it.
    ///
    /// `seed` separates two displays whose `Pos` falls in the same block, which
    /// is all the UUID is built from; two panels meeting at a corner would
    /// otherwise get the same UUID and the game would keep one of them.
    /// `extra` carries the display's own tags. False outside the editor's area
    /// or in a region already flushed to disk.
    pub fn add_item_display(
        &mut self,
        x: f64,
        abs_y: f64,
        z: f64,
        seed: i64,
        mut extra: HashMap<String, Value>,
    ) -> bool {
        let (bx, bz) = (x.floor() as i32, z.floor() as i32);
        if !self.xzbbox.contains(&XZPoint::new(bx, bz)) || self.is_region_flushed(bx, bz) {
            return false;
        }
        // add_entity_seeded works in ground-relative Y and would centre Pos on
        // the block; the exact position goes in as an override.
        let rel_y = abs_y.floor() as i32 - self.get_absolute_y(bx, 0, bz);
        extra.insert(
            "Pos".to_string(),
            Value::List(vec![
                Value::Double(x),
                Value::Double(abs_y),
                Value::Double(z),
            ]),
        );
        self.add_entity_seeded("minecraft:item_display", bx, rel_y, bz, seed, Some(extra));
        true
    }

    /// Every item display currently in the world, as its raw NBT compound.
    #[cfg(test)]
    pub fn item_displays(&self) -> Vec<HashMap<String, Value>> {
        let mut out = Vec::new();
        for region in self.world.regions.values() {
            for chunk in region.chunks.values() {
                let Some(Value::List(entities)) = chunk.other.get("entities") else {
                    continue;
                };
                for entity in entities {
                    let Value::Compound(e) = entity else { continue };
                    if matches!(e.get("id"), Some(Value::String(id)) if id == "minecraft:item_display")
                    {
                        out.push(e.clone());
                    }
                }
            }
        }
        out
    }

    /// Places a registered decal on one face of a block. Multi-tile keys are laid out with
    /// this block behind the viewer's top-left tile; see `place_decal_panel`.
    pub fn place_decal(
        &mut self,
        bx: i32,
        abs_y: i32,
        bz: i32,
        facing: i8,
        key: &crate::decals::DecalKey,
    ) -> bool {
        self.place_decal_panel(bx, abs_y, bz, facing, key, false, false)
    }

    /// A multi-tile decal anchored at the viewer's top-left tile, running right and down.
    /// Nothing is placed unless every tile has an open frame cell.
    #[allow(clippy::too_many_arguments)]
    pub fn place_decal_panel(
        &mut self,
        bx: i32,
        abs_y: i32,
        bz: i32,
        facing: i8,
        key: &crate::decals::DecalKey,
        glow: bool,
        require_hosts: bool,
    ) -> bool {
        let Some(entry) = self.signage().and_then(|s| s.registry.get(key)) else {
            return false;
        };
        let (rx, rz, down_dy, floor_rz) = Self::panel_axes(facing);
        // Every tile must be placeable before any is written.
        for r in 0..entry.rows as i32 {
            for c in 0..entry.cols as i32 {
                let (hx, hy, hz) = if facing <= 1 {
                    (bx + rx * c, abs_y, bz + floor_rz * r)
                } else {
                    (bx + rx * c, abs_y + down_dy * r, bz + rz * c)
                };
                let (fx, fy, fz) = Self::decal_frame_cell(hx, hy, hz, facing);
                if !self.xzbbox.contains(&XZPoint::new(fx, fz)) || self.is_region_flushed(fx, fz) {
                    return false;
                }
                if fy - self.get_absolute_y(fx, 0, fz) < 1 || !self.cell_is_open(fx, fy, fz) {
                    return false;
                }
                if require_hosts && self.cell_is_open(hx, hy, hz) {
                    return false;
                }
            }
        }
        for r in 0..entry.rows as i32 {
            for c in 0..entry.cols as i32 {
                let (hx, hy, hz) = if facing <= 1 {
                    (bx + rx * c, abs_y, bz + floor_rz * r)
                } else {
                    (bx + rx * c, abs_y + down_dy * r, bz + rz * c)
                };
                self.place_map_decal_ex(
                    hx,
                    hy,
                    hz,
                    facing,
                    entry.tile_id(c as u32, r as u32),
                    0,
                    glow,
                    false,
                );
            }
        }
        true
    }

    /// Viewer's right, the Y row step for walls, and the Z row step for floors.
    fn panel_axes(facing: i8) -> (i32, i32, i32, i32) {
        match facing {
            0 | 1 => (1, 0, 0, 1),
            2 => (-1, 0, -1, 0),
            3 => (1, 0, -1, 0),
            4 => (0, 1, -1, 0),
            _ => (0, -1, -1, 0),
        }
    }

    /// Host block behind the viewer's-left tile of a `cols`-wide wall panel centred on
    /// (cx, cz), for a frame `facing` the viewer. Even widths lean toward the viewer's left.
    pub fn panel_left_anchor(cx: i32, cz: i32, facing: i8, cols: i32) -> (i32, i32) {
        let (rx, rz, _, _) = Self::panel_axes(facing);
        let half = (cols - 1) / 2;
        (cx - rx * half, cz - rz * half)
    }

    /// Item frame facing byte for an outward normal snapped to an axis.
    pub fn facing_for_normal(nx: i32, nz: i32) -> i8 {
        if nx.abs() >= nz.abs() {
            if nx >= 0 {
                5
            } else {
                4
            }
        } else if nz >= 0 {
            3
        } else {
            2
        }
    }

    /// Every item frame currently in the world, for tests that check decal placement.
    #[cfg(test)]
    pub fn item_frames(&self) -> Vec<PlacedFrame> {
        let mut out = Vec::new();
        for region in self.world.regions.values() {
            for chunk in region.chunks.values() {
                let Some(Value::List(entities)) = chunk.other.get("entities") else {
                    continue;
                };
                for entity in entities {
                    let Value::Compound(e) = entity else { continue };
                    let is_frame = matches!(e.get("id"), Some(Value::String(id))
                        if id == "minecraft:item_frame" || id == "minecraft:glow_item_frame");
                    if !is_frame {
                        continue;
                    }
                    let int = |k: &str| match e.get(k) {
                        Some(Value::Int(v)) => Some(*v),
                        _ => None,
                    };
                    let map_id = match e.get("Item") {
                        Some(Value::Compound(item)) => match item.get("components") {
                            Some(Value::Compound(c)) => match c.get("minecraft:map_id") {
                                Some(Value::Int(v)) => Some(*v),
                                _ => None,
                            },
                            _ => None,
                        },
                        _ => None,
                    };
                    if let (Some(x), Some(y), Some(z), Some(map_id)) =
                        (int("TileX"), int("TileY"), int("TileZ"), map_id)
                    {
                        out.push(PlacedFrame { x, y, z, map_id });
                    }
                }
            }
        }
        out
    }

    /// Toggle placement of bundled schematic props (cars, boats, cranes, ...).
    pub fn set_place_schematics(&mut self, enabled: bool) {
        self.place_schematics = enabled;
    }

    /// True if bundled schematic props should be placed (see `set_place_schematics`).
    pub fn place_schematics(&self) -> bool {
        self.place_schematics
    }

    /// Returns the current world format
    #[allow(dead_code)]
    pub fn format(&self) -> WorldFormat {
        self.format
    }

    /// Consume the WorldEditor and return the underlying WorldToModify.
    /// Used for tile-based parallel processing where tile results need to be merged.
    pub(crate) fn into_world(self) -> WorldToModify {
        self.world
    }

    /// Deterministic content hash of the world (see `WorldToModify::content_hash`).
    pub fn content_hash(&self) -> u64 {
        self.world.content_hash()
    }

    /// Deterministic hash of one region (see `WorldToModify::region_content_hash`).
    pub fn region_content_hash(&self, rx: i32, rz: i32) -> u64 {
        self.world.region_content_hash(rx, rz)
    }

    /// Region keys currently resident in memory (not yet flushed to disk).
    pub(crate) fn resident_region_keys(&self) -> Vec<(i32, i32)> {
        self.world.regions.keys().copied().collect()
    }

    /// Attach a map preview accumulator, fed as regions are saved/flushed.
    pub fn set_preview(&mut self, preview: Arc<crate::map_renderer::PreviewAccumulator>) {
        self.preview = Some(preview);
    }

    /// Attach a voxy LOD writer, fed alongside the region files and finalized
    /// once every region has been written.
    pub fn set_voxy(&mut self, voxy: Arc<crate::voxy::VoxyWriter>) {
        self.voxy = Some(voxy);
    }

    /// Owned, `Send` context for writing regions off the merge thread.
    pub(crate) fn region_write_ctx(&self) -> java::RegionWriteCtx {
        java::RegionWriteCtx::new(
            self.world_dir.clone(),
            self.llbbox,
            self.ground.clone(),
            self.bake_lighting,
            self.void_world,
            self.preview.clone(),
            self.voxy.clone(),
            self.region_write_mode(),
            self.climate_lat(),
            (self.ground_origin_x, self.ground_origin_z),
        )
    }

    /// Evict one region (stream-to-disk): hand it to the background `worker` for
    /// compaction + serialization, then record it so any later stray write is
    /// dropped by the guard. Only marks the region flushed once the worker has
    /// accepted it; if the handoff fails the region is restored to RAM and the
    /// worker's real write error is surfaced. Java-only; `Ok(true)` if evicted.
    pub(crate) fn flush_region_via(
        &mut self,
        worker: &FlushWorker,
        rx: i32,
        rz: i32,
    ) -> Result<bool, String> {
        if self.format != WorldFormat::JavaAnvil {
            return Ok(false);
        }
        let Some(region) = self.world.regions.remove(&(rx, rz)) else {
            return Ok(false);
        };
        match worker.send(rx, rz, region) {
            Ok(()) => {
                self.flushed_regions.insert((rx, rz));
                Ok(true)
            }
            Err((region, err)) => {
                self.world.regions.insert((rx, rz), region);
                Err(err)
            }
        }
    }

    /// Merge another WorldToModify into this editor's world with authoritative bounds.
    /// Blocks within the authoritative region always overwrite; blocks outside only
    /// write if the target position is currently AIR (empty).
    pub(crate) fn merge_world(
        &mut self,
        other: WorldToModify,
        auth_min_x: i32,
        auth_min_z: i32,
        auth_max_x: i32,
        auth_max_z: i32,
    ) {
        self.world
            .merge(other, auth_min_x, auth_min_z, auth_max_x, auth_max_z);
    }

    /// Calculate the absolute Y position from a ground-relative offset
    #[inline(always)]
    pub fn get_absolute_y(&self, x: i32, y_offset: i32, z: i32) -> i32 {
        self.get_ground_level(x, z) + y_offset
    }

    /// Köppen climate class of the generated area, taken at the bbox centre.
    pub fn climate(&self) -> crate::climate::Climate {
        match self.climate_anchor {
            Some((lat, lon)) => crate::climate::Climate::classify_at(lat, lon),
            None => crate::climate::Climate::classify(&self.llbbox),
        }
    }

    /// Get the effective ground level at a world coordinate.
    ///
    /// Checks the road-surface override map first so that a later
    /// `ground_generation` pass will build terrain matching the road's
    /// flattened cross-section. Falls back to `Ground::level` otherwise.
    ///
    /// The `is_empty` guard matters: this function is called per-block
    /// during element processing, so every element placed before highways
    /// run (most elements in small bboxes, all non-road elements before
    /// priority-ordering kicks highways to the front) would otherwise pay
    /// a hash + bucket-probe per call even though the map is empty.
    #[inline(always)]
    pub fn get_ground_level(&self, x: i32, z: i32) -> i32 {
        if !self.road_surface_overrides.is_empty() {
            if let Some(&y) = self.road_surface_overrides.get(&(x, z)) {
                return y;
            }
        }
        if let Some(ground) = &self.ground {
            ground.level(XZPoint::new(
                x - self.ground_origin_x,
                z - self.ground_origin_z,
            ))
        } else {
            0 // Default ground level if no terrain data
        }
    }

    /// True if no orthogonal neighbour sits lower, so a surface water source here stays boxed in and can't flow downhill.
    pub fn water_source_is_enclosed(&self, x: i32, z: i32) -> bool {
        let base = self.get_ground_level(x, z);
        self.get_ground_level(x + 1, z) >= base
            && self.get_ground_level(x - 1, z) >= base
            && self.get_ground_level(x, z + 1) >= base
            && self.get_ground_level(x, z - 1) >= base
    }

    /// Raw terrain elevation at world (x, z) via the ground origin (correct in tile editors, unlike get_min_coords); None without elevation data.
    pub fn terrain_level(&self, x: i32, z: i32) -> Option<i32> {
        self.ground.as_ref().map(|g| {
            g.level(XZPoint::new(
                x - self.ground_origin_x,
                z - self.ground_origin_z,
            ))
        })
    }

    /// Register a flattened ground Y for a road cell. See
    /// `road_surface_overrides` for the full rationale; in short: wide roads
    /// choose a single Y per cross-section so all lateral blocks sit flat,
    /// and the override lets the later ground pass fill below / cut above to
    /// match, yielding natural embankments/cuts instead of floating strips.
    ///
    /// Last writer wins — acceptable because road placements for the same
    /// cell come from overlapping stamps of adjacent centerline points whose
    /// target Ys differ by at most ~1 block.
    #[inline]
    pub fn register_road_surface_y(&mut self, x: i32, z: i32, y: i32) {
        self.road_surface_overrides.insert((x, z), y);
    }

    /// Record a bridge pier or pylon column standing on the terrain at (x, z).
    #[inline]
    pub fn register_support_column(&mut self, x: i32, z: i32, block: Block) {
        self.support_columns.insert((x, z), block);
    }

    /// Material of the support column standing at (x, z), if any.
    #[inline]
    pub fn support_column(&self, x: i32, z: i32) -> Option<Block> {
        if self.support_columns.is_empty() {
            return None;
        }
        self.support_columns.get(&(x, z)).copied()
    }

    /// Take this editor's road-surface overrides (tile editors hand theirs to the main editor).
    pub(crate) fn take_road_surface_overrides(&mut self) -> FnvHashMap<(i32, i32), i32> {
        std::mem::take(&mut self.road_surface_overrides)
    }

    /// Merge in road-surface overrides from a tile editor so post-merge passes stay road-aware.
    pub(crate) fn merge_road_surface_overrides(&mut self, overrides: FnvHashMap<(i32, i32), i32>) {
        self.road_surface_overrides.extend(overrides);
    }

    /// Merge only the overrides whose cell falls in `regions`. Under stream-to-disk, only the
    /// deferred 3D regions need road-aware ground for the post-merge placement pass.
    pub(crate) fn merge_road_surface_overrides_in_regions(
        &mut self,
        overrides: FnvHashMap<(i32, i32), i32>,
        regions: &std::collections::HashSet<(i32, i32)>,
    ) {
        self.road_surface_overrides.extend(
            overrides
                .into_iter()
                .filter(|((x, z), _)| regions.contains(&(x >> 9, z >> 9))),
        );
    }

    /// Get the water-appropriate Y level at a world coordinate.
    /// On steep terrain, snaps to the local minimum to compensate for
    /// spatial misalignment between water data and the elevation DEM.
    #[inline(always)]
    pub fn get_water_level(&self, x: i32, z: i32) -> i32 {
        if let Some(ground) = &self.ground {
            ground.water_level(XZPoint::new(
                x - self.ground_origin_x,
                z - self.ground_origin_z,
            ))
        } else {
            0
        }
    }

    /// Returns the minimum world coordinates
    pub fn get_min_coords(&self) -> (i32, i32) {
        (self.xzbbox.min_x(), self.xzbbox.min_z())
    }

    /// Returns the maximum world coordinates
    pub fn get_max_coords(&self) -> (i32, i32) {
        (self.xzbbox.max_x(), self.xzbbox.max_z())
    }

    /// Checks if there's a block at the given coordinates
    #[allow(unused)]
    #[inline]
    pub fn block_at(&self, x: i32, y: i32, z: i32) -> bool {
        let absolute_y = self.get_absolute_y(x, y, z);
        self.world.get_block(x, absolute_y, z).is_some()
    }

    #[inline]
    pub fn get_block_absolute(&self, x: i32, absolute_y: i32, z: i32) -> Option<Block> {
        self.world.get_block(x, absolute_y, z)
    }

    /// Stored properties of the block at an absolute position, if any.
    #[cfg(test)]
    pub fn block_properties_absolute(&self, x: i32, absolute_y: i32, z: i32) -> Option<Value> {
        self.world
            .get_properties(x, absolute_y, z)
            .map(|p| p.as_ref().clone())
    }
    #[allow(clippy::too_many_arguments)]
    pub fn place_wall_banner(
        &mut self,
        block: Block,
        x: i32,
        y: i32,
        z: i32,
        facing: &str,              // "north" / "south" / "east" / "west"
        base_color: &str,          // "light_gray" etc.
        patterns: &[(&str, &str)], // [("red", "minecraft:triangle_top"), ...]
    ) {
        // Apply Block rotation
        self.set_block_with_properties_absolute(
            crate::block_definitions::BlockWithProperties::new(
                block,
                Some(fastnbt::nbt!({ "facing": facing })),
            ),
            x,
            y,
            z,
            None,
            None,
        );
        match self.format() {
            crate::world_editor::WorldFormat::JavaAnvil => {
                self.set_banner_block_entity_absolute(x, y, z, patterns);
            }
            crate::world_editor::WorldFormat::BedrockMcWorld => {
                self.set_bedrock_banner_block_entity_absolute(x, y, z, base_color, patterns);
            }
            crate::world_editor::WorldFormat::LuantiWorld => {}
        }
    }

    fn insert_block_entity(&mut self, x: i32, z: i32, be: HashMap<String, Value>) {
        if !self.xzbbox.contains(&XZPoint::new(x, z)) {
            return;
        }
        if self.is_region_flushed(x, z) {
            return;
        }
        let chunk_x = x >> 4;
        let chunk_z = z >> 4;
        let region_x = chunk_x >> 5;
        let region_z = chunk_z >> 5;

        let region = self.world.get_or_create_region(region_x, region_z);
        let chunk = region.get_or_create_chunk(chunk_x & 31, chunk_z & 31);

        const BLOCK_ENTITIES_KEY: &str = "block_entities";

        match chunk.other.entry(BLOCK_ENTITIES_KEY.to_string()) {
            Entry::Occupied(mut entry) => {
                if let Value::List(list) = entry.get_mut() {
                    list.push(Value::Compound(be));
                }
            }
            Entry::Vacant(entry) => {
                entry.insert(Value::List(vec![Value::Compound(be)]));
            }
        }
    }

    /// Schedules a fluid tick so a worldgen-placed water or lava source flows on first chunk
    /// load. Without one the source sits frozen until some unrelated neighbour update pokes it.
    /// Java only: Bedrock and Luanti have no such list.
    pub fn schedule_fluid_tick(&mut self, fluid: Block, x: i32, y: i32, z: i32) {
        if self.format != WorldFormat::JavaAnvil {
            return;
        }
        if !self.xzbbox.contains(&XZPoint::new(x, z)) || self.is_region_flushed(x, z) {
            return;
        }
        let id = if fluid == LAVA {
            "minecraft:lava"
        } else {
            "minecraft:water"
        };
        let chunk_x = x >> 4;
        let chunk_z = z >> 4;
        let region = self.world.get_or_create_region(chunk_x >> 5, chunk_z >> 5);
        let chunk = region.get_or_create_chunk(chunk_x & 31, chunk_z & 31);
        // `t` is the delay in ticks and `p` the priority; 0 fires on the first tick.
        let tick = HashMap::from([
            ("i".to_string(), Value::String(id.to_string())),
            ("x".to_string(), Value::Int(x)),
            ("y".to_string(), Value::Int(y)),
            ("z".to_string(), Value::Int(z)),
            ("t".to_string(), Value::Int(0)),
            ("p".to_string(), Value::Int(0)),
        ]);
        match chunk.other.entry("fluid_ticks".to_string()) {
            Entry::Occupied(mut entry) => {
                if let Value::List(list) = entry.get_mut() {
                    list.push(Value::Compound(tick));
                }
            }
            Entry::Vacant(entry) => {
                entry.insert(Value::List(vec![Value::Compound(tick)]));
            }
        }
    }

    /// Writes a minecraft:bed block entity; beds have no baked model and render only when present.
    pub fn set_bed_block_entity_absolute(&mut self, x: i32, absolute_y: i32, z: i32) {
        let mut be = HashMap::new();
        be.insert("id".to_string(), Value::String("minecraft:bed".to_string()));
        be.insert("x".to_string(), Value::Int(x));
        be.insert("y".to_string(), Value::Int(absolute_y));
        be.insert("z".to_string(), Value::Int(z));
        be.insert("keepPacked".to_string(), Value::Byte(0));
        self.insert_block_entity(x, z, be);
    }

    /// Preview map in a frame at spawn, with the arnismc.com map one block below.
    pub fn place_map_item_frame(
        &mut self,
        spawn_x: i32,
        spawn_z: i32,
        map_id: i32,
        branding_map_id: i32,
    ) {
        // Player spawns facing south (+Z), so the display sits a couple blocks that way.
        let ground = self.get_absolute_y(spawn_x, 0, spawn_z);
        let lower_y = ground + 1;
        let eye_y = ground + 2;
        let frame_z = spawn_z + 2;
        let post_z = spawn_z + 3;

        // Solid block behind the lower map; chest behind the upper one.
        self.set_block_absolute(SMOOTH_STONE, spawn_x, lower_y, post_z, None, Some(&[]));

        self.set_block_absolute(AIR, spawn_x, eye_y, frame_z, None, Some(&[]));
        self.set_block_absolute(AIR, spawn_x, lower_y, frame_z, None, Some(&[]));

        // Preview on top, branding one block below.
        self.add_filled_map_frame(spawn_x, eye_y, frame_z, map_id);
        self.add_filled_map_frame(spawn_x, lower_y, frame_z, branding_map_id);

        // Chest holds a takeable copy of the preview map.
        let mut chest_components = HashMap::new();
        chest_components.insert("minecraft:map_id".to_string(), Value::Int(map_id));
        let mut chest_map = HashMap::new();
        chest_map.insert("Slot".to_string(), Value::Byte(13));
        chest_map.insert(
            "id".to_string(),
            Value::String("minecraft:filled_map".to_string()),
        );
        chest_map.insert("count".to_string(), Value::Int(1));
        chest_map.insert("components".to_string(), Value::Compound(chest_components));
        self.set_chest_with_items_absolute(spawn_x, eye_y, post_z, vec![chest_map]);
    }

    /// arnismc.com map at spawn on a floating block, used when the preview map is off.
    pub fn place_branding_map_only(&mut self, spawn_x: i32, spawn_z: i32, branding_map_id: i32) {
        let display_y = self.get_absolute_y(spawn_x, 0, spawn_z) + 2;
        let frame_z = spawn_z + 2;
        let post_z = spawn_z + 3;

        // Floating block with the map on its front.
        self.set_block_absolute(SMOOTH_STONE, spawn_x, display_y, post_z, None, Some(&[]));
        self.set_block_absolute(AIR, spawn_x, display_y, frame_z, None, Some(&[]));
        self.add_filled_map_frame(spawn_x, display_y, frame_z, branding_map_id);
    }

    /// Places an item frame holding a locked filled map, facing the player at spawn.
    /// Left breakable (Fixed:0) on purpose; the chest below holds a takeable copy.
    fn add_filled_map_frame(&mut self, x: i32, absolute_y: i32, frame_z: i32, map_id: i32) {
        let mut components = HashMap::new();
        components.insert("minecraft:map_id".to_string(), Value::Int(map_id));
        let mut item = HashMap::new();
        item.insert(
            "id".to_string(),
            Value::String("minecraft:filled_map".to_string()),
        );
        item.insert("count".to_string(), Value::Int(1));
        item.insert("components".to_string(), Value::Compound(components));

        let mut extra = HashMap::new();
        extra.insert("Facing".to_string(), Value::Byte(2)); // faces north, toward the player
        extra.insert("ItemRotation".to_string(), Value::Byte(0));
        extra.insert("Item".to_string(), Value::Compound(item));
        extra.insert("ItemDropChance".to_string(), Value::Float(1.0));
        extra.insert("Fixed".to_string(), Value::Byte(0));
        extra.insert("TileX".to_string(), Value::Int(x));
        extra.insert("TileY".to_string(), Value::Int(absolute_y));
        extra.insert("TileZ".to_string(), Value::Int(frame_z));
        extra.insert(
            "block_pos".to_string(),
            Value::List(vec![
                Value::Int(x),
                Value::Int(absolute_y),
                Value::Int(frame_z),
            ]),
        );

        let rel_y = absolute_y - self.get_absolute_y(x, 0, frame_z);
        self.add_entity("minecraft:item_frame", x, rel_y, frame_z, Some(extra));
    }

    /// Places a banner block entity at the given coordinates (absolute Y).
    /// This writes the pattern data into the chunk's block_entities list,
    /// which is required for the banner patterns to appear in-game.
    fn set_banner_block_entity_absolute(
        &mut self,
        x: i32,
        absolute_y: i32,
        z: i32,
        patterns_list: &[(&str, &str)],
    ) {
        let mut be = HashMap::new();
        be.insert(
            "id".to_string(),
            Value::String("minecraft:banner".to_string()),
        );
        be.insert("x".to_string(), Value::Int(x));
        be.insert("y".to_string(), Value::Int(absolute_y));
        be.insert("z".to_string(), Value::Int(z));
        be.insert("keepPacked".to_string(), Value::Byte(0));
        let patterns: Vec<Value> = patterns_list
            .iter()
            .map(|(color, pattern)| {
                let mut entry = HashMap::new();

                entry.insert("color".to_string(), Value::String(color.to_string()));
                entry.insert("pattern".to_string(), Value::String(pattern.to_string()));
                Value::Compound(entry)
            })
            .collect();
        be.insert("patterns".to_string(), Value::List(patterns));
        be.insert("components".to_string(), Value::Compound(HashMap::new()));
        self.insert_block_entity(x, z, be);
    }

    /// Places a Bedrock-format banner block entity at the given coordinates (absolute Y).
    ///
    /// Bedrock banners use a completely different block entity schema from Java:
    ///   - `Base`:     Int  — base color index (0=black … 15=white; light_gray=7)
    ///   - `Patterns`: List — each entry has `Color` (Int) and `Pattern` (String, short code)
    ///   - `Type`:     Int  — 0 = normal banner
    ///
    /// Java color names and pattern resource-path IDs are converted here to their
    /// Bedrock integer color indices and short pattern codes.
    fn set_bedrock_banner_block_entity_absolute(
        &mut self,
        x: i32,
        absolute_y: i32,
        z: i32,
        base_color: &str,
        patterns: &[(&str, &str)], // &[(java_color_name, java_pattern_id)]
    ) {
        /// Maps a Java color name to the Bedrock integer color index used in banner
        /// block entities.  The ordering is the standard Minecraft dye index.
        fn java_color_to_bedrock_int(color: &str) -> i32 {
            match color {
                "black" => 0,
                "red" => 1,
                "green" => 2,
                "brown" => 3,
                "blue" => 4,
                "purple" => 5,
                "cyan" => 6,
                "light_gray" => 7,
                "gray" => 8,
                "pink" => 9,
                "lime" => 10,
                "yellow" => 11,
                "light_blue" => 12,
                "magenta" => 13,
                "orange" => 14,
                "white" => 15,
                _ => 0,
            }
        }

        /// Maps a Java banner pattern resource-path ID (e.g. "minecraft:triangle_top")
        /// to the Bedrock short pattern code (e.g. "tts").
        fn java_pattern_to_bedrock_code(pattern: &str) -> &'static str {
            // Strip the optional "minecraft:" namespace prefix
            let key = pattern.strip_prefix("minecraft:").unwrap_or(pattern);
            match key {
                "base" => "b",
                "square_bottom_left" => "bl",
                "square_bottom_right" => "br",
                "square_top_left" => "tl",
                "square_top_right" => "tr",
                "stripe_bottom" => "bs",
                "stripe_top" => "ts",
                "stripe_left" => "ls",
                "stripe_right" => "rs",
                "stripe_center" => "cs",
                "stripe_middle" => "ms",
                "stripe_downright" => "drs",
                "stripe_downleft" => "dls",
                "stripe_small" => "ss",
                "cross" => "cr",
                "straight_cross" => "sc",
                "triangle_bottom" => "bt",
                "triangle_top" => "tt",
                "triangles_bottom" => "bts",
                "triangles_top" => "tts",
                "diagonal_left" => "ld",
                "diagonal_right" => "rd",
                "diagonal_up_left" => "lud",
                "diagonal_up_right" => "rud",
                "circle" => "mc",
                "rhombus" => "mr",
                "half_vertical" => "vh",
                "half_vertical_right" => "vhr",
                "half_horizontal" => "hh",
                "half_horizontal_bottom" => "hhb",
                "border" => "bo",
                "curly_border" => "cbo",
                "gradient" => "gra",
                "gradient_up" => "gru",
                "bricks" => "bri",
                "globe" => "glb",
                "creeper" => "cre",
                "skull" => "sku",
                "flower" => "flo",
                "mojang" => "moj",
                "piglin" => "pig",
                "flow" => "flw",
                "guster" => "gus",
                _ => "b", // fallback: solid base
            }
        }

        let bedrock_patterns: Vec<Value> = patterns
            .iter()
            .map(|(color, pattern)| {
                let mut entry = HashMap::new();
                entry.insert(
                    "Color".to_string(),
                    Value::Int(java_color_to_bedrock_int(color)),
                );
                entry.insert(
                    "Pattern".to_string(),
                    Value::String(java_pattern_to_bedrock_code(pattern).to_string()),
                );
                Value::Compound(entry)
            })
            .collect();

        let mut be = HashMap::new();
        be.insert("id".to_string(), Value::String("Banner".to_string()));
        be.insert("x".to_string(), Value::Int(x));
        be.insert("y".to_string(), Value::Int(absolute_y));
        be.insert("z".to_string(), Value::Int(z));
        be.insert(
            "Base".to_string(),
            Value::Int(java_color_to_bedrock_int(base_color)),
        );
        be.insert("Patterns".to_string(), Value::List(bedrock_patterns));
        be.insert("Type".to_string(), Value::Int(0));

        self.insert_block_entity(x, z, be);
    }

    /// Sign block entity with up to four front lines (JSON text components).
    fn sign_block_entity(
        x: i32,
        absolute_y: i32,
        z: i32,
        lines: &[&str],
        color: &str,
        glow: bool,
    ) -> HashMap<String, Value> {
        let messages: Vec<Value> = (0..4)
            .map(|i| Value::String(json_string(lines.get(i).copied().unwrap_or(""))))
            .collect();
        let mut text_data = HashMap::new();
        text_data.insert("messages".to_string(), Value::List(messages));
        text_data.insert("color".to_string(), Value::String(color.to_string()));
        text_data.insert("has_glowing_text".to_string(), Value::Byte(glow as i8));

        let mut be = HashMap::new();
        be.insert("front_text".to_string(), Value::Compound(text_data));
        be.insert(
            "id".to_string(),
            Value::String("minecraft:sign".to_string()),
        );
        be.insert("is_waxed".to_string(), Value::Byte(1));
        be.insert("keepPacked".to_string(), Value::Byte(0));
        be.insert("x".to_string(), Value::Int(x));
        be.insert("y".to_string(), Value::Int(absolute_y));
        be.insert("z".to_string(), Value::Int(z));
        be
    }

    /// Standing sign with four text lines at ground-relative `y`; `rotation` is 0..=15
    /// (0 = facing south, clockwise). Java only.
    #[allow(clippy::too_many_arguments, dead_code)]
    pub fn set_sign(
        &mut self,
        line1: String,
        line2: String,
        line3: String,
        line4: String,
        x: i32,
        y: i32,
        z: i32,
        rotation: i8,
    ) {
        if self.format != WorldFormat::JavaAnvil {
            return;
        }
        if !self.xzbbox.contains(&XZPoint::new(x, z)) || self.is_region_flushed(x, z) {
            return;
        }
        let absolute_y = self.get_absolute_y(x, y, z);
        let be = Self::sign_block_entity(
            x,
            absolute_y,
            z,
            &[&line1, &line2, &line3, &line4],
            "black",
            false,
        );
        self.insert_block_entity(x, z, be);
        let props = fastnbt::nbt!({ "rotation": rotation.rem_euclid(16).to_string(), "waterlogged": "false" });
        self.set_block_with_properties_absolute(
            BlockWithProperties::new(SIGN, Some(props)),
            x,
            absolute_y,
            z,
            None,
            None,
        );
    }

    /// Wall sign with white text, used where the bundled font lacks the glyphs. Java only.
    pub fn place_wall_sign(
        &mut self,
        bx: i32,
        abs_y: i32,
        bz: i32,
        facing: i8,
        lines: &[&str],
    ) -> bool {
        if self.format != WorldFormat::JavaAnvil || !(2..=5).contains(&facing) {
            return false;
        }
        let (fx, fy, fz) = Self::decal_frame_cell(bx, abs_y, bz, facing);
        if !self.xzbbox.contains(&XZPoint::new(fx, fz)) || self.is_region_flushed(fx, fz) {
            return false;
        }
        if fy - self.get_absolute_y(fx, 0, fz) < 1 || !self.cell_is_open(fx, fy, fz) {
            return false;
        }
        let facing_name = match facing {
            3 => "south",
            4 => "west",
            5 => "east",
            _ => "north",
        };
        let be = Self::sign_block_entity(fx, fy, fz, lines, "white", false);
        self.insert_block_entity(fx, fz, be);
        self.set_block_with_properties_absolute(
            BlockWithProperties::new(
                SPRUCE_WALL_SIGN,
                Some(fastnbt::nbt!({ "facing": facing_name, "waterlogged": "false" })),
            ),
            fx,
            fy,
            fz,
            None,
            Some(&[]),
        );
        true
    }

    /// Adds an entity at the given coordinates (Y is ground-relative).
    #[allow(dead_code)]
    pub fn add_entity(
        &mut self,
        id: &str,
        x: i32,
        y: i32,
        z: i32,
        extra_data: Option<HashMap<String, Value>>,
    ) {
        // Two hanging entities can share a cell on opposite faces, so the face belongs in
        // the UUID seed; without it they collide and the game keeps only one.
        let face = match extra_data.as_ref().and_then(|e| e.get("Facing")) {
            Some(Value::Byte(f)) => *f as i64,
            _ => -1,
        };
        self.add_entity_seeded(id, x, y, z, face, extra_data);
    }

    /// `add_entity` with the UUID's extra seed given outright, for entities
    /// that share a block cell without carrying a face byte. Entries in
    /// `extra_data` are written last, so they can also override a base tag
    /// (the item displays replace `Pos` with their exact sub-block position).
    fn add_entity_seeded(
        &mut self,
        id: &str,
        x: i32,
        y: i32,
        z: i32,
        seed: i64,
        extra_data: Option<HashMap<String, Value>>,
    ) {
        if !self.xzbbox.contains(&XZPoint::new(x, z)) {
            return;
        }
        // Entities must respect eviction too, or they resurrect a flushed region.
        if self.is_region_flushed(x, z) {
            return;
        }

        let absolute_y = self.get_absolute_y(x, y, z);
        let face = seed;
        let mut entity = HashMap::new();
        entity.insert("id".to_string(), Value::String(id.to_string()));
        entity.insert(
            "Pos".to_string(),
            Value::List(vec![
                Value::Double(x as f64 + 0.5),
                Value::Double(absolute_y as f64),
                Value::Double(z as f64 + 0.5),
            ]),
        );
        entity.insert(
            "Motion".to_string(),
            Value::List(vec![
                Value::Double(0.0),
                Value::Double(0.0),
                Value::Double(0.0),
            ]),
        );
        entity.insert(
            "Rotation".to_string(),
            Value::List(vec![Value::Float(0.0), Value::Float(0.0)]),
        );
        entity.insert("OnGround".to_string(), Value::Byte(1));
        entity.insert("FallDistance".to_string(), Value::Float(0.0));
        entity.insert("Fire".to_string(), Value::Short(-20));
        entity.insert("Air".to_string(), Value::Short(300));
        entity.insert("PortalCooldown".to_string(), Value::Int(0));
        entity.insert(
            "UUID".to_string(),
            Value::IntArray(build_deterministic_uuid(id, x, absolute_y, z, face)),
        );

        if let Some(extra) = extra_data {
            for (key, value) in extra {
                entity.insert(key, value);
            }
        }

        let chunk_x: i32 = x >> 4;
        let chunk_z: i32 = z >> 4;
        let region_x: i32 = chunk_x >> 5;
        let region_z: i32 = chunk_z >> 5;

        let region = self.world.get_or_create_region(region_x, region_z);
        let chunk = region.get_or_create_chunk(chunk_x & 31, chunk_z & 31);

        match chunk.other.entry("entities".to_string()) {
            Entry::Occupied(mut entry) => {
                if let Value::List(list) = entry.get_mut() {
                    list.push(Value::Compound(entity));
                }
            }
            Entry::Vacant(entry) => {
                entry.insert(Value::List(vec![Value::Compound(entity)]));
            }
        }
    }

    /// Places a chest with the provided items at the given coordinates (ground-relative Y).
    #[allow(dead_code)]
    pub fn set_chest_with_items(
        &mut self,
        x: i32,
        y: i32,
        z: i32,
        items: Vec<HashMap<String, Value>>,
    ) {
        let absolute_y = self.get_absolute_y(x, y, z);
        self.set_chest_with_items_absolute(x, absolute_y, z, items);
    }

    /// Places a chest with the provided items at the given coordinates (absolute Y).
    #[allow(dead_code)]
    pub fn set_chest_with_items_absolute(
        &mut self,
        x: i32,
        absolute_y: i32,
        z: i32,
        items: Vec<HashMap<String, Value>>,
    ) {
        if !self.xzbbox.contains(&XZPoint::new(x, z)) {
            return;
        }
        if self.is_region_flushed(x, z) {
            return;
        }

        let chunk_x: i32 = x >> 4;
        let chunk_z: i32 = z >> 4;
        let region_x: i32 = chunk_x >> 5;
        let region_z: i32 = chunk_z >> 5;

        let mut chest_data = HashMap::new();
        chest_data.insert(
            "id".to_string(),
            Value::String("minecraft:chest".to_string()),
        );
        chest_data.insert("x".to_string(), Value::Int(x));
        chest_data.insert("y".to_string(), Value::Int(absolute_y));
        chest_data.insert("z".to_string(), Value::Int(z));
        chest_data.insert(
            "Items".to_string(),
            Value::List(items.into_iter().map(Value::Compound).collect()),
        );
        chest_data.insert("keepPacked".to_string(), Value::Byte(0));

        let region = self.world.get_or_create_region(region_x, region_z);
        let chunk = region.get_or_create_chunk(chunk_x & 31, chunk_z & 31);

        match chunk.other.entry("block_entities".to_string()) {
            Entry::Occupied(mut entry) => {
                if let Value::List(list) = entry.get_mut() {
                    list.push(Value::Compound(chest_data));
                }
            }
            Entry::Vacant(entry) => {
                entry.insert(Value::List(vec![Value::Compound(chest_data)]));
            }
        }

        self.set_block_absolute(CHEST, x, absolute_y, z, None, None);
    }

    /// Places a block entity with items at the given coordinates (ground-relative Y).
    #[allow(dead_code)]
    pub fn set_block_entity_with_items(
        &mut self,
        block_with_props: BlockWithProperties,
        x: i32,
        y: i32,
        z: i32,
        block_entity_id: &str,
        items: Vec<HashMap<String, Value>>,
    ) {
        let absolute_y = self.get_absolute_y(x, y, z);
        self.set_block_entity_with_items_absolute(
            block_with_props,
            x,
            absolute_y,
            z,
            block_entity_id,
            items,
        );
    }

    /// Places a block entity with items at the given coordinates (absolute Y).
    #[allow(dead_code)]
    pub fn set_block_entity_with_items_absolute(
        &mut self,
        block_with_props: BlockWithProperties,
        x: i32,
        absolute_y: i32,
        z: i32,
        block_entity_id: &str,
        items: Vec<HashMap<String, Value>>,
    ) {
        if !self.xzbbox.contains(&XZPoint::new(x, z)) {
            return;
        }
        if self.is_region_flushed(x, z) {
            return;
        }

        let chunk_x: i32 = x >> 4;
        let chunk_z: i32 = z >> 4;
        let region_x: i32 = chunk_x >> 5;
        let region_z: i32 = chunk_z >> 5;

        let mut block_entity = HashMap::new();
        block_entity.insert("id".to_string(), Value::String(block_entity_id.to_string()));
        block_entity.insert("x".to_string(), Value::Int(x));
        block_entity.insert("y".to_string(), Value::Int(absolute_y));
        block_entity.insert("z".to_string(), Value::Int(z));
        block_entity.insert(
            "Items".to_string(),
            Value::List(items.into_iter().map(Value::Compound).collect()),
        );
        block_entity.insert("keepPacked".to_string(), Value::Byte(0));

        let region = self.world.get_or_create_region(region_x, region_z);
        let chunk = region.get_or_create_chunk(chunk_x & 31, chunk_z & 31);

        match chunk.other.entry("block_entities".to_string()) {
            Entry::Occupied(mut entry) => {
                if let Value::List(list) = entry.get_mut() {
                    list.push(Value::Compound(block_entity));
                }
            }
            Entry::Vacant(entry) => {
                entry.insert(Value::List(vec![Value::Compound(block_entity)]));
            }
        }

        self.set_block_with_properties_absolute(block_with_props, x, absolute_y, z, None, None);
    }

    /// Sets a block of the specified type at the given coordinates.
    ///
    /// Y value is interpreted as an offset from ground level.
    #[inline]
    pub fn set_block(
        &mut self,
        block: Block,
        x: i32,
        y: i32,
        z: i32,
        override_whitelist: Option<&[Block]>,
        override_blacklist: Option<&[Block]>,
    ) {
        // Short-circuit for out-of-bbox writes before we pay for a
        // ground-level lookup (bilinear interpolation of the elevation
        // grid). The downstream `set_block_with_properties_absolute`
        // does the same check, but only *after* we would have done the
        // elevation work.
        if !self.xzbbox.contains(&XZPoint::new(x, z)) {
            return;
        }
        self.set_block_absolute(
            block,
            x,
            self.get_absolute_y(x, y, z),
            z,
            override_whitelist,
            override_blacklist,
        );
    }

    /// Sets a block of the specified type at the given coordinates with absolute Y value.
    #[inline]
    pub fn set_block_absolute(
        &mut self,
        block: Block,
        x: i32,
        absolute_y: i32,
        z: i32,
        override_whitelist: Option<&[Block]>,
        override_blacklist: Option<&[Block]>,
    ) {
        self.set_block_with_properties_absolute(
            BlockWithProperties {
                block,
                properties: None,
            },
            x,
            absolute_y,
            z,
            override_whitelist,
            override_blacklist,
        )
    }

    /// True if the region at these block coords was already streamed to disk and evicted.
    /// Writers must drop such writes, or they resurrect the region and the final save
    /// truncates the real on-disk data. Short-circuits when nothing has been evicted.
    #[inline]
    fn is_region_flushed(&self, x: i32, z: i32) -> bool {
        !self.flushed_regions.is_empty() && self.flushed_regions.contains(&(x >> 9, z >> 9))
    }

    /// Sets a block with properties at the given coordinates with absolute Y value.
    #[inline]
    pub fn set_block_with_properties_absolute(
        &mut self,
        block_with_props: BlockWithProperties,
        x: i32,
        absolute_y: i32,
        z: i32,
        override_whitelist: Option<&[Block]>,
        override_blacklist: Option<&[Block]>,
    ) {
        // Check if coordinates are within bounds
        if !self.xzbbox.contains(&XZPoint::new(x, z)) {
            return;
        }
        // Drop writes to regions already flushed to disk (stream-to-disk eviction).
        if self.is_region_flushed(x, z) {
            return;
        }
        // A tile's halo repeats what the owning tile draws there, and the merge lets
        // it in wherever the owner left air: on its water, under its trunks. The owner
        // draws its own undergrowth, so the halo keeps none.
        if !self.owns(x, z) && crate::ground_decoration::is_undergrowth(block_with_props.block) {
            return;
        }

        // None/None is the dominant pattern; skip the redundant get_block() read.
        if override_whitelist.is_none() && override_blacklist.is_none() {
            self.world
                .set_with_props_if_absent(x, absolute_y, z, block_with_props);
            return;
        }

        let should_insert = if let Some(existing_block) = self.world.get_block(x, absolute_y, z) {
            // Check against whitelist and blacklist
            if let Some(whitelist) = override_whitelist {
                whitelist
                    .iter()
                    .any(|whitelisted_block: &Block| whitelisted_block.id() == existing_block.id())
            } else if let Some(blacklist) = override_blacklist {
                !blacklist
                    .iter()
                    .any(|blacklisted_block: &Block| blacklisted_block.id() == existing_block.id())
            } else {
                false
            }
        } else {
            true
        };

        if should_insert {
            self.world
                .set_block_with_properties(x, absolute_y, z, block_with_props);
        }
    }

    /// Fills a cuboid area with the specified block between two coordinates.
    #[allow(clippy::too_many_arguments)]
    #[inline]
    pub fn fill_blocks(
        &mut self,
        block: Block,
        x1: i32,
        y1: i32,
        z1: i32,
        x2: i32,
        y2: i32,
        z2: i32,
        override_whitelist: Option<&[Block]>,
        override_blacklist: Option<&[Block]>,
    ) {
        let (min_x, max_x) = if x1 < x2 { (x1, x2) } else { (x2, x1) };
        let (min_y, max_y) = if y1 < y2 { (y1, y2) } else { (y2, y1) };
        let (min_z, max_z) = if z1 < z2 { (z1, z2) } else { (z2, z1) };

        for x in min_x..=max_x {
            for y_offset in min_y..=max_y {
                for z in min_z..=max_z {
                    self.set_block(
                        block,
                        x,
                        y_offset,
                        z,
                        override_whitelist,
                        override_blacklist,
                    );
                }
            }
        }
    }

    /// Fill a rectangular volume with a block using absolute Y coordinates.
    #[inline]
    #[allow(clippy::too_many_arguments)]
    pub fn fill_blocks_absolute(
        &mut self,
        block: Block,
        x1: i32,
        y1: i32,
        z1: i32,
        x2: i32,
        y2: i32,
        z2: i32,
        override_whitelist: Option<&[Block]>,
        override_blacklist: Option<&[Block]>,
    ) {
        let (min_x, max_x) = if x1 < x2 { (x1, x2) } else { (x2, x1) };
        let (min_y, max_y) = if y1 < y2 { (y1, y2) } else { (y2, y1) };
        let (min_z, max_z) = if z1 < z2 { (z1, z2) } else { (z2, z1) };

        for x in min_x..=max_x {
            for abs_y in min_y..=max_y {
                for z in min_z..=max_z {
                    self.set_block_absolute(
                        block,
                        x,
                        abs_y,
                        z,
                        override_whitelist,
                        override_blacklist,
                    );
                }
            }
        }
    }

    /// Checks for a block at the given coordinates.
    #[inline]
    pub fn check_for_block(&self, x: i32, y: i32, z: i32, whitelist: Option<&[Block]>) -> bool {
        let absolute_y = self.get_absolute_y(x, y, z);

        // Retrieve the chunk modification map
        if let Some(existing_block) = self.world.get_block(x, absolute_y, z) {
            if let Some(whitelist) = whitelist {
                if whitelist
                    .iter()
                    .any(|whitelisted_block: &Block| whitelisted_block.id() == existing_block.id())
                {
                    return true; // Block is in the list
                }
            }
        }
        false
    }

    /// Checks for a block at the given coordinates with absolute Y value.
    #[allow(unused)]
    pub fn check_for_block_absolute(
        &self,
        x: i32,
        absolute_y: i32,
        z: i32,
        whitelist: Option<&[Block]>,
        blacklist: Option<&[Block]>,
    ) -> bool {
        // Retrieve the chunk modification map
        if let Some(existing_block) = self.world.get_block(x, absolute_y, z) {
            // Check against whitelist and blacklist
            if let Some(whitelist) = whitelist {
                if whitelist
                    .iter()
                    .any(|whitelisted_block: &Block| whitelisted_block.id() == existing_block.id())
                {
                    return true; // Block is in whitelist
                }
                return false;
            }
            if let Some(blacklist) = blacklist {
                if blacklist
                    .iter()
                    .any(|blacklisted_block: &Block| blacklisted_block.id() == existing_block.id())
                {
                    return true; // Block is in blacklist
                }
            }
            return whitelist.is_none() && blacklist.is_none();
        }

        false
    }

    /// Sets a block only if no modification has been recorded yet at this
    /// position (i.e. the in-memory overlay still holds AIR).
    ///
    /// This is faster than `set_block_absolute` with `None` whitelists/blacklists
    /// because it avoids the double HashMap traversal.
    #[inline]
    pub fn set_block_if_absent_absolute(
        &mut self,
        block: Block,
        x: i32,
        absolute_y: i32,
        z: i32,
    ) -> bool {
        if !self.xzbbox.contains(&XZPoint::new(x, z)) || self.is_region_flushed(x, z) {
            return false;
        }
        self.world.set_block_if_absent(x, absolute_y, z, block)
    }

    /// Returns true if a non-AIR block exists at the given absolute coordinates.
    #[inline]
    pub fn block_exists_absolute(&self, x: i32, absolute_y: i32, z: i32) -> bool {
        self.world.get_block(x, absolute_y, z).is_some()
    }

    /// Highest non-AIR block in `min_y..=max_y` at (x, z), or None when the column is clear.
    #[inline]
    pub fn highest_block_between(&self, x: i32, z: i32, min_y: i32, max_y: i32) -> Option<i32> {
        self.world.highest_block_between(x, z, min_y, max_y)
    }

    /// Fills an entire column from y_min to y_max with one block type.
    ///
    /// Resolves region/chunk once instead of per-Y-level, making underground
    /// fill (`--fillground`) dramatically faster.
    #[inline]
    pub fn fill_column_absolute(
        &mut self,
        block: Block,
        x: i32,
        z: i32,
        y_min: i32,
        y_max: i32,
        skip_existing: bool,
    ) {
        if !self.xzbbox.contains(&XZPoint::new(x, z)) {
            return;
        }
        if self.is_region_flushed(x, z) {
            return;
        }
        self.world
            .fill_column(x, z, y_min, y_max, block, skip_existing);
    }

    /// See [`WorldToModify::fill_column_with`].
    pub fn fill_column_with_absolute(
        &mut self,
        x: i32,
        z: i32,
        y_min: i32,
        y_max: i32,
        block_at: impl FnMut(i32) -> Block,
    ) {
        if !self.xzbbox.contains(&XZPoint::new(x, z)) || self.is_region_flushed(x, z) {
            return;
        }
        self.world.fill_column_with(x, z, y_min, y_max, block_at);
    }

    /// See [`WorldToModify::bulk_fill_chunk_sections_below`].
    pub fn bulk_fill_chunk_sections_below(
        &mut self,
        chunk_x: i32,
        chunk_z: i32,
        section_y_min: i8,
        section_y_max: i8,
        block: Block,
    ) -> bool {
        // chunk coords -> block coords for the region check (chunk << 4).
        if self.is_region_flushed(chunk_x << 4, chunk_z << 4) {
            return false;
        }
        self.world.bulk_fill_chunk_sections_below(
            chunk_x,
            chunk_z,
            section_y_min,
            section_y_max,
            block,
        )
    }

    /// Saves all changes made to the world by writing to the appropriate format.
    ///
    /// Returns `Err` on I/O failure so callers can abort the generation pipeline
    /// cleanly. A user-facing error message is also emitted via `emit_gui_error`
    /// before returning so the GUI is notified regardless of how the caller handles
    /// the `Result`.
    pub fn save(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        println!(
            "Generating world for: {}",
            match self.format {
                WorldFormat::JavaAnvil => "Java Edition (Anvil)",
                WorldFormat::BedrockMcWorld => "Bedrock Edition (.mcworld)",
                WorldFormat::LuantiWorld => "Luanti/Minetest",
            }
        );

        // Compact sections before saving: collapses uniform mixed sections back to
        // Uniform and repacks any overflowed direct sections that fit a palette again.
        self.world.compact_sections();

        // Non-Java formats have no per-region write hook, so feed the preview here.
        if self.format != WorldFormat::JavaAnvil {
            if let Some(preview) = &self.preview {
                use rayon::prelude::*;
                self.world
                    .regions
                    .par_iter()
                    .for_each(|(&(rx, rz), region)| preview.ingest_region(rx, rz, region));
            }
        }

        match self.format {
            WorldFormat::JavaAnvil => {
                if let Err(e) = self.save_java() {
                    let user_msg = if is_disk_full_error(e.as_ref()) {
                        "Not enough disk space available.".to_string()
                    } else {
                        format!("Failed to save world: {}", e)
                    };
                    eprintln!("{}", user_msg);
                    #[cfg(feature = "gui")]
                    emit_gui_error(&user_msg);
                    return Err(user_msg.into());
                }
                self.finish_voxy();
            }
            WorldFormat::BedrockMcWorld => self.save_bedrock()?,
            WorldFormat::LuantiWorld => {
                if let Err(e) = luanti::save_luanti_world(
                    &self.world,
                    &self.world_dir,
                    self.xzbbox,
                    &self.llbbox,
                    self.luanti_game,
                    self.luanti_level_name.as_deref(),
                    self.luanti_spawn_point,
                    self.luanti_ground_level,
                    self.game_mode,
                    self.world_time,
                ) {
                    let user_msg = format!("Failed to save Luanti world: {}", e);
                    eprintln!("{}", user_msg);
                    #[cfg(feature = "gui")]
                    emit_gui_error(&user_msg);
                    return Err(user_msg.into());
                }
            }
        }

        Ok(())
    }

    /// Seal the voxy LOD database. A failure here costs the user nothing but
    /// distant terrain, so it is reported and swallowed rather than failing a
    /// world that is already written.
    fn finish_voxy(&mut self) {
        let Some(voxy) = self.voxy.take() else {
            return;
        };
        match voxy.finish() {
            Ok((sections, bytes)) => println!(
                "  Voxy LOD: {} sections, {:.1} MB",
                sections,
                bytes as f64 / (1024.0 * 1024.0)
            ),
            Err(e) => {
                let msg = format!("Failed to write the Voxy LOD cache: {e}");
                eprintln!("{msg}");
                #[cfg(feature = "gui")]
                send_log(LogLevel::Warning, &msg);
            }
        }
    }

    fn save_bedrock(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        println!("{} Saving Bedrock world...", "[7/7]".bold());
        emit_gui_progress_update(90.0, "Saving Bedrock world...");

        if let Err(error) = self.save_bedrock_internal() {
            let user_msg = format!("Failed to save Bedrock world: {error}");
            eprintln!("{user_msg}");
            #[cfg(feature = "gui")]
            emit_gui_error(&user_msg);
            return Err(user_msg.into());
        }
        Ok(())
    }

    fn save_bedrock_internal(&mut self) -> Result<(), BedrockSaveError> {
        // Use the stored level name if available, otherwise extract from path
        let level_name = self.bedrock_level_name.clone().unwrap_or_else(|| {
            self.world_dir
                .file_stem()
                .and_then(|s| s.to_str())
                .unwrap_or("Arnis World")
                .to_string()
        });

        BedrockWriter::new(
            self.world_dir.clone(),
            level_name,
            self.bedrock_spawn_point,
            self.ground.clone(),
            self.bedrock_extend_height,
            self.projection.clone(),
            self.scale,
            self.game_mode,
            self.world_time,
            self.start_with_map,
        )
        .write_world(&self.world, self.xzbbox, &self.llbbox)
    }

    /// Saves world metadata to a JSON file
    pub(crate) fn save_metadata(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        let metadata_path = self.world_dir.join("metadata.json");

        let mut file = File::create(&metadata_path).map_err(|e| {
            format!(
                "Failed to create metadata file at {}: {}",
                metadata_path.display(),
                e
            )
        })?;

        let (xzbbox, llbbox) = match &self.metadata_extent {
            Some((xz, ll)) => (xz.clone(), *ll),
            None => (self.xzbbox.clone(), self.llbbox),
        };
        let metadata = WorldMetadata {
            min_mc_x: xzbbox.min_x(),
            max_mc_x: xzbbox.max_x(),
            min_mc_z: xzbbox.min_z(),
            max_mc_z: xzbbox.max_z(),

            min_geo_lat: llbbox.min().lat(),
            max_geo_lat: llbbox.max().lat(),
            min_geo_lon: llbbox.min().lng(),
            max_geo_lon: llbbox.max().lng(),

            projection: self.projection.clone(),
            scale: self.scale,
        };

        let contents = serde_json::to_string(&metadata)
            .map_err(|e| format!("Failed to serialize metadata to JSON: {}", e))?;

        write!(&mut file, "{}", contents)
            .map_err(|e| format!("Failed to write metadata to file: {}", e))?;

        Ok(())
    }
}

#[allow(dead_code)]
fn build_deterministic_uuid(id: &str, x: i32, y: i32, z: i32, face: i64) -> IntArray {
    let mut hash: i64 = 17;
    for byte in id.bytes() {
        hash = hash.wrapping_mul(31).wrapping_add(byte as i64);
    }
    hash = hash.wrapping_mul(31).wrapping_add(face);

    let seed_a = hash ^ (x as i64).wrapping_shl(32) ^ (y as i64).wrapping_mul(17);
    let seed_b = hash.rotate_left(7) ^ (z as i64).wrapping_mul(31) ^ (x as i64).wrapping_mul(13);

    IntArray::new(vec![
        (seed_a >> 32) as i32,
        seed_a as i32,
        (seed_b >> 32) as i32,
        seed_b as i32,
    ])
}

// Compile-time assertions that WorldEditor is thread-safe for shared reads.
// Needed for rayon-based parallel tile processing; the build fails here
// if anyone adds a non-Send/Sync field to WorldEditor.
#[allow(dead_code)]
const _: () = {
    fn assert_sync<T: Sync>() {}
    fn assert_send<T: Send>() {}
    fn check() {
        assert_sync::<WorldEditor<'_>>();
        assert_send::<WorldEditor<'_>>();
    }
};

/// Estimated resident MB of one queued region.
///
/// The flat figure is calibrated on a dense full-feature vanilla run (terrain + land cover +
/// Overture + 3D). `--fillground` is the one mode whose column follows the dimension rather
/// than the surface, so there it scales with the span the fill actually covers; a vanilla
/// span reproduces the flat figure exactly.
pub(crate) fn per_region_estimate_mb(fillground: bool) -> u64 {
    const BASE_MB: u64 = 26;
    const VANILLA_SPAN: i32 = DEFAULT_MAX_Y - DEFAULT_MIN_Y;
    if !fillground {
        return BASE_MB;
    }
    let span = (world_max_y() - terrain_floor_y()).max(VANILLA_SPAN) as u64;
    BASE_MB * span / VANILLA_SPAN as u64
}

/// Thread count and queue depth for the flush pool. `threads` is throughput,
/// `capacity` is RAM. One region is evicted per merged tile, so covering a whole
/// batch without backpressure would need `capacity + threads >= tile_batch`. That is
/// the target, not a guarantee: both are clamped and capped by the RAM budget below,
/// so a wide batch still stalls the producer some. `flush_stall_ms` measures it.
pub(crate) fn flush_pool_params(
    tile_batch: usize,
    available_mb: u64,
    fillground: bool,
) -> (usize, usize) {
    let cores = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(4);
    // `capacity + threads + 1` regions are alive at once, so budget the total rather
    // than each knob. Shared with should_stream_to_disk; measured is ~7 on a vanilla run.
    let per_region_mb = per_region_estimate_mb(fillground);
    let budget = if available_mb > 0 {
        // A tenth of free RAM, floored so the pool always beats the old single writer.
        ((available_mb / 10 / per_region_mb) as usize).clamp(5, 15)
    } else {
        15
    };

    let mut threads = cores.div_ceil(4).clamp(2, 6);
    threads = threads.min(budget.saturating_sub(2).max(1));
    if let Some(n) = std::env::var("ARNIS_FLUSH_THREADS")
        .ok()
        .and_then(|v| v.parse::<usize>().ok())
    {
        threads = n.clamp(1, 32);
    }

    // Evictions arrive one per merged tile, so a batch lands as a burst of that size.
    let mut capacity = tile_batch.saturating_sub(threads).clamp(3, 8);
    capacity = capacity.min(budget.saturating_sub(threads + 1).max(1));
    if let Some(q) = std::env::var("ARNIS_FLUSH_QUEUE")
        .ok()
        .and_then(|v| v.parse::<usize>().ok())
    {
        capacity = q.clamp(1, 64);
    }
    (threads, capacity)
}

/// Resident block-storage bytes of a region, as queued (before `compact()`).
fn region_storage_bytes(region: &common::RegionToModify) -> u64 {
    let mut bytes = 0u64;
    for chunk in region.chunks.values() {
        for section in chunk.sections.values() {
            bytes += section.storage.resident_bytes();
        }
    }
    bytes
}

/// Background writer pool for stream-to-disk eviction. Regions taken off the merge
/// thread are compacted, serialized and written here, overlapping I/O with the next
/// batch's compute. At most `capacity + threads + 1` regions are alive at once; the
/// `+1` is the one the producer holds across `send`.
pub(crate) struct FlushWorker {
    tx: Option<std::sync::mpsc::SyncSender<(i32, i32, common::RegionToModify)>>,
    handles: Vec<std::thread::JoinHandle<Result<(), String>>>,
    // Real write error from the worker, so a failed handoff surfaces the cause
    // (disk full, permissions, ...) instead of a generic "terminated early".
    error: Arc<Mutex<Option<String>>>,
    // With a shared receiver the channel only closes when the LAST worker exits,
    // so a dead worker has to be advertised explicitly or errors go unnoticed.
    failed: Arc<std::sync::atomic::AtomicBool>,
    stall_ns: std::sync::atomic::AtomicU64,
    write_ns: Arc<std::sync::atomic::AtomicU64>,
    regions: Arc<std::sync::atomic::AtomicUsize>,
    bytes: std::sync::atomic::AtomicU64,
    bench: bool,
}

impl FlushWorker {
    pub(crate) fn spawn(
        ctx: java::RegionWriteCtx,
        capacity: usize,
        threads: usize,
        bench: bool,
    ) -> Self {
        use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize};
        let threads = threads.max(1);
        let (tx, rx) =
            std::sync::mpsc::sync_channel::<(i32, i32, common::RegionToModify)>(capacity.max(1));
        let rx = Arc::new(Mutex::new(rx));
        let ctx = Arc::new(ctx);
        let error = Arc::new(Mutex::new(None));
        let failed = Arc::new(AtomicBool::new(false));
        let write_ns = Arc::new(AtomicU64::new(0));
        let regions = Arc::new(AtomicUsize::new(0));

        let handles = (0..threads)
            .map(|_| {
                let rx = Arc::clone(&rx);
                let ctx = Arc::clone(&ctx);
                let error_w = Arc::clone(&error);
                let failed_w = Arc::clone(&failed);
                let write_ns = Arc::clone(&write_ns);
                let regions = Arc::clone(&regions);
                std::thread::spawn(move || -> Result<(), String> {
                    loop {
                        // Lock spans recv() only, never a write.
                        let item = {
                            let guard = rx.lock().unwrap_or_else(|p| p.into_inner());
                            guard.recv()
                        };
                        let Ok((rxx, rzz, mut region)) = item else {
                            return Ok(());
                        };
                        let started = bench.then(std::time::Instant::now);
                        for chunk in region.chunks.values_mut() {
                            for section in chunk.sections.values_mut() {
                                section.compact();
                            }
                        }
                        let result = ctx.write(rxx, rzz, &region);
                        if let Some(t) = started {
                            write_ns.fetch_add(
                                t.elapsed().as_nanos() as u64,
                                std::sync::atomic::Ordering::Relaxed,
                            );
                            regions.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                        }
                        if let Err(e) = result {
                            let msg = e.to_string();
                            if let Ok(mut slot) = error_w.lock() {
                                if slot.is_none() {
                                    *slot = Some(msg.clone());
                                }
                            }
                            failed_w.store(true, std::sync::atomic::Ordering::Release);
                            return Err(msg);
                        }
                    }
                })
            })
            .collect();

        Self {
            tx: Some(tx),
            handles,
            error,
            failed,
            stall_ns: AtomicU64::new(0),
            write_ns,
            regions,
            bytes: AtomicU64::new(0),
            bench,
        }
    }

    fn error_msg(&self) -> String {
        self.error
            .lock()
            .ok()
            .and_then(|slot| slot.clone())
            .unwrap_or_else(|| "flush worker terminated early".to_string())
    }

    /// Enqueue a region; blocks when the channel is full (backpressure). On
    /// failure the region is handed back unchanged (so the caller can keep it in
    /// RAM) alongside the worker's real error.
    fn send(
        &self,
        rx: i32,
        rz: i32,
        region: common::RegionToModify,
    ) -> Result<(), (common::RegionToModify, String)> {
        use std::sync::atomic::Ordering;
        let Some(tx) = self.tx.as_ref() else {
            return Err((region, "flush worker already finished".to_string()));
        };
        if self.failed.load(Ordering::Acquire) {
            return Err((region, self.error_msg()));
        }
        // Measured before the move, but only counted once the region is actually queued.
        let bytes = if self.bench {
            region_storage_bytes(&region)
        } else {
            0
        };
        let started = self.bench.then(std::time::Instant::now);
        let sent = tx.send((rx, rz, region));
        if let Some(t) = started {
            self.stall_ns
                .fetch_add(t.elapsed().as_nanos() as u64, Ordering::Relaxed);
        }
        match sent {
            Ok(()) => {
                self.bytes.fetch_add(bytes, Ordering::Relaxed);
                Ok(())
            }
            Err(std::sync::mpsc::SendError((_, _, region))) => Err((region, self.error_msg())),
        }
    }

    /// Close the queue and wait for all pending writes; propagates the first error.
    pub(crate) fn finish(mut self) -> Result<(), String> {
        use std::sync::atomic::Ordering;
        drop(self.tx.take());
        let mut first: Option<String> = None;
        for handle in self.handles.drain(..) {
            match handle.join() {
                Ok(Ok(())) => {}
                Ok(Err(e)) => {
                    first.get_or_insert(e);
                }
                Err(_) => {
                    first.get_or_insert_with(|| "flush worker panicked".to_string());
                }
            }
        }
        if self.bench {
            eprintln!(
                "[BENCHMARK] flush_stall_ms={}",
                self.stall_ns.load(Ordering::Relaxed) / 1_000_000
            );
            eprintln!(
                "[BENCHMARK] flush_write_ms={}",
                self.write_ns.load(Ordering::Relaxed) / 1_000_000
            );
            eprintln!(
                "[BENCHMARK] flush_regions={}",
                self.regions.load(Ordering::Relaxed)
            );
            eprintln!(
                "[BENCHMARK] flush_bytes_mb={}",
                self.bytes.load(Ordering::Relaxed) / (1024 * 1024)
            );
        }
        match first {
            Some(e) => Err(e),
            None => Ok(()),
        }
    }
}

impl Drop for FlushWorker {
    /// The error paths drop the worker instead of calling `finish`, and the GUI
    /// deletes the world directory right after; detached writers would race it.
    fn drop(&mut self) {
        drop(self.tx.take());
        for handle in self.handles.drain(..) {
            let _ = handle.join();
        }
    }
}

#[allow(dead_code)]
fn single_item(id: &str, slot: i8, count: i8) -> HashMap<String, Value> {
    let mut item = HashMap::new();
    item.insert("id".to_string(), Value::String(id.to_string()));
    item.insert("Slot".to_string(), Value::Byte(slot));
    item.insert("Count".to_string(), Value::Byte(count));
    item
}

#[cfg(test)]
mod eviction_guard_tests {
    use super::*;
    use crate::coordinate_system::cartesian::XZBBox;
    use crate::coordinate_system::geographic::LLBBox;

    fn flush_test_ctx(dir: &std::path::Path) -> java::RegionWriteCtx {
        java::RegionWriteCtx::new(
            dir.to_path_buf(),
            LLBBox::new(54.6, 9.9, 54.61, 9.91).unwrap(),
            None,
            false,
            false,
            None,
            None,
            java::RegionWriteMode::Fresh,
            None,
            (0, 0),
        )
    }

    /// One region with a single non-AIR block, so the writer has real work to do.
    fn flush_test_region() -> common::RegionToModify {
        let mut region = common::RegionToModify::default();
        let chunk = region.chunks.entry((0, 0)).or_default();
        let section = chunk.sections.entry(0).or_default();
        section.storage.set(0, SMOOTH_STONE);
        region
    }

    /// Chunks stored in a written region file.
    fn stored_chunks(path: &std::path::Path) -> usize {
        let file = std::fs::File::open(path).unwrap();
        let mut region = fastanvil::Region::from_stream(file).unwrap();
        (0..32)
            .flat_map(|x| (0..32).map(move |z| (x, z)))
            .filter(|&(x, z)| region.read_chunk(x, z).unwrap().is_some())
            .count()
    }

    #[test]
    fn a_void_world_writes_only_the_chunks_the_area_touches() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("region").join("r.0.0.mca");
        let write = |void_world: bool| {
            java::RegionWriteCtx::new(
                dir.path().to_path_buf(),
                LLBBox::new(54.6, 9.9, 54.61, 9.91).unwrap(),
                None,
                false,
                void_world,
                None,
                None,
                java::RegionWriteMode::Fresh,
                None,
                (0, 0),
            )
            .write(0, 0, &flush_test_region())
            .unwrap();
        };

        write(false);
        assert_eq!(stored_chunks(&path), 1024, "a flat world fills the region");
        write(true);
        assert_eq!(
            stored_chunks(&path),
            1,
            "a void world leaves the rest to the void generator"
        );
    }

    #[test]
    fn flush_pool_writes_every_region_once() {
        let dir = tempfile::tempdir().unwrap();
        let worker = FlushWorker::spawn(flush_test_ctx(dir.path()), 4, 4, false);
        for i in 0..32 {
            assert!(worker.send(i, 0, flush_test_region()).is_ok());
        }
        worker.finish().unwrap();

        for i in 0..32 {
            let path = dir.path().join("region").join(format!("r.{i}.0.mca"));
            let len = std::fs::metadata(&path)
                .unwrap_or_else(|e| panic!("{path:?}: {e}"))
                .len();
            assert!(len > 0, "{path:?} is empty");
        }
    }

    #[test]
    fn flush_pool_reports_the_real_first_error() {
        // A file where the region directory should go, so create_dir_all fails.
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(dir.path().join("region"), b"not a directory").unwrap();
        let worker = FlushWorker::spawn(flush_test_ctx(dir.path()), 2, 3, false);
        // Some sends may fail once a worker has died; the surfaced error must be the cause.
        for i in 0..16 {
            if let Err((_, msg)) = worker.send(i, 0, flush_test_region()) {
                assert!(
                    !msg.contains("terminated early"),
                    "expected the real I/O cause, got {msg:?}"
                );
            }
        }
        let err = worker.finish().unwrap_err();
        assert!(!err.is_empty());
    }

    #[test]
    fn flush_pool_fails_fast_after_a_worker_error() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(dir.path().join("region"), b"not a directory").unwrap();
        let worker = FlushWorker::spawn(flush_test_ctx(dir.path()), 1, 2, false);
        // Keep sending until the failure is observed; with a shared receiver this only
        // works because `failed` is published explicitly.
        let mut refused = false;
        for i in 0..64 {
            if worker.send(i, 0, flush_test_region()).is_err() {
                refused = true;
                break;
            }
            std::thread::yield_now();
        }
        assert!(
            refused,
            "send kept accepting regions after every worker died"
        );
        let _ = worker.finish();
    }

    #[test]
    fn dropping_a_flush_worker_joins_its_threads() {
        // The error paths drop instead of calling finish, and the GUI deletes the world
        // directory straight after; a detached writer would race that removal.
        let dir = tempfile::tempdir().unwrap();
        {
            let worker = FlushWorker::spawn(flush_test_ctx(dir.path()), 4, 3, false);
            for i in 0..12 {
                assert!(worker.send(i, 0, flush_test_region()).is_ok());
            }
        }
        // Drop returned, so every write has landed and the directory is safe to remove.
        std::fs::remove_dir_all(dir.path().join("region")).unwrap();
    }

    // Writing an entity or chest to an already-evicted region must NOT resurrect it,
    // or the truncating final save wipes the region's real ground (the empty-spawn-chunk bug).
    #[test]
    fn writes_to_a_flushed_region_do_not_resurrect_it() {
        let xzbbox = XZBBox::rect_from_min_max(0, 0, 1023, 1023).unwrap();
        let llbbox = LLBBox::new(54.6, 9.9, 54.61, 9.91).unwrap();
        let mut editor = WorldEditor::new(std::env::temp_dir(), &xzbbox, llbbox);

        // Mark region (0,0) (blocks 0..511) as already streamed to disk.
        editor.flushed_regions.insert((0, 0));

        // All of these target region (0,0) and must be dropped.
        editor.add_entity("minecraft:item_frame", 100, 5, 100, None);
        editor.set_chest_with_items_absolute(100, 5, 100, vec![]);
        editor.set_block_absolute(SMOOTH_STONE, 100, 5, 100, None, None);

        assert!(
            !editor.world.regions.contains_key(&(0, 0)),
            "a flushed region must not be resurrected by entity/chest/block writes"
        );

        // A write to a non-flushed region still works.
        editor.add_entity("minecraft:item_frame", 600, 5, 600, None);
        assert!(
            editor.world.regions.contains_key(&(1, 1)),
            "writes to a resident region still land"
        );
    }

    #[test]
    fn frames_on_opposite_faces_of_one_cell_get_distinct_uuids() {
        let xzbbox = XZBBox::rect_from_min_max(0, 0, 63, 63).unwrap();
        let llbbox = LLBBox::new(54.6, 9.9, 54.61, 9.91).unwrap();
        let mut editor = WorldEditor::new(std::env::temp_dir(), &xzbbox, llbbox);
        editor.set_map_decals(true);
        // Two hosts with a one block gap, each showing a sign into that gap.
        editor.set_block_absolute(SMOOTH_STONE, 20, 5, 20, None, None);
        editor.set_block_absolute(SMOOTH_STONE, 20, 5, 22, None, None);
        assert!(editor.place_map_decal_ex(20, 5, 20, 3, 7, 0, false, false));
        assert!(editor.place_map_decal_ex(20, 5, 22, 2, 8, 0, false, false));

        let mut uuids: Vec<Vec<i32>> = Vec::new();
        for region in editor.world.regions.values() {
            for chunk in region.chunks.values() {
                let Some(Value::List(entities)) = chunk.other.get("entities") else {
                    continue;
                };
                for e in entities {
                    let Value::Compound(m) = e else { continue };
                    if let Some(Value::IntArray(u)) = m.get("UUID") {
                        uuids.push(u.iter().copied().collect());
                    }
                }
            }
        }
        assert_eq!(uuids.len(), 2);
        assert_ne!(uuids[0], uuids[1], "same cell, different face, same UUID");
    }

    /// The owning tile draws its own undergrowth; a halo copy would land on its
    /// water and under its trunks. Wood, leaves and ground still pass.
    #[test]
    fn a_tile_halo_keeps_no_undergrowth() {
        let xzbbox = XZBBox::rect_from_min_max(0, 0, 63, 63).unwrap();
        let llbbox = LLBBox::new(54.6, 9.9, 54.61, 9.91).unwrap();
        let mut editor = WorldEditor::new(std::env::temp_dir(), &xzbbox, llbbox);
        editor.set_strict_bounds(0, 0, 31, 63);
        for (x, block) in [
            (10, GRASS),
            (40, GRASS),
            (41, CORNFLOWER),
            (42, OAK_LOG),
            (43, OAK_LEAVES),
        ] {
            editor.set_block_absolute(block, x, 1, 10, None, None);
        }
        assert!(
            editor.block_exists_absolute(10, 1, 10),
            "owned undergrowth stays"
        );
        assert!(!editor.block_exists_absolute(40, 1, 10));
        assert!(!editor.block_exists_absolute(41, 1, 10));
        assert!(editor.block_exists_absolute(42, 1, 10), "halo wood passes");
        assert!(editor.block_exists_absolute(43, 1, 10), "halo leaves pass");
    }

    #[test]
    fn solid_blocks_that_read_like_plants_are_not_passable() {
        for solid in [
            "grass_block",
            "snow_block",
            "flower_pot",
            "stone",
            "oak_planks",
        ] {
            assert!(!is_passable_cover(solid), "{solid}");
        }
        for cover in [
            "short_grass",
            "tall_grass",
            "fern",
            "snow",
            "poppy",
            "white_carpet",
        ] {
            assert!(is_passable_cover(cover), "{cover}");
        }
    }

    #[test]
    fn wall_signs_reject_floor_and_ceiling_facings() {
        let xzbbox = XZBBox::rect_from_min_max(0, 0, 63, 63).unwrap();
        let llbbox = LLBBox::new(54.6, 9.9, 54.61, 9.91).unwrap();
        let mut editor = WorldEditor::new(std::env::temp_dir(), &xzbbox, llbbox);
        editor.set_block_absolute(SMOOTH_STONE, 10, 5, 10, None, None);
        for facing in [0i8, 1] {
            assert!(!editor.place_wall_sign(10, 5, 10, facing, &["x"]));
        }
        assert!(editor.place_wall_sign(10, 5, 10, 2, &["x"]));
    }
}
