//! Java Edition Anvil format world saving.
//!
//! This module handles saving worlds in the Java Edition Anvil (.mca) format.

use super::common::{Chunk, ChunkToModify, Section};
use super::WorldEditor;
use crate::block_definitions::Block;
use crate::progress::emit_gui_progress_update;
use colored::Colorize;
use fastanvil::Region;
use fastnbt::{ByteArray, LongArray, Value};
use fnv::FnvHashMap;
use indicatif::{ProgressBar, ProgressStyle};
use rayon::prelude::*;
use std::cmp::Reverse;
use std::collections::HashMap;
use std::fs::File;
use std::io::Write;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex, OnceLock};

/// Minecraft 1.21.1 data version for chunk format identification.
pub(crate) const DATA_VERSION: i32 = 3955;

/// Cached base chunk sections (a grass plane at the terrain base).
/// Keyed by that base: it sinks when the relief needs the extended floor, and a GUI process
/// can generate several worlds in a row, so a plain OnceLock would go stale.
/// Cached filler-chunk sections, keyed by the base Y and block they came from.
type BaseChunkCache = Option<(i32, Block, Arc<Vec<Section>>)>;

static BASE_CHUNK_SECTIONS: Mutex<BaseChunkCache> = Mutex::new(None);

/// Get or create the cached base chunk sections for the current terrain base.
fn get_base_chunk_sections() -> Arc<Vec<Section>> {
    let base_y = crate::world_editor::base_chunk_y();
    let block = crate::world_editor::base_chunk_block();
    let mut cache = BASE_CHUNK_SECTIONS.lock().unwrap();
    if let Some((cached_y, cached_block, ref sections)) = *cache {
        if cached_y == base_y && cached_block == block {
            return Arc::clone(sections);
        }
    }
    let mut chunk = ChunkToModify::default();
    for x in 0..16 {
        for z in 0..16 {
            chunk.set_block(x, base_y, z, block);
        }
    }
    let sections = Arc::new(chunk.sections().collect::<Vec<Section>>());
    *cache = Some((base_y, block, Arc::clone(&sections)));
    sections
}

#[cfg(feature = "gui")]
use crate::telemetry::{send_log, LogLevel};

impl<'a> WorldEditor<'a> {
    /// Saves the world in Java Edition Anvil format.
    ///
    /// Uses parallel processing with rayon for fast region saving.
    /// Returns an error if any region fails to save (e.g. disk full).
    pub(super) fn save_java(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        println!("{} Saving world...", "[7/7]".bold());
        emit_gui_progress_update(90.0, "Saving world...");

        // Save metadata with error handling
        if let Err(e) = self.save_metadata() {
            eprintln!("Failed to save world metadata: {}", e);
            #[cfg(feature = "gui")]
            send_log(LogLevel::Warning, "Failed to save world metadata.");
            // Continue with world saving even if metadata fails
        }

        if self.world.regions.is_empty() {
            return Ok(());
        }

        // Compute region bounds from original bbox to skip halo regions.
        // A region at (rx, rz) covers blocks [rx*512 .. rx*512+511] × [rz*512 .. rz*512+511].
        let min_region_x = self.xzbbox.min_x().div_euclid(512);
        let max_region_x = self.xzbbox.max_x().div_euclid(512);
        let min_region_z = self.xzbbox.min_z().div_euclid(512);
        let max_region_z = self.xzbbox.max_z().div_euclid(512);

        let total_regions = self
            .world
            .regions
            .keys()
            .filter(|(rx, rz)| {
                *rx >= min_region_x
                    && *rx <= max_region_x
                    && *rz >= min_region_z
                    && *rz <= max_region_z
            })
            .count() as u64;

        if total_regions == 0 {
            return Ok(());
        }

        let save_pb = ProgressBar::new(total_regions);
        save_pb.set_style(
            ProgressStyle::default_bar()
                .template(
                    "{spinner:.green} [{elapsed_precise}] [{bar:45}] {pos}/{len} regions ({eta})",
                )
                .unwrap()
                .progress_chars("█▓░"),
        );

        let regions_processed = AtomicU64::new(0);
        let should_stop = std::sync::atomic::AtomicBool::new(false);
        let first_error: Mutex<Option<Box<dyn std::error::Error + Send + Sync>>> = Mutex::new(None);

        self.world
            .regions
            .par_iter()
            .for_each(|((region_x, region_z), region_to_modify)| {
                // Skip halo regions outside the original bbox.
                if *region_x < min_region_x
                    || *region_x > max_region_x
                    || *region_z < min_region_z
                    || *region_z > max_region_z
                {
                    return;
                }

                // Fast-path: bail out without locking once an error has been recorded.
                if should_stop.load(Ordering::Acquire) {
                    return;
                }

                if let Err(e) = self.save_single_region(*region_x, *region_z, region_to_modify) {
                    let mut guard = first_error.lock().unwrap_or_else(|p| p.into_inner());
                    if guard.is_none() {
                        *guard = Some(e);
                    }
                    should_stop.store(true, Ordering::Release);
                    return;
                }

                // Update progress
                let regions_done = regions_processed.fetch_add(1, Ordering::SeqCst) + 1;

                // 90->97; 97-100 is the finalize tail (map/signage tiles, settings).
                let update_interval = (total_regions / 10).max(1);
                if regions_done.is_multiple_of(update_interval) || regions_done == total_regions {
                    let progress = 90.0 + (regions_done as f64 / total_regions as f64) * 7.0;
                    emit_gui_progress_update(progress, "Saving world...");
                }

                save_pb.inc(1);
            });

        save_pb.finish();

        if let Some(e) = first_error.lock().unwrap_or_else(|p| p.into_inner()).take() {
            return Err(e);
        }

        Ok(())
    }

    /// Saves a single region to disk.
    ///
    /// Optimized for new world creation, writes chunks directly without reading existing data.
    /// This assumes we're creating a fresh world, not modifying an existing one.
    pub(super) fn save_single_region(
        &self,
        region_x: i32,
        region_z: i32,
        region_to_modify: &super::common::RegionToModify,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        write_region_to_disk(
            &self.world_dir,
            &self.llbbox,
            self.ground.as_deref(),
            self.bake_lighting,
            self.void_world,
            self.preview.as_deref(),
            self.voxy.as_deref(),
            region_x,
            region_z,
            region_to_modify,
            &self.region_write_mode(),
            self.climate_lat(),
            (self.ground_origin_x, self.ground_origin_z),
        )
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub(crate) enum RegionWriteMode {
    /// New region file, every chunk written (content or filler).
    Fresh,
    /// Only the chunks inside the inclusive block bounds, written into the
    /// existing region file. Every other chunk stays as it was.
    Merge {
        min_x: i32,
        min_z: i32,
        max_x: i32,
        max_z: i32,
        layout: crate::world_utils::WorldLayout,
    },
}

impl RegionWriteMode {
    fn writes_chunk(&self, abs_chunk_x: i32, abs_chunk_z: i32) -> bool {
        match *self {
            RegionWriteMode::Fresh => true,
            RegionWriteMode::Merge {
                min_x,
                min_z,
                max_x,
                max_z,
                ..
            } => {
                let bx0 = abs_chunk_x * 16;
                let bz0 = abs_chunk_z * 16;
                bx0 + 15 >= min_x && bx0 <= max_x && bz0 + 15 >= min_z && bz0 <= max_z
            }
        }
    }
}

/// Opens `r.X.Z.mca` for a merge, or creates it empty. Never from the
/// template: its placeholder chunks carry another region's positions, and
/// Minecraft refuses to load the ones a merge leaves standing.
fn open_region_file_for_merge(
    overworld_dir: &std::path::Path,
    region_x: i32,
    region_z: i32,
) -> Result<Region<File>, Box<dyn std::error::Error + Send + Sync>> {
    let region_dir = overworld_dir.join("region");
    let out_path = region_dir.join(format!("r.{}.{}.mca", region_x, region_z));
    if out_path.is_file() {
        let file = File::options().read(true).write(true).open(&out_path)?;
        // Refused rather than replaced: the file holds chunks of other areas.
        return Region::from_stream(file).map_err(|e| {
            format!("{} is not a readable region file: {e}", out_path.display()).into()
        });
    }
    std::fs::create_dir_all(&region_dir)?;
    let file = File::options()
        .read(true)
        .write(true)
        .create(true)
        .truncate(true)
        .open(&out_path)?;
    Ok(Region::create(file)?)
}

/// Removes chunks whose stored position does not match their slot, as left
/// by the first One World build. Returns how many.
pub(crate) fn drop_misplaced_chunks(world_dir: &std::path::Path) -> std::io::Result<usize> {
    let region_dir = crate::world_utils::WorldLayout::of(world_dir)
        .overworld_dir(world_dir)
        .join("region");
    if !region_dir.is_dir() {
        return Ok(0);
    }
    let mut removed = 0usize;
    for entry in std::fs::read_dir(&region_dir)? {
        let path = entry?.path();
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
        let mut parts = name.strip_suffix(".mca").unwrap_or("").split('.');
        let (Some("r"), Some(rx), Some(rz)) = (parts.next(), parts.next(), parts.next()) else {
            continue;
        };
        let (Ok(rx), Ok(rz)) = (rx.parse::<i32>(), rz.parse::<i32>()) else {
            continue;
        };
        let (Some(bx), Some(bz)) = (rx.checked_mul(32), rz.checked_mul(32)) else {
            continue;
        };
        let file = File::options().read(true).write(true).open(&path)?;
        let Ok(mut region) = Region::from_stream(file) else {
            continue;
        };
        for cz in 0..32usize {
            for cx in 0..32usize {
                let Ok(Some(data)) = region.read_chunk(cx, cz) else {
                    continue;
                };
                let Ok(Value::Compound(root)) = fastnbt::from_bytes::<Value>(&data) else {
                    continue;
                };
                let (Some(Value::Int(x)), Some(Value::Int(z))) =
                    (root.get("xPos"), root.get("zPos"))
                else {
                    continue;
                };
                if (*x, *z) != (bx + cx as i32, bz + cz as i32) {
                    region
                        .remove_chunk(cx, cz)
                        .map_err(|e| std::io::Error::other(e.to_string()))?;
                    removed += 1;
                }
            }
        }
    }
    Ok(removed)
}

/// Minecraft moves a chunk's entities into `entities/` on first load. Drop
/// them for rewritten chunks so they do not linger over the new blocks.
fn strip_stale_side_chunks(
    overworld_dir: &std::path::Path,
    region_x: i32,
    region_z: i32,
    chunks: &[(i32, i32)],
) {
    for folder in ["entities", "poi"] {
        let path = overworld_dir
            .join(folder)
            .join(format!("r.{}.{}.mca", region_x, region_z));
        if !path.is_file() {
            continue;
        }
        let Ok(file) = File::options().read(true).write(true).open(&path) else {
            continue;
        };
        let Ok(mut region) = Region::from_stream(file) else {
            continue;
        };
        for &(cx, cz) in chunks {
            if let Err(e) = region.remove_chunk(cx as usize, cz as usize) {
                eprintln!(
                    "Warning: could not drop chunk ({cx}, {cz}) from {}: {e}",
                    path.display()
                );
            }
        }
    }
}

/// Open (truncating) a fresh `r.X.Z.mca` under `world_dir/region`. A flat world starts
/// from the template; a void world starts empty, since nothing outside the area is written.
fn create_region_file(
    world_dir: &std::path::Path,
    region_x: i32,
    region_z: i32,
    void_world: bool,
) -> Result<Region<File>, Box<dyn std::error::Error + Send + Sync>> {
    let region_dir = world_dir.join("region");
    let out_path = region_dir.join(format!("r.{}.{}.mca", region_x, region_z));
    std::fs::create_dir_all(&region_dir)?;

    let mut region_file: File = File::options()
        .read(true)
        .write(true)
        .create(true)
        .truncate(true)
        .open(&out_path)?;
    if void_world {
        return Ok(Region::create(region_file)?);
    }
    const REGION_TEMPLATE: &[u8] = include_bytes!("../../assets/minecraft/region.template");
    region_file.write_all(REGION_TEMPLATE)?;
    Ok(Region::from_stream(region_file)?)
}

/// Serialize one region's chunks to its `.mca`. Shared by the synchronous save
/// path and the background flush worker (hence free-standing, not `&self`).
/// Every in-bbox region passes here exactly once, so the map preview and the
/// voxy LOD cache are both fed here.
///
/// Chunks are visited in Morton (quadtree) order. The `.mca` does not care -
/// it allocates sectors as chunks land - but the voxy builder does: it finishes
/// a level-`n` LOD column every `4^n` chunk columns, which is what keeps its
/// working set at a handful of megabytes instead of a whole region's worth.
#[allow(clippy::too_many_arguments)]
fn write_region_to_disk(
    world_dir: &std::path::Path,
    llbbox: &crate::coordinate_system::geographic::LLBBox,
    ground: Option<&crate::ground::Ground>,
    bake_lighting: bool,
    void_world: bool,
    preview: Option<&crate::map_renderer::PreviewAccumulator>,
    voxy: Option<&crate::voxy::VoxyWriter>,
    region_x: i32,
    region_z: i32,
    region_to_modify: &super::common::RegionToModify,
    mode: &RegionWriteMode,
    climate_lat: Option<f64>,
    ground_origin: (i32, i32),
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    if let Some(preview) = preview {
        preview.ingest_region(region_x, region_z, region_to_modify);
    }
    // A merge goes where the world keeps its overworld, which 26.1 moves.
    let merge_dir = match *mode {
        RegionWriteMode::Merge { layout, .. } => Some(layout.overworld_dir(world_dir)),
        RegionWriteMode::Fresh => None,
    };
    let merge = merge_dir.is_some();
    let mut region = match &merge_dir {
        Some(dir) => open_region_file_for_merge(dir, region_x, region_z)?,
        None => create_region_file(world_dir, region_x, region_z, void_world)?,
    };
    let mut ser_buffer = Vec::with_capacity(8192);
    let mut written_chunks: Vec<(i32, i32)> = Vec::new();

    // World-center latitude drives temperature-based biome variants (taiga
    // vs forest vs jungle) at chunk-build time. Cheap to recompute.
    let center_lat = climate_lat.unwrap_or((llbbox.min().lat() + llbbox.max().lat()) * 0.5);

    // Filler chunks all share one set of sections, so they share their light too. A void
    // world has none: what the area does not touch is left to the void generator.
    let base_sections = if void_world {
        Arc::new(Vec::new())
    } else {
        get_base_chunk_sections()
    };
    let (base_min_y, base_max_y) = chunk_section_span(&base_sections);
    let base_lighting = (bake_lighting && !void_world)
        .then(|| compute_chunk_lighting(&base_sections, (base_min_y, base_max_y)));

    let mut lod = voxy.map(|writer| {
        let (min_y, max_y) = region_content_span(region_to_modify);
        writer.region_lod(
            min_y,
            max_y,
            live_lod_sections(region_to_modify, region_x, region_z),
        )
    });

    for column in 0..256usize {
        let (sx, sz) = morton_16(column);
        for dz in 0..2 {
            for dx in 0..2 {
                let chunk_x = sx * 2 + dx;
                let chunk_z = sz * 2 + dz;
                let abs_chunk_x = chunk_x + (region_x * 32);
                let abs_chunk_z = chunk_z + (region_z * 32);
                if !mode.writes_chunk(abs_chunk_x, abs_chunk_z) {
                    continue;
                }
                let mut existing = region_to_modify.get_chunk(chunk_x, chunk_z);

                // A chunk that is present but holds nothing is left unwritten,
                // as it was before this loop was reordered. A merge fills it.
                if existing.is_some_and(|c| c.sections.is_empty() && c.other.is_empty()) {
                    if merge {
                        existing = None;
                    } else {
                        continue;
                    }
                }
                // A fresh void region holds only the chunks the area touches; the void
                // generator makes the rest. A merge stays inside its area anyway.
                if void_world && !merge && existing.is_none() {
                    continue;
                }

                let biome_names = crate::biome::chunk_biome_names(
                    abs_chunk_x,
                    abs_chunk_z,
                    ground,
                    center_lat,
                    ground_origin,
                );
                let biome_value = crate::biome::biome_nbt_from_names(&biome_names);

                let (sections, other, lighting, span) = match existing {
                    Some(chunk_to_modify) => {
                        let sections: Vec<Section> = chunk_to_modify.sections().collect();
                        let span = chunk_section_span(&sections);
                        let lighting =
                            bake_lighting.then(|| compute_chunk_lighting(&sections, span));
                        (
                            sections,
                            strip_orphan_block_entities(chunk_to_modify),
                            lighting,
                            span,
                        )
                    }
                    None => (
                        base_sections.to_vec(),
                        FnvHashMap::default(),
                        base_lighting.clone(),
                        (base_min_y, base_max_y),
                    ),
                };

                if let Some(lod) = lod.as_mut() {
                    lod.ingest_chunk(
                        abs_chunk_x,
                        abs_chunk_z,
                        &sections,
                        (span.0 as i32, span.1 as i32),
                        lighting.as_deref(),
                        &biome_names,
                    );
                }

                let chunk = Chunk {
                    sections,
                    x_pos: abs_chunk_x,
                    z_pos: abs_chunk_z,
                    is_light_on: 0,
                    other,
                };
                let chunk_nbt = create_chunk_nbt_with_lighting(&chunk, lighting, &biome_value);
                ser_buffer.clear();
                fastnbt::to_writer(&mut ser_buffer, &chunk_nbt)?;
                region.write_chunk(chunk_x as usize, chunk_z as usize, &ser_buffer)?;
                if merge {
                    written_chunks.push((chunk_x, chunk_z));
                }
            }
        }

        if let Some(lod) = lod.as_mut() {
            lod.end_column(column);
        }
    }

    if let Some(mut lod) = lod {
        lod.finish();
    }

    if let Some(dir) = merge_dir.filter(|_| !written_chunks.is_empty()) {
        drop(region);
        strip_stale_side_chunks(&dir, region_x, region_z, &written_chunks);
    }

    Ok(())
}

/// Morton (Z-order) index into a 16x16 grid of 2x2-chunk columns.
fn morton_16(index: usize) -> (i32, i32) {
    let mut x = 0i32;
    let mut z = 0i32;
    for bit in 0..4 {
        x |= (((index >> (2 * bit)) & 1) as i32) << bit;
        z |= (((index >> (2 * bit + 1)) & 1) as i32) << bit;
    }
    (x, z)
}

/// Which LOD sections of this region can hold a block.
///
/// Derived from chunk section keys alone, so it costs nothing next to the voxel
/// work it saves: above the roofline every column is air, and without this the
/// builder would allocate and zero a 256 KB buffer for each of those sections
/// only to drop it again at flush.
///
/// A section that turns out to be all air anyway is still listed - the keys say
/// a chunk section exists there, not that it holds a block - which costs one
/// buffer that the flush then discards.
///
/// Note this marks LOD *sections*, not chunk sections: the air one section
/// above the tallest roof is never marked here, yet it still gets ingested,
/// because the level-1..4 sections it falls into are live from the content
/// below it. That is what `region_content_span`'s `+ 1` relies on.
fn live_lod_sections(
    region: &super::common::RegionToModify,
    region_x: i32,
    region_z: i32,
) -> crate::voxy::LiveSections {
    let base_section_y = crate::world_editor::base_chunk_y() >> 4;
    let mut live: crate::voxy::LiveSections = Default::default();
    for local_x in 0..32 {
        for local_z in 0..32 {
            let chunk_x = region_x * 32 + local_x;
            let chunk_z = region_z * 32 + local_z;
            match region.get_chunk(local_x, local_z) {
                Some(chunk) => {
                    for &section_y in chunk.sections.keys() {
                        crate::voxy::mark_live(&mut live, chunk_x, section_y as i32, chunk_z);
                    }
                }
                // Filler chunks are a flat plane at the terrain base.
                None => crate::voxy::mark_live(&mut live, chunk_x, base_section_y, chunk_z),
            }
        }
    }
    live
}

/// The span of chunk sections the voxy builder has to walk for one region.
///
/// The upper bound is the highest section holding a block anywhere in the
/// region: above it every column is air, so any LOD section up there would be
/// dropped as empty. Sections that are present but all-air only widen the span,
/// which costs a little work and never loses data.
fn region_content_span(region: &super::common::RegionToModify) -> (i32, i32) {
    let base_section_y = crate::world_editor::base_chunk_y() >> 4;
    let mut min_y = base_section_y.min(-4);
    let mut max_y = base_section_y;
    for chunk in region.chunks.values() {
        for &section_y in chunk.sections.keys() {
            min_y = min_y.min(section_y as i32);
            max_y = max_y.max(section_y as i32);
        }
    }
    // One section past the top. Every solid voxel sits at or below `max_y`, so
    // this is exactly enough for each of them to have its lit neighbour above
    // ingested - at level 4 that neighbour is a whole chunk section away.
    // Dropping the +1 leaves dark air over the tallest roofs in the coarse
    // levels; going further only fills sections that nothing samples.
    (min_y, max_y + 1)
}

/// Owned, `Send` context for writing regions off the main thread (background flush).
/// Mirrors the fields `write_region_to_disk` needs from a `WorldEditor`.
pub(crate) struct RegionWriteCtx {
    world_dir: std::path::PathBuf,
    llbbox: crate::coordinate_system::geographic::LLBBox,
    ground: Option<std::sync::Arc<crate::ground::Ground>>,
    bake_lighting: bool,
    void_world: bool,
    preview: Option<std::sync::Arc<crate::map_renderer::PreviewAccumulator>>,
    voxy: Option<std::sync::Arc<crate::voxy::VoxyWriter>>,
    mode: RegionWriteMode,
    climate_lat: Option<f64>,
    ground_origin: (i32, i32),
}

impl RegionWriteCtx {
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn new(
        world_dir: std::path::PathBuf,
        llbbox: crate::coordinate_system::geographic::LLBBox,
        ground: Option<std::sync::Arc<crate::ground::Ground>>,
        bake_lighting: bool,
        void_world: bool,
        preview: Option<std::sync::Arc<crate::map_renderer::PreviewAccumulator>>,
        voxy: Option<std::sync::Arc<crate::voxy::VoxyWriter>>,
        mode: RegionWriteMode,
        climate_lat: Option<f64>,
        ground_origin: (i32, i32),
    ) -> Self {
        Self {
            world_dir,
            llbbox,
            ground,
            bake_lighting,
            void_world,
            preview,
            voxy,
            mode,
            climate_lat,
            ground_origin,
        }
    }

    pub(crate) fn write(
        &self,
        region_x: i32,
        region_z: i32,
        region_to_modify: &super::common::RegionToModify,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        write_region_to_disk(
            &self.world_dir,
            &self.llbbox,
            self.ground.as_deref(),
            self.bake_lighting,
            self.void_world,
            self.preview.as_deref(),
            self.voxy.as_deref(),
            region_x,
            region_z,
            region_to_modify,
            &self.mode,
            self.climate_lat,
            self.ground_origin,
        )
    }
}

/// Helper function to get entity coordinates
/// Extracts a block entity or entity position for coordinate dedup. Hanging entities
/// (item frames) add their `Facing`, so several decals can share one cell.
///
/// An entity's UUID beats `Facing` where there is one. Every UUID this writer
/// produces comes from `build_deterministic_uuid`, so the two copies a tile
/// halo makes of one entity carry the same one and still collapse, while two
/// entities that merely round into the same cell (two facade panels meeting at
/// a building corner put their centres in one block) no longer take each
/// other's place. Block entities have no UUID and keep the old key.
///
/// The whole UUID goes in the key, not a fold of it: `uuid[0] ^ uuid[3]` would
/// put 128 bits into 32, and at a few thousand panels in one world the birthday
/// odds of two colliding are percents, not nothing. A collision here is silent
/// entity loss, which is the defect this key exists to fix.
#[derive(PartialEq, Eq, Hash, Clone, Copy, Debug)]
enum EntityIdentity {
    Uuid([i32; 4]),
    /// Block entities carry no UUID; `Facing` separates the ones that share a
    /// cell, and -1 stands for an entity that has neither.
    Facing(i32),
}

#[inline]
fn get_entity_coords(entity: &HashMap<String, Value>) -> Option<(i32, i32, i32, EntityIdentity)> {
    let facing = match entity.get("UUID") {
        Some(Value::IntArray(uuid)) if uuid.len() == 4 => {
            EntityIdentity::Uuid([uuid[0], uuid[1], uuid[2], uuid[3]])
        }
        _ => EntityIdentity::Facing(entity.get("Facing").and_then(value_to_i32).unwrap_or(-1)),
    };
    if let Some(Value::List(pos)) = entity.get("Pos") {
        if pos.len() == 3 {
            if let (Some(x), Some(y), Some(z)) = (
                value_to_i32(&pos[0]),
                value_to_i32(&pos[1]),
                value_to_i32(&pos[2]),
            ) {
                return Some((x, y, z, facing));
            }
        }
    }

    let (Some(x), Some(y), Some(z)) = (
        entity.get("x").and_then(value_to_i32),
        entity.get("y").and_then(value_to_i32),
        entity.get("z").and_then(value_to_i32),
    ) else {
        return None;
    };

    Some((x, y, z, facing))
}

// Reads a string blockstate property, if present.
fn prop_str<'a>(props: Option<&'a Value>, key: &str) -> Option<&'a str> {
    if let Some(Value::Compound(m)) = props {
        if let Some(Value::String(s)) = m.get(key) {
            return Some(s.as_str());
        }
    }
    None
}

// Light a block emits, 0 if none. Honours the `lit` state where it matters.
fn block_light_emission(name: &str, props: Option<&Value>) -> u8 {
    let unlit = matches!(prop_str(props, "lit"), Some("false"));
    match name {
        "minecraft:beacon"
        | "minecraft:conduit"
        | "minecraft:end_gateway"
        | "minecraft:end_portal"
        | "minecraft:fire"
        | "minecraft:glowstone"
        | "minecraft:jack_o_lantern"
        | "minecraft:lantern"
        | "minecraft:lava"
        | "minecraft:ochre_froglight"
        | "minecraft:pearlescent_froglight"
        | "minecraft:verdant_froglight"
        | "minecraft:sea_lantern"
        | "minecraft:shroomlight" => 15,
        "minecraft:campfire" if !unlit => 15,
        "minecraft:end_rod" | "minecraft:torch" | "minecraft:wall_torch" => 14,
        "minecraft:crying_obsidian"
        | "minecraft:soul_lantern"
        | "minecraft:soul_torch"
        | "minecraft:soul_wall_torch" => 10,
        "minecraft:soul_campfire" if !unlit => 10,
        "minecraft:glow_lichen" => 7,
        "minecraft:redstone_torch" | "minecraft:redstone_wall_torch" if !unlit => 7,
        "minecraft:sculk_catalyst" => 6,
        "minecraft:magma_block" => 3,
        "minecraft:brewing_stand" | "minecraft:brown_mushroom" => 1,
        _ => 0,
    }
}

// Blocks that don't occlude skylight: air, glass, leaves, water/ice, plants, thin decor.
fn is_light_transparent(name: &str) -> bool {
    let n = name.strip_prefix("minecraft:").unwrap_or(name);
    if n == "tinted_glass" {
        return false; // tinted glass blocks all light, unlike other glass
    }
    if n.ends_with("air") || n.ends_with("leaves") || n.contains("glass") {
        return true;
    }
    const EXACT: &[&str] = &[
        "water",
        "ice",
        "frosted_ice",
        "bubble_column",
        "grass",
        "short_grass",
        "tall_grass",
        "fern",
        "large_fern",
        "dead_bush",
        "bush",
        "dandelion",
        "poppy",
        "blue_orchid",
        "allium",
        "azure_bluet",
        "oxeye_daisy",
        "cornflower",
        "lily_of_the_valley",
        "wither_rose",
        "torchflower",
        "red_tulip",
        "orange_tulip",
        "white_tulip",
        "pink_tulip",
        "sunflower",
        "lilac",
        "rose_bush",
        "peony",
        "pink_petals",
        "spore_blossom",
        "hanging_roots",
        "glow_lichen",
        "sweet_berry_bush",
        "cactus",
        "bamboo",
        "sugar_cane",
        "nether_wart",
        "wheat",
        "carrots",
        "potatoes",
        "lily_pad",
        "sea_pickle",
        "cobweb",
        "snow",
        "lever",
        "tripwire",
        "tripwire_hook",
        "end_rod",
        "lightning_rod",
        "scaffolding",
        "pointed_dripstone",
        "turtle_egg",
    ];
    if EXACT.contains(&n) {
        return true;
    }
    if n.ends_with("_block") || n.ends_with("_stem") {
        return false;
    }
    // Slabs/stairs are left opaque: their solid half occludes light via shape.
    const SUB: &[&str] = &[
        "torch", "lantern", "sign", "rail", "carpet", "candle", "chain", "ladder", "banner",
        "sapling", "coral", "sprouts", "roots", "vine", "flower", "mushroom", "amethyst", "_bud",
        "seagrass", "kelp", "petals", "fence", "wall", "_bars", "door",
    ];
    SUB.iter().any(|s| n.contains(s))
}

// Light a block removes: 0 passes, 1 attenuates (water/leaves/ice), 15 blocks.
pub(crate) fn light_opacity(name: &str) -> u8 {
    let n = name.strip_prefix("minecraft:").unwrap_or(name);
    if n.ends_with("leaves")
        || matches!(
            n,
            "water"
                | "ice"
                | "frosted_ice"
                | "bubble_column"
                | "kelp"
                | "kelp_plant"
                | "seagrass"
                | "tall_seagrass"
        )
    {
        return 1;
    }
    if is_light_transparent(name) {
        0
    } else {
        15
    }
}

// Per-cell light opacity and emission for a section (YZX order, 4096 cells).
fn decode_section_light_props(section: &Section) -> (Vec<u8>, Vec<u8>) {
    let palette = &section.block_states.palette;
    let pal_opacity: Vec<u8> = palette.iter().map(|p| light_opacity(&p.name)).collect();
    let pal_emission: Vec<u8> = palette
        .iter()
        .map(|p| block_light_emission(&p.name, p.properties.as_ref()))
        .collect();

    let mut opacity = vec![0u8; 4096];
    let mut emission = vec![0u8; 4096];

    match &section.block_states.data {
        None => {
            let o = pal_opacity.first().copied().unwrap_or(0);
            let e = pal_emission.first().copied().unwrap_or(0);
            if o > 0 {
                opacity.iter_mut().for_each(|v| *v = o);
            }
            if e > 0 {
                emission.iter_mut().for_each(|v| *v = e);
            }
        }
        Some(data) => {
            let mut bits = 4;
            while (1usize << bits) < palette.len() {
                bits += 1;
            }
            let vals_per_long = 64 / bits;
            let mask = (1u64 << bits) - 1;
            for i in 0..4096usize {
                let long_idx = i / vals_per_long;
                let off = (i % vals_per_long) * bits;
                if long_idx < data.len() {
                    let pi = ((data[long_idx] as u64 >> off) & mask) as usize;
                    if pi < palette.len() {
                        opacity[i] = pal_opacity[pi];
                        emission[i] = pal_emission[pi];
                    }
                }
            }
        }
    }
    (opacity, emission)
}

// Flood-fill light from the seeded queue, -1 per block, through cells light can enter.
fn propagate_light(
    light: &mut [u8],
    opacity: &[u8],
    queue: &mut std::collections::VecDeque<(usize, usize, usize, u8)>,
    height: usize,
) {
    let idx = |x: usize, y: usize, z: usize| y * 256 + z * 16 + x;
    while let Some((x, y, z, level)) = queue.pop_front() {
        if level <= 1 {
            continue;
        }
        let next = level - 1;
        let try_spread =
            |nx: usize,
             ny: usize,
             nz: usize,
             light: &mut [u8],
             queue: &mut std::collections::VecDeque<(usize, usize, usize, u8)>| {
                let g = idx(nx, ny, nz);
                if opacity[g] < 15 && light[g] < next {
                    light[g] = next;
                    queue.push_back((nx, ny, nz, next));
                }
            };
        if x > 0 {
            try_spread(x - 1, y, z, light, queue);
        }
        if x < 15 {
            try_spread(x + 1, y, z, light, queue);
        }
        if z > 0 {
            try_spread(x, y, z - 1, light, queue);
        }
        if z < 15 {
            try_spread(x, y, z + 1, light, queue);
        }
        if y > 0 {
            try_spread(x, y - 1, z, light, queue);
        }
        if y + 1 < height {
            try_spread(x, y + 1, z, light, queue);
        }
    }
}

// Pack a 0..15 value into the 4-bit-per-cell light array.
#[inline]
fn pack_light_nibble(arr: &mut [i8], index: usize, value: u8) {
    let byte = index >> 1;
    let cur = arr[byte] as u8;
    let new = if index & 1 == 0 {
        (cur & 0xF0) | (value & 0x0F)
    } else {
        (cur & 0x0F) | (value << 4)
    };
    arr[byte] = new as i8;
}

/// Sky and block light for a run of sections, as 2048-byte nibble arrays per section.
type SectionLight = Vec<(Vec<i8>, Vec<i8>)>;

// Sky + block light per section as 2048-byte nibble arrays.
//
// `sky_above` is the skylight entering the top of the range: 15 under open sky, or the level
// leaving the bottom of the range above. Also returns the level leaving this range's bottom,
// or None when that plane is mixed and a caller stacking ranges cannot carry a single value.
fn compute_lighting(
    sections: &[Section],
    min_section_y: i8,
    max_section_y: i8,
    sky_above: u8,
) -> (SectionLight, Option<u8>) {
    use std::collections::VecDeque;

    let num_sections = (max_section_y as i32 - min_section_y as i32 + 1).max(0) as usize;
    let height = num_sections * 16;
    if height == 0 {
        return (Vec::new(), Some(sky_above));
    }
    let idx = |x: usize, y: usize, z: usize| y * 256 + z * 16 + x;

    let mut opacity = vec![0u8; height * 256];
    let mut emission = vec![0u8; height * 256];

    let sec_by_y: HashMap<i8, &Section> = sections.iter().map(|s| (s.y, s)).collect();
    let mut htop = 0usize;
    let mut any_solid = false;
    for sy in min_section_y..=max_section_y {
        let Some(sec) = sec_by_y.get(&sy) else {
            continue;
        };
        let base_y = ((sy as i32 - min_section_y as i32) * 16) as usize;
        let (op, em) = decode_section_light_props(sec);
        for ly in 0..16usize {
            for z in 0..16usize {
                for x in 0..16usize {
                    let local = ly * 256 + z * 16 + x;
                    let g = idx(x, base_y + ly, z);
                    opacity[g] = op[local];
                    emission[g] = em[local];
                    if op[local] > 0 {
                        any_solid = true;
                        htop = htop.max(base_y + ly);
                    }
                }
            }
        }
    }

    // SkyLight: open sky above the highest non-transparent block is 15; flood-fill the band below.
    let top = if any_solid { (htop + 2).min(height) } else { 0 };
    let mut sky = vec![0u8; height * 256];
    sky[top * 256..].fill(sky_above);
    let mut sq: VecDeque<(usize, usize, usize, u8)> = VecDeque::new();
    for z in 0..16usize {
        for x in 0..16usize {
            let mut level = sky_above;
            for y in (0..top).rev() {
                let g = idx(x, y, z);
                if opacity[g] >= 15 {
                    break;
                }
                sky[g] = level;
                if level > 0 {
                    sq.push_back((x, y, z, level));
                }
                if opacity[g] > 0 {
                    level = level.saturating_sub(1);
                }
            }
        }
    }
    propagate_light(&mut sky, &opacity, &mut sq, height);

    // BlockLight: flood-fill from emitters.
    let mut block = vec![0u8; height * 256];
    let mut bq: VecDeque<(usize, usize, usize, u8)> = VecDeque::new();
    for g in 0..height * 256 {
        if emission[g] > 0 {
            block[g] = emission[g];
            let rem = g % 256;
            bq.push_back((rem % 16, g / 256, rem / 16, emission[g]));
        }
    }
    propagate_light(&mut block, &opacity, &mut bq, height);

    let mut out = Vec::with_capacity(num_sections);
    for s in 0..num_sections {
        let base_y = s * 16;
        let mut sl = vec![0i8; 2048];
        let mut bl = vec![0i8; 2048];
        for ly in 0..16usize {
            for z in 0..16usize {
                for x in 0..16usize {
                    let local = ly * 256 + z * 16 + x;
                    let g = idx(x, base_y + ly, z);
                    pack_light_nibble(&mut sl, local, sky[g]);
                    pack_light_nibble(&mut bl, local, block[g]);
                }
            }
        }
        out.push((sl, bl));
    }

    let first = sky[0];
    let sky_below = sky[..256].iter().all(|&v| v == first).then_some(first);
    (out, sky_below)
}

/// Light for the sections a chunk actually writes, indexed by `y - span.0` so callers keep
/// using span offsets. Computed one contiguous run at a time, top down: the working grids then
/// cover a run's height instead of the whole span, which under the tall datapack is ~180
/// sections of mostly air between the bedrock plane and the surface.
///
/// The skipped gaps are air, so the skylight leaving a run passes through unchanged and seeds
/// the run below, and block light cannot cross their 16-plus blocks. A gap plane that is not
/// uniform cannot be carried that way, so those chunks fall back to one full-span pass.
fn compute_chunk_lighting(sections: &[Section], span: (i8, i8)) -> SectionLight {
    let (min_section_y, max_section_y) = span;
    let len = (max_section_y as i32 - min_section_y as i32 + 1).max(0) as usize;
    let mut out: SectionLight = vec![(Vec::new(), Vec::new()); len];

    let ys = emitted_section_ys(sections, span);
    let mut runs: Vec<(i8, i8)> = Vec::new();
    for &y in &ys {
        match runs.last_mut() {
            Some(run) if run.1 as i32 + 1 == y as i32 => run.1 = y,
            _ => runs.push((y, y)),
        }
    }

    let mut sky_above = 15u8;
    let mut gap_top: Option<i8> = None;
    for &(lo, hi) in runs.iter().rev() {
        // `compute_lighting` only reads sections inside the range it is given, so the full
        // slice can be passed without copying the run out of it.
        let (light, sky_below) = compute_lighting(sections, lo, hi, sky_above);
        let base = (lo as i32 - min_section_y as i32) as usize;
        for (k, section_light) in light.into_iter().enumerate() {
            out[base + k] = section_light;
        }
        let Some(sky_below) = sky_below else {
            return compute_lighting(sections, min_section_y, max_section_y, 15).0;
        };
        // A lit gap only happens in a chunk with no terrain over it, so paying for the two
        // constant arrays there keeps the LOD exact without costing the common case anything.
        if sky_above > 0 {
            if let Some(top) = gap_top {
                let packed = ((sky_above << 4) | sky_above) as i8;
                for y in hi as i32 + 1..=top as i32 {
                    let at = (y - min_section_y as i32) as usize;
                    out[at] = (vec![packed; 2048], vec![0i8; 2048]);
                }
            }
        }
        sky_above = sky_below;
        gap_top = Some(lo - 1);
    }
    out
}

/// Cached air block_states value shared by all empty sections.
static AIR_BLOCK_STATES: OnceLock<Value> = OnceLock::new();

fn get_air_block_states() -> &'static Value {
    AIR_BLOCK_STATES.get_or_init(|| {
        Value::Compound(HashMap::from([(
            "palette".to_string(),
            Value::List(vec![Value::Compound(HashMap::from([(
                "Name".to_string(),
                Value::String("minecraft:air".to_string()),
            )]))]),
        )]))
    })
}

/// Cached structures value shared by all chunks.
static STRUCTURES_VALUE: OnceLock<Value> = OnceLock::new();

fn get_structures_value() -> &'static Value {
    STRUCTURES_VALUE.get_or_init(|| {
        Value::Compound(HashMap::from([
            ("References".to_string(), Value::Compound(HashMap::new())),
            ("starts".to_string(), Value::Compound(HashMap::new())),
        ]))
    })
}

/// Vanilla build range, in section coordinates (Y=-64 to Y=319).
const VANILLA_MIN_SECTION_Y: i8 = -4;
const VANILLA_MAX_SECTION_Y: i8 = 19;

/// Section Ys a chunk writes: the vanilla span, plus any section outside it holding content.
/// Lighting and the emitted NBT list both come from here so the two cannot drift apart.
fn emitted_section_ys(sections: &[Section], span: (i8, i8)) -> Vec<i8> {
    let content: std::collections::HashSet<i8> = sections.iter().map(|s| s.y).collect();
    (span.0..=span.1)
        .filter(|y| {
            (VANILLA_MIN_SECTION_Y..=VANILLA_MAX_SECTION_Y).contains(y) || content.contains(y)
        })
        .collect()
}

/// Outer bounds of a chunk: the vanilla span, widened to reach any section with content.
/// The sections actually written are a sparse subset of it, see `emitted_section_ys`.
pub(crate) fn chunk_section_span(sections: &[Section]) -> (i8, i8) {
    let mut min_section_y: i8 = VANILLA_MIN_SECTION_Y;
    let mut max_section_y: i8 = VANILLA_MAX_SECTION_Y;
    for section in sections {
        if section.y < min_section_y {
            min_section_y = section.y;
        }
        if section.y > max_section_y {
            max_section_y = section.y;
        }
    }
    (min_section_y, max_section_y)
}

/// Builds a chunk and its lighting in one call. The region writer computes the
/// two separately so it can share the light with the LOD cache; this stays for
/// callers that only want the NBT.
#[cfg(test)]
fn create_chunk_nbt(
    chunk: &Chunk,
    bake_lighting: bool,
    biome_value: &Value,
) -> HashMap<String, Value> {
    let (min_section_y, max_section_y) = chunk_section_span(&chunk.sections);
    let lighting = bake_lighting
        .then(|| compute_chunk_lighting(&chunk.sections, (min_section_y, max_section_y)));
    create_chunk_nbt_with_lighting(chunk, lighting, biome_value)
}

/// Builds one chunk's NBT from light arrays the caller already has. The voxy
/// LOD writer needs the very same light the chunk is written with, so the
/// region loop computes it once and hands it to both.
fn create_chunk_nbt_with_lighting(
    chunk: &Chunk,
    lighting: Option<SectionLight>,
    biome_value: &Value,
) -> HashMap<String, Value> {
    // Index existing sections by Y for quick lookup
    let section_map: HashMap<i8, usize> = chunk
        .sections
        .iter()
        .enumerate()
        .map(|(i, s)| (s.y, i))
        .collect();

    let (min_section_y, max_section_y) = chunk_section_span(&chunk.sections);

    // `yPos` and the heightmaps are dimension-relative and must NOT come from the emitted
    // range: Minecraft sizes the heightmap bit width from the dimension's height and offsets
    // every value from its floor. With the tall datapack installed but shallow relief, a
    // content-derived span writes 9-bit maps against a -64 origin where the engine expects
    // 12-bit against -2032 — usually a length mismatch it warns about and recomputes, but
    // when the widths happen to agree it accepts the values silently, off by ~1968 blocks.
    let (world_min_section, world_max_section) = crate::world_editor::world_section_range();
    let world_height = ((world_max_section as i32 + 1) - world_min_section as i32) * 16;

    // Lighting is baked only when requested; otherwise the engine relights on load.
    let bake_lighting = lighting.is_some();
    let mut lighting = lighting.unwrap_or_default();

    // Sparse section list: the vanilla span plus whatever content sits outside it. Empty gaps
    // beyond the vanilla span are left out entirely; Minecraft slots each section by its own
    // `Y` and treats the missing ones as air. Under the tall datapack a chunk otherwise emits
    // ~180 sections, nearly all of them synthesized air, instead of the usual 24.
    let sections: Vec<Value> = emitted_section_ys(&chunk.sections, (min_section_y, max_section_y))
        .into_iter()
        .map(|y| {
            let mut section_nbt = if let Some(&idx) = section_map.get(&y) {
                build_section_value(&chunk.sections[idx])
            } else {
                // Empty air section
                HashMap::from([
                    ("Y".to_string(), Value::Byte(y)),
                    ("block_states".to_string(), get_air_block_states().clone()),
                ])
            };
            section_nbt.insert("biomes".to_string(), biome_value.clone());
            if bake_lighting {
                // `lighting` covers the whole span, so index by Y, not by list position.
                let off = (y as i32 - min_section_y as i32) as usize;
                let (sky_light, block_light) = std::mem::take(&mut lighting[off]);
                section_nbt.insert(
                    "SkyLight".to_string(),
                    Value::ByteArray(ByteArray::new(sky_light)),
                );
                section_nbt.insert(
                    "BlockLight".to_string(),
                    Value::ByteArray(ByteArray::new(block_light)),
                );
            }
            Value::Compound(section_nbt)
        })
        .collect();

    // Compute heightmaps from block data, against the dimension rather than the content.
    let heightmaps = compute_heightmaps(&chunk.sections, world_min_section, world_height);

    // PostProcessing: one empty list per section
    let post_processing: Vec<Value> = (0..sections.len()).map(|_| Value::List(vec![])).collect();

    // Build root-level chunk NBT (modern format — no Level wrapper)
    let mut root = HashMap::from([
        ("DataVersion".to_string(), Value::Int(DATA_VERSION)),
        ("xPos".to_string(), Value::Int(chunk.x_pos)),
        ("yPos".to_string(), Value::Int(world_min_section as i32)),
        ("zPos".to_string(), Value::Int(chunk.z_pos)),
        (
            "Status".to_string(),
            Value::String("minecraft:full".to_string()),
        ),
        ("isLightOn".to_string(), Value::Byte(bake_lighting as i8)),
        ("InhabitedTime".to_string(), Value::Long(0)),
        ("LastUpdate".to_string(), Value::Long(0)),
        ("sections".to_string(), Value::List(sections)),
        ("Heightmaps".to_string(), heightmaps),
        ("structures".to_string(), get_structures_value().clone()),
        ("PostProcessing".to_string(), Value::List(post_processing)),
        ("block_ticks".to_string(), Value::List(vec![])),
        ("fluid_ticks".to_string(), Value::List(vec![])),
        ("block_entities".to_string(), Value::List(vec![])),
    ]);

    // Merge extra chunk data (block_entities, entities, etc.)
    // This overwrites the empty defaults above when actual data exists.
    // Dedup entity lists by coordinate; tile halos process boundary buildings twice.
    for (key, value) in &chunk.other {
        if key == "block_entities" || key == "entities" {
            if let Value::List(list) = value {
                root.insert(key.clone(), Value::List(dedup_compound_list(list)));
                continue;
            }
        }
        root.insert(key.clone(), value.clone());
    }

    root
}

/// Returns the chunk's `other` map with block entities whose block does not own their type dropped.
/// Cross-tile halos and set_if_absent races can leave a block entity on a plain block; MC 26.2
/// crashes on the mismatch (older versions silently discarded it).
fn strip_orphan_block_entities(chunk: &ChunkToModify) -> FnvHashMap<String, Value> {
    let mut other = chunk.other.clone();
    if let Some(Value::List(list)) = other.get_mut("block_entities") {
        list.retain(|be| block_entity_owned_by_block(chunk, be));
    }
    other
}

fn block_entity_owned_by_block(chunk: &ChunkToModify, be: &Value) -> bool {
    let Value::Compound(map) = be else {
        return true;
    };
    let Some(Value::String(id)) = map.get("id") else {
        return true;
    };
    let (Some(Value::Int(x)), Some(Value::Int(y)), Some(Value::Int(z))) =
        (map.get("x"), map.get("y"), map.get("z"))
    else {
        return true;
    };
    let Some(block) = chunk.get_block((x & 15) as u8, *y, (z & 15) as u8) else {
        return false;
    };
    let name = block.name();
    match id.as_str() {
        "minecraft:banner" => name.ends_with("_banner"),
        "minecraft:chest" | "minecraft:trapped_chest" => name.ends_with("chest"),
        "minecraft:bed" => name.ends_with("_bed"),
        "minecraft:barrel" => name == "barrel",
        "minecraft:sign" | "minecraft:hanging_sign" => name.ends_with("sign"),
        _ => true,
    }
}

/// Deduplicates a compound list by entity coordinate, keeping the last occurrence.
fn dedup_compound_list(values: &[Value]) -> Vec<Value> {
    let mut coord_index: HashMap<(i32, i32, i32, EntityIdentity), usize> = HashMap::new();
    let mut deduped: Vec<Value> = Vec::with_capacity(values.len());

    for value in values {
        if let Value::Compound(map) = value {
            if let Some(coords) = get_entity_coords(map) {
                if let Some(idx) = coord_index.get(&coords).copied() {
                    deduped[idx] = value.clone();
                    continue;
                }
                coord_index.insert(coords, deduped.len());
            }
        }
        deduped.push(value.clone());
    }

    deduped
}

/// Build a section Value from a Section struct.
fn build_section_value(section: &Section) -> HashMap<String, Value> {
    let mut block_states = HashMap::from([(
        "palette".to_string(),
        Value::List(
            section
                .block_states
                .palette
                .iter()
                .map(|item| {
                    let mut palette_item =
                        HashMap::from([("Name".to_string(), Value::String(item.name.clone()))]);
                    if let Some(props) = &item.properties {
                        palette_item.insert("Properties".to_string(), props.clone());
                    }
                    Value::Compound(palette_item)
                })
                .collect(),
        ),
    )]);

    // Only add the `data` attribute if it's non-empty
    // to maintain compatibility with third-party tools like Dynmap
    if let Some(data) = &section.block_states.data {
        if !data.is_empty() {
            block_states.insert("data".to_string(), Value::LongArray(data.to_owned()));
        }
    }

    HashMap::from([
        ("Y".to_string(), Value::Byte(section.y)),
        ("block_states".to_string(), Value::Compound(block_states)),
    ])
}

/// Compute heightmaps from section block data.
///
/// Returns a Value::Compound with four heightmap types (MOTION_BLOCKING,
/// MOTION_BLOCKING_NO_LEAVES, OCEAN_FLOOR, WORLD_SURFACE) as packed LongArrays.
/// Bit width is determined dynamically based on total world height.
/// Value for each column = (highest_non_air_Y - min_block_y + 1), or 0 if all air,
/// clamped to the dimension height so a block outside it cannot wrap the packed mask.
fn compute_heightmaps(sections: &[Section], min_section_y: i8, total_height: i32) -> Value {
    // Precompute per-section metadata to avoid redundant work in the inner loop.
    enum SectionKind<'a> {
        Uniform {
            solid: bool,
        },
        NoAir,
        Mixed {
            data: &'a LongArray,
            bits: usize,
            vals_per_long: usize,
            mask: u64,
        },
    }
    struct SectionMeta<'a> {
        y: i8,
        palette: &'a [super::common::PaletteItem],
        kind: SectionKind<'a>,
    }

    let mut metas: Vec<SectionMeta> = sections
        .iter()
        .map(|s| {
            let palette = &s.block_states.palette;
            let kind = if palette.len() == 1 {
                SectionKind::Uniform {
                    solid: palette[0].name != "minecraft:air",
                }
            } else if !palette.iter().any(|p| p.name == "minecraft:air") {
                SectionKind::NoAir
            } else if let Some(data) = &s.block_states.data {
                let mut bits = 4;
                while (1usize << bits) < palette.len() {
                    bits += 1;
                }
                SectionKind::Mixed {
                    data,
                    bits,
                    vals_per_long: 64 / bits,
                    mask: (1u64 << bits) - 1,
                }
            } else {
                SectionKind::Uniform { solid: false }
            };
            SectionMeta {
                y: s.y,
                palette,
                kind,
            }
        })
        .collect();

    // Sort by Y descending so we scan top-down
    metas.sort_by_key(|b| Reverse(b.y));

    let mut heights = [0i32; 256]; // 16x16 grid, Z-major order
    let min_block_y = min_section_y as i32 * 16;

    for z in 0..16usize {
        for x in 0..16usize {
            let col_idx = z * 16 + x;

            'outer: for meta in &metas {
                match &meta.kind {
                    SectionKind::Uniform { solid: false } => continue,
                    SectionKind::Uniform { solid: true } | SectionKind::NoAir => {
                        let abs_y = (meta.y as i32) * 16 + 15;
                        heights[col_idx] = (abs_y - min_block_y + 1).clamp(0, total_height);
                        break 'outer;
                    }
                    SectionKind::Mixed {
                        data,
                        bits,
                        vals_per_long,
                        mask,
                    } => {
                        for local_y in (0..16usize).rev() {
                            let block_idx = local_y * 256 + z * 16 + x;
                            let long_idx = block_idx / vals_per_long;
                            let bit_offset = (block_idx % vals_per_long) * bits;

                            if long_idx < data.len() {
                                let palette_idx =
                                    ((data[long_idx] as u64 >> bit_offset) & mask) as usize;
                                if palette_idx < meta.palette.len()
                                    && meta.palette[palette_idx].name != "minecraft:air"
                                {
                                    let abs_y = (meta.y as i32) * 16 + local_y as i32;
                                    heights[col_idx] =
                                        (abs_y - min_block_y + 1).clamp(0, total_height);
                                    break 'outer;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    let packed = pack_heightmap_values(&heights, total_height);
    // All four heightmap types use the same data. Vanilla differentiates them (e.g.
    // MOTION_BLOCKING includes fluids, OCEAN_FLOOR excludes them), but servers
    // recompute heightmaps on load — they just need valid structure here.
    Value::Compound(HashMap::from([
        (
            "MOTION_BLOCKING".to_string(),
            Value::LongArray(packed.clone()),
        ),
        (
            "MOTION_BLOCKING_NO_LEAVES".to_string(),
            Value::LongArray(packed.clone()),
        ),
        ("OCEAN_FLOOR".to_string(), Value::LongArray(packed.clone())),
        ("WORLD_SURFACE".to_string(), Value::LongArray(packed)),
    ]))
}

/// Pack 256 heightmap values into a LongArray with dynamic bit width.
/// Bit width = ceil(log2(total_height + 1)). Values don't span across longs.
fn pack_heightmap_values(values: &[i32; 256], total_height: i32) -> LongArray {
    // Calculate bits needed: ceil(log2(total_height + 1)), minimum 9
    let bits = ((total_height + 1) as f64).log2().ceil().max(9.0) as usize;
    let vals_per_long = 64 / bits;
    let num_longs = 256_usize.div_ceil(vals_per_long);
    let mask = (1i64 << bits) - 1;

    let mut result = Vec::with_capacity(num_longs);
    let mut current: i64 = 0;
    let mut bit_pos = 0;

    for &val in values.iter() {
        if bit_pos + bits > 64 {
            result.push(current);
            current = 0;
            bit_pos = 0;
        }
        current |= ((val as i64) & mask) << bit_pos;
        bit_pos += bits;
    }
    if bit_pos > 0 {
        result.push(current);
    }

    LongArray::new(result)
}

/// Merge compound lists (entities, block_entities) from chunk_to_modify into chunk
/// Note: Currently unused since we write directly without merging, but kept for potential future use
#[allow(dead_code)]
fn merge_compound_list(chunk: &mut Chunk, chunk_to_modify: &ChunkToModify, key: &str) {
    if let Some(existing_entities) = chunk.other.get_mut(key) {
        if let Some(new_entities) = chunk_to_modify.other.get(key) {
            if let (Value::List(existing), Value::List(new)) = (existing_entities, new_entities) {
                existing.retain(|e| {
                    if let Value::Compound(map) = e {
                        if let Some(coords) = get_entity_coords(map) {
                            return !new.iter().any(|new_e| {
                                if let Value::Compound(new_map) = new_e {
                                    get_entity_coords(new_map) == Some(coords)
                                } else {
                                    false
                                }
                            });
                        }
                    }
                    true
                });
                existing.extend(new.clone());
            }
        }
    } else if let Some(new_entities) = chunk_to_modify.other.get(key) {
        chunk.other.insert(key.to_string(), new_entities.clone());
    }
}

/// Convert NBT Value to i32
fn value_to_i32(value: &Value) -> Option<i32> {
    match value {
        Value::Byte(v) => Some(i32::from(*v)),
        Value::Short(v) => Some(i32::from(*v)),
        Value::Int(v) => Some(*v),
        Value::Long(v) => i32::try_from(*v).ok(),
        Value::Float(v) => Some(*v as i32),
        Value::Double(v) => Some(*v as i32),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::super::common::{Chunk, ChunkToModify};
    use super::create_chunk_nbt;
    use crate::block_definitions::{FARMLAND, GRASS_BLOCK, WHEAT};
    use fastnbt::Value;
    use fnv::FnvHashMap;
    use std::collections::HashMap;

    fn grass_chunk() -> Chunk {
        let mut c = ChunkToModify::default();
        for x in 0..16 {
            for z in 0..16 {
                c.set_block(x, -62, z, GRASS_BLOCK);
            }
        }
        Chunk {
            sections: c.sections().collect(),
            x_pos: 0,
            z_pos: 0,
            is_light_on: 0,
            other: FnvHashMap::default(),
        }
    }

    fn sections(nbt: &HashMap<String, Value>) -> &Vec<Value> {
        match &nbt["sections"] {
            Value::List(v) => v,
            _ => panic!("sections is not a list"),
        }
    }

    fn plains_biome() -> Value {
        crate::biome::biome_nbt_from_names(&crate::biome::chunk_biome_names(
            0,
            0,
            None,
            0.0,
            (0, 0),
        ))
    }

    #[test]
    fn bake_lighting_writes_valid_light_arrays() {
        let nbt = create_chunk_nbt(&grass_chunk(), true, &plains_biome());
        assert_eq!(nbt["isLightOn"], Value::Byte(1));
        assert!(nbt.contains_key("Heightmaps"));
        let secs = sections(&nbt);
        assert_eq!(secs.len(), 24);
        for s in secs {
            let Value::Compound(m) = s else { panic!() };
            for key in ["SkyLight", "BlockLight"] {
                match &m[key] {
                    Value::ByteArray(b) => assert_eq!(b.len(), 2048),
                    _ => panic!("{key} is not a byte array"),
                }
            }
        }
    }

    #[test]
    fn baked_lighting_leaves_crops_under_open_sky() {
        let mut c = ChunkToModify::default();
        for x in 0..16 {
            for z in 0..16 {
                c.set_block(x, -62, z, FARMLAND);
                c.set_block(x, -61, z, WHEAT);
            }
        }
        let chunk = Chunk {
            sections: c.sections().collect(),
            x_pos: 0,
            z_pos: 0,
            is_light_on: 0,
            other: FnvHashMap::default(),
        };

        let nbt = create_chunk_nbt(&chunk, true, &plains_biome());
        let Value::Compound(bottom) = &sections(&nbt)[0] else {
            panic!("bottom section missing")
        };
        let Value::ByteArray(sky) = &bottom["SkyLight"] else {
            panic!("SkyLight is not a byte array")
        };
        // Wheat sits at local y 3 of the bottom section, so cell (0, 3, 0) is nibble 768.
        assert_eq!(sky[384] as u8 & 0x0F, 15);
    }

    #[test]
    fn no_bake_lighting_omits_light_arrays() {
        let nbt = create_chunk_nbt(&grass_chunk(), false, &plains_biome());
        assert_eq!(nbt["isLightOn"], Value::Byte(0));
        for s in sections(&nbt) {
            let Value::Compound(m) = s else { panic!() };
            assert!(!m.contains_key("SkyLight"));
            assert!(!m.contains_key("BlockLight"));
        }
    }

    #[test]
    fn all_air_chunk_is_fully_skylit() {
        let chunk = Chunk {
            sections: vec![],
            x_pos: 0,
            z_pos: 0,
            is_light_on: 0,
            other: FnvHashMap::default(),
        };
        let nbt = create_chunk_nbt(&chunk, true, &plains_biome());
        for s in sections(&nbt) {
            let Value::Compound(m) = s else { panic!() };
            let Value::ByteArray(b) = &m["SkyLight"] else {
                panic!()
            };
            // 0xFF == two nibbles of 15 (full skylight)
            assert!(b.iter().all(|&v| v == -1));
        }
    }
}

#[cfg(test)]
mod dimension_bounds_tests {
    use super::*;
    use crate::block_definitions::STONE;
    use crate::world_editor::{set_world_bounds, DEFAULT_MAX_Y, DEFAULT_MIN_Y};

    /// Longs Minecraft allocates for a heightmap in a dimension `height` blocks tall:
    /// ceil(log2(height + 1)) bits per value, 256 values, no value spanning two longs.
    fn expected_longs(height: i32) -> usize {
        let bits = ((height + 1) as f64).log2().ceil().max(9.0) as usize;
        256_usize.div_ceil(64 / bits)
    }

    fn heightmap_longs(nbt: &HashMap<String, Value>) -> usize {
        let Value::Compound(maps) = &nbt["Heightmaps"] else {
            panic!("chunk has no Heightmaps")
        };
        let Value::LongArray(packed) = &maps["MOTION_BLOCKING"] else {
            panic!("no MOTION_BLOCKING heightmap")
        };
        packed.len()
    }

    /// A chunk whose blocks all sit in the vanilla span, as shallow relief produces.
    fn shallow_chunk() -> Chunk {
        let mut c = ChunkToModify::default();
        for x in 0..16 {
            for z in 0..16 {
                c.set_block(x, -62, z, STONE);
            }
        }
        Chunk {
            sections: c.sections().collect(),
            x_pos: 0,
            z_pos: 0,
            is_light_on: 0,
            other: FnvHashMap::default(),
        }
    }

    /// A chunk with a bedrock plane far below the surface, the shape a sunk terrain base makes.
    fn chunk_with_plane_at(depths: &[i32]) -> Chunk {
        let mut c = ChunkToModify::default();
        for &y in depths {
            for x in 0..16 {
                for z in 0..16 {
                    c.set_block(x, y, z, STONE);
                }
            }
        }
        Chunk {
            sections: c.sections().collect(),
            x_pos: 0,
            z_pos: 0,
            is_light_on: 0,
            other: FnvHashMap::default(),
        }
    }

    #[test]
    fn run_by_run_light_matches_one_pass_over_the_whole_span() {
        let _g = super::super::common::FLOOR_TEST_LOCK
            .lock()
            .unwrap_or_else(|p| p.into_inner());
        set_world_bounds(-2032, 2031);

        // Terrain over a deep plane, a lone deep plane (nothing above it blocks the sky), a
        // partly filled column, and the vanilla shape.
        for depths in [
            &[-2000, -62][..],
            &[-2000][..],
            &[-2000, -62, 500][..],
            &[-62][..],
        ] {
            let chunk = chunk_with_plane_at(depths);
            let span = chunk_section_span(&chunk.sections);
            let runs = compute_chunk_lighting(&chunk.sections, span);
            let whole = compute_lighting(&chunk.sections, span.0, span.1, 15).0;

            for y in emitted_section_ys(&chunk.sections, span) {
                let at = (y as i32 - span.0 as i32) as usize;
                assert_eq!(runs[at], whole[at], "section {y} of {depths:?}");
            }
        }

        set_world_bounds(DEFAULT_MIN_Y, DEFAULT_MAX_Y);
    }

    #[test]
    fn heightmaps_follow_the_dimension_not_the_chunk_content() {
        let _g = super::super::common::FLOOR_TEST_LOCK
            .lock()
            .unwrap_or_else(|p| p.into_inner());
        let biome = Value::Compound(HashMap::new());

        set_world_bounds(DEFAULT_MIN_Y, DEFAULT_MAX_Y);
        let nbt = create_chunk_nbt(&shallow_chunk(), false, &biome);
        assert_eq!(nbt["yPos"], Value::Int(-4));
        assert_eq!(heightmap_longs(&nbt), expected_longs(384));

        // Tall datapack installed, but the relief never reaches the extended floor: the chunk
        // still holds only vanilla-range sections, yet the engine sizes heightmaps for a
        // 4064-block dimension and offsets every value from -2032.
        set_world_bounds(-2032, 2031);
        let nbt = create_chunk_nbt(&shallow_chunk(), false, &biome);
        assert_eq!(nbt["yPos"], Value::Int(-127));
        assert_eq!(
            heightmap_longs(&nbt),
            expected_longs(4064),
            "heightmaps must be sized for the dimension, not the populated sections"
        );

        set_world_bounds(DEFAULT_MIN_Y, DEFAULT_MAX_Y);
    }

    #[test]
    fn sections_stay_sparse_under_the_tall_datapack() {
        // Spanning all 254 dimension sections per chunk would bloat every region file tenfold.
        // Minecraft slots each section by its own Y and fills the gaps with air.
        let _g = super::super::common::FLOOR_TEST_LOCK
            .lock()
            .unwrap_or_else(|p| p.into_inner());
        set_world_bounds(-2032, 2031);
        let nbt = create_chunk_nbt(&shallow_chunk(), false, &Value::Compound(HashMap::new()));
        let Value::List(sections) = &nbt["sections"] else {
            panic!("chunk has no sections")
        };
        assert_eq!(
            sections.len(),
            24,
            "expected just the vanilla span, got {}",
            sections.len()
        );
        set_world_bounds(DEFAULT_MIN_Y, DEFAULT_MAX_Y);
    }

    #[test]
    fn deep_content_adds_its_own_section_without_filling_the_gap() {
        let _g = super::super::common::FLOOR_TEST_LOCK
            .lock()
            .unwrap_or_else(|p| p.into_inner());
        set_world_bounds(-2032, 2031);

        let mut c = ChunkToModify::default();
        for x in 0..16 {
            for z in 0..16 {
                c.set_block(x, -2000, z, STONE);
                c.set_block(x, -62, z, STONE);
            }
        }
        let chunk = Chunk {
            sections: c.sections().collect(),
            x_pos: 0,
            z_pos: 0,
            is_light_on: 0,
            other: FnvHashMap::default(),
        };

        let nbt = create_chunk_nbt(&chunk, true, &Value::Compound(HashMap::new()));
        let Value::List(sections) = &nbt["sections"] else {
            panic!("chunk has no sections")
        };
        // Vanilla span plus the one deep section, not the 145 the span covers.
        assert_eq!(sections.len(), 25);

        let ys: Vec<i8> = sections
            .iter()
            .map(|s| match s {
                Value::Compound(m) => match m["Y"] {
                    Value::Byte(y) => y,
                    _ => panic!("Y is not a byte"),
                },
                _ => panic!("section is not a compound"),
            })
            .collect();
        assert_eq!(ys[0], -125);
        assert_eq!(&ys[1..], (-4..=19).collect::<Vec<i8>>());

        // Light must follow the section's own Y, not its position in the list: everything
        // above the -62 plane is open sky, everything under it is buried. Section -4 straddles
        // the plane, so it is the one mixed section.
        for (y, s) in ys.iter().zip(sections).filter(|(y, _)| **y != -4) {
            let Value::Compound(m) = s else { panic!() };
            let Value::ByteArray(sky) = &m["SkyLight"] else {
                panic!("no SkyLight")
            };
            let expect: i8 = if *y > -4 { -1 } else { 0 };
            assert!(
                sky.iter().all(|&v| v == expect),
                "section {y} has the wrong skylight"
            );
        }

        set_world_bounds(DEFAULT_MIN_Y, DEFAULT_MAX_Y);
    }

    fn section_ys(nbt: &HashMap<String, Value>) -> Vec<i8> {
        let Value::List(sections) = &nbt["sections"] else {
            panic!("chunk has no sections")
        };
        sections
            .iter()
            .map(|s| match s {
                Value::Compound(m) => match m["Y"] {
                    Value::Byte(y) => y,
                    _ => panic!("Y is not a byte"),
                },
                _ => panic!("section is not a compound"),
            })
            .collect()
    }

    #[test]
    fn vanilla_chunks_emit_exactly_the_vanilla_section_span() {
        let _g = super::super::common::FLOOR_TEST_LOCK
            .lock()
            .unwrap_or_else(|p| p.into_inner());
        set_world_bounds(DEFAULT_MIN_Y, DEFAULT_MAX_Y);

        let nbt = create_chunk_nbt(&shallow_chunk(), true, &Value::Compound(HashMap::new()));
        assert_eq!(section_ys(&nbt), (-4..=19).collect::<Vec<i8>>());

        let Value::List(sections) = &nbt["sections"] else {
            panic!("chunk has no sections")
        };
        for (y, s) in section_ys(&nbt).iter().zip(sections).skip(1) {
            let Value::Compound(m) = s else { panic!() };
            let Value::ByteArray(sky) = &m["SkyLight"] else {
                panic!("no SkyLight")
            };
            assert!(
                sky.iter().all(|&v| v == -1),
                "section {y} above the surface should be fully skylit"
            );
        }
    }

    #[test]
    fn content_above_the_vanilla_ceiling_is_emitted_without_the_gap() {
        let _g = super::super::common::FLOOR_TEST_LOCK
            .lock()
            .unwrap_or_else(|p| p.into_inner());
        set_world_bounds(-2032, 2031);

        let mut c = ChunkToModify::default();
        for x in 0..16 {
            for z in 0..16 {
                c.set_block(x, -62, z, STONE);
                c.set_block(x, 500, z, STONE);
            }
        }
        let chunk = Chunk {
            sections: c.sections().collect(),
            x_pos: 0,
            z_pos: 0,
            is_light_on: 0,
            other: FnvHashMap::default(),
        };

        let nbt = create_chunk_nbt(&chunk, true, &Value::Compound(HashMap::new()));
        let mut expected: Vec<i8> = (-4..=19).collect();
        expected.push(31);
        assert_eq!(section_ys(&nbt), expected);

        set_world_bounds(DEFAULT_MIN_Y, DEFAULT_MAX_Y);
    }

    #[test]
    fn entity_dedup_keeps_two_entities_that_share_a_cell() {
        use super::{dedup_compound_list, get_entity_coords, EntityIdentity};
        use fastnbt::IntArray;

        // Two facade panels meeting at a building corner: different sub-block
        // positions inside one cell, no face byte, different UUIDs.
        let display = |x: f64, z: f64, uuid: [i32; 4]| {
            let mut e: HashMap<String, Value> = HashMap::new();
            e.insert(
                "id".to_string(),
                Value::String("minecraft:item_display".to_string()),
            );
            e.insert(
                "Pos".to_string(),
                Value::List(vec![
                    Value::Double(x),
                    Value::Double(-52.0),
                    Value::Double(z),
                ]),
            );
            e.insert(
                "UUID".to_string(),
                Value::IntArray(IntArray::new(uuid.into())),
            );
            Value::Compound(e)
        };
        let a = display(33.1, 12.2, [1, 2, 3, 4]);
        let b = display(33.8, 12.9, [5, 6, 7, 8]);
        assert_eq!(
            dedup_compound_list(&[a.clone(), b.clone()]).len(),
            2,
            "two panels rounding into one cell must both survive"
        );

        // The same panel seen twice by two tiles: identical UUID, one survives.
        assert_eq!(dedup_compound_list(&[a.clone(), a.clone()]).len(), 1);

        // Hanging entities still separate by cell, and a block entity, which
        // carries no UUID, still keys on its own x/y/z.
        let Value::Compound(am) = &a else { panic!() };
        let Value::Compound(bm) = &b else { panic!() };
        assert_ne!(get_entity_coords(am), get_entity_coords(bm));
        let mut be: HashMap<String, Value> = HashMap::new();
        be.insert("x".to_string(), Value::Int(7));
        be.insert("y".to_string(), Value::Int(8));
        be.insert("z".to_string(), Value::Int(9));
        assert_eq!(
            get_entity_coords(&be),
            Some((7, 8, 9, EntityIdentity::Facing(-1)))
        );
    }
}

#[cfg(test)]
mod merge_tests {
    use super::*;
    use crate::block_definitions::{SMOOTH_STONE, STONE};
    use crate::coordinate_system::geographic::LLBBox;
    use crate::world_editor::common::RegionToModify;

    fn llbbox() -> LLBBox {
        LLBBox::new(48.0, 11.0, 48.1, 11.1).unwrap()
    }

    /// One region with `block` at the base of chunk `(cx, cz)`.
    fn region_with(
        chunks: &[(i32, i32)],
        block: crate::block_definitions::Block,
    ) -> RegionToModify {
        let mut region = RegionToModify::default();
        for &(cx, cz) in chunks {
            let chunk = region.chunks.entry((cx, cz)).or_default();
            let section = chunk.sections.entry(0).or_default();
            section.storage.set(0, block);
        }
        region
    }

    fn write(dir: &std::path::Path, region: &RegionToModify, mode: RegionWriteMode) {
        write_region_to_disk(
            dir,
            &llbbox(),
            None,
            false,
            false,
            None,
            None,
            0,
            0,
            region,
            &mode,
            None,
            (0, 0),
        )
        .unwrap();
    }

    fn present_chunks(dir: &std::path::Path) -> Vec<(usize, usize)> {
        let file = File::open(dir.join("region").join("r.0.0.mca")).unwrap();
        let mut region = Region::from_stream(file).unwrap();
        let mut out = Vec::new();
        for cz in 0..32 {
            for cx in 0..32 {
                if region.read_chunk(cx, cz).unwrap().is_some() {
                    out.push((cx, cz));
                }
            }
        }
        out
    }

    /// The block at (0, 0, 0) of chunk (cx, cz), read back through the palette.
    fn base_block_name(dir: &std::path::Path, cx: usize, cz: usize) -> Option<String> {
        let file = File::open(dir.join("region").join("r.0.0.mca")).unwrap();
        let mut region = Region::from_stream(file).unwrap();
        let data = region.read_chunk(cx, cz).unwrap()?;
        let nbt: Value = fastnbt::from_bytes(&data).unwrap();
        let Value::Compound(root) = nbt else {
            return None;
        };
        let Some(Value::List(sections)) = root.get("sections") else {
            return None;
        };
        for section in sections {
            let Value::Compound(section) = section else {
                continue;
            };
            if section.get("Y") != Some(&Value::Byte(0)) {
                continue;
            }
            let Some(Value::Compound(states)) = section.get("block_states") else {
                continue;
            };
            let Some(Value::List(palette)) = states.get("palette") else {
                continue;
            };
            let first = match states.get("data") {
                Some(Value::LongArray(longs)) => {
                    let bits = ((palette.len() as f64).log2().ceil() as u32).max(4);
                    (longs[0] as u64 & ((1u64 << bits) - 1)) as usize
                }
                _ => 0,
            };
            if let Some(Value::Compound(entry)) = palette.get(first) {
                if let Some(Value::String(name)) = entry.get("Name") {
                    return Some(name.clone());
                }
            }
        }
        None
    }

    #[test]
    fn a_merge_keeps_the_chunks_of_an_earlier_run_and_writes_no_filler() {
        let dir = tempfile::tempdir().unwrap();
        write(
            dir.path(),
            &region_with(&[(0, 0), (1, 1)], SMOOTH_STONE),
            RegionWriteMode::Merge {
                min_x: 0,
                min_z: 0,
                max_x: 31,
                max_z: 31,
                layout: crate::world_utils::WorldLayout::Legacy,
            },
        );
        let after_first = present_chunks(dir.path());
        assert_eq!(after_first, vec![(0, 0), (1, 0), (0, 1), (1, 1)]);
        assert_eq!(
            base_block_name(dir.path(), 0, 0).as_deref(),
            Some("minecraft:smooth_stone")
        );

        write(
            dir.path(),
            &region_with(&[(2, 0), (3, 1)], STONE),
            RegionWriteMode::Merge {
                min_x: 32,
                min_z: 0,
                max_x: 63,
                max_z: 31,
                layout: crate::world_utils::WorldLayout::Legacy,
            },
        );
        assert_eq!(
            base_block_name(dir.path(), 0, 0).as_deref(),
            Some("minecraft:smooth_stone")
        );
        assert_eq!(
            base_block_name(dir.path(), 1, 1).as_deref(),
            Some("minecraft:smooth_stone")
        );
        assert_eq!(
            base_block_name(dir.path(), 2, 0).as_deref(),
            Some("minecraft:stone")
        );
        assert_eq!(
            base_block_name(dir.path(), 3, 1).as_deref(),
            Some("minecraft:stone")
        );

        write(
            dir.path(),
            &region_with(&[(0, 0)], STONE),
            RegionWriteMode::Merge {
                min_x: 0,
                min_z: 0,
                max_x: 15,
                max_z: 15,
                layout: crate::world_utils::WorldLayout::Legacy,
            },
        );
        assert_eq!(
            base_block_name(dir.path(), 0, 0).as_deref(),
            Some("minecraft:stone")
        );
        assert_eq!(
            base_block_name(dir.path(), 1, 1).as_deref(),
            Some("minecraft:smooth_stone")
        );
        assert_eq!(
            base_block_name(dir.path(), 2, 0).as_deref(),
            Some("minecraft:stone")
        );
    }

    #[test]
    fn misplaced_template_chunks_are_dropped_and_real_ones_kept() {
        let dir = tempfile::tempdir().unwrap();
        write(
            dir.path(),
            &region_with(&[(3, 4)], STONE),
            RegionWriteMode::Fresh,
        );
        let region_path = dir.path().join("region").join("r.0.0.mca");
        {
            let file = File::options()
                .read(true)
                .write(true)
                .open(&region_path)
                .unwrap();
            let mut region = Region::from_stream(file).unwrap();
            let bogus = fastnbt::to_bytes(&Value::Compound(HashMap::from([
                ("xPos".to_string(), Value::Int(500)),
                ("zPos".to_string(), Value::Int(500)),
            ])))
            .unwrap();
            region.write_chunk(7, 7, &bogus).unwrap();
        }
        let removed = drop_misplaced_chunks(dir.path()).unwrap();
        assert_eq!(removed, 1);
        let present = present_chunks(dir.path());
        assert!(present.contains(&(3, 4)));
        assert!(!present.contains(&(7, 7)));
        assert_eq!(present.len(), 1023);
    }

    #[test]
    fn a_fresh_write_fills_the_whole_region() {
        let dir = tempfile::tempdir().unwrap();
        write(
            dir.path(),
            &region_with(&[(5, 5)], STONE),
            RegionWriteMode::Fresh,
        );
        assert_eq!(present_chunks(dir.path()).len(), 1024);
        assert_eq!(
            base_block_name(dir.path(), 5, 5).as_deref(),
            Some("minecraft:stone")
        );
    }

    #[test]
    fn a_merge_drops_rewritten_chunks_from_the_entity_regions() {
        let dir = tempfile::tempdir().unwrap();
        let entities = dir.path().join("entities");
        std::fs::create_dir_all(&entities).unwrap();
        {
            let file = File::options()
                .read(true)
                .write(true)
                .create(true)
                .truncate(true)
                .open(entities.join("r.0.0.mca"))
                .unwrap();
            let mut region = Region::create(file).unwrap();
            let payload = fastnbt::to_bytes(&Value::Compound(HashMap::from([(
                "Entities".to_string(),
                Value::List(vec![]),
            )])))
            .unwrap();
            region.write_chunk(0, 0, &payload).unwrap();
            region.write_chunk(5, 5, &payload).unwrap();
        }
        write(
            dir.path(),
            &region_with(&[(0, 0)], STONE),
            RegionWriteMode::Merge {
                min_x: 0,
                min_z: 0,
                max_x: 15,
                max_z: 15,
                layout: crate::world_utils::WorldLayout::Legacy,
            },
        );
        let file = File::open(entities.join("r.0.0.mca")).unwrap();
        let mut region = Region::from_stream(file).unwrap();
        assert!(
            region.read_chunk(0, 0).unwrap().is_none(),
            "rewritten chunk keeps stale entities"
        );
        assert!(
            region.read_chunk(5, 5).unwrap().is_some(),
            "untouched chunk lost its entities"
        );
    }

    #[test]
    fn a_merge_into_a_world_minecraft_has_upgraded_writes_where_it_reads() {
        let dir = tempfile::tempdir().unwrap();
        let overworld = dir.path().join("dimensions/minecraft/overworld");
        write(
            dir.path(),
            &region_with(&[(0, 0)], SMOOTH_STONE),
            RegionWriteMode::Merge {
                min_x: 0,
                min_z: 0,
                max_x: 15,
                max_z: 15,
                layout: crate::world_utils::WorldLayout::Dimensions,
            },
        );
        assert_eq!(present_chunks(&overworld), vec![(0, 0)]);
        assert!(!dir.path().join("region").exists());
    }

    #[test]
    fn merge_bounds_are_inclusive_block_coordinates() {
        let m = RegionWriteMode::Merge {
            min_x: -32,
            min_z: 0,
            max_x: 31,
            max_z: 15,
            layout: crate::world_utils::WorldLayout::Legacy,
        };
        assert!(m.writes_chunk(-2, 0));
        assert!(m.writes_chunk(1, 0));
        assert!(!m.writes_chunk(2, 0));
        assert!(!m.writes_chunk(-3, 0));
        assert!(!m.writes_chunk(0, 1));
        assert!(RegionWriteMode::Fresh.writes_chunk(1000, -1000));
    }
}
