use crate::args::Args;
use crate::block_definitions::*;
use crate::bresenham::bresenham_line;
use crate::climate::Climate;
use crate::clipping::clip_way_to_bbox;
use crate::colors::color_text_to_rgb_tuple;
use crate::deterministic_rng::{coord_rng, element_rng};
use crate::element_processing::building_facade::{
    compute_facade_plan, BuildingContext, ColumnFacade, FacadeAnchor, FacadeClass, FacadePlan,
    MIN_FACADE_FOOTPRINT,
};
use crate::element_processing::historic;
use crate::element_processing::subprocessor::interior::{
    generate_building_interior, plan_interior, Entry, InteriorRequest, PlanInputs,
};
use crate::floodfill_cache::{CoordinateBitmap, FloodFillCache};
use crate::osm_parser::{
    ArchEra, ProcessedMemberRole, ProcessedNode, ProcessedRelation, ProcessedWay,
};
use crate::world_editor::WorldEditor;
use fastnbt::Value;
use fnv::FnvHashSet;
use rand::Rng;
use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::Arc;
use std::time::Duration;

/// Lifecycle / damage state derived from OSM tags.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum BuildingCondition {
    Normal,
    Construction,
    Disused,
    Abandoned,
    Ruined,
}

impl BuildingCondition {
    /// Returns the strongest applicable state (Ruined > Abandoned > Disused > Construction > Normal).
    fn from_tags(tags: &HashMap<String, String>) -> Self {
        let building_value = tags.get("building").map(String::as_str);
        if matches!(building_value, Some("ruins" | "collapsed"))
            || tags.get("historic").map(String::as_str) == Some("ruins")
            || tags.get("ruins").map(String::as_str) == Some("yes")
            || tags.contains_key("ruins:building")
        {
            return Self::Ruined;
        }

        if tags.get("abandoned").map(String::as_str) == Some("yes")
            || tags.contains_key("abandoned:building")
        {
            return Self::Abandoned;
        }

        // Bare `disused=yes` is ambiguous, only the namespaced form counts.
        if tags.contains_key("disused:building") {
            return Self::Disused;
        }

        if building_value == Some("construction") || tags.contains_key("construction:building") {
            return Self::Construction;
        }

        Self::Normal
    }
}

/// Enum representing different roof types
#[derive(Debug, Clone, Copy, PartialEq)]
pub(crate) enum RoofType {
    /// Steep lower slope, shallow upper slope, flat cap.
    Mansard,
    /// Barn roof: steep lower gable pitch breaking to a shallow upper pitch.
    Gambrel,
    /// Gable whose ends are hipped only above half height.
    HalfHipped,
    Gabled, // Two sloping sides meeting at a ridge
    /// Barrel vault: a rounded section across the ridge.
    Round,
    Hipped, // All sides slope downwards to walls (including Half-hipped, Gambrel, Mansard variations)
    Skillion, // Single sloping surface
    Pyramidal, // All sides come to a point at the top
    Dome,   // Rounded, hemispherical structure
    Cone,   // Conical roof, circular base tapering to a point
    Onion,  // Bulbous onion roof
    Flat,   // Default flat roof
}

/// Enum representing different wall depth styles for building facades.
/// Each style creates visual depth by placing blocks outward from the wall
/// plane, making windows appear recessed.
#[derive(Debug, Clone, Copy, PartialEq)]
pub(crate) enum WallDepthStyle {
    None,               // No depth features (sheds, greenhouses, tiny buildings)
    SubtlePilasters,    // Thin columns between windows (residential, houses)
    ModernPillars,      // Clean paired columns + horizontal bands (commercial, office, hotel)
    InstitutionalBands, // Columns + stair ledges at floor lines (school, hospital)
    IndustrialBeams,    // Corner pillars only (industrial, warehouse)
    HistoricOrnate,     // Stone columns + arched window tops + cornice (historic)
    ReligiousButtress,  // Stepped buttresses + cornice (religious)
    SkyscraperFins,     // Full-height vertical fins (tall building, modern skyscraper)
    GlassCurtain,       // Minimal corner definition only (glassy skyscraper)
}

#[derive(Clone)]
pub(crate) struct HolePolygon {
    way: ProcessedWay,
    add_walls: bool,
}

// ============================================================================
// Building Style System
// ============================================================================

/// Height (in blocks above ground floor) of a building-passage archway.
/// Walls and floors below this height are removed at tunnel=building_passage
/// highway coordinates, creating a ground-level opening through the building.
pub(crate) const BUILDING_PASSAGE_HEIGHT: i32 = 4;

/// Smallest footprint, in cells, that gets an interior.
const MIN_INTERIOR_CELLS: usize = 24;

/// Accent block options for building decoration
const ACCENT_BLOCK_OPTIONS: [Block; 6] = [
    POLISHED_ANDESITE,
    SMOOTH_STONE,
    STONE_BRICKS,
    MUD_BRICKS,
    ANDESITE,
    CHISELED_STONE_BRICKS,
];

// ============================================================================
// Wall Block Palettes for Different Building Types
// ============================================================================

/// Wall blocks suitable for residential buildings.
const RESIDENTIAL_WALL_OPTIONS: [Block; 29] = [
    BRICK,
    STONE_BRICKS,
    WHITE_TERRACOTTA,
    BROWN_TERRACOTTA,
    SANDSTONE,
    SMOOTH_SANDSTONE,
    QUARTZ_BRICKS,
    MUD_BRICKS,
    POLISHED_GRANITE,
    END_STONE_BRICKS,
    BROWN_CONCRETE,
    DEEPSLATE_BRICKS,
    GRAY_CONCRETE,
    GRAY_TERRACOTTA,
    LIGHT_BLUE_TERRACOTTA,
    LIGHT_GRAY_CONCRETE,
    LIGHT_GRAY_TERRACOTTA,
    NETHER_BRICK,
    POLISHED_ANDESITE,
    POLISHED_BLACKSTONE,
    POLISHED_BLACKSTONE_BRICKS,
    POLISHED_DEEPSLATE,
    QUARTZ_BLOCK,
    WHITE_CONCRETE,
    ORANGE_TERRACOTTA,
    RED_TERRACOTTA,
    RED_NETHER_BRICKS,
    GRANITE,
    TERRACOTTA,
];

/// Wall blocks suitable for commercial/office buildings (modern, clean look)
const COMMERCIAL_WALL_OPTIONS: [Block; 8] = [
    WHITE_CONCRETE,
    LIGHT_GRAY_CONCRETE,
    GRAY_CONCRETE,
    POLISHED_ANDESITE,
    SMOOTH_STONE,
    QUARTZ_BLOCK,
    QUARTZ_BRICKS,
    STONE_BRICKS,
];

/// Wall blocks suitable for industrial buildings (utilitarian)
const INDUSTRIAL_WALL_OPTIONS: [Block; 7] = [
    GRAY_CONCRETE,
    LIGHT_GRAY_CONCRETE,
    STONE,
    SMOOTH_STONE,
    POLISHED_ANDESITE,
    DEEPSLATE_BRICKS,
    BLACKSTONE,
];

/// Wall blocks suitable for religious buildings (ornate, traditional)
const RELIGIOUS_WALL_OPTIONS: [Block; 9] = [
    STONE_BRICKS,
    CHISELED_STONE_BRICKS,
    QUARTZ_BLOCK,
    WHITE_CONCRETE,
    SANDSTONE,
    SMOOTH_SANDSTONE,
    POLISHED_DIORITE,
    END_STONE_BRICKS,
    WAXED_OXIDIZED_COPPER,
];

/// Wall blocks suitable for institutional buildings (formal, clean)
const INSTITUTIONAL_WALL_OPTIONS: [Block; 8] = [
    WHITE_CONCRETE,
    LIGHT_GRAY_CONCRETE,
    QUARTZ_BRICKS,
    STONE_BRICKS,
    POLISHED_ANDESITE,
    SMOOTH_STONE,
    SANDSTONE,
    END_STONE_BRICKS,
];

/// Wall blocks suitable for farm/agricultural buildings (rustic)
const FARM_WALL_OPTIONS: [Block; 8] = [
    OAK_PLANKS,
    SPRUCE_PLANKS,
    DARK_OAK_PLANKS,
    COBBLESTONE,
    STONE,
    MUD_BRICKS,
    MOSSY_COBBLESTONE,
    BROWN_TERRACOTTA,
];

/// Wall blocks suitable for historic/castle buildings
const HISTORIC_WALL_OPTIONS: [Block; 16] = [
    STONE_BRICKS,
    CRACKED_STONE_BRICKS,
    CHISELED_STONE_BRICKS,
    COBBLESTONE,
    SANDSTONE,
    SMOOTH_SANDSTONE,
    POLISHED_BLACKSTONE_BRICKS,
    DEEPSLATE_BRICKS,
    POLISHED_ANDESITE,
    ANDESITE,
    SMOOTH_STONE,
    BRICK,
    RED_NETHER_BRICKS,
    MOSSY_STONE_BRICKS,
    MOSSY_COBBLESTONE,
    COBBLED_DEEPSLATE,
];

/// Wall blocks for garages (sturdy, simple, varied)
const GARAGE_WALL_OPTIONS: [Block; 6] = [
    BRICK,
    STONE_BRICKS,
    POLISHED_ANDESITE,
    COBBLESTONE,
    SMOOTH_STONE,
    LIGHT_GRAY_CONCRETE,
];

/// Wall blocks for sheds (wooden)
const SHED_WALL_OPTIONS: [Block; 1] = [OAK_LOG];

/// Wall blocks for greenhouses (glass variants)
const GREENHOUSE_WALL_OPTIONS: [Block; 4] = [
    GLASS,
    CYAN_STAINED_GLASS,
    WHITE_STAINED_GLASS,
    LIGHT_GRAY_STAINED_GLASS,
];

// ============================================================================
// Building Category System
// ============================================================================

/// Building category determines which preset rules to apply.
/// This is derived from OSM tags and can influence style choices.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum BuildingCategory {
    // Residential types
    Residential, // Generic residential (apartments, etc.)
    House,       // Single-family homes
    Farm,        // Farmhouses and agricultural dwellings

    // Commercial types
    Commercial, // Shops, retail, supermarkets
    Office,     // Office buildings
    Hotel,      // Hotels and accommodation

    // Industrial types
    Industrial, // Factories, manufacturing
    Warehouse,  // Storage and logistics

    // Institutional types
    School,    // Schools, kindergartens, colleges
    Hospital,  // Healthcare buildings
    Religious, // Churches, mosques, temples, etc.

    // Special types
    TallBuilding,           // Tall buildings (>7 floors or >28m)
    GlassySkyscraper,       // Glass-facade skyscrapers
    GlassCornerSkyscraper,  // Glass facade with concrete corner pillars
    GridSkyscraper,         // Large glass panes in a concrete grid
    ContemporarySkyscraper, // Concrete/light-stone frame with wide glass windows
    ModernSkyscraper,       // Horizontal-window skyscrapers with stone bands
    MasonrySkyscraper,      // Stone/art-deco towers, from historic/material OSM tags
    Historic,               // Castles, ruins, historic buildings
    Tower,                  // man_made=tower or building=tower (stone towers)
    Garage,                 // Garages and carports
    Shed,                   // Sheds, huts, simple storage
    Greenhouse,             // Greenhouses and glasshouses

    Default, // Unknown or generic buildings
}

impl BuildingCategory {
    /// Determines the building category from OSM tags and calculated properties
    fn from_element(
        element: &ProcessedWay,
        is_tall_building: bool,
        building_height: i32,
        group_seed: u64,
        scale_factor: f64,
    ) -> Self {
        // Check for man_made=tower before anything else
        if element.tags.get("man_made").map(|s| s.as_str()) == Some("tower") {
            return BuildingCategory::Tower;
        }

        if is_tall_building {
            // OSM tags can pin the facade style. The seed carries the building's decision to all
            // its S3DB parts; the element's own tags cover standalone buildings.
            use crate::osm_parser::StyleHint;
            let mut hint = crate::osm_parser::style_hint_from_seed(group_seed);
            if hint == StyleHint::None {
                hint = crate::osm_parser::building_style_hint(&element.tags);
            }
            let clean_seed = crate::osm_parser::seed_without_hint(group_seed);
            match hint {
                // Tagged glass towers stay glass, but vary the treatment for a livelier skyline.
                StyleHint::Glass => return Self::glass_family_variant(clean_seed),
                StyleHint::Masonry => return BuildingCategory::MasonrySkyscraper,
                StyleHint::Contemporary => return BuildingCategory::ContemporarySkyscraper,
                StyleHint::None => {}
            }

            // Check if this qualifies as a true skyscraper:
            // Must be significantly tall AND have skyscraper proportions
            // (taller than twice its longest side dimension)
            let is_true_skyscraper = building_height >= multiply_scale(120, scale_factor)
                && Self::has_skyscraper_proportions(element, building_height);

            if is_true_skyscraper {
                // shared seed so parts of one tower pick the same variant
                let hash = clean_seed.wrapping_mul(2654435761); // Knuth multiplicative hash
                return match hash % 100 {
                    0..=17 => BuildingCategory::GlassySkyscraper,
                    18..=29 => BuildingCategory::GlassCornerSkyscraper,
                    30..=44 => BuildingCategory::GridSkyscraper,
                    45..=69 => BuildingCategory::ContemporarySkyscraper,
                    70..=84 => BuildingCategory::ModernSkyscraper,
                    _ => BuildingCategory::TallBuilding,
                };
            }

            return BuildingCategory::TallBuilding;
        }

        // Religious buildings keep their style even when also tagged historic.
        let building_type = element
            .tags
            .get("building")
            .or_else(|| element.tags.get("building:part"))
            .map(|s| s.as_str())
            .unwrap_or("yes");

        let is_religious_building = matches!(
            building_type,
            "religious" | "church" | "cathedral" | "chapel" | "mosque" | "synagogue" | "temple"
        );
        let is_religious_amenity =
            element.tags.get("amenity").map(|s| s.as_str()) == Some("place_of_worship");

        if is_religious_building || is_religious_amenity {
            return BuildingCategory::Religious;
        }

        // Check for historic buildings (only after ruling out religious ones)
        if element.tags.contains_key("historic") {
            return BuildingCategory::Historic;
        }

        match building_type {
            // Single-family homes
            "house" | "detached" | "semidetached_house" | "terrace" | "bungalow" | "villa"
            | "cabin" | "hut" => BuildingCategory::House,

            // Multi-family residential
            "residential" | "apartments" | "dormitory" => BuildingCategory::Residential,

            // Farm and agricultural
            "farm" | "farm_auxiliary" | "barn" | "stable" | "cowshed" | "sty" | "sheepfold" => {
                BuildingCategory::Farm
            }

            // Commercial/retail
            "commercial" | "retail" | "supermarket" | "kiosk" | "shop" => {
                BuildingCategory::Commercial
            }

            // Office buildings
            "office" => BuildingCategory::Office,

            // Hotels and accommodation
            "hotel" => BuildingCategory::Hotel,

            // Industrial/manufacturing
            "industrial" | "factory" | "manufacture" | "hangar" => BuildingCategory::Industrial,

            // Warehouses and storage
            "warehouse" | "storage_tank" => BuildingCategory::Warehouse,

            // Schools and education
            "school" | "kindergarten" | "college" | "university" => BuildingCategory::School,

            // Healthcare
            "hospital" => BuildingCategory::Hospital,

            // Religious buildings
            "religious" | "church" | "cathedral" | "chapel" | "mosque" | "synagogue" | "temple" => {
                BuildingCategory::Religious
            }

            // Towers
            "tower" | "clock_tower" | "transformer_tower" => BuildingCategory::Tower,

            // Historic structures
            "castle" | "ruins" | "fort" | "bunker" => BuildingCategory::Historic,

            // Garages
            "garage" | "garages" | "carport" => BuildingCategory::Garage,

            // Simple storage structures
            "shed" => BuildingCategory::Shed,

            // Greenhouses
            "greenhouse" | "glasshouse" => BuildingCategory::Greenhouse,

            // Public/civic (map to appropriate institutional)
            "public" | "government" | "civic" => BuildingCategory::School, // Use school style for generic institutional

            // Default for unknown types
            _ => BuildingCategory::Default,
        }
    }

    /// Checks if a tall building has skyscraper proportions:
    /// building height >= 40 blocks AND height >= 2× the longest side of its bounding box.
    /// Picks a glass-family treatment (pure curtain, concrete corners, or grid) from the shared seed.
    fn glass_family_variant(seed: u64) -> BuildingCategory {
        // Even split so a formerly all-glass tower is usually a grid or corner variant.
        match (seed ^ 0x6C07_A55E).wrapping_mul(2654435761) % 3 {
            0 => BuildingCategory::GlassySkyscraper,
            1 => BuildingCategory::GridSkyscraper,
            _ => BuildingCategory::GlassCornerSkyscraper,
        }
    }

    fn has_skyscraper_proportions(element: &ProcessedWay, building_height: i32) -> bool {
        if building_height < 40 {
            return false;
        }

        if element.nodes.len() < 3 {
            return false;
        }

        let min_x = element.nodes.iter().map(|n| n.x).min().unwrap_or(0);
        let max_x = element.nodes.iter().map(|n| n.x).max().unwrap_or(0);
        let min_z = element.nodes.iter().map(|n| n.z).min().unwrap_or(0);
        let max_z = element.nodes.iter().map(|n| n.z).max().unwrap_or(0);

        let longest_side = (max_x - min_x).max(max_z - min_z).max(1);
        building_height as f64 / longest_side as f64 >= 2.0
    }
}

/// A partial style specification where `None` means "pick randomly".
/// Use this to create building presets that enforce certain properties
/// while allowing variation in others.
#[derive(Debug, Clone, Default)]
pub struct BuildingStylePreset {
    // Block palette (None = randomly chosen)
    pub wall_block: Option<Block>,
    pub floor_block: Option<Block>,
    pub window_block: Option<Block>,
    pub accent_block: Option<Block>,
    pub roof_block: Option<Block>, // Material for roof (used in gabled roofs, etc.)

    // Window style
    pub use_vertical_windows: Option<bool>,
    pub use_horizontal_windows: Option<bool>, // Full-width horizontal window bands (modern skyscrapers)
    pub has_windows: Option<bool>,            // Whether to generate windows at all

    // Accent features
    pub use_accent_roof_line: Option<bool>,
    pub use_accent_lines: Option<bool>,
    pub use_vertical_accent: Option<bool>,

    // Roof
    pub roof_type: Option<RoofType>,
    pub has_chimney: Option<bool>,
    pub generate_roof: Option<bool>,

    // Special features
    pub has_garage_door: Option<bool>, // Generate double door on front face
    pub has_single_door: Option<bool>, // Generate a single door somewhere

    // Wall depth
    pub wall_depth_style: Option<WallDepthStyle>,
    pub has_parapet: Option<bool>, // Whether flat-roofed buildings get a parapet wall
}

impl BuildingStylePreset {
    /// Creates an empty preset (all random)
    pub fn empty() -> Self {
        Self::default()
    }

    /// Preset for residential buildings (houses, apartments)
    pub fn residential() -> Self {
        Self {
            use_vertical_windows: Some(false),
            use_accent_lines: Some(false), // Residential buildings rarely have accent lines
            wall_depth_style: Some(WallDepthStyle::SubtlePilasters),
            ..Default::default()
        }
    }

    /// Preset for tall buildings (>7 floors, not true skyscrapers)
    pub fn tall_building() -> Self {
        Self {
            use_vertical_windows: Some(true), // Always vertical windows
            roof_type: Some(RoofType::Flat),  // Always flat roof
            has_chimney: Some(false),         // No chimneys on tall buildings
            use_accent_roof_line: Some(true), // Usually have accent roof line
            wall_depth_style: Some(WallDepthStyle::SkyscraperFins),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Preset for modern skyscrapers with horizontal window bands
    pub fn modern_skyscraper() -> Self {
        Self {
            roof_type: Some(RoofType::Flat),
            generate_roof: Some(true),
            has_chimney: Some(false),
            use_accent_roof_line: Some(true),
            use_vertical_accent: Some(false),
            wall_depth_style: Some(WallDepthStyle::SkyscraperFins),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Preset for glass-facade skyscrapers
    pub fn glassy_skyscraper() -> Self {
        Self {
            has_windows: Some(false),
            use_vertical_accent: Some(false),
            use_accent_roof_line: Some(true),
            roof_type: Some(RoofType::Flat),
            generate_roof: Some(true),
            has_chimney: Some(false),
            wall_depth_style: Some(WallDepthStyle::GlassCurtain),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Glass tower with concrete corner pillars (GlassCurtain places accent_block at the corners).
    pub fn glass_corner_skyscraper() -> Self {
        Self {
            accent_block: Some(LIGHT_GRAY_CONCRETE),
            has_windows: Some(false),
            use_vertical_accent: Some(false),
            use_accent_roof_line: Some(true),
            roof_type: Some(RoofType::Flat),
            generate_roof: Some(true),
            has_chimney: Some(false),
            wall_depth_style: Some(WallDepthStyle::GlassCurtain),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Large glass panes in a concrete grid (mullions at floor lines and every few columns).
    pub fn grid_skyscraper() -> Self {
        Self {
            window_block: Some(LIGHT_BLUE_STAINED_GLASS),
            has_windows: Some(true),
            use_vertical_windows: Some(false),
            use_horizontal_windows: Some(false),
            use_accent_roof_line: Some(true),
            roof_type: Some(RoofType::Flat),
            generate_roof: Some(true),
            has_chimney: Some(false),
            has_garage_door: Some(false),
            has_single_door: Some(false),
            wall_depth_style: Some(WallDepthStyle::None),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Preset for contemporary towers: concrete/light-stone piers with wide glass windows.
    pub fn contemporary_skyscraper() -> Self {
        Self {
            window_block: Some(LIGHT_BLUE_STAINED_GLASS),
            has_windows: Some(true),
            use_vertical_windows: Some(false),
            use_horizontal_windows: Some(false),
            use_accent_roof_line: Some(true),
            roof_type: Some(RoofType::Flat),
            generate_roof: Some(true),
            has_chimney: Some(false),
            has_garage_door: Some(false),
            has_single_door: Some(false),
            wall_depth_style: Some(WallDepthStyle::ModernPillars),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Preset for stone/art-deco towers (historic + masonry-tagged tall buildings).
    pub fn masonry_skyscraper() -> Self {
        Self {
            // wall_block None so building:material / building:colour still win; palette from category.
            floor_block: Some(SMOOTH_STONE), // stops the setback crown capping tiers in oak planks
            window_block: Some(LIGHT_GRAY_STAINED_GLASS),
            accent_block: Some(SMOOTH_STONE),
            has_windows: Some(true),
            use_vertical_windows: Some(false),
            use_horizontal_windows: Some(false),
            use_accent_lines: Some(true),
            use_accent_roof_line: Some(true),
            roof_type: Some(RoofType::Flat),
            generate_roof: Some(true),
            has_chimney: Some(false),
            has_garage_door: Some(false),
            has_single_door: Some(false),
            wall_depth_style: Some(WallDepthStyle::HistoricOrnate),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Preset for industrial buildings (warehouses, factories)
    pub fn industrial() -> Self {
        Self {
            roof_type: None,
            has_chimney: Some(false),
            use_accent_lines: Some(false),
            use_vertical_accent: Some(false),
            wall_depth_style: Some(WallDepthStyle::IndustrialBeams),
            ..Default::default()
        }
    }

    /// Preset for historic buildings (castles, etc.)
    pub fn historic() -> Self {
        Self {
            roof_type: Some(RoofType::Flat),
            has_chimney: Some(false),
            use_accent_lines: Some(false),
            use_vertical_accent: Some(false),
            use_accent_roof_line: Some(false),
            wall_depth_style: Some(WallDepthStyle::HistoricOrnate),
            ..Default::default()
        }
    }

    /// Preset for single-family houses
    pub fn house() -> Self {
        Self {
            use_vertical_windows: Some(false),
            use_accent_lines: Some(false),
            use_accent_roof_line: Some(true),
            has_chimney: Some(true), // Houses often have chimneys
            wall_depth_style: Some(WallDepthStyle::SubtlePilasters),
            ..Default::default()
        }
    }

    /// Preset for farm buildings (barns, stables, etc.)
    pub fn farm() -> Self {
        Self {
            use_vertical_windows: Some(false),
            use_accent_lines: Some(false),
            use_vertical_accent: Some(false),
            has_chimney: Some(false),
            wall_depth_style: Some(WallDepthStyle::None),
            ..Default::default()
        }
    }

    /// Preset for office buildings
    pub fn office() -> Self {
        Self {
            use_vertical_windows: Some(true), // Office buildings typically have vertical windows
            use_accent_roof_line: Some(true),
            has_chimney: Some(false),
            wall_depth_style: Some(WallDepthStyle::ModernPillars),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Preset for hotels
    pub fn hotel() -> Self {
        Self {
            use_vertical_windows: Some(true),
            use_accent_roof_line: Some(true),
            use_accent_lines: Some(true), // Hotels often have floor-separating lines
            has_chimney: Some(false),
            wall_depth_style: Some(WallDepthStyle::ModernPillars),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Preset for warehouses
    pub fn warehouse() -> Self {
        Self {
            roof_type: None,
            has_chimney: Some(false),
            use_accent_lines: Some(false),
            use_vertical_accent: Some(false),
            use_accent_roof_line: Some(false),
            use_vertical_windows: Some(false),
            wall_depth_style: Some(WallDepthStyle::IndustrialBeams),
            ..Default::default()
        }
    }

    /// Preset for schools and educational buildings
    pub fn school() -> Self {
        Self {
            use_vertical_windows: Some(false), // Schools usually have regular windows
            use_accent_roof_line: Some(true),
            has_chimney: Some(false),
            wall_depth_style: Some(WallDepthStyle::InstitutionalBands),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Preset for hospitals
    pub fn hospital() -> Self {
        Self {
            use_vertical_windows: Some(true),
            use_accent_roof_line: Some(true),
            roof_type: Some(RoofType::Flat), // Hospitals typically have flat roofs
            has_chimney: Some(false),
            wall_depth_style: Some(WallDepthStyle::InstitutionalBands),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Preset for religious buildings (churches, mosques, etc.)
    pub fn religious() -> Self {
        Self {
            use_vertical_windows: Some(true), // Tall stained glass windows
            use_accent_roof_line: Some(true),
            use_accent_lines: Some(false),
            has_chimney: Some(false),
            wall_depth_style: Some(WallDepthStyle::ReligiousButtress),
            ..Default::default()
        }
    }

    /// Preset for man_made=tower buildings.
    pub fn tower() -> Self {
        Self {
            has_windows: Some(true),
            window_block: Some(GLASS),
            use_accent_lines: Some(true),
            use_vertical_accent: Some(false),
            use_accent_roof_line: Some(true),
            roof_type: Some(RoofType::Flat),
            generate_roof: Some(true),
            has_chimney: Some(false),
            wall_depth_style: Some(WallDepthStyle::None),
            ..Default::default()
        }
    }

    /// Preset for garages and carports
    pub fn garage() -> Self {
        Self {
            roof_type: Some(RoofType::Flat),
            has_chimney: Some(false),
            use_accent_lines: Some(false),
            use_vertical_accent: Some(false),
            use_accent_roof_line: Some(true), // Accent band at roofline for visual interest
            generate_roof: Some(true),
            has_windows: Some(false),    // No windows on garages
            has_garage_door: Some(true), // Generate double door on front
            wall_depth_style: Some(WallDepthStyle::None),
            ..Default::default()
        }
    }

    /// Preset for sheds and small storage structures
    pub fn shed() -> Self {
        Self {
            wall_block: Some(OAK_LOG),    // Oak logs for walls
            roof_block: Some(OAK_PLANKS), // Oak planks for roof
            has_chimney: Some(false),
            use_accent_lines: Some(false),
            use_vertical_accent: Some(false),
            use_accent_roof_line: Some(false),
            has_windows: Some(false),    // No windows on sheds
            has_single_door: Some(true), // One door somewhere
            wall_depth_style: Some(WallDepthStyle::None),
            ..Default::default()
        }
    }

    /// Preset for greenhouses
    pub fn greenhouse() -> Self {
        Self {
            // Wall block is randomly chosen from GREENHOUSE_WALL_OPTIONS
            roof_block: Some(SMOOTH_STONE_SLAB), // Smooth stone slab roof
            has_chimney: Some(false),
            use_accent_lines: Some(false),
            use_vertical_accent: Some(false),
            use_accent_roof_line: Some(false),
            roof_type: Some(RoofType::Flat),
            generate_roof: Some(true),
            has_windows: Some(false),    // The walls themselves are glass
            has_single_door: Some(true), // One entrance door
            wall_depth_style: Some(WallDepthStyle::None),
            ..Default::default()
        }
    }

    /// Preset for commercial buildings (retail, shops)
    pub fn commercial() -> Self {
        Self {
            use_vertical_windows: Some(false),
            use_accent_roof_line: Some(true),
            wall_depth_style: Some(WallDepthStyle::ModernPillars),
            has_parapet: Some(true),
            ..Default::default()
        }
    }

    /// Gets the appropriate preset for a building category
    pub fn for_category(category: BuildingCategory) -> Self {
        match category {
            BuildingCategory::House => Self::house(),
            BuildingCategory::Residential => Self::residential(),
            BuildingCategory::Farm => Self::farm(),
            BuildingCategory::Commercial => Self::commercial(),
            BuildingCategory::Office => Self::office(),
            BuildingCategory::Hotel => Self::hotel(),
            BuildingCategory::Industrial => Self::industrial(),
            BuildingCategory::Warehouse => Self::warehouse(),
            BuildingCategory::School => Self::school(),
            BuildingCategory::Hospital => Self::hospital(),
            BuildingCategory::Religious => Self::religious(),
            BuildingCategory::Historic => Self::historic(),
            BuildingCategory::Tower => Self::tower(),
            BuildingCategory::Garage => Self::garage(),
            BuildingCategory::Shed => Self::shed(),
            BuildingCategory::Greenhouse => Self::greenhouse(),
            BuildingCategory::TallBuilding => Self::tall_building(),
            BuildingCategory::GlassySkyscraper => Self::glassy_skyscraper(),
            BuildingCategory::GlassCornerSkyscraper => Self::glass_corner_skyscraper(),
            BuildingCategory::GridSkyscraper => Self::grid_skyscraper(),
            BuildingCategory::ContemporarySkyscraper => Self::contemporary_skyscraper(),
            BuildingCategory::ModernSkyscraper => Self::modern_skyscraper(),
            BuildingCategory::MasonrySkyscraper => Self::masonry_skyscraper(),
            BuildingCategory::Default => Self::empty(),
        }
    }
}

/// Fully resolved building style with all parameters determined.
/// Created by resolving a `BuildingStylePreset` with deterministic RNG.
#[derive(Debug, Clone)]
pub struct BuildingStyle {
    // Block palette
    pub wall_block: Block,
    pub floor_block: Block,
    pub window_block: Block,
    pub accent_block: Block,
    pub roof_block: Option<Block>, // Optional specific roof material

    // Window style
    pub use_vertical_windows: bool,
    pub use_horizontal_windows: bool, // Full-width horizontal window bands
    pub has_windows: bool,            // Whether to generate windows

    // Accent features
    pub use_accent_roof_line: bool,
    pub use_accent_lines: bool,
    pub use_vertical_accent: bool,

    // Roof
    pub roof_type: RoofType,
    pub has_chimney: bool,
    pub generate_roof: bool,

    // Special features
    pub has_garage_door: bool,
    pub has_single_door: bool,

    // Wall depth
    pub wall_depth_style: WallDepthStyle,
    pub has_parapet: bool,
}

impl BuildingStyle {
    /// Resolves a preset into a fully determined style using deterministic RNG.
    /// Parameters not specified in the preset are randomly chosen.
    ///
    /// # Arguments
    /// * `preset` - The style preset (partial specification)
    /// * `element` - The OSM element (used for tag-based decisions)
    /// * `building_type` - The building type string from tags
    /// * `category` - The resolved building category
    /// * `has_multiple_floors` - Whether building has more than 6 height units
    /// * `footprint_size` - The building's floor area in blocks
    /// * `rng` - Deterministic RNG seeded by element ID
    #[allow(clippy::too_many_arguments, clippy::unnecessary_lazy_evaluations)]
    pub fn resolve(
        preset: &BuildingStylePreset,
        element: &ProcessedWay,
        building_type: &str,
        category: BuildingCategory,
        era: ArchEra,
        climate: Climate,
        detail: DetailTier,
        building_height: i32,
        has_multiple_floors: bool,
        footprint_size: usize,
        style_seed: u64,
        rng: &mut impl Rng,
    ) -> Self {
        // === Block Palette ===

        // Priority: OSM tag > preset > category palette. A photographed colour
        // enters later, in `resolve`, because it belongs to the building rather
        // than to its category and the facade store is what knows it.
        let wall_block = determine_wall_block_from_tags(element, category, rng)
            .or(preset.wall_block)
            .unwrap_or_else(|| determine_wall_block(element, category, era, climate, rng));

        // Floor block: from preset or random
        // For glassy/modern skyscrapers, use dark cap materials for the flat roof
        let floor_block = preset.floor_block.unwrap_or_else(|| {
            if matches!(
                category,
                BuildingCategory::GlassySkyscraper | BuildingCategory::ModernSkyscraper
            ) {
                const SKYSCRAPER_ROOF_CAP_OPTIONS: [Block; 3] =
                    [POLISHED_ANDESITE, BLACKSTONE, NETHER_BRICK];
                SKYSCRAPER_ROOF_CAP_OPTIONS[rng.random_range(0..SKYSCRAPER_ROOF_CAP_OPTIONS.len())]
            } else {
                get_floor_block_with_rng(rng)
            }
        });

        // Window block: from preset or random based on building category (tint coordinated below).
        let window_block = preset.window_block.unwrap_or_else(|| {
            let pool = window_pool_for_category(category);
            pool[rng.random_range(0..pool.len())]
        });

        // Accent block: from preset or random
        // For glassy skyscrapers, use white stained glass or blackstone
        // For modern skyscrapers, use stone separation band materials
        let accent_block = preset.accent_block.unwrap_or_else(|| {
            if category == BuildingCategory::GlassySkyscraper {
                const GLASSY_ACCENT_OPTIONS: [Block; 2] = [WHITE_STAINED_GLASS, BLACKSTONE];
                GLASSY_ACCENT_OPTIONS[rng.random_range(0..GLASSY_ACCENT_OPTIONS.len())]
            } else if category == BuildingCategory::ModernSkyscraper {
                const MODERN_ACCENT_OPTIONS: [Block; 5] = [
                    POLISHED_ANDESITE,
                    SMOOTH_STONE,
                    BLACKSTONE,
                    NETHER_BRICK,
                    STONE_BRICKS,
                ];
                MODERN_ACCENT_OPTIONS[rng.random_range(0..MODERN_ACCENT_OPTIONS.len())]
            } else {
                ACCENT_BLOCK_OPTIONS[rng.random_range(0..ACCENT_BLOCK_OPTIONS.len())]
            }
        });

        // Concrete/modern towers tint their glass dark when the wall or the accent bands are
        // dark, so a blackstone-banded tower reads with dark glass instead of bright blue.
        let window_block = if matches!(
            category,
            BuildingCategory::ContemporarySkyscraper
                | BuildingCategory::GridSkyscraper
                | BuildingCategory::ModernSkyscraper
        ) {
            coordinated_window_block(wall_block, accent_block, window_block)
        } else {
            window_block
        };

        // === Window Style ===

        let use_vertical_windows = preset
            .use_vertical_windows
            .unwrap_or_else(|| rng.random_bool(0.7));

        // Horizontal windows: full-width bands, used by modern skyscrapers
        let use_horizontal_windows = preset
            .use_horizontal_windows
            .unwrap_or_else(|| category == BuildingCategory::ModernSkyscraper);

        // === Accent Features ===

        let use_accent_roof_line = preset
            .use_accent_roof_line
            .unwrap_or_else(|| rng.random_bool(0.25));

        // Accent lines only for multi-floor buildings
        // Glassy skyscrapers get 60% chance, Modern skyscrapers always have them
        let use_accent_lines = preset.use_accent_lines.unwrap_or_else(|| {
            if category == BuildingCategory::ModernSkyscraper {
                true // Stone bands always present on modern skyscrapers
            } else if category == BuildingCategory::GlassySkyscraper {
                rng.random_bool(0.6)
            } else {
                has_multiple_floors && rng.random_bool(0.2)
            }
        });

        // Vertical accent: only if no accent lines and multi-floor
        let use_vertical_accent = preset
            .use_vertical_accent
            .unwrap_or_else(|| has_multiple_floors && !use_accent_lines && rng.random_bool(0.1));

        // === Roof ===

        // Priority: roof:shape tag, preset default, auto-gable, then flat.
        let (roof_type, generate_roof) = if let Some(roof_shape) = element.tags.get("roof:shape") {
            (parse_roof_type(roof_shape), true)
        } else if let Some(rt) = preset.roof_type {
            let should_generate = preset.generate_roof.unwrap_or(rt != RoofType::Flat);
            (rt, should_generate)
        } else if element.tags.contains_key("building:part")
            && (element.tags.contains_key("height") || element.tags.contains_key("building:levels"))
        {
            // Parts with an explicit top are modeled volumes, flat by default
            (RoofType::Flat, false)
        } else if qualifies_for_auto_gabled_roof(building_type) {
            const MAX_FOOTPRINT_FOR_GABLED: usize = 800;
            // Own stream: the draw count here depends on footprint and would
            // otherwise desync sibling parts.
            let mut roof_rng = element_rng(style_seed ^ 0x0F1E_2D3C_4B5A_6907);
            let big_block = footprint_size > MAX_FOOTPRINT_FOR_GABLED || building_height >= 15;
            if building_type == "apartments" && big_block {
                // Urban apartment blocks: flat, hipped, or (pre-war) mansard.
                let (flat_w, hip_w) =
                    if matches!(era, ArchEra::HistoricOrnate | ArchEra::TraditionalPreWar) {
                        (45, 20)
                    } else {
                        (45, 35)
                    };
                let roll = roof_rng.random_range(0u32..100);
                if roll < flat_w {
                    (RoofType::Flat, false)
                } else if roll < flat_w + hip_w {
                    (RoofType::Hipped, true)
                } else {
                    (RoofType::Mansard, true)
                }
            } else if matches!(era, ArchEra::HistoricOrnate | ArchEra::TraditionalPreWar)
                && (100..=MAX_FOOTPRINT_FOR_GABLED).contains(&footprint_size)
                && roof_rng.random_bool(0.30)
            {
                // Mid-size pre-war fabric occasionally carries a mansard.
                (RoofType::Mansard, true)
            } else if footprint_size <= MAX_FOOTPRINT_FOR_GABLED
                && roof_rng.random_bool(climate_gable_probability(climate))
            {
                (RoofType::Gabled, true)
            } else {
                (RoofType::Flat, false)
            }
        } else if matches!(building_type, "industrial" | "warehouse" | "hangar")
            && footprint_size > 800
        {
            // Big industrial halls: shallow mono-pitch or flat.
            let mut roof_rng = element_rng(style_seed ^ 0x0F1E_2D3C_4B5A_6907);
            if roof_rng.random_bool(0.55) {
                (RoofType::Skillion, true)
            } else {
                (RoofType::Flat, false)
            }
        } else {
            (RoofType::Flat, false)
        };

        // downgrade only truly rotated shapes, not concave axis-aligned ones
        let has_explicit_roof_shape = element.tags.contains_key("roof:shape");
        const DIAGONAL_THRESHOLD: f64 = 0.35;
        let diagonality = compute_building_diagonality(&element.nodes);
        let roof_type = if !has_explicit_roof_shape
            && matches!(
                roof_type,
                RoofType::Gabled | RoofType::Hipped | RoofType::Mansard | RoofType::Gambrel
            )
            && diagonality < DIAGONAL_THRESHOLD
            && dominant_axis_angle(&element.nodes).to_degrees().abs() > 10.0
        {
            RoofType::Pyramidal
        } else {
            roof_type
        };

        // Chimney: only for residential with gabled/hipped roofs
        let has_chimney = preset.has_chimney.unwrap_or_else(|| {
            let is_residential = matches!(
                building_type,
                "house"
                    | "residential"
                    | "detached"
                    | "semidetached_house"
                    | "terrace"
                    | "farm"
                    | "cabin"
                    | "bungalow"
                    | "villa"
                    | "yes"
            );
            let suitable_roof = matches!(
                roof_type,
                RoofType::Gabled
                    | RoofType::Hipped
                    | RoofType::Mansard
                    | RoofType::Gambrel
                    | RoofType::HalfHipped
            );
            let suitable_size = (30..=400).contains(&footprint_size);

            is_residential && suitable_roof && suitable_size && rng.random_bool(0.40)
        });

        // Roof block: specific material for roofs
        let roof_block = preset.roof_block;

        // Windows: default to true unless explicitly disabled
        let has_windows = preset.has_windows.unwrap_or(true);

        // Suppress preset doors when an entrance/door node is mapped on the outline.
        let has_mapped_entrance = outline_has_mapped_entrance(element);
        let has_garage_door = if has_mapped_entrance {
            false
        } else {
            preset.has_garage_door.unwrap_or(false)
        };
        let has_single_door = if has_mapped_entrance {
            false
        } else {
            preset.has_single_door.unwrap_or(false)
        };

        // Wall depth style: default based on category and era (preset may override)
        let wall_depth_style = preset.wall_depth_style.unwrap_or_else(|| {
            if footprint_size < 20 || detail == DetailTier::Minimal {
                WallDepthStyle::None
            } else {
                // Era overrides for the general urban fabric: heritage gets
                // ornate relief, panel-era facades stay flat.
                match (era, category) {
                    (
                        ArchEra::HistoricOrnate,
                        BuildingCategory::House
                        | BuildingCategory::Residential
                        | BuildingCategory::Commercial,
                    ) => return WallDepthStyle::HistoricOrnate,
                    (
                        ArchEra::PostWarPanel,
                        BuildingCategory::House | BuildingCategory::Residential,
                    ) => return WallDepthStyle::None,
                    (ArchEra::Contemporary, BuildingCategory::Residential)
                        if element_rng(style_seed ^ 0xE5A0_11DE_57A1_0003).random_bool(0.50) =>
                    {
                        return WallDepthStyle::ModernPillars;
                    }
                    _ => {}
                }
                match category {
                    BuildingCategory::House | BuildingCategory::Residential => {
                        WallDepthStyle::SubtlePilasters
                    }
                    BuildingCategory::Commercial
                    | BuildingCategory::Office
                    | BuildingCategory::Hotel => WallDepthStyle::ModernPillars,
                    BuildingCategory::School | BuildingCategory::Hospital => {
                        WallDepthStyle::InstitutionalBands
                    }
                    BuildingCategory::Industrial | BuildingCategory::Warehouse => {
                        WallDepthStyle::IndustrialBeams
                    }
                    BuildingCategory::Historic => WallDepthStyle::HistoricOrnate,
                    BuildingCategory::Religious => WallDepthStyle::ReligiousButtress,
                    BuildingCategory::TallBuilding | BuildingCategory::ModernSkyscraper => {
                        WallDepthStyle::SkyscraperFins
                    }
                    BuildingCategory::GlassySkyscraper => WallDepthStyle::GlassCurtain,
                    _ => WallDepthStyle::None,
                }
            }
        });

        // Parapet: flat-roofed multi-floor non-residential buildings
        let has_parapet = preset.has_parapet.unwrap_or_else(|| {
            let is_flat = roof_type == RoofType::Flat;
            let suitable = matches!(
                category,
                BuildingCategory::Commercial
                    | BuildingCategory::Office
                    | BuildingCategory::Hotel
                    | BuildingCategory::School
                    | BuildingCategory::Hospital
                    | BuildingCategory::TallBuilding
                    | BuildingCategory::GlassySkyscraper
                    | BuildingCategory::ModernSkyscraper
            );
            is_flat && has_multiple_floors && suitable
        });

        let style = Self {
            wall_block,
            floor_block,
            window_block,
            accent_block,
            roof_block,
            use_vertical_windows,
            use_horizontal_windows,
            has_windows,
            use_accent_roof_line,
            use_accent_lines,
            use_vertical_accent,
            roof_type,
            has_chimney,
            generate_roof,
            has_garage_door,
            has_single_door,
            wall_depth_style,
            has_parapet,
        };

        // A building with facade textures takes the lab's whole-building
        // colour as its wall block, at every scale, and keeps everything else
        // it resolved. The flattening a texture needs, so that it is not
        // fighting procedural windows and pilasters, is applied per column
        // instead (`BuildingConfig::is_photo_column`), because a building
        // gets a facade as soon as one of its walls was photographed: on the
        // Munich test box 105 of the 310 ring segments of the 42 buildings
        // with a facade carry a photograph, so flattening the whole shell
        // turned the other 205 into blank single colour walls where a normal
        // Arnis building has windows and doors.
        if crate::mapillary::facades::has_building(element.id) {
            let base = crate::mapillary::facades::building_colour(element.id)
                .map(|rgb| crate::block_palette::wall_block_for_color(rgb, rng))
                .unwrap_or(style.wall_block);
            return style.with_wall_block(base);
        }
        style
    }

    /// The same style with only its wall block swapped: windows, doors,
    /// accents, wall depth and roof stay as resolved, so a building with
    /// facade data still reads as the procedural one, in the lab's colour,
    /// wherever no photograph covers it.
    fn with_wall_block(mut self, wall_block: Block) -> Self {
        self.wall_block = wall_block;
        self
    }
}

/// Building configuration derived from OSM tags and args
#[derive(Clone)]
struct BuildingConfig {
    /// True when the building starts at ground level (no min_height / min_level offset).
    /// When false, foundation pillars should not be generated.
    is_ground_level: bool,
    building_height: i32,
    /// Gross block height of one upper floor (see `floor_cycle_for`).
    floor_cycle: i32,
    is_tall_building: bool,
    start_y_offset: i32,
    abs_terrain_offset: i32,
    wall_block: Block,
    floor_block: Block,
    window_block: Block,
    accent_block: Block,
    roof_block: Option<Block>,
    use_vertical_windows: bool,
    use_horizontal_windows: bool,
    use_accent_roof_line: bool,
    use_accent_lines: bool,
    use_vertical_accent: bool,
    is_abandoned_building: bool,
    has_windows: bool,
    has_garage_door: bool,
    has_single_door: bool,
    category: BuildingCategory,
    /// Architectural era from tags (weathering, and style decisions upstream).
    era: ArchEra,
    /// Decorative budget from prominence (shutters, rooftop bits, two-tone).
    detail: DetailTier,
    /// Narrower top-floor windows with an accent band below them.
    top_treatment: bool,
    /// Solid attic band with small lights under a pitched roof.
    attic_style: bool,
    /// Taller, wider windows on the first floor above ground (piano nobile).
    piano_nobile: bool,
    wall_depth_style: WallDepthStyle,
    has_parapet: bool,
    has_lobby_base: bool,
    condition: BuildingCondition,
    element_id: u64,
    // shared across all parts of one building for coherent roof style
    style_seed: u64,
    /// Per-building offset of the window rhythm so facades don't align citywide.
    window_phase: i32,
    /// Per-building window layout on the shared lattice.
    window_archetype: WindowArchetype,
    /// Balcony layout on street facades.
    balcony_band: BalconyBand,
    /// Banded stone ground floor on masonry-era urban buildings.
    rustication: bool,
    /// Darker plinth block for the bottom wall rows, None to skip.
    base_course_block: Option<Block>,
    /// Wider, taller glass on the ground floor of commercial buildings.
    has_storefront: bool,
    /// Per-building window dressing style, derived from hand-built reference frames.
    window_frame: Option<WindowFrameStyle>,
    /// The wall columns a facade photograph covers, built as a plain shell
    /// for the texture to override (see `photo_shell_columns`). Empty on a
    /// building with no facade, and below two blocks per metre without photo
    /// panels, where the export supplies colours only and the building keeps
    /// every procedural feature.
    facade_shell: Arc<FnvHashSet<(i32, i32)>>,
    /// The wall columns a preset facade photograph covers, flattened for the
    /// same reason a Mapillary-photographed column is
    /// (`building_facades::collect`). Per column and not per run: the
    /// presets hang nothing on a courtyard ring inside a building, on a ring
    /// too short or too low to carry a panel, or on a wall the Mapillary store
    /// already owns, and a column flattened for a photograph that never comes
    /// loses its window, its plinth and its accent line for nothing.
    preset_shell: Arc<FnvHashSet<(i32, i32)>>,
}

/// Window frame styles distilled from the reference schematics, one per building.
#[derive(Copy, Clone, PartialEq, Eq)]
enum WindowFrameStyle {
    SpruceCottage,
    DarkTimber,
    StoneOrnate,
    Blackstone,
    RusticMossy,
    TerracottaCopper,
    QuartzModern,
}

impl WindowFrameStyle {
    /// Post block at flanking columns, None when the style uses shutters there.
    fn post_block(self) -> Option<Block> {
        match self {
            Self::SpruceCottage | Self::TerracottaCopper => None,
            Self::DarkTimber => Some(DARK_OAK_PLANKS),
            Self::StoneOrnate => Some(POLISHED_DIORITE),
            Self::Blackstone => Some(POLISHED_BLACKSTONE),
            Self::RusticMossy => Some(MOSSY_COBBLESTONE),
            Self::QuartzModern => Some(QUARTZ_BLOCK),
        }
    }

    /// Trapdoor shutters at flanking columns.
    fn shutter_block(self) -> Option<Block> {
        match self {
            Self::SpruceCottage => Some(SPRUCE_TRAPDOOR),
            Self::TerracottaCopper => Some(JUNGLE_TRAPDOOR),
            _ => None,
        }
    }

    /// Material for the upside-down stair band over each window.
    fn band_material(self) -> Block {
        match self {
            Self::SpruceCottage => SPRUCE_PLANKS,
            Self::DarkTimber => DARK_OAK_PLANKS,
            Self::StoneOrnate => STONE_BRICKS,
            Self::Blackstone => BLACKSTONE,
            Self::RusticMossy => COBBLESTONE,
            Self::TerracottaCopper => WAXED_COPPER_BLOCK,
            Self::QuartzModern => QUARTZ_BLOCK,
        }
    }

    fn has_lanterns(self) -> bool {
        matches!(self, Self::SpruceCottage | Self::TerracottaCopper)
    }

    /// Trapdoor material for shelves, canopies and aprons.
    fn detail_trapdoor(self) -> Block {
        match self {
            Self::DarkTimber => DARK_OAK_TRAPDOOR,
            Self::Blackstone => WARPED_TRAPDOOR,
            Self::QuartzModern => IRON_TRAPDOOR,
            Self::TerracottaCopper => JUNGLE_TRAPDOOR,
            _ => SPRUCE_TRAPDOOR,
        }
    }

    /// Lantern hung under the band beside a window top.
    fn hanging_lantern(self) -> Option<Block> {
        match self {
            Self::SpruceCottage | Self::TerracottaCopper | Self::StoneOrnate => Some(LANTERN),
            Self::Blackstone => Some(SOUL_LANTERN),
            _ => None,
        }
    }

    /// Button studs on the band front.
    fn stud_button(self) -> Option<Block> {
        match self {
            Self::RusticMossy | Self::StoneOrnate => Some(STONE_BUTTON),
            Self::Blackstone => Some(POLISHED_BLACKSTONE_BUTTON),
            _ => None,
        }
    }
}

/// Whether a frame style's trim harmonizes with the wall it sits on.
fn frame_fits_wall(style: WindowFrameStyle, wall: Block) -> bool {
    use WindowFrameStyle::*;
    match wall {
        WHITE_CONCRETE | LIGHT_GRAY_CONCRETE | GRAY_CONCRETE | QUARTZ_BLOCK | QUARTZ_BRICKS
        | SMOOTH_STONE | POLISHED_ANDESITE | POLISHED_DIORITE => {
            matches!(style, QuartzModern | Blackstone | StoneOrnate)
        }
        OAK_PLANKS | SPRUCE_PLANKS | DARK_OAK_PLANKS | OAK_LOG | SPRUCE_LOG => {
            matches!(style, SpruceCottage | DarkTimber | RusticMossy)
        }
        BRICK | RED_TERRACOTTA | ORANGE_TERRACOTTA | TERRACOTTA | BROWN_TERRACOTTA
        | RED_NETHER_BRICKS | NETHER_BRICK | GRANITE | POLISHED_GRANITE => {
            matches!(style, StoneOrnate | TerracottaCopper | DarkTimber)
        }
        SANDSTONE | SMOOTH_SANDSTONE | END_STONE_BRICKS | WHITE_TERRACOTTA => {
            matches!(style, StoneOrnate | TerracottaCopper | QuartzModern)
        }
        _ => true,
    }
}

/// Picks a per-building frame style suited to category, era and wall.
fn pick_window_frame(
    category: BuildingCategory,
    era: ArchEra,
    detail: DetailTier,
    wall_block: Block,
    element_id: u64,
) -> Option<WindowFrameStyle> {
    if detail == DetailTier::Minimal {
        return None;
    }
    use WindowFrameStyle::*;
    // Category gate first: only these get dressed frames at all.
    if !matches!(
        category,
        BuildingCategory::House
            | BuildingCategory::Residential
            | BuildingCategory::Commercial
            | BuildingCategory::Hotel
            | BuildingCategory::Historic
    ) {
        return None;
    }
    // A known era narrows the pool and shifts how often frames appear:
    // heritage facades are almost always dressed, panel-era ones rarely.
    let (pool, chance): (&[WindowFrameStyle], f64) = match era {
        ArchEra::HistoricOrnate => (&[StoneOrnate, RusticMossy], 0.95),
        ArchEra::TraditionalPreWar => (
            &[
                SpruceCottage,
                DarkTimber,
                StoneOrnate,
                RusticMossy,
                TerracottaCopper,
            ],
            0.90,
        ),
        ArchEra::PostWarPanel => (&[QuartzModern], 0.15),
        ArchEra::Contemporary => (&[QuartzModern, Blackstone], 0.70),
        ArchEra::Unknown => (
            match category {
                BuildingCategory::House | BuildingCategory::Residential => &[
                    SpruceCottage,
                    DarkTimber,
                    StoneOrnate,
                    RusticMossy,
                    TerracottaCopper,
                ],
                BuildingCategory::Commercial | BuildingCategory::Hotel => {
                    &[QuartzModern, Blackstone, StoneOrnate]
                }
                _ => &[RusticMossy, StoneOrnate, Blackstone],
            },
            0.90,
        ),
    };
    let chance = match detail {
        DetailTier::Enhanced => (chance + 0.15).min(0.95),
        DetailTier::Landmark => (chance + 0.30).min(0.95),
        _ => chance,
    };
    let fitting: Vec<WindowFrameStyle> = pool
        .iter()
        .copied()
        .filter(|&f| frame_fits_wall(f, wall_block))
        .collect();
    if fitting.is_empty() {
        return None;
    }
    let mut rng = element_rng(element_id ^ 0xF7A3_E001_57BD_2210);
    rng.random_bool(chance)
        .then(|| fitting[rng.random_range(0..fitting.len())])
}

impl BuildingConfig {
    /// Whether the wall column at `(bx, bz)` is one a facade photograph
    /// covers, and so is built as a plain shell in `wall_block` for the
    /// texture to override.
    ///
    /// Only the photographed walls are flattened, because only they have a
    /// photograph: a procedural window, accent line, pilaster or quoin here
    /// would show through the texture wherever it has no data, and a
    /// protrusion in front of it would hide part of it, but on the walls the
    /// export never covered, the same features are the whole building.
    #[inline]
    fn is_photo_column(&self, bx: i32, bz: i32) -> bool {
        self.facade_shell.contains(&(bx, bz))
    }

    /// Whether the wall column at `(bx, bz)` has a photograph of some kind
    /// coming over it, from Mapillary or from the preset set, and so is built
    /// as a plain shell.
    ///
    /// A panel hangs `displays::PUSH_OUT` in front of the outermost wall
    /// cell, so anything the building sticks out past its own wall stands
    /// between the viewer and the picture: a window frame, a quoin, a cornice
    /// or a downpipe reads as a lump of concrete floating on the photograph.
    /// The Mapillary path has always flattened for this reason. Doors are the
    /// deliberate exception and keep using [`Self::is_photo_column`]: a door
    /// sits in the wall plane rather than in front of it, so the panel hides
    /// it anyway, and suppressing it would seal every building in the world.
    #[inline]
    fn is_flat_column(&self, bx: i32, bz: i32) -> bool {
        self.is_photo_column(bx, bz) || self.preset_shell.contains(&(bx, bz))
    }

    /// Grammar anchor: +2 at ground level; elevated parts already carry the
    /// bonus in their min_level offset, keeping stacked bands in phase.
    #[inline]
    fn grammar_anchor(&self) -> i32 {
        if self.is_ground_level {
            GROUND_FLOOR_BONUS
        } else {
            0
        }
    }

    /// Returns the position within the floor cycle (0 = floor row, 1..cycle-1 = open rows).
    /// This aligns with `generate_floors_and_ceilings` which places intermediate ceilings
    /// at `start_y_offset + anchor + cycle, + 2*cycle, …`.
    #[inline]
    fn floor_row(&self, h: i32) -> i32 {
        ((h - self.start_y_offset - self.grammar_anchor()) % self.floor_cycle + self.floor_cycle)
            % self.floor_cycle
    }

    /// Rows an entrance column keeps clear of dressing: the door itself and
    /// its canopy row. Bands, headers and sills above carry on across it.
    #[inline]
    fn entrance_row(&self, h: i32) -> bool {
        h <= self.start_y_offset + 3
    }

    /// Highest wall row that still belongs to the ground floor (the ground floor
    /// is one row taller than upper floors thanks to the +2 grammar offset).
    #[inline]
    fn ground_floor_top(&self) -> i32 {
        self.start_y_offset + self.grammar_anchor() - 1 + self.floor_cycle
    }

    /// Positional role of a wall row: ground floor, body, or topmost cycle.
    #[inline]
    fn floor_role(&self, h: i32) -> FloorRole {
        if h <= self.ground_floor_top() {
            FloorRole::Ground
        } else if h > self.start_y_offset + self.building_height - self.floor_cycle {
            FloorRole::Top
        } else {
            FloorRole::Body
        }
    }

    /// Position within the 6-block window cycle (0-2 = window strip, 3-5 = wall pier).
    /// `u` is the along-wall ordinate, not a world-space sum; `bx + bz` would make
    /// the period depend on the wall angle.
    #[inline]
    fn window_col(&self, u: i32) -> i32 {
        (u + self.window_phase).rem_euclid(6)
    }

    /// Index of the 6-block bay containing `u`. Same lattice as `window_col`.
    #[inline]
    fn window_bay(&self, u: i32) -> i32 {
        (u + self.window_phase).div_euclid(6)
    }

    /// Number of darker plinth rows at the wall base (2 from roughly three floors up).
    #[inline]
    fn base_course_rows(&self) -> i32 {
        if self.building_height >= 3 * self.floor_cycle {
            2
        } else {
            1
        }
    }
}

// Never render as buildings: Eiffel Tower, London Eye, Utah Capitol, Starbase Pad 2 trench + mount ring.
const SKIP_WAY_IDS: &[u64] = &[5013364, 204068874, 32920861, 1352374225, 1486731987];

/// Darker stone family plinth matching the wall material tone.
fn base_course_for_wall(wall: Block) -> Block {
    match wall {
        OAK_PLANKS | SPRUCE_PLANKS | OAK_LOG | SPRUCE_LOG => COBBLESTONE,
        ANDESITE | GRAY_CONCRETE | LIGHT_GRAY_CONCRETE => POLISHED_ANDESITE,
        _ => STONE_BRICKS,
    }
}

/// Building bounds calculated from nodes
struct BuildingBounds {
    min_x: i32,
    max_x: i32,
    min_z: i32,
    max_z: i32,
}

impl BuildingBounds {
    fn from_nodes(nodes: &[crate::osm_parser::ProcessedNode]) -> Self {
        Self {
            min_x: nodes.iter().map(|n| n.x).min().unwrap_or(0),
            max_x: nodes.iter().map(|n| n.x).max().unwrap_or(0),
            min_z: nodes.iter().map(|n| n.z).min().unwrap_or(0),
            max_z: nodes.iter().map(|n| n.z).max().unwrap_or(0),
        }
    }

    fn width(&self) -> i32 {
        self.max_x - self.min_x
    }

    fn length(&self) -> i32 {
        self.max_z - self.min_z
    }
}

// ============================================================================
// Helper Functions for Building Configuration
// ============================================================================

/// Checks if a building should be skipped (underground structures)
#[inline]
pub(crate) fn is_underground_building(tags: &HashMap<String, String>) -> bool {
    // An explicit surface location wins over layer=-1, which is only stacking order
    match tags.get("location").map(String::as_str) {
        Some("underground") | Some("subway") => return true,
        Some("surface") | Some("overground") | Some("roof") => return false,
        _ => {}
    }

    // Check layer tag, negative means underground
    if let Some(layer) = tags.get("layer") {
        if layer.parse::<i32>().unwrap_or(0) < 0 {
            return true;
        }
    }

    // Check level tag, negative means underground
    if let Some(level) = tags.get("level") {
        if level.parse::<i32>().unwrap_or(0) < 0 {
            return true;
        }
    }

    // Check building:levels:underground, if this is the only levels tag, it's underground
    if tags.contains_key("building:levels:underground") && !tags.contains_key("building:levels") {
        return true;
    }

    false
}

/// Calculates the starting Y offset based on terrain and min_level
pub(crate) fn calculate_start_y_offset(
    editor: &WorldEditor,
    element: &ProcessedWay,
    args: &Args,
    min_level_offset: i32,
) -> i32 {
    if args.terrain() {
        // Seeded from the terrain itself, never from args.ground_level: with the extended
        // floor the scaler sinks the terrain base far below it, and a seeded max would
        // strand every low-lying building up at the requested ground level.
        let mut max_ground_level: Option<i32> = None;
        for node in &element.nodes {
            if let Some(level) = editor.terrain_level(node.x, node.z) {
                max_ground_level = Some(max_ground_level.map_or(level, |m: i32| m.max(level)));
            }
        }
        max_ground_level.unwrap_or(args.ground_level) + min_level_offset
    } else {
        min_level_offset
    }
}

/// Window glass pool per building category.
fn window_pool_for_category(category: BuildingCategory) -> &'static [Block] {
    match category {
        BuildingCategory::Residential | BuildingCategory::House => &RESIDENTIAL_WINDOW_OPTIONS,
        BuildingCategory::School
        | BuildingCategory::Hospital
        | BuildingCategory::Office
        | BuildingCategory::Commercial => &INSTITUTIONAL_WINDOW_OPTIONS,
        BuildingCategory::Hotel => &HOSPITALITY_WINDOW_OPTIONS,
        BuildingCategory::Industrial | BuildingCategory::Warehouse => &INDUSTRIAL_WINDOW_OPTIONS,
        BuildingCategory::Religious => &RELIGIOUS_WINDOW_OPTIONS,
        BuildingCategory::Farm => &FARM_WINDOW_OPTIONS,
        BuildingCategory::Historic => &HISTORIC_WINDOW_OPTIONS,
        _ => &WINDOW_VARIATIONS,
    }
}

/// Balcony layout for multi-storey residential street facades. A repeated
/// pattern reads as architecture where scattered singles read as noise.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum BalconyBand {
    /// Legacy per-window random balconies.
    Scattered,
    /// A balcony on every street-facing bay of every upper floor.
    EveryBay,
    /// Balconies on every other bay, stacked vertically.
    Alternating,
}

fn pick_balcony_band(
    category: BuildingCategory,
    building_height: i32,
    floor_cycle: i32,
    has_street: bool,
    group_seed: u64,
) -> BalconyBand {
    if !matches!(
        category,
        BuildingCategory::Residential | BuildingCategory::House
    ) || building_height < 3 * floor_cycle
        || !has_street
    {
        return BalconyBand::Scattered;
    }
    let roll = element_rng(group_seed ^ 0xBA1C_0417_0000_0009).random_range(0u32..100);
    if roll < 30 {
        BalconyBand::Scattered
    } else if roll < 60 {
        BalconyBand::EveryBay
    } else {
        BalconyBand::Alternating
    }
}

/// Per-building window layout on the shared 6-column / floor-cycle lattice.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum WindowArchetype {
    /// Classic 3-wide bays over the full window rows.
    Standard3,
    /// Two 1-wide sashes (cols 0 and 2) with a lintel row above.
    PairedNarrow,
    /// Single centered 1-wide strip over the full window rows.
    VerticalStrip,
    /// 4-wide band windows with a sill row below.
    WideHorizontal,
    /// Like Standard3 plus protruding stair headers over the window tops.
    ArchedTraditional,
}

/// Whether (window_col, floor_row) is glass under the given archetype.
/// `floor_row` 0 is always the solid band; rows 1..cycle-1 are open rows.
fn archetype_allows_window(
    archetype: WindowArchetype,
    window_col: i32,
    floor_row: i32,
    floor_cycle: i32,
) -> bool {
    match archetype {
        WindowArchetype::Standard3 | WindowArchetype::ArchedTraditional => window_col < 3,
        // Drop the top open row: it reads as a lintel over the two sashes.
        WindowArchetype::PairedNarrow => {
            (window_col == 0 || window_col == 2) && floor_row < floor_cycle - 1
        }
        WindowArchetype::VerticalStrip => window_col == 1,
        // Drop the bottom open row: it reads as a sill under the band window.
        WindowArchetype::WideHorizontal => window_col < 4 && floor_row > 1,
    }
}

/// Weighted per-category archetype choice, seeded on the shared group seed.
fn pick_window_archetype(
    category: BuildingCategory,
    era: ArchEra,
    group_seed: u64,
) -> WindowArchetype {
    use WindowArchetype::*;
    // (archetype, weight), summing to 100 per row
    let table: &[(WindowArchetype, u32)] = match category {
        BuildingCategory::House => &[
            (Standard3, 40),
            (PairedNarrow, 35),
            (VerticalStrip, 5),
            (WideHorizontal, 10),
            (ArchedTraditional, 10),
        ],
        BuildingCategory::Residential => &[
            (Standard3, 35),
            (PairedNarrow, 30),
            (VerticalStrip, 10),
            (WideHorizontal, 15),
            (ArchedTraditional, 10),
        ],
        BuildingCategory::Commercial | BuildingCategory::Office => &[
            (Standard3, 25),
            (PairedNarrow, 5),
            (VerticalStrip, 20),
            (WideHorizontal, 45),
            (ArchedTraditional, 5),
        ],
        BuildingCategory::Hotel => &[
            (Standard3, 30),
            (PairedNarrow, 10),
            (VerticalStrip, 20),
            (WideHorizontal, 35),
            (ArchedTraditional, 5),
        ],
        BuildingCategory::School | BuildingCategory::Hospital => &[
            (Standard3, 30),
            (PairedNarrow, 10),
            (VerticalStrip, 10),
            (WideHorizontal, 50),
        ],
        BuildingCategory::Industrial | BuildingCategory::Warehouse => {
            &[(Standard3, 20), (VerticalStrip, 10), (WideHorizontal, 70)]
        }
        _ => return Standard3,
    };
    let mut rng = element_rng(group_seed ^ 0x57A2_C0DE_A5C1_0007);
    let total: u32 = table.iter().map(|&(_, w)| w).sum();
    let mut roll = rng.random_range(0..total);
    let mut picked = Standard3;
    for &(archetype, weight) in table {
        if roll < weight {
            picked = archetype;
            break;
        }
        roll -= weight;
    }
    // Era adjustment on top of the category weights.
    let mut era_rng = element_rng(group_seed ^ 0x57A2_C0DE_A5C1_0008);
    match (era, picked) {
        (ArchEra::HistoricOrnate, Standard3) if era_rng.random_bool(0.75) => ArchedTraditional,
        (ArchEra::TraditionalPreWar, Standard3) if era_rng.random_bool(0.25) => ArchedTraditional,
        (ArchEra::PostWarPanel, PairedNarrow) => WideHorizontal,
        (ArchEra::Contemporary, Standard3) if era_rng.random_bool(0.25) => WideHorizontal,
        _ => picked,
    }
}

/// Tints a tower's glass to match a dark wall or dark accent band; else keeps the light default.
fn coordinated_window_block(wall_block: Block, accent_block: Block, light_default: Block) -> Block {
    const DARK: &[Block] = &[
        BLACK_CONCRETE,
        GRAY_CONCRETE,
        BLACKSTONE,
        POLISHED_BLACKSTONE,
        DEEPSLATE_BRICKS,
        NETHER_BRICK,
        BLACK_TERRACOTTA,
        GRAY_TERRACOTTA,
    ];
    if DARK.contains(&wall_block) || DARK.contains(&accent_block) {
        GRAY_STAINED_GLASS
    } else {
        light_default
    }
}

/// Wall block from an OSM material/colour tag, or None if no tag is set.
fn determine_wall_block_from_tags(
    element: &ProcessedWay,
    category: BuildingCategory,
    rng: &mut impl Rng,
) -> Option<Block> {
    if category == BuildingCategory::GlassySkyscraper {
        // GlassySkyscraper walls must stay glass.
        return None;
    }
    if element.tags.get("historic").map(String::as_str) == Some("castle") {
        return None;
    }
    if let Some(material) = element
        .tags
        .get("building:material")
        .or_else(|| element.tags.get("building:facade:material"))
        .or_else(|| element.tags.get("facade:material"))
    {
        if let Some(block) = get_wall_block_for_material(material, rng) {
            return Some(block);
        }
    }
    let colour = element
        .tags
        .get("building:colour")
        .or_else(|| element.tags.get("colour"));
    if let Some(building_colour) = colour {
        if let Some(rgb) = color_text_to_rgb_tuple(building_colour) {
            return Some(crate::block_palette::wall_block_for_color(rgb, rng));
        }
    }
    None
}

/// Wall block from explicit material/colour tags, falling back to category palette.
fn determine_wall_block(
    element: &ProcessedWay,
    category: BuildingCategory,
    era: ArchEra,
    climate: Climate,
    rng: &mut impl Rng,
) -> Block {
    // Historic castles have their own special treatment
    if element.tags.get("historic").map(String::as_str) == Some("castle") {
        return get_castle_wall_block(rng);
    }

    // GlassySkyscraper walls must stay glass.
    if category != BuildingCategory::GlassySkyscraper {
        if let Some(material) = element
            .tags
            .get("building:material")
            .or_else(|| element.tags.get("building:facade:material"))
            .or_else(|| element.tags.get("facade:material"))
        {
            if let Some(block) = get_wall_block_for_material(material, rng) {
                return block;
            }
        }

        let colour = element
            .tags
            .get("building:colour")
            .or_else(|| element.tags.get("colour"));
        if let Some(building_colour) = colour {
            if let Some(rgb) = color_text_to_rgb_tuple(building_colour) {
                return crate::block_palette::wall_block_for_color(rgb, rng);
            }
        }
    }

    // Otherwise, select from category-specific palette
    get_wall_block_for_category(category, era, climate, rng)
}

/// Whether the wall depth style stands a pier on column 3 of every bay, the
/// same roll `generate_wall_depth_features` makes; shutters and flank posts
/// would sit on that column otherwise.
fn wall_depth_piers_active(element: &ProcessedWay, config: &BuildingConfig) -> bool {
    let bounds = BuildingBounds::from_nodes(&element.nodes);
    if bounds.width() < 4 || bounds.length() < 4 {
        return false;
    }
    if config.building_height < config.floor_cycle + 2
        && config.wall_depth_style != WallDepthStyle::HistoricOrnate
    {
        return false;
    }
    let depth_roll: u32 = element_rng(config.style_seed.wrapping_add(7919)).random_range(0..100);
    match config.wall_depth_style {
        WallDepthStyle::SubtlePilasters => depth_roll < 60,
        WallDepthStyle::ModernPillars
        | WallDepthStyle::InstitutionalBands
        | WallDepthStyle::HistoricOrnate
        | WallDepthStyle::SkyscraperFins => true,
        _ => false,
    }
}

/// Blocks a protruding feature must run down from the wall base to reach the
/// ground under both the wall column and its own cell.
fn feature_descent(
    editor: &WorldEditor,
    config: &BuildingConfig,
    wall_x: i32,
    wall_z: i32,
    out_x: i32,
    out_z: i32,
) -> i32 {
    let ground = [(wall_x, wall_z), (out_x, out_z)]
        .iter()
        .filter_map(|&(x, z)| editor.terrain_level(x, z))
        .min();
    ground.map_or(0, |g| (config.start_y_offset - g).max(0))
}

/// Wall blocks that fit a building era; None for Unknown.
fn era_allow_list(era: ArchEra) -> Option<&'static [Block]> {
    let allowed: &'static [Block] = match era {
        ArchEra::Unknown => return None,
        ArchEra::TraditionalPreWar => &[
            BRICK,
            STONE_BRICKS,
            WHITE_TERRACOTTA,
            BROWN_TERRACOTTA,
            SANDSTONE,
            SMOOTH_SANDSTONE,
            MUD_BRICKS,
            GRANITE,
            POLISHED_GRANITE,
            TERRACOTTA,
            END_STONE_BRICKS,
            QUARTZ_BRICKS,
            ORANGE_TERRACOTTA,
            RED_TERRACOTTA,
            RED_NETHER_BRICKS,
            NETHER_BRICK,
            COBBLESTONE,
            OAK_PLANKS,
            SPRUCE_PLANKS,
        ],
        ArchEra::PostWarPanel => &[
            GRAY_CONCRETE,
            LIGHT_GRAY_CONCRETE,
            WHITE_CONCRETE,
            BROWN_CONCRETE,
            GRAY_TERRACOTTA,
            LIGHT_GRAY_TERRACOTTA,
            POLISHED_ANDESITE,
            SMOOTH_STONE,
            BRICK,
            WHITE_TERRACOTTA,
        ],
        ArchEra::Contemporary => &[
            WHITE_CONCRETE,
            LIGHT_GRAY_CONCRETE,
            GRAY_CONCRETE,
            QUARTZ_BLOCK,
            QUARTZ_BRICKS,
            POLISHED_ANDESITE,
            SMOOTH_STONE,
            POLISHED_DEEPSLATE,
            DEEPSLATE_BRICKS,
            POLISHED_BLACKSTONE,
            LIGHT_GRAY_TERRACOTTA,
        ],
        ArchEra::HistoricOrnate => &[
            SANDSTONE,
            SMOOTH_SANDSTONE,
            STONE_BRICKS,
            CHISELED_STONE_BRICKS,
            END_STONE_BRICKS,
            QUARTZ_BRICKS,
            WHITE_TERRACOTTA,
            BRICK,
            POLISHED_DIORITE,
            GRANITE,
            POLISHED_GRANITE,
        ],
    };
    Some(allowed)
}

/// Categories whose palettes get filtered by the building era. Specialised
/// palettes (farm wood, religious stone, industrial, glass towers) already
/// carry their identity and stay untouched.
fn era_filters_category(category: BuildingCategory) -> bool {
    matches!(
        category,
        BuildingCategory::House
            | BuildingCategory::Residential
            | BuildingCategory::Commercial
            | BuildingCategory::Office
            | BuildingCategory::Hotel
            | BuildingCategory::Default
    )
}

/// Vertical position of a wall row.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum FloorRole {
    Ground,
    Body,
    /// The topmost floor cycle (attic/top-floor treatments hook in here).
    Top,
}

/// Decorative budget from footprint, height, category, tags and visibility.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub(crate) enum DetailTier {
    Minimal,
    Standard,
    Enhanced,
    Landmark,
}

fn compute_detail_tier(
    element: &ProcessedWay,
    category: BuildingCategory,
    footprint: usize,
    building_height: i32,
    street_facing: bool,
) -> DetailTier {
    let mut score: i32 = 0;
    score += (footprint as i32 / 40).min(25);
    score += building_height.saturating_mul(2).min(25);
    score += match category {
        BuildingCategory::Historic | BuildingCategory::Religious => 20,
        BuildingCategory::Commercial | BuildingCategory::Hotel | BuildingCategory::Office => 10,
        BuildingCategory::Garage | BuildingCategory::Shed | BuildingCategory::Greenhouse => -20,
        _ => 0,
    };
    let tags = &element.tags;
    if tags.contains_key("wikidata") {
        score += 15;
    }
    if tags.get("tourism").is_some_and(|t| {
        matches!(
            t.as_str(),
            "attraction" | "museum" | "gallery" | "viewpoint"
        )
    }) {
        score += 15;
    }
    if tags.get("heritage").is_some_and(|v| v != "no") {
        score += 20;
    }
    if tags.get("historic").is_some_and(|v| v != "no") {
        score += 15;
    }
    if tags.contains_key("building:architecture") || tags.contains_key("architecture") {
        score += 10;
    }
    if street_facing {
        score += 10;
    }
    if score <= 24 {
        DetailTier::Minimal
    } else if score <= 55 {
        DetailTier::Standard
    } else if score <= 80 {
        DetailTier::Enhanced
    } else {
        DetailTier::Landmark
    }
}

/// Wood species a nordic climate adds to the residential palette.
const NORDIC_WOOD_ADDITIONS: [Block; 3] = [SPRUCE_PLANKS, OAK_PLANKS, DARK_OAK_PLANKS];

/// Whether climate reweighting applies to this category in this climate.
/// Residential fabric adapts everywhere; commercial only in hot climates
/// (light high-albedo bias). Temperate is handled upstream (no change at all).
fn climate_applies(climate: Climate, category: BuildingCategory) -> bool {
    match category {
        BuildingCategory::House | BuildingCategory::Residential => true,
        BuildingCategory::Commercial | BuildingCategory::Office | BuildingCategory::Hotel => {
            matches!(
                climate,
                Climate::HotDesert | Climate::HotSteppe | Climate::TropicalSavanna
            )
        }
        _ => false,
    }
}

/// Per-block weight for climate-adapted palettes (1 neutral, 0 excluded),
/// following real regional construction. Tags override upstream.
fn climate_wall_weight(climate: Climate, category: BuildingCategory, block: Block) -> u8 {
    let residential_scale = |w: u8| {
        // Multi-family blocks are less often wood than single homes.
        if category == BuildingCategory::Residential {
            (w / 2).max(1)
        } else {
            w
        }
    };
    match climate {
        Climate::Temperate => 1,
        Climate::HotDesert | Climate::HotSteppe => match block {
            SANDSTONE | SMOOTH_SANDSTONE | MUD_BRICKS | WHITE_TERRACOTTA => 4,
            WHITE_CONCRETE | END_STONE_BRICKS | TERRACOTTA => 3,
            LIGHT_GRAY_CONCRETE | QUARTZ_BRICKS | QUARTZ_BLOCK | ORANGE_TERRACOTTA
            | BROWN_TERRACOTTA => 2,
            DEEPSLATE_BRICKS
            | POLISHED_DEEPSLATE
            | POLISHED_BLACKSTONE
            | POLISHED_BLACKSTONE_BRICKS
            | NETHER_BRICK
            | RED_NETHER_BRICKS
            | RED_TERRACOTTA
            | GRAY_TERRACOTTA
            | BROWN_CONCRETE
            | SPRUCE_PLANKS
            | OAK_PLANKS
            | DARK_OAK_PLANKS => 0,
            _ => 1,
        },
        Climate::TropicalSavanna => match block {
            WHITE_CONCRETE => 4,
            WHITE_TERRACOTTA | LIGHT_GRAY_CONCRETE | BRICK => 3,
            GRAY_CONCRETE
            | TERRACOTTA
            | ORANGE_TERRACOTTA
            | LIGHT_BLUE_TERRACOTTA
            | QUARTZ_BRICKS
            | SMOOTH_SANDSTONE
            | MUD_BRICKS => 2,
            DEEPSLATE_BRICKS
            | POLISHED_DEEPSLATE
            | POLISHED_BLACKSTONE
            | POLISHED_BLACKSTONE_BRICKS
            | NETHER_BRICK
            | RED_NETHER_BRICKS
            | SPRUCE_PLANKS
            | OAK_PLANKS
            | DARK_OAK_PLANKS => 0,
            _ => 1,
        },
        Climate::Boreal => match block {
            SPRUCE_PLANKS => residential_scale(5),
            OAK_PLANKS => residential_scale(3),
            DARK_OAK_PLANKS => residential_scale(2),
            RED_TERRACOTTA => 3, // falu red, rare-filter exempt
            WHITE_CONCRETE | WHITE_TERRACOTTA | BRICK => 2,
            SANDSTONE | SMOOTH_SANDSTONE | MUD_BRICKS => 0,
            _ => 1,
        },
        Climate::Tundra | Climate::IceCap => match block {
            SPRUCE_PLANKS => residential_scale(3),
            OAK_PLANKS => residential_scale(2),
            LIGHT_BLUE_TERRACOTTA
            | RED_TERRACOTTA
            | WHITE_CONCRETE
            | GRAY_CONCRETE
            | LIGHT_GRAY_CONCRETE => 2,
            SANDSTONE | SMOOTH_SANDSTONE | MUD_BRICKS | DARK_OAK_PLANKS => 0,
            _ => 1,
        },
        Climate::ColdSteppe | Climate::ColdDesert | Climate::DryContinental => match block {
            BRICK => 3,
            WHITE_TERRACOTTA | WHITE_CONCRETE | LIGHT_GRAY_CONCRETE | GRAY_CONCRETE
            | STONE_BRICKS | MUD_BRICKS => 2,
            SPRUCE_PLANKS | OAK_PLANKS | DARK_OAK_PLANKS => 0,
            _ => 1,
        },
    }
}

/// Weighted wall pick with the same rare-block damping as
/// `pick_with_rare_filter`; `rare_exempt` lets a climate keep one rare block
/// at full frequency (boreal falu red).
fn pick_weighted_wall(
    pool: &[(Block, u8)],
    rare_exempt: Option<Block>,
    rng: &mut impl Rng,
) -> Block {
    let total: u32 = pool.iter().map(|&(_, w)| w as u32).sum();
    for _ in 0..8 {
        let mut roll = rng.random_range(0..total);
        let mut picked = pool[0].0;
        for &(b, w) in pool {
            if roll < w as u32 {
                picked = b;
                break;
            }
            roll -= w as u32;
        }
        if !is_rare_wall_block(picked) || Some(picked) == rare_exempt || rng.random_bool(0.20) {
            return picked;
        }
    }
    pool[0].0
}

/// Probability that an auto-gabled candidate actually gets the pitched roof;
/// flat roofs dominate arid construction, pitched roofs the snowy north.
fn climate_gable_probability(climate: Climate) -> f64 {
    match climate {
        Climate::HotDesert | Climate::HotSteppe => 0.35,
        Climate::TropicalSavanna => 0.60,
        Climate::Boreal | Climate::Tundra | Climate::IceCap => 0.95,
        _ => 0.90,
    }
}

/// Walls accepted only ~20% of the time when picked, to keep them rare.
#[inline]
fn is_rare_wall_block(block: Block) -> bool {
    matches!(block, NETHER_BRICK | RED_NETHER_BRICKS | RED_TERRACOTTA)
}

/// Picks from `palette`, biasing against `is_rare_wall_block` entries.
fn pick_with_rare_filter<R: Rng>(palette: &[Block], rng: &mut R) -> Block {
    debug_assert!(!palette.is_empty());
    let mut last = palette[rng.random_range(0..palette.len())];
    for _ in 0..8 {
        if !is_rare_wall_block(last) || rng.random_bool(0.20) {
            return last;
        }
        last = palette[rng.random_range(0..palette.len())];
    }
    last
}

/// Selects a wall block from the appropriate category palette
fn get_wall_block_for_category(
    category: BuildingCategory,
    era: ArchEra,
    climate: Climate,
    rng: &mut impl Rng,
) -> Block {
    // Climate path (never Temperate, which keeps the legacy draw sequence
    // exactly): reweighted palette intersected with the era allow-list.
    if climate != Climate::Temperate && climate_applies(climate, category) {
        let palette: &[Block] = match category {
            BuildingCategory::House | BuildingCategory::Residential => &RESIDENTIAL_WALL_OPTIONS,
            _ => &COMMERCIAL_WALL_OPTIONS,
        };
        let nordic = matches!(climate, Climate::Boreal | Climate::Tundra | Climate::IceCap)
            && matches!(
                category,
                BuildingCategory::House | BuildingCategory::Residential
            );
        let allow = era_allow_list(era);
        let extra: &[Block] = if nordic { &NORDIC_WOOD_ADDITIONS } else { &[] };
        let pool: Vec<(Block, u8)> = palette
            .iter()
            .chain(extra.iter())
            .copied()
            .filter(|b| allow.is_none_or(|a| a.contains(b)))
            .map(|b| (b, climate_wall_weight(climate, category, b)))
            .filter(|&(_, w)| w > 0)
            .collect();
        if pool.len() >= 2 {
            let rare_exempt =
                matches!(climate, Climate::Boreal | Climate::Tundra | Climate::IceCap)
                    .then_some(RED_TERRACOTTA);
            return pick_weighted_wall(&pool, rare_exempt, rng);
        }
    }

    // Era path: intersect the category palette with the era allow-list; thin
    // intersections draw from the era list directly.
    if era_filters_category(category) {
        if let Some(allow) = era_allow_list(era) {
            let palette: &[Block] = match category {
                BuildingCategory::House | BuildingCategory::Residential => {
                    &RESIDENTIAL_WALL_OPTIONS
                }
                BuildingCategory::Commercial
                | BuildingCategory::Office
                | BuildingCategory::Hotel => &COMMERCIAL_WALL_OPTIONS,
                _ => &[],
            };
            let filtered: Vec<Block> = palette
                .iter()
                .copied()
                .filter(|b| allow.contains(b))
                .collect();
            return if filtered.len() >= 4 {
                pick_with_rare_filter(&filtered, rng)
            } else {
                pick_with_rare_filter(allow, rng)
            };
        }
    }
    match category {
        BuildingCategory::House | BuildingCategory::Residential => {
            pick_with_rare_filter(&RESIDENTIAL_WALL_OPTIONS, rng)
        }
        BuildingCategory::Commercial | BuildingCategory::Office | BuildingCategory::Hotel => {
            pick_with_rare_filter(&COMMERCIAL_WALL_OPTIONS, rng)
        }
        BuildingCategory::Industrial | BuildingCategory::Warehouse => {
            pick_with_rare_filter(&INDUSTRIAL_WALL_OPTIONS, rng)
        }
        BuildingCategory::Religious => pick_with_rare_filter(&RELIGIOUS_WALL_OPTIONS, rng),
        BuildingCategory::School | BuildingCategory::Hospital => {
            pick_with_rare_filter(&INSTITUTIONAL_WALL_OPTIONS, rng)
        }
        BuildingCategory::Farm => pick_with_rare_filter(&FARM_WALL_OPTIONS, rng),
        BuildingCategory::Historic => pick_with_rare_filter(&HISTORIC_WALL_OPTIONS, rng),
        BuildingCategory::Garage => pick_with_rare_filter(&GARAGE_WALL_OPTIONS, rng),
        BuildingCategory::Shed => SHED_WALL_OPTIONS[rng.random_range(0..SHED_WALL_OPTIONS.len())],
        BuildingCategory::Tower => {
            const TOWER_WALL_OPTIONS: [Block; 8] = [
                STONE_BRICKS,
                COBBLESTONE,
                CRACKED_STONE_BRICKS,
                BRICK,
                POLISHED_ANDESITE,
                ANDESITE,
                DEEPSLATE_BRICKS,
                SMOOTH_STONE,
            ];
            TOWER_WALL_OPTIONS[rng.random_range(0..TOWER_WALL_OPTIONS.len())]
        }
        BuildingCategory::Greenhouse => {
            GREENHOUSE_WALL_OPTIONS[rng.random_range(0..GREENHOUSE_WALL_OPTIONS.len())]
        }
        BuildingCategory::TallBuilding => {
            // Tall buildings use commercial palette (glass, concrete, stone)
            COMMERCIAL_WALL_OPTIONS[rng.random_range(0..COMMERCIAL_WALL_OPTIONS.len())]
        }
        BuildingCategory::ModernSkyscraper => {
            // Modern skyscrapers use clean concrete/stone wall materials
            const MODERN_SKYSCRAPER_WALL_OPTIONS: [Block; 7] = [
                GRAY_CONCRETE,
                LIGHT_GRAY_CONCRETE,
                WHITE_CONCRETE,
                POLISHED_ANDESITE,
                SMOOTH_STONE,
                QUARTZ_BLOCK,
                SMOOTH_SANDSTONE,
            ];
            MODERN_SKYSCRAPER_WALL_OPTIONS
                [rng.random_range(0..MODERN_SKYSCRAPER_WALL_OPTIONS.len())]
        }
        BuildingCategory::ContemporarySkyscraper | BuildingCategory::GridSkyscraper => {
            // Light modern concrete/stone frame. Sandstone belongs here for the
            // same reason it belongs in the masonry and historic palettes: a
            // buff stone frame around glass is as common as a pale concrete
            // one, and without it every untagged tower comes out grey.
            const CONTEMPORARY: [Block; 7] = [
                LIGHT_GRAY_CONCRETE,
                WHITE_CONCRETE,
                GRAY_CONCRETE,
                QUARTZ_BLOCK,
                SMOOTH_STONE,
                SMOOTH_SANDSTONE,
                SANDSTONE,
            ];
            CONTEMPORARY[rng.random_range(0..CONTEMPORARY.len())]
        }
        BuildingCategory::MasonrySkyscraper => {
            // One warm (buff sandstone) or grey (limestone/granite) palette per building.
            if rng.random_bool(0.5) {
                const WARM: [Block; 3] = [SMOOTH_SANDSTONE, SANDSTONE, END_STONE_BRICKS];
                WARM[rng.random_range(0..WARM.len())]
            } else {
                const GREY: [Block; 4] = [
                    STONE_BRICKS,
                    SMOOTH_STONE,
                    POLISHED_ANDESITE,
                    POLISHED_DIORITE,
                ];
                GREY[rng.random_range(0..GREY.len())]
            }
        }
        BuildingCategory::GlassySkyscraper | BuildingCategory::GlassCornerSkyscraper => {
            // Glass-facade skyscrapers use stained glass as wall material
            const GLASSY_WALL_OPTIONS: [Block; 4] = [
                GRAY_STAINED_GLASS,
                CYAN_STAINED_GLASS,
                BLUE_STAINED_GLASS,
                LIGHT_BLUE_STAINED_GLASS,
            ];
            GLASSY_WALL_OPTIONS[rng.random_range(0..GLASSY_WALL_OPTIONS.len())]
        }
        BuildingCategory::Default => get_fallback_building_block(rng),
    }
}

/// Gross block height of one upper floor: 3 for residential-scale types
/// (~3 m storeys), 4 for commercial/institutional. Tags only, because the
/// category is resolved after the height and cannot be used here.
fn floor_cycle_for(building_type: &str, tags: &HashMap<String, String>) -> i32 {
    const RESIDENTIAL_SCALE: &[&str] = &[
        "house",
        "detached",
        "semidetached_house",
        "terrace",
        "bungalow",
        "villa",
        "cabin",
        "residential",
        "apartments",
        "dormitory",
        "farm",
        "hut",
        "shed",
        "static_caravan",
    ];
    if tags.contains_key("building:part") {
        // One cycle for all parts keeps stacked volumes flush at the seams.
        return 4;
    }
    if RESIDENTIAL_SCALE.contains(&building_type) || building_type == "yes" {
        3
    } else {
        4
    }
}

/// Inferred storey count or explicit hall height for buildings without any
/// height data in OSM. Halls are single tall volumes (industrial, churches,
/// garages) whose height is not a storey multiple.
enum InferredHeight {
    Levels(f64),
    HallBlocks(i32),
}

/// Deterministic weighted pick from (value, weight) pairs.
fn pick_weighted_value(rng: &mut impl Rng, options: &[(i32, u32)]) -> i32 {
    let total: u32 = options.iter().map(|&(_, w)| w).sum();
    let mut roll = rng.random_range(0..total);
    for &(value, weight) in options {
        if roll < weight {
            return value;
        }
        roll -= weight;
    }
    options[options.len() - 1].0
}

/// Storey inference for buildings without any OSM height data, following
/// real-world typology per type and footprint. Seeded on the group seed so
/// parts of one building agree (#1197, #935, #1220).
fn infer_building_height(
    building_type: &str,
    tags: &HashMap<String, String>,
    footprint_area: usize,
    scale_factor: f64,
    group_seed: u64,
) -> InferredHeight {
    let mut rng = element_rng(group_seed ^ 0x48E1_6F00_1EA5_0001);

    // Thresholds are m2. Parts are pinned to the middle band so siblings of
    // one group draw from the same table regardless of their own footprint.
    let area_m2 = if tags.contains_key("building:part") {
        400
    } else if scale_factor > 0.0 {
        (footprint_area as f64 / (scale_factor * scale_factor)) as usize
    } else {
        footprint_area
    };

    if tags.get("man_made").map(String::as_str) == Some("tower") {
        let blocks = pick_weighted_value(&mut rng, &[(12, 40), (16, 35), (20, 25)]);
        return InferredHeight::HallBlocks(blocks);
    }

    let (is_hall, table): (bool, &[(i32, u32)]) = match building_type {
        "bungalow" | "static_caravan" => (false, &[(1, 100)]),
        "house" | "detached" | "villa" | "farm" => (false, &[(1, 25), (2, 55), (3, 20)]),
        "semidetached_house" => (false, &[(2, 70), (3, 30)]),
        "terrace" => (false, &[(2, 50), (3, 40), (4, 10)]),
        "apartments" | "residential" | "dormitory" => {
            (false, &[(3, 30), (4, 30), (5, 25), (6, 15)])
        }
        "hotel" => (false, &[(3, 25), (4, 30), (5, 25), (6, 10), (8, 10)]),
        "office" | "commercial" => match area_m2 {
            0..=299 => (false, &[(2, 40), (3, 60)]),
            300..=999 => (false, &[(3, 40), (4, 35), (5, 25)]),
            _ => (false, &[(4, 40), (5, 30), (6, 20), (8, 10)]),
        },
        "retail" | "shop" | "supermarket" => (false, &[(1, 60), (2, 40)]),
        "kiosk" => (false, &[(1, 100)]),
        "parking" => (false, &[(2, 30), (3, 40), (4, 20), (5, 10)]),
        "school" | "kindergarten" | "college" | "university" => {
            (false, &[(2, 50), (3, 40), (4, 10)])
        }
        "hospital" => (false, &[(4, 40), (5, 30), (6, 20), (7, 10)]),
        "cathedral" => (true, &[(18, 50), (21, 30), (24, 20)]),
        "church" | "chapel" | "mosque" | "synagogue" | "temple" | "religious" => {
            (true, &[(10, 50), (12, 30), (14, 20)])
        }
        "industrial" | "warehouse" | "hangar" | "barn" | "stable" => {
            (true, &[(5, 20), (7, 50), (9, 30)])
        }
        "garage" | "garages" | "carport" | "shed" | "hut" => (true, &[(3, 100)]),
        "cabin" => (false, &[(1, 80), (2, 20)]),
        // building=yes and unrecognised types: infer from footprint size.
        _ => match area_m2 {
            // Tiny: a utility box or a small one-storey house.
            0..=39 => {
                if rng.random_bool(0.5) {
                    (true, &[(3, 100)])
                } else {
                    (false, &[(1, 100)])
                }
            }
            40..=149 => (false, &[(1, 15), (2, 60), (3, 25)]),
            150..=599 => (false, &[(2, 40), (3, 40), (4, 20)]),
            // Large generic footprint: often a hall, else a mid-rise block.
            _ => {
                let roll = rng.random_range(0u32..100);
                if roll < 40 {
                    (true, &[(7, 100)])
                } else if roll < 75 {
                    (false, &[(3, 100)])
                } else {
                    (false, &[(4, 100)])
                }
            }
        },
    };

    let value = pick_weighted_value(&mut rng, table);
    if is_hall {
        InferredHeight::HallBlocks(value)
    } else {
        InferredHeight::Levels(value as f64)
    }
}

/// Extra rows on top of `levels * cycle`: one taller ground floor row plus the
/// floor slab row (the "+2" in the wall grammar).
const GROUND_FLOOR_BONUS: i32 = 2;

/// Tallest `height` tag taken at face value. The tallest building is about
/// 830 m; values beyond this are usually an elevation mapped into `height`.
const MAX_PLAUSIBLE_HEIGHT_M: f64 = 1000.0;

/// Parses a `height` tag in meters, dropping values no building can have.
fn parse_building_height_tag(tags: &HashMap<String, String>) -> Option<f64> {
    let height = tags
        .get("height")?
        .trim_end_matches('m')
        .trim()
        .parse::<f64>()
        .ok()?;
    (height.is_finite() && height <= MAX_PLAUSIBLE_HEIGHT_M).then_some(height)
}

/// Determines building height from OSM tags, falling back to per-type
/// inference when the element carries no height data at all.
#[allow(clippy::too_many_arguments)]
fn calculate_building_height(
    element: &ProcessedWay,
    building_type: &str,
    min_level: i32,
    scale_factor: f64,
    relation_levels: Option<i32>,
    floor_cycle: i32,
    footprint_area: usize,
    group_seed: u64,
) -> (i32, bool) {
    let mut building_height = ((10.0 * scale_factor) as i32).max(3);
    let mut is_tall_building = false;
    // Whether any explicit height source (tag or relation) applied.
    let mut has_source = false;

    // From building:levels tag (may be fractional, e.g. "2.5")
    if let Some(levels_str) = element.tags.get("building:levels") {
        if let Ok(levels) = levels_str.trim().parse::<f64>() {
            let lev = levels - min_level as f64;
            if lev >= 1.0 {
                // Elevated elements get the +2 in their min_level offset instead,
                // keeping the total top at levels * cycle + 2
                let bonus = if min_level > 0 {
                    0.0
                } else {
                    GROUND_FLOOR_BONUS as f64
                };
                building_height =
                    (((lev * floor_cycle as f64 + bonus) * scale_factor) as i32).max(3);
                has_source = true;
                if levels > 7.0 {
                    is_tall_building = true;
                }
            }
        }
    }

    // From height tag (overrides levels).
    // When min_height is also present, the wall height is height − min_height
    // (OSM `height` is absolute from ground, not relative to min_height).
    let mut has_explicit_height = false;
    if let Some(height) = parse_building_height_tag(&element.tags) {
        has_explicit_height = true;
        has_source = true;
        let mut is_elevated_part = false;
        let effective = if let Some(mh_str) = element.tags.get("min_height") {
            let mh = mh_str
                .trim_end_matches('m')
                .trim()
                .parse::<f64>()
                .unwrap_or(0.0);
            is_elevated_part = mh > 0.0;
            (height - mh).max(1.0)
        } else if min_level > 0 {
            // `height` is absolute from ground; without a min_height tag
            // the level-based offset must still come off the wall span,
            // matching the min_level_offset the part is lifted by.
            is_elevated_part = true;
            let offset = (min_level * floor_cycle + GROUND_FLOOR_BONUS) as f64;
            (height - offset).max(1.0)
        } else {
            height
        };
        // Parts can be thin slabs (a plinth, a cornice), elevated or not:
        // they skip the 3-block interior minimum, under a roof as well
        let is_part = element.tags.contains_key("building:part");
        let wall_floor: f64 = if is_part { 1.0 } else { 3.0 };
        let effective = match (
            element.tags.get("roof:height"),
            element.tags.get("roof:shape"),
        ) {
            (Some(rh), Some(shape)) if shape != "flat" => {
                // height includes the roof, a tagged roof:height comes off the walls
                let rh = rh
                    .trim_end_matches('m')
                    .trim()
                    .parse::<f64>()
                    .unwrap_or(0.0);
                (effective - rh.max(0.0)).max(wall_floor.min(effective))
            }
            _ => effective,
        };
        building_height = (effective * scale_factor) as i32;
        building_height = building_height.max(if is_elevated_part || is_part { 1 } else { 3 });
        if height > 28.0 {
            is_tall_building = true;
        }
    }

    // Relation levels only estimate the height, an explicit height tag wins
    if !has_explicit_height {
        if let Some(levels) = relation_levels {
            let bonus = if min_level > 0 { 0 } else { GROUND_FLOOR_BONUS };
            building_height = multiply_scale(
                (levels - min_level).max(1) * floor_cycle + bonus,
                scale_factor,
            )
            .max(3);
            has_source = true;
            if levels > 7 {
                is_tall_building = true;
            }
        }
    }

    // No height data anywhere: infer a plausible height from the building type
    // and footprint instead of a flat citywide default.
    if !has_source {
        match infer_building_height(
            building_type,
            &element.tags,
            footprint_area,
            scale_factor,
            group_seed,
        ) {
            InferredHeight::Levels(levels) => {
                // subtract min_level like the tagged branches, parts top out flush
                let lev = (levels - min_level as f64).max(1.0);
                let bonus = if min_level > 0 {
                    0.0
                } else {
                    GROUND_FLOOR_BONUS as f64
                };
                building_height =
                    (((lev * floor_cycle as f64 + bonus) * scale_factor) as i32).max(3);
                if levels > 7.0 {
                    is_tall_building = true;
                }
            }
            InferredHeight::HallBlocks(blocks) => {
                building_height = multiply_scale(blocks, scale_factor).max(3);
            }
        }
    }

    (building_height, is_tall_building)
}

// ============================================================================
// Special Building Type Generators
// ============================================================================

/// Generates a shelter structure with fence posts and roof
fn generate_shelter(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    cached_floor_area: &[(i32, i32)],
    scale_factor: f64,
) {
    let roof_block = STONE_BRICK_SLAB;

    for node in &element.nodes {
        let x = node.x;
        let z = node.z;
        for shelter_y in 1..=multiply_scale(4, scale_factor) {
            editor.set_block(OAK_FENCE, x, shelter_y, z, None, None);
        }
        editor.set_block(roof_block, x, 5, z, None, None);
    }

    for &(x, z) in cached_floor_area {
        editor.set_block(roof_block, x, 5, z, None, None);
    }
}

/// Generates a bicycle parking shed structure
fn generate_bicycle_parking_shed(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    cached_floor_area: &[(i32, i32)],
) {
    let ground_block = OAK_PLANKS;
    let roof_block = STONE_BLOCK_SLAB;

    // Fill the floor area
    for &(x, z) in cached_floor_area {
        editor.set_block(ground_block, x, 0, z, None, None);
    }

    // Place fences and roof slabs at each corner node
    for node in &element.nodes {
        let x = node.x;
        let z = node.z;
        for dy in 1..=4 {
            editor.set_block(OAK_FENCE, x, dy, z, None, None);
        }
        editor.set_block(roof_block, x, 5, z, None, None);
    }

    // Flood fill the roof area
    for &(x, z) in cached_floor_area {
        editor.set_block(roof_block, x, 5, z, None, None);
    }
}

/// Generates a roof-only structure (covered walkway, etc.)
fn generate_roof_only_structure(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    cached_floor_area: &[(i32, i32)],
    args: &Args,
    group_seed: u64,
) {
    let scale_factor = args.scale;
    let abs_terrain_offset = if !args.terrain() {
        args.ground_level
    } else {
        0
    };
    let floor_cycle = floor_cycle_for(
        element
            .tags
            .get("building")
            .or_else(|| element.tags.get("building:part"))
            .map(|s| s.as_str())
            .unwrap_or("roof"),
        &element.tags,
    );

    // Determine where the roof structure starts vertically.
    // Priority: min_height → building:min_level → layer hint → default.
    let min_level_offset = if let Some(mh) = element.tags.get("min_height") {
        // min_height is in meters; convert via scale factor.
        mh.trim_end_matches('m')
            .trim()
            .parse::<f64>()
            .ok()
            .map(|h| (h * scale_factor) as i32)
            .unwrap_or(0)
    } else if let Some(ml) = element.tags.get("building:min_level") {
        ml.parse::<i32>()
            .ok()
            .map(|l| {
                if l > 0 {
                    multiply_scale(l * floor_cycle + GROUND_FLOOR_BONUS, scale_factor)
                } else {
                    0
                }
            })
            .unwrap_or(0)
    } else if let Some(layer) = element.tags.get("layer") {
        // For building:part=roof elements without explicit height tags, interpret
        // the layer tag as a coarse vertical-placement hint.  Each layer maps to
        // one floor cycle, producing reasonable stacking for multi-shell roof structures.
        layer
            .parse::<i32>()
            .ok()
            .filter(|&l| l > 0)
            .map(|l| multiply_scale(l * floor_cycle, scale_factor))
            .unwrap_or(0)
    } else {
        0
    };

    let start_y_offset = calculate_start_y_offset(editor, element, args, min_level_offset);

    // Determine roof thickness / height.
    let roof_thickness: i32 = if let Some(h) = parse_building_height_tag(&element.tags) {
        let total = (h * scale_factor) as i32;
        // If we already applied a min_height offset, the thickness is just
        // the difference.  Otherwise keep the parsed value.
        if element.tags.contains_key("min_height") {
            // Elevated roof parts can be thin plates, keep them thin
            (total - min_level_offset).max(if min_level_offset > 0 { 1 } else { 3 })
        } else {
            total.max(3)
        }
    } else if let Some(levels) = element.tags.get("building:levels") {
        levels
            .parse::<i32>()
            .ok()
            .map(|l| multiply_scale(l * floor_cycle + GROUND_FLOOR_BONUS, scale_factor).max(3))
            .unwrap_or(5)
    } else {
        5 // Default thickness for thin roof / canopy structures
    };

    // Pick a block for the roof surface.
    // Priority: roof:material > roof:colour > building/colour > default.
    let mut rng = element_rng(group_seed);
    let roof_block = element
        .tags
        .get("roof:material")
        .or_else(|| element.tags.get("material"))
        .and_then(|m| get_roof_block_for_material(m, &mut rng))
        .or_else(|| {
            element
                .tags
                .get("roof:colour")
                .or_else(|| element.tags.get("building:colour"))
                .or_else(|| element.tags.get("colour"))
                .and_then(|c| color_text_to_rgb_tuple(c))
                .map(|rgb| crate::block_palette::roof_block_for_color(rgb, &mut rng))
        })
        .unwrap_or(STONE_BRICK_SLAB);

    // Determine the roof shape from tags.
    let roof_type = element
        .tags
        .get("roof:shape")
        .map(|s| parse_roof_type(s))
        .unwrap_or(RoofType::Flat);

    match roof_type {
        RoofType::Dome
        | RoofType::Hipped
        | RoofType::Pyramidal
        | RoofType::Cone
        | RoofType::Onion
        | RoofType::Round => {
            if !cached_floor_area.is_empty() {
                let (min_x, max_x, min_z, max_z) = cached_floor_area.iter().fold(
                    (i32::MAX, i32::MIN, i32::MAX, i32::MIN),
                    |(min_x, max_x, min_z, max_z), &(x, z)| {
                        (min_x.min(x), max_x.max(x), min_z.min(z), max_z.max(z))
                    },
                );
                // shaped canopies spring from the support height like the flat arm
                let springing = start_y_offset + roof_thickness;
                let config = RoofConfig {
                    min_x,
                    max_x,
                    min_z,
                    max_z,
                    center_x: (min_x + max_x) >> 1,
                    center_z: (min_z + max_z) >> 1,
                    base_height: springing,
                    building_height: roof_thickness.max(3),
                    abs_terrain_offset,
                    roof_block,
                    add_dormers: false,
                    element_id_for_decor: element.id,
                    peak_cap: None,
                };
                for node in &element.nodes {
                    let pillar_base = if args.terrain() {
                        editor.get_ground_level(node.x, node.z)
                    } else {
                        0
                    };
                    for y in (pillar_base + 1)..springing {
                        editor.set_block_absolute(
                            COBBLESTONE_WALL,
                            node.x,
                            y + abs_terrain_offset,
                            node.z,
                            None,
                            None,
                        );
                    }
                }
                let nodes = &element.nodes;
                match roof_type {
                    RoofType::Cone => generate_cone_roof(editor, cached_floor_area, &config, nodes),
                    RoofType::Onion => generate_onion_roof(editor, cached_floor_area, &config),
                    RoofType::Hipped => generate_hipped_roof(editor, cached_floor_area, &config),
                    RoofType::Pyramidal => {
                        generate_pyramidal_roof(editor, cached_floor_area, &config, nodes)
                    }
                    // A canopy mapped round is a barrel vault like any other.
                    RoofType::Round => {
                        let ridge = ridge_frame(
                            nodes,
                            config.width(),
                            config.length(),
                            element.tags.get("roof:orientation").map(|s| s.as_str()),
                            element.tags.get("roof:direction").map(|s| s.as_str()),
                            None,
                        );
                        generate_gabled_roof(
                            editor,
                            cached_floor_area,
                            &config,
                            GableProfile::Round,
                            &ridge,
                        );
                    }
                    _ => generate_dome_roof(editor, cached_floor_area, &config, nodes),
                }
            }
        }
        _ => {
            // Flat / unsupported shape: pillars at outline nodes + slab fill.
            let slab_y = start_y_offset + roof_thickness;

            // Outline pillars and edge slabs.
            let mut previous_node: Option<(i32, i32)> = None;
            for node in &element.nodes {
                let x = node.x;
                let z = node.z;

                if let Some(prev) = previous_node {
                    let pts = bresenham_line(prev.0, slab_y, prev.1, x, slab_y, z);
                    for (bx, _, bz) in pts {
                        editor.set_block_absolute(
                            roof_block,
                            bx,
                            slab_y + abs_terrain_offset,
                            bz,
                            None,
                            None,
                        );
                    }
                }

                // Determine the pillar base in the same coordinate system as
                // slab_y.  When terrain is enabled, both values are absolute
                // world coordinates.  When terrain is disabled, both are
                // relative to ground (abs_terrain_offset is added separately).
                let pillar_base = if args.terrain() {
                    editor.get_ground_level(x, z)
                } else {
                    0
                };
                for y in (pillar_base + 1)..slab_y {
                    editor.set_block_absolute(
                        COBBLESTONE_WALL,
                        x,
                        y + abs_terrain_offset,
                        z,
                        None,
                        None,
                    );
                }

                previous_node = Some((x, z));
            }

            // Slab fill across the floor area.
            for &(x, z) in cached_floor_area {
                editor.set_block_absolute(
                    roof_block,
                    x,
                    slab_y + abs_terrain_offset,
                    z,
                    None,
                    None,
                );
            }
        }
    }
}

// ============================================================================
// Building Component Generators
// ============================================================================

/// Footprints this small are pillars: no windows, no doors.
const THIN_RING_MAX_CELLS: usize = 4;

/// Cells on a closed ring's edges, for footprints the flood fill leaves
/// empty because no lattice cell lies strictly inside them.
fn thin_ring_cells(nodes: &[ProcessedNode]) -> Vec<(i32, i32)> {
    let closed = nodes.len() >= 4
        && (nodes[0].x, nodes[0].z) == (nodes[nodes.len() - 1].x, nodes[nodes.len() - 1].z);
    if !closed {
        return Vec::new();
    }
    let mut cells: Vec<(i32, i32)> = nodes
        .windows(2)
        .flat_map(|pair| {
            bresenham_line(pair[0].x, 0, pair[0].z, pair[1].x, 0, pair[1].z)
                .into_iter()
                .map(|(x, _, z)| (x, z))
        })
        .collect();
    cells.sort_unstable();
    cells.dedup();
    cells
}

/// True when the outline carries a mapped entrance/door node.
pub(crate) fn outline_has_mapped_entrance(element: &ProcessedWay) -> bool {
    element
        .nodes
        .iter()
        .any(|n| n.tags.contains_key("entrance") || n.tags.contains_key("door"))
}

/// Wood species for an entrance door, matched to category and wall material.
#[derive(Copy, Clone, PartialEq, Eq)]
enum DoorStyle {
    Oak,
    Spruce,
    DarkOak,
    Birch,
}

impl DoorStyle {
    fn base_block(self) -> Block {
        match self {
            DoorStyle::Oak => OAK_DOOR,
            DoorStyle::Spruce => SPRUCE_DOOR_LOWER,
            DoorStyle::DarkOak => DARK_OAK_DOOR_LOWER,
            DoorStyle::Birch => BIRCH_DOOR,
        }
    }

    /// Matching trapdoor species for the entrance canopy.
    fn trapdoor_block(self) -> Block {
        match self {
            DoorStyle::Oak => OAK_TRAPDOOR,
            DoorStyle::Spruce => SPRUCE_TRAPDOOR,
            DoorStyle::DarkOak => DARK_OAK_TRAPDOOR,
            DoorStyle::Birch => BIRCH_TRAPDOOR,
        }
    }
}

/// A planned entrance: one or two door leaves plus their dressing.
struct EntrancePlan {
    x: i32,
    z: i32,
    normal: (i32, i32),
    tangent: (i32, i32),
    double: bool,
    style: DoorStyle,
    canopy: bool,
    lantern: bool,
}

fn door_style_for(category: BuildingCategory, wall_block: Block, group_seed: u64) -> DoorStyle {
    match category {
        BuildingCategory::Industrial
        | BuildingCategory::Warehouse
        | BuildingCategory::Commercial
        | BuildingCategory::Office
        | BuildingCategory::Hotel
        | BuildingCategory::Historic
        | BuildingCategory::Religious => DoorStyle::DarkOak,
        _ => match wall_block {
            OAK_PLANKS | OAK_LOG => DoorStyle::Spruce,
            SPRUCE_PLANKS | SPRUCE_LOG | DARK_OAK_PLANKS => DoorStyle::Oak,
            QUARTZ_BLOCK | QUARTZ_BRICKS | WHITE_CONCRETE | WHITE_TERRACOTTA => DoorStyle::Birch,
            _ => {
                if element_rng(group_seed ^ 0xD00E_57E9_0000_0012).random_bool(0.50) {
                    DoorStyle::Oak
                } else {
                    DoorStyle::DarkOak
                }
            }
        },
    }
}

/// Plans a synthetic street-facing entrance for buildings whose outline has no
/// mapped entrance node. Every ordinary ground-level building gets one door.
fn plan_synthetic_entrance(
    element: &ProcessedWay,
    config: &BuildingConfig,
    facade: &FacadePlan,
    building_passages: &CoordinateBitmap,
    group_seed: u64,
) -> Option<EntrancePlan> {
    if !config.is_ground_level
        || config.has_garage_door
        || config.has_single_door
        || matches!(
            config.condition,
            BuildingCondition::Construction | BuildingCondition::Ruined
        )
        || matches!(
            config.category,
            BuildingCategory::Greenhouse | BuildingCategory::Shed | BuildingCategory::Garage
        )
        || facade.segments.is_empty()
    {
        return None;
    }

    // Corner buildings of public categories put the door right at the corner.
    let corner_pick = facade.corner.as_ref().filter(|_| {
        matches!(
            config.category,
            BuildingCategory::Commercial | BuildingCategory::Hotel | BuildingCategory::Office
        )
    });

    let seg_index = if let Some(corner) = corner_pick {
        // The longer of the two corner legs hosts the door.
        let len = |i: usize| facade.segments[i].as_ref().map(|s| s.len).unwrap_or(0);
        if len(corner.seg_a) >= len(corner.seg_b) {
            corner.seg_a
        } else {
            corner.seg_b
        }
    } else if let Some(front) = facade.front_segment {
        front
    } else {
        // Rural fallback: the longest non-party segment still gets a door.
        facade
            .segments
            .iter()
            .enumerate()
            .filter_map(|(i, s)| s.as_ref().map(|s| (i, s)))
            .filter(|(_, s)| s.class != FacadeClass::Party)
            .max_by_key(|(_, s)| s.len)
            .map(|(i, _)| i)?
    };

    let seg = facade.segments.get(seg_index)?.as_ref()?;
    if seg.len < 4 {
        return None;
    }
    let (x1, z1) = {
        let n = element.nodes.get(seg_index)?;
        (n.x, n.z)
    };
    let (x2, z2) = {
        let n = element.nodes.get(seg_index + 1)?;
        (n.x, n.z)
    };
    let points: Vec<(i32, i32)> = bresenham_line(x1, 0, z1, x2, 0, z2)
        .into_iter()
        .map(|(x, _, z)| (x, z))
        .collect();
    if points.len() < 5 {
        return None;
    }

    let mut pos_rng = element_rng(group_seed ^ 0xD00E_57E9_0000_0011);
    let target = if let Some(corner) = corner_pick {
        // 2-3 columns in from the corner vertex end of the segment.
        let from_corner = 2 + pos_rng.random_range(0..2u32) as usize;
        if corner.seg_a == seg_index {
            points.len().saturating_sub(1 + from_corner)
        } else {
            from_corner
        }
    } else {
        let jitter: f64 = pos_rng.random_range(-0.15..0.15);
        ((points.len() as f64) * (0.5 + jitter)) as usize
    };
    // Dodge passages and party columns, keep 2 columns clear of the ends.
    let clamp = |i: isize| (i.clamp(2, points.len() as isize - 3)) as usize;
    let mut chosen: Option<(i32, i32)> = None;
    for attempt in [0isize, 1, -1, 2, -2] {
        let idx = clamp(target as isize + attempt);
        let (bx, bz) = points[idx];
        if building_passages.contains(bx, bz) || facade.is_party(bx, bz) {
            continue;
        }
        chosen = Some((bx, bz));
        break;
    }
    let (x, z) = chosen?;

    let double = matches!(
        config.category,
        BuildingCategory::Commercial
            | BuildingCategory::Office
            | BuildingCategory::Hotel
            | BuildingCategory::School
            | BuildingCategory::Hospital
    ) && seg.len >= 8
        && (seg.tangent.0 == 0 || seg.tangent.1 == 0);

    let style = door_style_for(config.category, config.wall_block, group_seed);
    let mut dress_rng = element_rng(group_seed ^ 0xD00E_57E9_0000_0013);
    let canopy = (double
        || matches!(
            config.category,
            BuildingCategory::Commercial | BuildingCategory::Hotel
        ))
        && dress_rng.random_bool(0.60);
    let lantern = !canopy
        && matches!(
            config.category,
            BuildingCategory::House | BuildingCategory::Residential | BuildingCategory::Historic
        )
        && dress_rng.random_bool(0.35);

    Some(EntrancePlan {
        x,
        z,
        normal: seg.normal,
        tangent: seg.tangent,
        double,
        style,
        canopy,
        lantern,
    })
}

/// A street door for each unit of a shared ground floor that has none, on the wall
/// in front of the unit nearest its anchor.
fn plan_unit_entrances(
    element: &ProcessedWay,
    config: &BuildingConfig,
    facade: &FacadePlan,
    building_passages: &CoordinateBitmap,
    group_seed: u64,
    anchors: &[(i32, i32)],
    existing: &[EntrancePlan],
) -> Vec<EntrancePlan> {
    if !config.is_ground_level
        || config.has_garage_door
        || config.has_single_door
        || matches!(
            config.condition,
            BuildingCondition::Construction | BuildingCondition::Ruined
        )
        || facade.segments.is_empty()
    {
        return Vec::new();
    }
    let unit_of = |x: i32, z: i32| -> usize {
        anchors
            .iter()
            .enumerate()
            .min_by_key(|(_, a)| {
                let (dx, dz) = ((x - a.0) as i64, (z - a.1) as i64);
                dx * dx + dz * dz
            })
            .map(|(k, _)| k)
            .unwrap_or(0)
    };
    let mut doors: Vec<(i32, i32)> = existing.iter().map(|p| (p.x, p.z)).collect();
    let mut served = vec![false; anchors.len()];
    for p in existing {
        served[unit_of(p.x - p.normal.0, p.z - p.normal.1)] = true;
    }
    let style = door_style_for(config.category, config.wall_block, group_seed);
    let mut out = Vec::new();
    for (unit, anchor) in anchors.iter().enumerate() {
        if served[unit] {
            continue;
        }
        // Street walls first, then the nearest column to the anchor.
        // (wall rank, distance squared), door column, segment.
        type Pick = ((u8, i64), (i32, i32), usize);
        let mut best: Option<Pick> = None;
        for (i, seg) in facade.segments.iter().enumerate() {
            let Some(seg) = seg else {
                continue;
            };
            let rank = match seg.class {
                FacadeClass::Street => 0,
                FacadeClass::Open => 1,
                FacadeClass::Rear => 2,
                FacadeClass::Party => continue,
            };
            let (Some(a), Some(b)) = (element.nodes.get(i), element.nodes.get(i + 1)) else {
                continue;
            };
            let points: Vec<(i32, i32)> = bresenham_line(a.x, 0, a.z, b.x, 0, b.z)
                .into_iter()
                .map(|(x, _, z)| (x, z))
                .collect();
            if seg.len < 4 || points.len() < 5 {
                continue;
            }
            for &(x, z) in &points[2..points.len() - 2] {
                if building_passages.contains(x, z) || facade.is_party(x, z) {
                    continue;
                }
                if unit_of(x - seg.normal.0, z - seg.normal.1) != unit {
                    continue;
                }
                if doors
                    .iter()
                    .any(|&(dx, dz)| (dx - x).abs() + (dz - z).abs() < 3)
                {
                    continue;
                }
                let d = ((x - anchor.0) as i64).pow(2) + ((z - anchor.1) as i64).pow(2);
                if best.as_ref().is_none_or(|(k, _, _)| (rank, d) < *k) {
                    best = Some(((rank, d), (x, z), i));
                }
            }
        }
        if let Some((_, (x, z), i)) = best {
            let Some(seg) = facade.segments[i].as_ref() else {
                continue;
            };
            doors.push((x, z));
            out.push(EntrancePlan {
                x,
                z,
                normal: seg.normal,
                tangent: seg.tangent,
                double: false,
                style,
                canopy: false,
                lantern: false,
            });
        }
    }
    out
}

/// Oriented, styled doors at mapped entrance/door nodes on the outline,
/// replacing the unoriented placeholder from the node-level doors pass.
fn plan_mapped_entrances(
    element: &ProcessedWay,
    config: &BuildingConfig,
    facade: &FacadePlan,
    group_seed: u64,
) -> Vec<EntrancePlan> {
    let mut plans = Vec::new();
    if !config.is_ground_level
        || matches!(
            config.condition,
            BuildingCondition::Construction | BuildingCondition::Ruined
        )
    {
        return plans;
    }
    let style = door_style_for(config.category, config.wall_block, group_seed);
    let n_nodes = element.nodes.len();
    let mut seen: FnvHashSet<(i32, i32)> = FnvHashSet::default();
    for (i, node) in element.nodes.iter().enumerate() {
        let entrance = node.tags.get("entrance");
        let door = node.tags.get("door");
        if entrance.is_none() && door.is_none() {
            continue;
        }
        // A closed way repeats its first node at the end; render one door.
        if !seen.insert((node.x, node.z)) {
            continue;
        }
        if entrance.map(String::as_str) == Some("no") || door.map(String::as_str) == Some("no") {
            continue;
        }
        // Only ground-level entrances; upper-level ones have no wall opening here.
        if let Some(level) = node.tags.get("level") {
            if level
                .trim()
                .parse::<f64>()
                .map(|l| l != 0.0)
                .unwrap_or(false)
            {
                continue;
            }
        }
        // Segment ending here (i-1) or starting here (i); pick the longer.
        let before = i
            .checked_sub(1)
            .and_then(|j| facade.segments.get(j))
            .and_then(|s| s.as_ref());
        let after = if i + 1 < n_nodes {
            facade.segments.get(i).and_then(|s| s.as_ref())
        } else {
            None
        };
        let seg = match (before, after) {
            (Some(a), Some(b)) => Some(if a.len >= b.len {
                (a, true)
            } else {
                (b, false)
            }),
            (Some(a), None) => Some((a, true)),
            (None, Some(b)) => Some((b, false)),
            (None, None) => None,
        };
        let Some((seg, ends_here)) = seg else {
            continue;
        };
        // The second leaf steps along the wall, so on a segment that ends at
        // this node it steps back into it, not past the corner.
        let tangent = if ends_here {
            (-seg.tangent.0, -seg.tangent.1)
        } else {
            seg.tangent
        };
        let double = entrance.map(String::as_str) == Some("main")
            && matches!(
                config.category,
                BuildingCategory::Commercial | BuildingCategory::Office | BuildingCategory::Hotel
            )
            && seg.len >= 8
            && (seg.tangent.0 == 0 || seg.tangent.1 == 0);
        plans.push(EntrancePlan {
            x: node.x,
            z: node.z,
            normal: seg.normal,
            tangent,
            double,
            style,
            canopy: false,
            lantern: false,
        });
    }
    plans
}

/// The longest doorstep run outside a door: three steps, one block of descent
/// each. A deeper drop gets no steps at all rather than a longer flight, which
/// in front of every downhill door would read as a ramp.
const DOORSTEP_MAX_STEPS: i32 = 3;

/// The cells and heights of the doorstep run outside a door, or `None` when the
/// run cannot land on the ground.
///
/// A building's floor is `calculate_start_y_offset`, the *highest* terrain level
/// under its outline, so on a slope the door on the downhill side sits well
/// above the ground in front of it. The run descends one block per cell and so
/// bridges at most `DOORSTEP_MAX_STEPS` of that; anything deeper used to get a
/// truncated flight whose last step stopped two or three blocks up in the air.
///
/// The terrain under each step decides, not one probe in front of the door:
/// what the run has to reach is the ground beneath the steps themselves, and on
/// a slope that is not the ground at the threshold.
fn plan_doorstep_steps(
    editor: &WorldEditor,
    door: (i32, i32),
    normal: (i32, i32),
    floor_y: i32,
) -> Option<Vec<((i32, i32), i32)>> {
    let (nx, nz) = normal;
    // No elevation data means no drop to bridge.
    let out_ground = editor.terrain_level(door.0 + nx, door.1 + nz)?;
    let drop = floor_y - out_ground;
    // Nothing to bridge below one, and past the reach the run cannot land.
    if !(1..=DOORSTEP_MAX_STEPS).contains(&drop) {
        return None;
    }
    let mut steps = Vec::with_capacity(drop as usize);
    for step in 1..=drop {
        let cell = (door.0 + nx * step, door.1 + nz * step);
        let step_y = floor_y - step + 1;
        // The first cell already carries the threshold block, so its step is
        // never written and only the terrain past it can leave one hanging.
        if step > 1 && editor.terrain_level(cell.0, cell.1)? < step_y - 1 {
            return None;
        }
        steps.push((cell, step_y));
    }
    Some(steps)
}

/// Places a planned entrance: door leaves (overwriting the wall), threshold,
/// doorstep stairs down to terrain, and optional canopy/lantern dressing.
fn render_entrance(
    editor: &mut WorldEditor,
    plan: &EntrancePlan,
    config: &BuildingConfig,
    args: &Args,
) {
    let (nx, nz) = plan.normal;
    let facing = facing_for_normal(nx, nz);
    let base = plan.style.base_block();
    let door_positions: Vec<((i32, i32), &str)> = if plan.double {
        vec![
            ((plan.x, plan.z), "left"),
            ((plan.x + plan.tangent.0, plan.z + plan.tangent.1), "right"),
        ]
    } else {
        vec![((plan.x, plan.z), "left")]
    };

    for ((dx, dz), hinge) in &door_positions {
        let lower = cached_prop_block(
            base,
            &[("half", "lower"), ("facing", facing), ("hinge", hinge)],
        );
        let upper = cached_prop_block(
            base,
            &[("half", "upper"), ("facing", facing), ("hinge", hinge)],
        );
        editor.set_block_with_properties_absolute(
            lower,
            *dx,
            config.start_y_offset + 1 + config.abs_terrain_offset,
            *dz,
            None,
            Some(&[]),
        );
        editor.set_block_with_properties_absolute(
            upper,
            *dx,
            config.start_y_offset + 2 + config.abs_terrain_offset,
            *dz,
            None,
            Some(&[]),
        );

        // Threshold block just outside the door (first writer wins the cell,
        // and buildings run before roads).
        let threshold = config.base_course_block.unwrap_or(STONE_BRICKS);
        editor.set_block_absolute(
            threshold,
            dx + nx,
            config.start_y_offset + config.abs_terrain_offset,
            dz + nz,
            None,
            None,
        );

        // Doorstep stairs bridging a terrain drop in front of the door, but
        // only where the run lands on the ground: see `plan_doorstep_steps`.
        if args.terrain() && config.is_ground_level {
            if let Some(steps) =
                plan_doorstep_steps(editor, (*dx, *dz), (nx, nz), config.start_y_offset)
            {
                let stair_base = get_stair_block_for_material(threshold);
                // Ascend toward the door: high side of each step faces inward.
                let stair_facing = match facing_for_normal(-nx, -nz) {
                    "north" => StairFacing::North,
                    "south" => StairFacing::South,
                    "east" => StairFacing::East,
                    _ => StairFacing::West,
                };
                for ((sx, sz), step_y) in steps {
                    let stair = create_stair_with_properties(
                        stair_base,
                        stair_facing,
                        StairShape::Straight,
                    );
                    editor.set_block_with_properties_absolute(
                        stair,
                        sx,
                        step_y + config.abs_terrain_offset,
                        sz,
                        Some(&[AIR]),
                        None,
                    );
                }
            }
        }
    }

    // Canopy: closed top-half trapdoors one block out, spanning the doorway.
    if plan.canopy {
        let span: &[i32] = if plan.double {
            &[-1, 0, 1, 2]
        } else {
            &[-1, 0, 1]
        };
        for t in span {
            let cx = plan.x + nx + plan.tangent.0 * t;
            let cz = plan.z + nz + plan.tangent.1 * t;
            editor.set_block_with_properties_absolute(
                make_closed_trapdoor(plan.style.trapdoor_block(), facing, "top"),
                cx,
                config.start_y_offset + 3 + config.abs_terrain_offset,
                cz,
                Some(&[AIR]),
                None,
            );
        }
    }
    // Lantern: hung from a small bracket over the door, never standing on air.
    if plan.lantern {
        let (lx, lz) = (plan.x + nx, plan.z + nz);
        editor.set_block_with_properties_absolute(
            make_closed_trapdoor(plan.style.trapdoor_block(), facing, "top"),
            lx,
            config.start_y_offset + 4 + config.abs_terrain_offset,
            lz,
            Some(&[AIR]),
            None,
        );
        editor.set_block_with_properties_absolute(
            make_prop_block(LANTERN, &[("hanging", "true")]),
            lx,
            config.start_y_offset + 3 + config.abs_terrain_offset,
            lz,
            Some(&[AIR]),
            None,
        );
    }
}

/// Builds a wall ring (outer shell or inner courtyard) for a set of nodes.
#[allow(clippy::too_many_arguments)]
fn build_wall_ring(
    editor: &mut WorldEditor,
    nodes: &[ProcessedNode],
    config: &BuildingConfig,
    args: &Args,
    has_sloped_roof: bool,
    building_passages: &CoordinateBitmap,
    facade: &FacadePlan,
) -> (Vec<(i32, i32)>, i32, Vec<WallSegmentKind>) {
    let mut previous_node: Option<(i32, i32)> = None;
    // Count of generated wall coordinates; the caller only needs to know the ring is non-empty.
    let mut corner_count: i32 = 0;
    let mut current_building: Vec<(i32, i32)> = Vec::new();
    let mut segments: Vec<WallSegmentKind> = Vec::new();

    let passage_height = BUILDING_PASSAGE_HEIGHT.min(config.building_height);

    for (node_idx, node) in nodes.iter().enumerate() {
        let x = node.x;
        let z = node.z;

        if let Some(prev) = previous_node {
            let seg_axis_x = segment_axis_x(prev.0, prev.1, x, z);
            let start_axis_x = segment_start_axis_x(nodes, node_idx, seg_axis_x);
            let bresenham_points = bresenham_line(
                prev.0,
                config.start_y_offset,
                prev.1,
                x,
                config.start_y_offset,
                z,
            );

            let mut kind = WallSegmentKind::default();
            let seg_last = bresenham_points.len().saturating_sub(1);
            for (pt_idx, (bx, _, bz)) in bresenham_points.into_iter().enumerate() {
                // Passages only apply to ground-level buildings; elevated
                // building:part elements (min_level > 0) receive an empty bitmap
                // via effective_passages, so this is always false for them.
                let is_passage = building_passages.contains(bx, bz);

                // Foundation pillars below terrain. Skipped in passage zones.
                if args.terrain() && config.is_ground_level && !is_passage {
                    let local_ground_level =
                        editor.terrain_level(bx, bz).unwrap_or(args.ground_level);

                    for y in local_ground_level..config.start_y_offset + 1 {
                        let block = apply_block_variety(config.wall_block, bx, y, bz, config);
                        editor.set_block_absolute(
                            block,
                            bx,
                            y + config.abs_terrain_offset,
                            bz,
                            None,
                            None,
                        );
                    }
                }

                // Generate wall blocks with windows.
                // In passage zones, skip below passage ceiling so the road
                // can pass through; place a floor-block lintel at the top of
                // the opening and continue the wall above.
                let wall_start = if is_passage {
                    config.start_y_offset + passage_height + 1
                } else {
                    config.start_y_offset + 1
                };

                // Construction: per-column variable wall height for a half-built look.
                let column_top = if config.condition == BuildingCondition::Construction {
                    let mut col_rng = coord_rng(bx, bz, config.element_id);
                    let factor: f64 = 0.30 + col_rng.random::<f64>() * 0.55;
                    let local = config.start_y_offset
                        + ((config.building_height as f64) * factor).round() as i32;
                    local
                        .max(config.start_y_offset + 1)
                        .min(config.start_y_offset + config.building_height - 1)
                } else {
                    config.start_y_offset + config.building_height
                };

                let col = ColumnFacade {
                    wall_u: wall_ordinate(pt_idx, start_axis_x, seg_axis_x, bx, bz),
                    party: facade.is_party(bx, bz),
                    street: !facade.has_any_street || facade.is_street(bx, bz),
                    // Only for a run long enough to have a middle: on a two or
                    // three block wall every column is an end, and calling them
                    // all corners would leave it with no windows at all.
                    corner: seg_last >= 4 && (pt_idx == 0 || pt_idx == seg_last),
                };
                // Resolved once per column rather than per block: it is a
                // lookup in the facade store, and the whole column shares it.
                let photo = config.is_photo_column(bx, bz);
                // The wall follows whichever source is going to cover it;
                // `photographed` stays Mapillary's own, because the facade
                // diagnostic below counts photographed segments.
                let flat = config.is_flat_column(bx, bz);
                kind.photographed |= photo;
                for h in wall_start..=column_top {
                    let block = determine_wall_block_at_position(bx, h, bz, config, col, flat);
                    kind.windowed |= !flat && (block == config.window_block || block == GLASS);
                    editor.set_block_absolute(
                        block,
                        bx,
                        h + config.abs_terrain_offset,
                        bz,
                        None,
                        None,
                    );
                }

                // Place passage ceiling lintel
                if is_passage && passage_height < config.building_height {
                    editor.set_block_absolute(
                        config.floor_block,
                        bx,
                        config.start_y_offset + passage_height + config.abs_terrain_offset,
                        bz,
                        None,
                        None,
                    );
                }

                // Add roof line only for flat roofs, sloped roofs will cover this area
                if !has_sloped_roof {
                    // An accent line over a photographed wall belongs to a
                    // building the photograph does not show, so the shell
                    // keeps its own colour up here too, and so does a wall
                    // the presets flatten for a picture of their own.
                    let roof_line_block = if config.use_accent_roof_line && !photo && !flat {
                        config.accent_block
                    } else {
                        config.wall_block
                    };
                    editor.set_block_absolute(
                        roof_line_block,
                        bx,
                        config.start_y_offset
                            + config.building_height
                            + config.abs_terrain_offset
                            + 1,
                        bz,
                        None,
                        None,
                    );
                }

                current_building.push((bx, bz));
                corner_count += 1;
            }
            segments.push(kind);
        }

        previous_node = Some((x, z));
    }

    // Photo panels are recorded once the wall exists, since how tall it was
    // built decides the panel. They are placed at the end of the run, once
    // every later block is in and the finished world can be checked.
    if crate::mapillary::facades::displays_enabled() {
        crate::mapillary::displays::collect(
            editor,
            config.element_id,
            config.start_y_offset,
            config.abs_terrain_offset,
            config.building_height,
        );
    }
    // The preset facades are not recorded here but in `generate_buildings`,
    // before this runs: their panels decide which columns are built as a plain
    // shell, and this function has already built them by now.

    (current_building, corner_count, segments)
}

/// The wall columns of `element`'s ring that a facade photograph covers, and
/// so are built as a plain shell for the texture to override. Empty unless
/// the export gives this building a block grid or a photo panel: below two
/// blocks per metre without panels it supplies floor band colours only, and
/// those already apply per column through `band_block_at`.
///
/// A column carrying a facade cell, plus its two neighbours along the same
/// ring segment. The dilation is one block of rounding, not a coverage claim:
/// the export numbers its columns in metres along its own extent, so the
/// block that straddles the end of a texture falls just past the last column
/// and drops out. Without it a photographed wall could end in a single
/// procedural window standing alone against the corner. Taking the columns as
/// a set also settles the corner block two ring segments share: it is decided
/// the same way whichever segment is being drawn, so a photographed wall
/// meeting a normal one cannot leave a gap or a doubled block there.
fn photo_shell_columns(element: &ProcessedWay) -> Arc<FnvHashSet<(i32, i32)>> {
    let mut shell = FnvHashSet::default();
    if !crate::mapillary::facades::has_building(element.id)
        || (crate::mapillary::facades::colour_only()
            && !crate::mapillary::facades::displays_enabled())
    {
        return Arc::new(shell);
    }
    let mut previous: Option<(i32, i32)> = None;
    for node in &element.nodes {
        if let Some((px, pz)) = previous {
            let points = bresenham_line(px, 0, pz, node.x, 0, node.z);
            for (i, &(bx, _, bz)) in points.iter().enumerate() {
                if !crate::mapillary::facades::photo_column(bx, bz, element.id) {
                    continue;
                }
                for near in &points[i.saturating_sub(1)..(i + 2).min(points.len())] {
                    shell.insert((near.0, near.2));
                }
            }
        }
        previous = Some((node.x, node.z));
    }
    Arc::new(shell)
}

/// What one ring segment of a facade building turned out to be, for the
/// `ARNIS_FACADE_WALL_STATS` line: whether a photograph covers any of it, and
/// whether the procedural pass put a window on it. A segment can be neither
/// (a blank wall, a party wall, a windowless style) and, where a photographed
/// wall ends part way along a ring segment, both.
#[derive(Clone, Copy, Default)]
struct WallSegmentKind {
    photographed: bool,
    windowed: bool,
}

/// Prints how one facade building's ring split between the walls a photograph
/// covers and the walls a normal Arnis building was generated on, and audits
/// every corner where the two meet, so both can be counted over a whole area
/// without reading the world back. Off unless `ARNIS_FACADE_WALL_STATS` is
/// set, since it is one line per building.
///
/// Segments are what the export calls a wall, but a corner block belongs to
/// two of them, so `cols`, `shell_cols` and `window_cols` count the ring's
/// world columns instead, each exactly once, which is the honest denominator.
///
/// `seams` counts the ring vertices a photographed segment shares with one
/// that is not, which are the corners the texture stops short of: a corner it
/// reaches is shell, and a shell corner belongs to both its segments, so both
/// count as photographed and it is not a seam at all. `seam_gaps` counts the
/// seam columns the wall left a hole in and has to read zero. `seam_orphan`
/// counts the ones that touch a shell column without being one, which is the
/// first block past the shell's single block of rounding allowance rather
/// than a defect, so a few are expected on an area of any size.
fn report_wall_segments(
    editor: &WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    passages: &CoordinateBitmap,
    segments: &[WallSegmentKind],
) {
    static ON: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    if !*ON.get_or_init(|| std::env::var_os("ARNIS_FACADE_WALL_STATS").is_some()) {
        return;
    }
    if !crate::mapillary::facades::has_building(config.element_id) || segments.len() < 2 {
        return;
    }
    let photo_segs = segments.iter().filter(|s| s.photographed).count();
    let window_segs = segments.iter().filter(|s| s.windowed).count();

    // Does any block of this wall column read as a window? On a shell column
    // that is the photograph's own window cell, everywhere else the
    // procedural one.
    let has_window = |x: i32, z: i32| {
        ((config.start_y_offset + 1)..=(config.start_y_offset + config.building_height)).any(|h| {
            editor
                .get_block_absolute(x, h + config.abs_terrain_offset, z)
                .is_some_and(|b| b.id() == config.window_block.id() || b.id() == GLASS.id())
        })
    };

    let mut ring: FnvHashSet<(i32, i32)> = FnvHashSet::default();
    let mut previous: Option<(i32, i32)> = None;
    for node in &element.nodes {
        if let Some((px, pz)) = previous {
            for (bx, _, bz) in bresenham_line(px, 0, pz, node.x, 0, node.z) {
                ring.insert((bx, bz));
            }
        }
        previous = Some((node.x, node.z));
    }
    let shell_cols = ring
        .iter()
        .filter(|c| config.facade_shell.contains(c))
        .count();
    let window_cols = ring
        .iter()
        .filter(|c| !config.facade_shell.contains(*c) && has_window(c.0, c.1))
        .count();

    let (mut seams, mut seam_gaps, mut seam_orphan) = (0, 0, 0);
    // Closed rings only, so that the last segment really does meet the first.
    let ends = |n: Option<&ProcessedNode>| n.map(|n| (n.x, n.z));
    let closed = ends(element.nodes.first()) == ends(element.nodes.last());
    for (i, kind) in segments.iter().enumerate() {
        let next = (i + 1) % segments.len();
        if (next == 0 && !closed) || kind.photographed == segments[next].photographed {
            continue;
        }
        // Segment i runs nodes[i] to nodes[i + 1], so the two share nodes[i + 1],
        // which for the closing pair is the repeated first node.
        let node = &element.nodes[i + 1];
        if passages.contains(node.x, node.z) {
            continue;
        }
        seams += 1;
        if !config.facade_shell.contains(&(node.x, node.z))
            && [(1, 0), (-1, 0), (0, 1), (0, -1)]
                .iter()
                .any(|(dx, dz)| config.facade_shell.contains(&(node.x + dx, node.z + dz)))
        {
            seam_orphan += 1;
        }
        let gap = ((config.start_y_offset + 1)..=(config.start_y_offset + config.building_height))
            .any(|h| {
                editor
                    .get_block_absolute(node.x, h + config.abs_terrain_offset, node.z)
                    .is_none()
            });
        seam_gaps += i32::from(gap);
    }
    println!(
        "facade-walls id={} segments={} photo_segs={photo_segs} window_segs={window_segs} \
         cols={} shell_cols={shell_cols} window_cols={window_cols} \
         seams={seams} seam_gaps={seam_gaps} seam_orphan={seam_orphan}",
        config.element_id,
        segments.len(),
        ring.len(),
    );
}

/// Generates special doors for garages (double door) and sheds (single door)
fn generate_special_doors(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    wall_outline: &[(i32, i32)],
    building_passages: &CoordinateBitmap,
) {
    if wall_outline.is_empty() {
        return;
    }

    // Find the front-facing wall segment (longest or first significant segment)
    // We'll use the first wall segment from the element nodes
    let nodes = &element.nodes;
    if nodes.len() < 2 {
        return;
    }

    let mut rng = element_rng(element.id);
    let door_y = config.start_y_offset + config.abs_terrain_offset + 1;

    if config.has_garage_door {
        // Place double spruce door on front face
        // Find a suitable wall segment (first one with enough length)
        for i in 0..nodes.len().saturating_sub(1) {
            let (x1, z1) = (nodes[i].x, nodes[i].z);
            let (x2, z2) = (nodes[i + 1].x, nodes[i + 1].z);

            let dx = (x2 - x1).abs();
            let dz = (z2 - z1).abs();
            let segment_len = dx.max(dz);

            // Need at least 2 blocks for double door
            if segment_len >= 2 {
                // Place doors in the middle of this segment
                let mid_x = (x1 + x2) / 2;
                let mid_z = (z1 + z2) / 2;

                // Determine door offset based on wall orientation
                let (door1_x, door1_z, door2_x, door2_z) = if dx > dz {
                    // Wall runs along X axis
                    (mid_x, mid_z, mid_x + 1, mid_z)
                } else {
                    // Wall runs along Z axis
                    (mid_x, mid_z, mid_x, mid_z + 1)
                };

                // Skip placing doors inside a building passage, and on a
                // photographed wall, which carries the door the photograph
                // shows and not a procedural one.
                if building_passages.contains(door1_x, door1_z)
                    || building_passages.contains(door2_x, door2_z)
                    || config.is_photo_column(door1_x, door1_z)
                    || config.is_photo_column(door2_x, door2_z)
                {
                    continue;
                }

                // Place the double door (lower and upper parts)
                // Use empty blacklist to overwrite existing wall blocks
                editor.set_block_absolute(
                    SPRUCE_DOOR_LOWER,
                    door1_x,
                    door_y,
                    door1_z,
                    None,
                    Some(&[]),
                );
                editor.set_block_absolute(
                    SPRUCE_DOOR_UPPER,
                    door1_x,
                    door_y + 1,
                    door1_z,
                    None,
                    Some(&[]),
                );
                editor.set_block_absolute(
                    SPRUCE_DOOR_LOWER,
                    door2_x,
                    door_y,
                    door2_z,
                    None,
                    Some(&[]),
                );
                editor.set_block_absolute(
                    SPRUCE_DOOR_UPPER,
                    door2_x,
                    door_y + 1,
                    door2_z,
                    None,
                    Some(&[]),
                );

                break; // Only place one set of garage doors
            }
        }
    } else if config.has_single_door {
        // Place a single oak door somewhere on the wall
        // Pick a random position from the wall outline
        if !wall_outline.is_empty() {
            let door_idx = rng.random_range(0..wall_outline.len());
            let (door_x, door_z) = wall_outline[door_idx];

            // Skip placing a door inside a building passage or on a
            // photographed wall, which carries its own door.
            if !building_passages.contains(door_x, door_z)
                && !config.is_photo_column(door_x, door_z)
            {
                // Place single oak door (empty blacklist to overwrite wall blocks)
                editor.set_block_absolute(OAK_DOOR, door_x, door_y, door_z, None, Some(&[]));
                editor.set_block_absolute(
                    OAK_DOOR_UPPER,
                    door_x,
                    door_y + 1,
                    door_z,
                    None,
                    Some(&[]),
                );
            }
        }
    }
}

/// Determines which block to place at a specific wall position (wall, window, or accent)
#[inline]
fn determine_wall_block_at_position(
    bx: i32,
    h: i32,
    bz: i32,
    config: &BuildingConfig,
    col: ColumnFacade,
    flat: bool,
) -> Block {
    // A column with a photograph coming over it is a plain shell: the facade
    // cell or panel above it decides what shows, and a procedural window or
    // accent line underneath would come through wherever the picture has no
    // data. `flat` is `config.is_flat_column(bx, bz)`, hoisted out of the
    // height loop.
    let chosen = if flat {
        config.wall_block
    } else {
        determine_wall_block_at_position_pristine(h, config, col)
    };
    let chosen = apply_block_variety(chosen, bx, h, bz, config);
    apply_condition_variation(chosen, bx, h, bz, config)
}

/// Substitutes the wall block with a same-family alternative for variety.
fn apply_block_variety(chosen: Block, bx: i32, h: i32, bz: i32, config: &BuildingConfig) -> Block {
    // From two blocks per metre up a facade texture cell wins over every
    // procedural choice for this position.
    if let Some(block) = crate::mapillary::facades::block_at(
        bx,
        h,
        bz,
        config.start_y_offset,
        config.element_id,
        config.window_block,
    ) {
        return block;
    }
    // Only the plain wall material is varied or recoloured below. Windows,
    // accent lines, plinth courses and storefront glass come back from
    // `determine_wall_block_at_position_pristine` as other blocks and are
    // kept as they are; pilasters and the other wall depth features never
    // pass through here.
    if chosen != config.wall_block {
        return chosen;
    }
    // Below two blocks per metre the lab supplies colours only: a plain wall
    // block takes the colour of the lab's floor band at this height, flat,
    // and keeps its procedural block above the textured rows. Scaffolding on
    // a construction site is not a wall colour.
    if config.condition != BuildingCondition::Construction {
        if let Some(block) = crate::mapillary::facades::band_block_at(
            bx,
            h,
            bz,
            config.start_y_offset,
            config.element_id,
        ) {
            return block;
        }
    }
    let pool = substitute_pool_only(chosen);
    if pool.is_empty() {
        return chosen;
    }

    // Two-tone facade: 20% chance on >=3-floor buildings; background fabric
    // (minimal detail) keeps a single flat field.
    let floors_estimate = config.building_height / config.floor_cycle;
    if floors_estimate >= 3 && config.detail != DetailTier::Minimal {
        let mut tt_enable_rng = element_rng(config.element_id ^ 0x9F4A_5DB2_C0DE_C0DE);
        if tt_enable_rng.random_bool(0.20) {
            let ground_floor_top = config.ground_floor_top();
            if h > ground_floor_top {
                let mut tt_mode_rng = element_rng(config.element_id ^ 0xC1A2_5544_99B7_3F02);
                let secondary_mix = tt_mode_rng.random_bool(0.50);
                if secondary_mix {
                    let mut pos_rng = coord_rng(
                        bx,
                        bz,
                        config.element_id ^ 0x7E11_AABB_5DEF_3211 ^ ((h as u64) << 12),
                    );
                    return pool[pos_rng.random_range(0..pool.len())];
                } else {
                    let mut sec_rng = element_rng(config.element_id ^ 0x4A8C_99B0_CAFE_F00D);
                    return pool[sec_rng.random_range(0..pool.len())];
                }
            }
        }
    }

    // 10% stays single; the rest keeps a clean primary field with ~20% same-family texture.
    let mut variety_mode_rng = element_rng(config.element_id ^ 0xBABE_F1A1_2222_8888);
    if !variety_mode_rng.random_bool(0.90) {
        return chosen;
    }

    let mut pos_rng = coord_rng(
        bx,
        bz,
        config.element_id ^ 0x5050_3030_AAFF_BBCC ^ ((h as u64) << 12),
    );
    if pos_rng.random_range(0u32..100) < 20 {
        pool[pos_rng.random_range(0..pool.len())]
    } else {
        chosen
    }
}

/// Swaps wall blocks that genuinely don't work as a roof.
fn roof_friendly_block(block: Block) -> Block {
    match block {
        OAK_LOG => OAK_PLANKS,
        SPRUCE_LOG => SPRUCE_PLANKS,
        RED_CONCRETE => RED_TERRACOTTA,
        ORANGE_CONCRETE => ORANGE_TERRACOTTA,
        YELLOW_CONCRETE => YELLOW_TERRACOTTA,
        LIME_CONCRETE => GREEN_CONCRETE,
        BLUE_CONCRETE => BLUE_TERRACOTTA,
        _ => block,
    }
}

/// Categories whose roof aesthetic (pitched / domed / glass) doesn't fit a parapet.
#[inline]
fn short_flat_parapet_excluded(category: BuildingCategory) -> bool {
    matches!(
        category,
        BuildingCategory::House
            | BuildingCategory::Farm
            | BuildingCategory::Garage
            | BuildingCategory::Shed
            | BuildingCategory::Greenhouse
            | BuildingCategory::Religious
    )
}

/// 75% chance of a parapet on short flat-roof buildings.
fn short_flat_parapet_for(
    element_id: u64,
    roof_type: RoofType,
    building_height: i32,
    category: BuildingCategory,
    condition: BuildingCondition,
) -> bool {
    if roof_type != RoofType::Flat {
        return false;
    }
    if building_height > 8 {
        return false;
    }
    if short_flat_parapet_excluded(category) {
        return false;
    }
    if condition != BuildingCondition::Normal {
        return false;
    }
    let mut rng = element_rng(element_id ^ 0x534F_F154_4AAE_E0F0);
    rng.random_bool(0.75)
}

/// 10% chance of rooftop equipment on short flat-roof buildings.
fn short_flat_rooftop_bits_for(
    element_id: u64,
    roof_type: RoofType,
    building_height: i32,
    category: BuildingCategory,
    condition: BuildingCondition,
    detail: DetailTier,
) -> bool {
    if detail == DetailTier::Minimal {
        return false;
    }
    if roof_type != RoofType::Flat {
        return false;
    }
    if building_height > 8 {
        return false;
    }
    if short_flat_parapet_excluded(category) {
        return false;
    }
    if condition != BuildingCondition::Normal {
        return false;
    }
    let mut rng = element_rng(element_id ^ 0xBCB1_5EED_5704_77F0);
    rng.random_bool(0.10)
}

/// Same-family substitutes for the wall variety system; empty slice = no variety.
fn substitute_pool_only(block: Block) -> &'static [Block] {
    match block {
        // Mid-grey stone
        STONE_BRICKS => &[
            COBBLESTONE,
            CRACKED_STONE_BRICKS,
            ANDESITE,
            CHISELED_STONE_BRICKS,
        ],
        COBBLESTONE => &[STONE_BRICKS, ANDESITE, STONE],
        STONE => &[COBBLESTONE, STONE_BRICKS],
        ANDESITE => &[POLISHED_ANDESITE, COBBLESTONE, STONE_BRICKS],
        POLISHED_ANDESITE => &[ANDESITE, STONE_BRICKS],
        CHISELED_STONE_BRICKS => &[STONE_BRICKS, CRACKED_STONE_BRICKS],
        CRACKED_STONE_BRICKS => &[STONE_BRICKS, MOSSY_STONE_BRICKS, CHISELED_STONE_BRICKS],
        TUFF => &[STONE_BRICKS, MOSSY_STONE_BRICKS],
        MOSSY_STONE_BRICKS => &[MOSSY_COBBLESTONE, TUFF],
        MOSSY_COBBLESTONE => &[MOSSY_STONE_BRICKS, TUFF],

        // Warm reds
        BRICK => &[POLISHED_GRANITE, GRANITE, TERRACOTTA],
        POLISHED_GRANITE => &[BRICK, GRANITE],
        GRANITE => &[POLISHED_GRANITE, BRICK],
        TERRACOTTA => &[BRICK, POLISHED_GRANITE],

        // Deepslate
        DEEPSLATE_BRICKS => &[POLISHED_DEEPSLATE, COBBLED_DEEPSLATE],
        POLISHED_DEEPSLATE => &[DEEPSLATE_BRICKS, COBBLED_DEEPSLATE],
        COBBLED_DEEPSLATE => &[DEEPSLATE_BRICKS, POLISHED_DEEPSLATE, DEEPSLATE],
        DEEPSLATE => &[COBBLED_DEEPSLATE, DEEPSLATE_BRICKS],

        // Blackstone
        POLISHED_BLACKSTONE_BRICKS => &[POLISHED_BLACKSTONE, BLACKSTONE],
        POLISHED_BLACKSTONE => &[POLISHED_BLACKSTONE_BRICKS, BLACKSTONE],
        BLACKSTONE => &[POLISHED_BLACKSTONE, POLISHED_BLACKSTONE_BRICKS],

        // Nether
        NETHER_BRICK => &[BLACK_TERRACOTTA],
        BLACK_TERRACOTTA => &[NETHER_BRICK],
        RED_NETHER_BRICKS => &[NETHER_BRICK],

        // Brown family
        BROWN_TERRACOTTA => &[BROWN_CONCRETE_POWDER, BROWN_CONCRETE],
        BROWN_CONCRETE => &[BROWN_CONCRETE_POWDER, BROWN_TERRACOTTA],

        // Off-white / quartz
        QUARTZ_BLOCK => &[QUARTZ_BRICKS, SMOOTH_QUARTZ],
        QUARTZ_BRICKS => &[QUARTZ_BLOCK, WHITE_CONCRETE, SMOOTH_QUARTZ],
        SMOOTH_QUARTZ => &[QUARTZ_BLOCK, QUARTZ_BRICKS],
        WHITE_CONCRETE => &[QUARTZ_BRICKS],

        // Sandstone
        SANDSTONE => &[SMOOTH_SANDSTONE],
        SMOOTH_SANDSTONE => &[SANDSTONE],

        SMOOTH_STONE => &[STONE_BRICKS, STONE],

        POLISHED_DIORITE => &[DIORITE],
        DIORITE => &[POLISHED_DIORITE],

        // Light-grey terracotta + muted copper
        LIGHT_GRAY_TERRACOTTA => &[
            WAXED_EXPOSED_COPPER,
            WAXED_EXPOSED_CHISELED_COPPER,
            WAXED_EXPOSED_CUT_COPPER,
        ],
        WAXED_EXPOSED_COPPER => &[
            LIGHT_GRAY_TERRACOTTA,
            WAXED_EXPOSED_CHISELED_COPPER,
            WAXED_EXPOSED_CUT_COPPER,
        ],
        WAXED_EXPOSED_CHISELED_COPPER => &[
            LIGHT_GRAY_TERRACOTTA,
            WAXED_EXPOSED_COPPER,
            WAXED_EXPOSED_CUT_COPPER,
        ],
        WAXED_EXPOSED_CUT_COPPER => &[
            LIGHT_GRAY_TERRACOTTA,
            WAXED_EXPOSED_COPPER,
            WAXED_EXPOSED_CHISELED_COPPER,
        ],

        // Orange terracotta + copper
        ORANGE_TERRACOTTA => &[WAXED_COPPER_BLOCK, TERRACOTTA],
        WAXED_COPPER_BLOCK => &[ORANGE_TERRACOTTA, TERRACOTTA],

        GRAY_CONCRETE => &[MUD],
        MUD => &[GRAY_CONCRETE],

        // Wood
        OAK_PLANKS => &[SPRUCE_PLANKS],
        SPRUCE_PLANKS => &[OAK_PLANKS, DARK_OAK_PLANKS],
        DARK_OAK_PLANKS => &[SPRUCE_PLANKS, SPRUCE_LOG],
        OAK_LOG => &[SPRUCE_LOG],

        _ => &[],
    }
}

/// Weathers walls and boards up windows for damaged condition states.
fn apply_condition_variation(
    chosen: Block,
    bx: i32,
    h: i32,
    bz: i32,
    config: &BuildingConfig,
) -> Block {
    if config.condition == BuildingCondition::Construction {
        return chosen;
    }

    // Subtle weathering on age-appropriate Normal-condition categories/eras.
    let normal_weather_rate: f64 = if config.condition == BuildingCondition::Normal {
        let category_rate: f64 = match config.category {
            BuildingCategory::Historic | BuildingCategory::Religious => 0.06,
            BuildingCategory::Farm => 0.03,
            _ => 0.0,
        };
        let era_rate = match config.era {
            ArchEra::HistoricOrnate => 0.05,
            ArchEra::TraditionalPreWar => 0.02,
            _ => 0.0,
        };
        category_rate.max(era_rate)
    } else {
        0.0
    };

    if config.condition == BuildingCondition::Normal && normal_weather_rate == 0.0 {
        return chosen;
    }

    let mut rng = coord_rng(bx, bz, config.element_id ^ ((h as u64) << 16));
    let is_window = chosen == config.window_block && config.has_windows;

    // Window-boarding rate for Disused/Abandoned (Ruined drops windows entirely).
    let board_rate: f64 = match config.condition {
        BuildingCondition::Disused => 0.30,
        BuildingCondition::Abandoned => 0.50,
        _ => 0.0,
    };
    if is_window && board_rate > 0.0 && rng.random_bool(board_rate) {
        return config.wall_block;
    }

    // Stone weathering rate per condition.
    let weather_rate: f64 = match config.condition {
        BuildingCondition::Abandoned => 0.05,
        BuildingCondition::Ruined => 0.50,
        BuildingCondition::Normal => normal_weather_rate,
        _ => 0.0,
    };
    if !is_window && weather_rate > 0.0 && rng.random_bool(weather_rate) {
        return weathered_variant(chosen, &mut rng);
    }

    chosen
}

/// Aged counterpart of `block` for damaged-condition states.
fn weathered_variant(block: Block, rng: &mut impl Rng) -> Block {
    match block {
        STONE_BRICKS => {
            const OPTIONS: [Block; 3] = [MOSSY_STONE_BRICKS, CRACKED_STONE_BRICKS, STONE_BRICKS];
            OPTIONS[rng.random_range(0..OPTIONS.len())]
        }
        COBBLESTONE => MOSSY_COBBLESTONE,
        STONE => {
            const OPTIONS: [Block; 2] = [ANDESITE, COBBLESTONE];
            OPTIONS[rng.random_range(0..OPTIONS.len())]
        }
        SMOOTH_STONE => STONE,
        POLISHED_ANDESITE => ANDESITE,
        OAK_PLANKS => {
            const OPTIONS: [Block; 2] = [SPRUCE_PLANKS, DARK_OAK_PLANKS];
            OPTIONS[rng.random_range(0..OPTIONS.len())]
        }
        OAK_LOG => SPRUCE_LOG,
        _ => block,
    }
}

/// Glass a tower can be walled in, so a corner can tell it apart from stone.
fn is_glass_wall(block: Block) -> bool {
    const GLASS_WALLS: [Block; 9] = [
        GLASS,
        WHITE_STAINED_GLASS,
        GRAY_STAINED_GLASS,
        LIGHT_GRAY_STAINED_GLASS,
        BLACK_STAINED_GLASS,
        BROWN_STAINED_GLASS,
        CYAN_STAINED_GLASS,
        BLUE_STAINED_GLASS,
        LIGHT_BLUE_STAINED_GLASS,
    ];
    GLASS_WALLS.contains(&block)
}

/// The pier at a glass tower's corner. Half the glassy towers draw a glass
/// accent, which would leave no corner at all.
fn corner_pier(config: &BuildingConfig) -> Block {
    if is_glass_wall(config.accent_block) {
        LIGHT_GRAY_CONCRETE
    } else {
        config.accent_block
    }
}

fn determine_wall_block_at_position_pristine(
    h: i32,
    config: &BuildingConfig,
    col: ColumnFacade,
) -> Block {
    // Darker plinth rows ground the building visually.
    if let Some(base) = config.base_course_block {
        if h <= config.start_y_offset + config.base_course_rows() {
            return base;
        }
    }

    let floor_row = config.floor_row(h);

    // Party walls render like windowless walls: no glazing into the
    // attached neighbor of a terraced row.
    if !config.has_windows || col.party {
        let above_floor = h > config.start_y_offset + 1;
        // Glass carried around a corner reads as a box of panes. Only the glass
        // towers: a greenhouse is glass walled too and wants no piers. A party
        // wall is not seen, so it keeps its plain treatment.
        let glass_tower = matches!(
            config.category,
            BuildingCategory::GlassySkyscraper | BuildingCategory::GlassCornerSkyscraper
        );
        if col.corner && !col.party && glass_tower {
            return corner_pier(config);
        }
        let use_accent_line = config.use_accent_lines && above_floor && floor_row == 0;
        if use_accent_line {
            return config.accent_block;
        }
        return config.wall_block;
    }

    let above_floor = h > config.start_y_offset + 1;

    if config.use_horizontal_windows {
        // Modern skyscraper pattern: continuous horizontal window bands
        // with stone separation bands at floor levels (every floor cycle)
        if col.corner {
            // Ahead of the bands, so the pier is not cut by one every storey.
            config.wall_block
        } else if above_floor && config.has_lobby_base && h <= config.ground_floor_top() {
            // Solid lobby base: first floor cycle uses wall block
            config.wall_block
        } else if above_floor && floor_row == 0 {
            // Floor-level separation band (stone/accent material)
            config.accent_block
        } else if above_floor {
            // Full-width window band
            config.window_block
        } else {
            config.wall_block
        }
    } else if config.category == BuildingCategory::Tower {
        // Tower pattern: glass windows every 4 blocks along the wall,
        // only in the middle two rows of each 4-row floor
        let is_slit = above_floor
            && (floor_row == 1 || floor_row == 2)
            && (col.wall_u + config.window_phase).rem_euclid(4) == 1;

        if is_slit {
            config.window_block
        } else {
            let use_accent_line = config.use_accent_lines && above_floor && floor_row == 0;
            if use_accent_line {
                config.accent_block
            } else {
                config.wall_block
            }
        }
    } else if config.category == BuildingCategory::GridSkyscraper {
        // Big glass panes separated by concrete mullions at floor lines and every 5th column.
        // The corner turns on a pier: glass carried around a corner reads as a
        // box of panes rather than a building, and a real curtain wall almost
        // always meets the return on solid material.
        let mullion = !above_floor
            || floor_row == 0
            || col.corner
            || (col.wall_u + config.window_phase).rem_euclid(5) == 0;
        if mullion {
            config.wall_block
        } else {
            config.window_block
        }
    } else if config.is_tall_building && config.use_vertical_windows {
        // Tall building pattern, vertical window strips alternating with wall columns
        if above_floor && !col.corner && (col.wall_u + config.window_phase).rem_euclid(2) == 0 {
            config.window_block
        } else {
            config.wall_block
        }
    } else {
        // Regular building pattern
        let window_col = config.window_col(col.wall_u);

        // Storefront glazing: wider full-glass bays across the whole ground floor.
        if config.has_storefront
            && col.street
            && above_floor
            && h <= config.ground_floor_top()
            && floor_row != 0
            && window_col < 4
        {
            return GLASS;
        }

        let role = config.floor_role(h);

        // Attic band: solid wall under the pitched roof with small single
        // lights instead of full windows.
        if config.attic_style && role == FloorRole::Top {
            return if above_floor && window_col == 1 && floor_row == 2 {
                config.window_block
            } else {
                config.wall_block
            };
        }

        // Band cornice separating the body from a treated top floor.
        if config.top_treatment
            && floor_row == 0
            && h == config.start_y_offset + config.building_height - config.floor_cycle
        {
            return config.accent_block;
        }

        // Window layout across the 6-block cycle: the two skyscraper families
        // keep their fixed widths (masonry narrow, contemporary wide); everything
        // else follows the per-building archetype.
        let mut is_window_position = above_floor
            && floor_row != 0
            && match config.category {
                BuildingCategory::MasonrySkyscraper => window_col < 2,
                BuildingCategory::ContemporarySkyscraper => window_col < 4,
                _ => archetype_allows_window(
                    config.window_archetype,
                    window_col,
                    floor_row,
                    config.floor_cycle,
                ),
            };

        // Treated top floors narrow their windows by one column.
        if config.top_treatment && role == FloorRole::Top {
            let narrowed = match config.window_archetype {
                WindowArchetype::Standard3 | WindowArchetype::ArchedTraditional => window_col != 2,
                WindowArchetype::WideHorizontal => window_col != 3,
                _ => true,
            };
            is_window_position = is_window_position && narrowed;
        }

        // Piano nobile: the first floor above ground gets grander glazing.
        if config.piano_nobile
            && role == FloorRole::Body
            && h <= config.ground_floor_top() + config.floor_cycle
            && above_floor
            && floor_row != 0
            && window_col < 3
        {
            is_window_position = true;
        }

        if is_window_position {
            config.window_block
        } else {
            let use_accent_line = config.use_accent_lines && above_floor && floor_row == 0;
            let use_vertical_accent_here =
                config.use_vertical_accent && above_floor && floor_row == 0 && window_col < 3;

            if use_accent_line || use_vertical_accent_here {
                config.accent_block
            } else if config.rustication
                && role == FloorRole::Ground
                && h > config.start_y_offset + config.base_course_rows()
                && (h - config.start_y_offset) % 2 == 0
            {
                // Banded stone courses over the plinth.
                config.base_course_block.unwrap_or(config.accent_block)
            } else {
                config.wall_block
            }
        }
    }
}

// ============================================================================
// Residential Window Decorations (Shutters & Window Boxes)
// ============================================================================

/// Trapdoor base blocks available for shutters (chosen once per building).
const SHUTTER_TRAPDOOR_OPTIONS: [Block; 4] = [
    OAK_TRAPDOOR_OPEN_NORTH, // re-used just for its name "oak_trapdoor"
    DARK_OAK_TRAPDOOR,
    SPRUCE_TRAPDOOR,
    BIRCH_TRAPDOOR,
];

/// Slab base blocks available for window sills (chosen once per building).
const SILL_SLAB_OPTIONS: [Block; 5] = [
    QUARTZ_SLAB_TOP,  // quartz_slab
    STONE_BRICK_SLAB, // stone_brick_slab
    MUD_BRICK_SLAB,   // mud_brick_slab
    OAK_SLAB,         // oak_slab
    BRICK_SLAB,       // brick_slab
];

/// Potted plant options for window boxes (chosen randomly per pot).
const POTTED_PLANT_OPTIONS: [Block; 4] = [
    FLOWER_POT, // potted_poppy
    POTTED_RED_TULIP,
    POTTED_DANDELION,
    POTTED_BLUE_ORCHID,
];

// Share one Arc per distinct facade property compound instead of allocating per placement.
type FacadePropsCache = std::sync::Mutex<fnv::FnvHashMap<(u16, String), std::sync::Arc<Value>>>;
static FACADE_PROPS: once_cell::sync::Lazy<FacadePropsCache> =
    once_cell::sync::Lazy::new(Default::default);

pub(crate) fn cached_prop_block(base: Block, props: &[(&str, &str)]) -> BlockWithProperties {
    let key: String = props.iter().flat_map(|(k, v)| [*k, "=", *v, ";"]).collect();
    let mut cache = FACADE_PROPS.lock().unwrap();
    let arc = cache
        .entry((base.id(), key))
        .or_insert_with(|| {
            let mut map: HashMap<String, Value> = HashMap::new();
            for (k, v) in props {
                map.insert((*k).to_string(), Value::String((*v).to_string()));
            }
            std::sync::Arc::new(Value::Compound(map))
        })
        .clone();
    BlockWithProperties::from_arc(base, Some(arc))
}

/// Creates a `BlockWithProperties` for an open trapdoor with the given
/// base block and facing direction string.
fn make_open_trapdoor(base: Block, facing: &str) -> BlockWithProperties {
    cached_prop_block(
        base,
        &[("facing", facing), ("open", "true"), ("half", "top")],
    )
}

/// Creates a `BlockWithProperties` for a top-half slab.
fn make_top_slab(base: Block) -> BlockWithProperties {
    cached_prop_block(base, &[("type", "top")])
}

/// Closed trapdoor pinned flat against the wall face, top or bottom half.
fn make_closed_trapdoor(base: Block, facing: &str, half: &str) -> BlockWithProperties {
    cached_prop_block(
        base,
        &[("facing", facing), ("open", "false"), ("half", half)],
    )
}

/// Block with arbitrary string properties, for repeated decorated placements.
fn make_prop_block(base: Block, props: &[(&str, &str)]) -> BlockWithProperties {
    cached_prop_block(base, props)
}

/// Computes how axis-aligned a building polygon is.
/// Returns ratio of polygon area to bounding box area.
/// - 1.0 = perfectly axis-aligned rectangle
/// - ~0.5 = 45° rotated square (bounding box is 2x larger)
/// - Lower values = more diagonal/rotated
///
/// Used to detect diagonal buildings that need rotation-invariant roofs.
fn compute_building_diagonality(nodes: &[ProcessedNode]) -> f64 {
    if nodes.len() < 3 {
        return 1.0;
    }

    // Calculate polygon area using shoelace formula
    let mut area = 0i64;
    for i in 0..nodes.len() {
        let j = (i + 1) % nodes.len();
        area += (nodes[i].x as i64) * (nodes[j].z as i64);
        area -= (nodes[j].x as i64) * (nodes[i].z as i64);
    }
    let polygon_area = (area.abs() as f64) / 2.0;

    // Calculate bounding box area
    let min_x = nodes.iter().map(|n| n.x).min().unwrap_or(0);
    let max_x = nodes.iter().map(|n| n.x).max().unwrap_or(0);
    let min_z = nodes.iter().map(|n| n.z).min().unwrap_or(0);
    let max_z = nodes.iter().map(|n| n.z).max().unwrap_or(0);
    let bbox_area = ((max_x - min_x + 1) * (max_z - min_z + 1)) as f64;

    if bbox_area <= 0.0 {
        return 1.0;
    }

    (polygon_area / bbox_area).min(1.0)
}

/// Length-weighted dominant edge angle in radians, folded to (-45, 45] deg.
fn dominant_axis_angle(nodes: &[ProcessedNode]) -> f64 {
    let mut sum_c = 0.0f64;
    let mut sum_s = 0.0f64;
    for i in 0..nodes.len() {
        let j = (i + 1) % nodes.len();
        let dx = (nodes[j].x - nodes[i].x) as f64;
        let dz = (nodes[j].z - nodes[i].z) as f64;
        let len = (dx * dx + dz * dz).sqrt();
        if len < 3.0 {
            continue;
        }
        let ang = dz.atan2(dx);
        sum_c += len * (4.0 * ang).cos();
        sum_s += len * (4.0 * ang).sin();
    }
    if sum_c == 0.0 && sum_s == 0.0 {
        return 0.0;
    }
    sum_s.atan2(sum_c) / 4.0
}

/// The rotated frame of a near-rectangular footprint turned off the grid:
/// `u` runs along its dominant axis (within 45 degrees of world X), `v`
/// across it. A two-slope roof laid in this frame has planar faces that
/// meet the walls, where a scan along the world axes warps them.
#[derive(Clone, Copy, Debug)]
struct TentFrame {
    /// Rotation of the dominant axis off world X, radians, in (-45, 45] deg.
    angle: f64,
    u_min: f64,
    u_max: f64,
    v_min: f64,
    v_max: f64,
}

impl TentFrame {
    fn uv(&self, x: i32, z: i32) -> (f64, f64) {
        let (c, sn) = (self.angle.cos(), self.angle.sin());
        let (x, z) = (x as f64, z as f64);
        (x * c + z * sn, -x * sn + z * c)
    }

    fn u_axis(&self) -> (f64, f64) {
        (self.angle.cos(), self.angle.sin())
    }

    fn v_axis(&self) -> (f64, f64) {
        (-self.angle.sin(), self.angle.cos())
    }
}

/// Near-rectangular footprints rotated 1 to 45 degrees get a planar tent in
/// their own frame; aligned ones, and wings, keep the polygon scan.
fn tent_frame(nodes: &[ProcessedNode]) -> Option<TentFrame> {
    if nodes.len() < 3 {
        return None;
    }
    let ang = dominant_axis_angle(nodes);
    let dev = ang.to_degrees().abs();
    if !(1.0..=45.0).contains(&dev) {
        return None;
    }
    let mut area = 0i64;
    for i in 0..nodes.len() {
        let j = (i + 1) % nodes.len();
        area += (nodes[i].x as i64) * (nodes[j].z as i64);
        area -= (nodes[j].x as i64) * (nodes[i].z as i64);
    }
    let polygon_area = (area.abs() as f64) / 2.0;
    let (c, sn) = (ang.cos(), ang.sin());
    let (mut u_min, mut u_max) = (f64::MAX, f64::MIN);
    let (mut v_min, mut v_max) = (f64::MAX, f64::MIN);
    for n in nodes {
        let u = n.x as f64 * c + n.z as f64 * sn;
        let v = -(n.x as f64) * sn + n.z as f64 * c;
        u_min = u_min.min(u);
        u_max = u_max.max(u);
        v_min = v_min.min(v);
        v_max = v_max.max(v);
    }
    let rect_area = (u_max - u_min) * (v_max - v_min);
    (rect_area > 0.0 && polygon_area / rect_area >= 0.78).then_some(TentFrame {
        angle: ang,
        u_min,
        u_max,
        v_min,
        v_max,
    })
}

/// Which way the ridge of a two-slope roof runs, and the frame it runs in.
#[derive(Clone, Copy, Debug)]
struct RidgeFrame {
    /// Ridge runs along world X (else Z); in a tent, along the axis nearest X.
    along_x: bool,
    /// Rotated frame of a turned footprint; None keeps the world grid.
    tent: Option<TentFrame>,
}

impl RidgeFrame {
    #[cfg(test)]
    fn grid(along_x: bool) -> Self {
        Self {
            along_x,
            tent: None,
        }
    }

    /// Unit vector across the ridge, toward the "plus" eave.
    fn across(&self) -> (f64, f64) {
        match self.tent {
            Some(t) if self.along_x => t.v_axis(),
            Some(t) => t.u_axis(),
            None if self.along_x => (0.0, 1.0),
            None => (1.0, 0.0),
        }
    }

    /// Cells the slope crosses from eave to eave, for a bounding box of
    /// `width` by `length` (extents, one less than the cell counts).
    fn span_cells(&self, width: i32, length: i32) -> f64 {
        match self.tent {
            Some(t) if self.along_x => t.v_max - t.v_min + 1.0,
            Some(t) => t.u_max - t.u_min + 1.0,
            None if self.along_x => length as f64 + 1.0,
            None => width as f64 + 1.0,
        }
    }
}

/// Ridge of a two-slope roof: across a mapped `roof:direction` (the way the
/// slope faces), else per `roof:orientation`, else along the longer side.
fn ridge_frame(
    nodes: &[ProcessedNode],
    width: i32,
    length: i32,
    roof_orientation: Option<&str>,
    roof_direction: Option<&str>,
    preferred_ridge_along_x: Option<bool>,
) -> RidgeFrame {
    let tent = tent_frame(nodes);
    let (u_len, v_len) = match tent {
        Some(t) => (t.u_max - t.u_min, t.v_max - t.v_min),
        None => (width as f64, length as f64),
    };
    let u_is_longer = u_len >= v_len;
    let (ux, uz) = tent.map_or((1.0, 0.0), |t| t.u_axis());
    let (vx, vz) = tent.map_or((0.0, 1.0), |t| t.v_axis());
    let along_x = if let Some(deg) = roof_direction.and_then(parse_roof_direction_degrees) {
        let (dx, dz) = bearing_unit_vector(deg);
        (dx * vx + dz * vz).abs() >= (dx * ux + dz * uz).abs()
    } else {
        match roof_orientation {
            Some(o) if o.eq_ignore_ascii_case("along") => u_is_longer,
            Some(o) if o.eq_ignore_ascii_case("across") => !u_is_longer,
            _ => preferred_ridge_along_x.unwrap_or(u_is_longer),
        }
    };
    RidgeFrame { along_x, tent }
}

/// The cardinal a world-space vector points closest to.
fn cardinal_for_vector(dx: f64, dz: f64) -> StairFacing {
    cardinal_for_bearing(dx.atan2(-dz).to_degrees())
}

/// Whether a wall segment steps along X, matching bresenham_line's driving axis.
/// Not derivable from compute_outward_normal, which snaps the opposite way.
#[inline]
fn segment_axis_x(x1: i32, z1: i32, x2: i32, z2: i32) -> bool {
    (x2 - x1).abs() >= (z2 - z1).abs()
}

/// Axis for a segment's first point, a vertex shared with the previous segment.
/// Both visits use that previous segment's axis so every pass agrees on the column.
#[inline]
fn segment_start_axis_x(nodes: &[ProcessedNode], i: usize, own_axis_x: bool) -> bool {
    let n = nodes.len();
    let closed = n >= 3 && nodes[0].x == nodes[n - 1].x && nodes[0].z == nodes[n - 1].z;
    let here = &nodes[i - 1];
    let mut j = i - 1;
    // A zero-length edge has no direction, so walk back to the last one that moved.
    for _ in 0..n {
        let prev_idx = if j >= 1 {
            j - 1
        } else if closed {
            n - 2
        } else {
            // Open polyline start: nothing else touches this vertex.
            return own_axis_x;
        };
        let prev = &nodes[prev_idx];
        if prev.x != here.x || prev.z != here.z {
            return segment_axis_x(prev.x, prev.z, here.x, here.z);
        }
        j = prev_idx;
    }
    own_axis_x
}

/// Along-wall ordinate of a segment's idx-th point. Only the first uses start_axis_x.
#[inline]
fn wall_ordinate(idx: usize, start_axis_x: bool, seg_axis_x: bool, bx: i32, bz: i32) -> i32 {
    let axis_x = if idx == 0 { start_axis_x } else { seg_axis_x };
    if axis_x {
        bx
    } else {
        bz
    }
}

/// Computes the axis-aligned outward normal for a wall segment defined by
/// `(x1,z1)→(x2,z2)`, given the building centroid `(cx,cz)`.
///
/// Returns one of `(±1, 0)` or `(0, ±1)`, or `(0, 0)` for degenerate
/// (zero-length) segments.
pub(crate) fn compute_outward_normal(
    x1: i32,
    z1: i32,
    x2: i32,
    z2: i32,
    outward: i32,
) -> (i32, i32) {
    let seg_dx = x2 - x1;
    let seg_dz = z2 - z1;

    // Left-hand normal of the segment, turned outward by the ring's winding.
    let (raw_nx, raw_nz) = (-seg_dz * outward, seg_dx * outward);

    // Snap to the dominant axis so the normal is always one of
    // (±1, 0) or (0, ±1).
    if raw_nx.abs() >= raw_nz.abs() {
        (raw_nx.signum(), 0)
    } else {
        (0, raw_nz.signum())
    }
}

/// Which side of its edges a ring's outside lies on: the factor that turns
/// the left-hand normal (-dz, dx) of every edge outward. Taken from the
/// signed area, which every edge of the ring shares, so the re-entrant walls
/// of an L or U get the same answer as the rest; a test against the centroid
/// flips them, and every balcony, door and pilaster on them ends up indoors.
pub(crate) fn outward_side(nodes: &[ProcessedNode]) -> i32 {
    let mut area2 = 0i64;
    for i in 0..nodes.len() {
        let j = (i + 1) % nodes.len();
        area2 += nodes[i].x as i64 * nodes[j].z as i64 - nodes[j].x as i64 * nodes[i].z as i64;
    }
    if area2 > 0 {
        -1
    } else {
        1
    }
}

/// Whether vertex `c` between `p` and `q` is a convex corner of a ring whose
/// outside is on `outward` (see `outward_side`). Collinear and re-entrant
/// vertices are not corners.
fn corner_is_convex(p: (i32, i32), c: (i32, i32), q: (i32, i32), outward: i32) -> bool {
    let cross = (c.0 - p.0) as i64 * (q.1 - c.1) as i64 - (c.1 - p.1) as i64 * (q.0 - c.0) as i64;
    cross != 0 && cross.signum() as i32 == -outward
}

/// Distinct vertices of a closed ring in order, the closing node dropped.
fn ring_vertices(nodes: &[ProcessedNode]) -> Vec<(i32, i32)> {
    let mut corners: Vec<(i32, i32)> = Vec::new();
    for node in nodes {
        let pos = (node.x, node.z);
        if corners.last() != Some(&pos) {
            corners.push(pos);
        }
    }
    if corners.len() > 1 && corners.first() == corners.last() {
        corners.pop();
    }
    corners
}

/// Returns the facing string for the wall's outward normal.
pub(crate) fn facing_for_normal(nx: i32, nz: i32) -> &'static str {
    match (nx, nz) {
        (1, _) => "east",
        (-1, _) => "west",
        (_, 1) => "south",
        _ => "north",
    }
}

/// Shutters and window sills on non-tall residential/house buildings.
fn generate_residential_window_decorations(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    building_passages: &CoordinateBitmap,
    facade: &FacadePlan,
) {
    // Only non-tall residential / house buildings get decorations.
    if config.is_tall_building {
        return;
    }
    if !matches!(
        config.category,
        BuildingCategory::Residential | BuildingCategory::House
    ) {
        return;
    }
    if !config.has_windows {
        return;
    }

    // --- Per-building random material choices ---
    let mut rng = element_rng(element.id);
    let trapdoor_base =
        SHUTTER_TRAPDOOR_OPTIONS[rng.random_range(0..SHUTTER_TRAPDOOR_OPTIONS.len())];
    let sill_base = SILL_SLAB_OPTIONS[rng.random_range(0..SILL_SLAB_OPTIONS.len())];
    let sill_block = make_top_slab(sill_base);

    // We need the building centroid so we can figure out which side of
    // each wall segment is "outside".
    let outward = outward_side(&element.nodes);

    // Piers on column 3 leave no room for shutters.
    let piers_here = wall_depth_piers_active(element, config);

    let mut previous_node: Option<(i32, i32)> = None;
    let mut seg_idx = 0usize;

    for (node_idx, node) in element.nodes.iter().enumerate() {
        let (x2, z2) = (node.x, node.z);
        if let Some((x1, z1)) = previous_node {
            // Rear facades get thinner dressing than street-facing ones.
            let is_rear = facade
                .segments
                .get(seg_idx)
                .and_then(|s| s.as_ref())
                .is_some_and(|s| s.class == FacadeClass::Rear);
            seg_idx += 1;
            let (out_nx, out_nz) = compute_outward_normal(x1, z1, x2, z2, outward);

            // Skip degenerate normals (zero-length segment)
            if out_nx == 0 && out_nz == 0 {
                previous_node = Some((x2, z2));
                continue;
            }

            let facing = facing_for_normal(out_nx, out_nz);
            let trapdoor_bwp = make_open_trapdoor(trapdoor_base, facing);

            // Wall tangent (axis-aligned): perpendicular to the outward
            // normal inside the XZ plane.
            let (tan_x, tan_z) = (-out_nz, out_nx);

            let seg_axis_x = segment_axis_x(x1, z1, x2, z2);
            let start_axis_x = segment_start_axis_x(&element.nodes, node_idx, seg_axis_x);
            // Constant along the segment, so parallel facades draw different rolls.
            let seg_cross = if seg_axis_x { z1 } else { x1 };

            // Walk the bresenham points of this wall segment
            let points =
                bresenham_line(x1, config.start_y_offset, z1, x2, config.start_y_offset, z2);
            let seg_columns: HashSet<(i32, i32)> = points.iter().map(|&(x, _, z)| (x, z)).collect();
            // A balcony spans five columns of this wall: all of them must be
            // on it, so it never wraps a corner, stands before a party wall or
            // hangs over a passage.
            let balcony_fits = |bx: i32, bz: i32| -> bool {
                (-2i32..=2).all(|t| {
                    let c = (bx + tan_x * t, bz + tan_z * t);
                    seg_columns.contains(&c)
                        && !facade.is_party(c.0, c.1)
                        && !building_passages.contains(c.0, c.1)
                })
            };

            for (pt_idx, (bx, _, bz)) in points.iter().enumerate() {
                let bx = *bx;
                let bz = *bz;

                // Skip decorations at passage openings
                if building_passages.contains(bx, bz)
                    || facade.is_party(bx, bz)
                    || config.is_flat_column(bx, bz)
                {
                    continue;
                }
                let door_column = facade.is_door(bx, bz);

                let wu = wall_ordinate(pt_idx, start_axis_x, seg_axis_x, bx, bz);
                let mod6 = config.window_col(wu); // always 0..5

                // --- Shutters ---
                // mod6 == 3 or 5 are the wall blocks flanking a window strip.
                // Both sides share the same roll (seeded on window centre).
                // Frame styles bring their own flank treatment, so skip these.
                // Only archetypes whose cols 3/5 are actually solid flanks
                // next to glazing get shutters (a strip archetype has no
                // window there; a wide band glazes col 3 itself).
                if (mod6 == 3 || mod6 == 5)
                    && config.window_frame.is_none()
                    && !piers_here
                    && matches!(
                        config.window_archetype,
                        WindowArchetype::Standard3
                            | WindowArchetype::PairedNarrow
                            | WindowArchetype::ArchedTraditional
                    )
                {
                    let centre_u = if mod6 == 3 { wu - 2 } else { wu + 2 };
                    let shutter_roll =
                        coord_rng(centre_u, seg_cross, element.id).random_range(0u32..100);
                    let shutter_max = match config.detail {
                        DetailTier::Minimal => 0,
                        DetailTier::Standard => 25,
                        DetailTier::Enhanced | DetailTier::Landmark => 40,
                    };
                    if shutter_roll < shutter_max {
                        for h in (config.start_y_offset + 1)
                            ..=(config.start_y_offset + config.building_height)
                        {
                            let above_floor = h > config.start_y_offset + 1;
                            if above_floor
                                && config.floor_row(h) != 0
                                && !(door_column && config.entrance_row(h))
                            {
                                editor.set_block_with_properties_absolute(
                                    trapdoor_bwp.clone(),
                                    bx + out_nx,
                                    h + config.abs_terrain_offset,
                                    bz + out_nz,
                                    Some(&[AIR]),
                                    None,
                                );
                            }
                        }
                    }
                }

                // --- Window Sills / Balconies ---
                // At each floor's floor_row==0 row we decide once per window
                // whether this floor gets a sill OR a balcony (mutually
                // exclusive).  The decision is shared across the window
                // columns via a seed derived from the window centre. Only
                // columns the archetype actually glazes get sills.
                if archetype_allows_window(config.window_archetype, mod6, 1, config.floor_cycle) {
                    // Stop a full window height before the top so every sill
                    // has a full window above it, avoids placing sills at the
                    // roof line.
                    let attic_gap = if config.attic_style {
                        config.floor_cycle
                    } else {
                        0
                    };
                    let sill_max = config.start_y_offset + config.building_height
                        - (config.floor_cycle - 1)
                        - attic_gap;
                    for h in (config.start_y_offset + config.grammar_anchor())..=sill_max {
                        if config.floor_row(h) == 0 {
                            let floor_idx = h / config.floor_cycle;

                            // Shared roll seeded from the window centre.
                            let centre_u = match mod6 {
                                0 => wu + 1,
                                1 => wu,
                                _ => wu - 1,
                            };
                            let decoration_roll = coord_rng(
                                centre_u.wrapping_add(floor_idx * 3),
                                seg_cross.wrapping_add(floor_idx * 5),
                                element.id,
                            )
                            .random_range(0u32..100);

                            let abs_y = h + config.abs_terrain_offset;
                            let (sill_roll_max, balcony_roll_max) =
                                if is_rear { (8, 18) } else { (15, 23) };
                            let above_ground = !config.is_ground_level
                                || h >= config.start_y_offset + 2 + config.floor_cycle;
                            let wants_balcony = mod6 == 1
                                && above_ground
                                && balcony_fits(bx, bz)
                                && match config.balcony_band {
                                    BalconyBand::Scattered => {
                                        (15..balcony_roll_max).contains(&decoration_roll)
                                    }
                                    BalconyBand::EveryBay => facade.is_street(bx, bz),
                                    BalconyBand::Alternating => {
                                        facade.is_street(bx, bz)
                                            && config.window_bay(wu).rem_euclid(2) == 0
                                    }
                                };

                            if !wants_balcony
                                && decoration_roll < sill_roll_max
                                && config.window_frame.is_none()
                            {
                                // ── Window sill ──
                                let lx = bx + out_nx;
                                let lz = bz + out_nz;

                                editor.set_block_with_properties_absolute(
                                    sill_block.clone(),
                                    lx,
                                    abs_y,
                                    lz,
                                    Some(&[AIR]),
                                    None,
                                );

                                let mut pot_rng =
                                    coord_rng(bx, bz.wrapping_add(floor_idx), element.id);
                                let (pot_centre, pot_side) =
                                    if is_rear { (35, 12) } else { (70, 25) };
                                let pot_here = if mod6 == 1 {
                                    pot_rng.random_range(0u32..100) < pot_centre
                                } else {
                                    pot_rng.random_range(0u32..100) < pot_side
                                };
                                if pot_here {
                                    let plant = POTTED_PLANT_OPTIONS
                                        [pot_rng.random_range(0..POTTED_PLANT_OPTIONS.len())];
                                    editor.set_block_absolute(
                                        plant,
                                        lx,
                                        abs_y + 1,
                                        lz,
                                        Some(&[AIR]),
                                        None,
                                    );
                                }
                            } else if wants_balcony {
                                // ── Balcony (placed once from centre col) ──
                                // Never on the ground floor; elevated parts keep their base row.
                                // A small 3-wide × 2-deep platform with
                                // open-trapdoor railing around the outer
                                // edge and occasional furniture.
                                //
                                // Top-down layout (outward = up):
                                //  depth 3:  [Tf] [Tf] [Tf]  front fence
                                //  depth 2:  [ f] [ f] [ f]  floor
                                //  depth 1:  [ f] [ f] [ f]  floor
                                //            wall wall wall
                                // Side fences at t=±2, depths 1-2.

                                let balcony_floor = make_top_slab(SMOOTH_STONE_SLAB);

                                // Facing strings for fences:
                                // Front fence faces back toward building
                                let front_facing = facing_for_normal(out_nx, out_nz);
                                // Side fences face inward along tangent
                                let left_facing = facing_for_normal(-tan_x, -tan_z);
                                let right_facing = facing_for_normal(tan_x, tan_z);

                                let front_fence = make_open_trapdoor(trapdoor_base, front_facing);
                                let left_fence = make_open_trapdoor(trapdoor_base, left_facing);
                                let right_fence = make_open_trapdoor(trapdoor_base, right_facing);

                                // Place floor slabs (3 wide × 2 deep)
                                for t in -1i32..=1 {
                                    let fx = bx + tan_x * t;
                                    let fz = bz + tan_z * t;

                                    for depth in 1i32..=2 {
                                        let px = fx + out_nx * depth;
                                        let pz = fz + out_nz * depth;

                                        editor.set_block_with_properties_absolute(
                                            balcony_floor.clone(),
                                            px,
                                            abs_y,
                                            pz,
                                            Some(&[AIR]),
                                            None,
                                        );
                                    }
                                }

                                // Front fence: trapdoors at depth 3
                                for t in -1i32..=1 {
                                    let fx = bx + tan_x * t + out_nx * 3;
                                    let fz = bz + tan_z * t + out_nz * 3;
                                    editor.set_block_with_properties_absolute(
                                        front_fence.clone(),
                                        fx,
                                        abs_y + 1,
                                        fz,
                                        Some(&[AIR]),
                                        None,
                                    );
                                }

                                // Side fences: trapdoors at t=±2, depths 1-2
                                for depth in 1i32..=2 {
                                    // Left side (t = -2)
                                    let lx = bx + tan_x * -2 + out_nx * depth;
                                    let lz = bz + tan_z * -2 + out_nz * depth;
                                    editor.set_block_with_properties_absolute(
                                        left_fence.clone(),
                                        lx,
                                        abs_y + 1,
                                        lz,
                                        Some(&[AIR]),
                                        None,
                                    );

                                    // Right side (t = +2)
                                    let rx = bx + tan_x * 2 + out_nx * depth;
                                    let rz = bz + tan_z * 2 + out_nz * depth;
                                    editor.set_block_with_properties_absolute(
                                        right_fence.clone(),
                                        rx,
                                        abs_y + 1,
                                        rz,
                                        Some(&[AIR]),
                                        None,
                                    );
                                }

                                // Occasional furniture on the balcony floor
                                let mut furn_rng = coord_rng(
                                    bx.wrapping_add(floor_idx * 11),
                                    bz.wrapping_add(floor_idx * 17),
                                    element.id,
                                );
                                let furniture_roll = furn_rng.random_range(0u32..100);

                                if furniture_roll < 30 {
                                    // Cauldron "planter" with a leaf block
                                    // on top, placed at depth 1 on one side
                                    let side = if furn_rng.random_bool(0.5) { -1i32 } else { 1 };
                                    let cx = bx + tan_x * side + out_nx;
                                    let cz = bz + tan_z * side + out_nz;
                                    editor.set_block_absolute(
                                        CAULDRON,
                                        cx,
                                        abs_y + 1,
                                        cz,
                                        Some(&[AIR]),
                                        None,
                                    );
                                    editor.set_block_absolute(
                                        OAK_LEAVES,
                                        cx,
                                        abs_y + 2,
                                        cz,
                                        Some(&[AIR]),
                                        None,
                                    );
                                } else if furniture_roll < 55 {
                                    // Stair "chair" facing outward
                                    let side = if furn_rng.random_bool(0.5) { -1i32 } else { 1 };
                                    let sx = bx + tan_x * side + out_nx;
                                    let sz = bz + tan_z * side + out_nz;
                                    let stair_facing = match facing_for_normal(-out_nx, -out_nz) {
                                        "north" => StairFacing::North,
                                        "south" => StairFacing::South,
                                        "east" => StairFacing::East,
                                        _ => StairFacing::West,
                                    };
                                    let chair = create_stair_with_properties(
                                        OAK_STAIRS,
                                        stair_facing,
                                        StairShape::Straight,
                                    );
                                    editor.set_block_with_properties_absolute(
                                        chair,
                                        sx,
                                        abs_y + 1,
                                        sz,
                                        Some(&[AIR]),
                                        None,
                                    );
                                }
                            }
                        }
                    }
                }
            }
        }

        previous_node = Some((x2, z2));
    }
}

// ============================================================================
// Wall Depth Features (Facade Protrusions)
// ============================================================================

/// Creates a `BlockWithProperties` for an upside-down stair used for
/// cornices and arched window headers. The `facing` parameter is the
/// **outward** wall direction; the stair is flipped to face **inward**
/// so that its ledge extends outward (matching real-world cornice behaviour).
fn make_upside_down_stair(material: Block, facing: &str) -> BlockWithProperties {
    let stair_block = get_stair_block_for_material(material);
    // Flip: stair faces inward so the "seat" ledge projects outward
    let stair_facing = match facing {
        "north" => StairFacing::South,
        "south" => StairFacing::North,
        "east" => StairFacing::West,
        _ => StairFacing::East,
    };
    top_stair(create_stair_with_properties(
        stair_block,
        stair_facing,
        StairShape::Straight,
    ))
}

/// Places accent-block columns at building polygon vertices (corner quoins).
/// This frames the building visually, a very common architectural detail.
/// Uses deterministic RNG for consistency across region boundaries.
fn generate_corner_quoins(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    building_passages: &CoordinateBitmap,
    facade: &FacadePlan,
) {
    // Skip if wall and accent are the same block (nothing visible)
    if config.wall_block == config.accent_block {
        return;
    }

    // Too-small buildings look odd with quoins
    let bounds = BuildingBounds::from_nodes(&element.nodes);
    if bounds.width() < 4 || bounds.length() < 4 {
        return;
    }

    // A detected street corner on a public building always gets its framing
    // column; otherwise the deterministic 60% roll decides.
    let guaranteed_corner = facade.corner.as_ref().map(|c| c.vertex).filter(|_| {
        matches!(
            config.category,
            BuildingCategory::Commercial
                | BuildingCategory::Hotel
                | BuildingCategory::Office
                | BuildingCategory::Historic
        )
    });
    let quoin_chance = if matches!(
        config.era,
        ArchEra::TraditionalPreWar | ArchEra::HistoricOrnate
    ) {
        0.9
    } else {
        0.6
    };
    let roll_passed = element_rng(element.id.wrapping_add(3571)).random_bool(quoin_chance);
    if !roll_passed && guaranteed_corner.is_none() {
        return;
    }

    // Corners are where the wall turns: a mid-wall node shared with a
    // neighbour or carrying an entrance gets no column.
    let vertices = ring_vertices(&element.nodes);
    let n = vertices.len();
    let corners: Vec<(i32, i32)> = (0..n)
        .filter(|&i| {
            let p = vertices[(i + n - 1) % n];
            let c = vertices[i];
            let q = vertices[(i + 1) % n];
            let cross =
                (c.0 - p.0) as i64 * (q.1 - c.1) as i64 - (c.1 - p.1) as i64 * (q.0 - c.0) as i64;
            n < 3 || cross != 0
        })
        .map(|i| vertices[i])
        .collect();

    let quoin_block = config.accent_block;
    let top_h = config.start_y_offset + config.building_height;
    let passage_h = config.start_y_offset + BUILDING_PASSAGE_HEIGHT.min(config.building_height);

    // Whitelist the whole substitute family, otherwise variety-substituted wall blocks break the columns.
    let mut wall_family: Vec<Block> = vec![config.wall_block];
    wall_family.extend_from_slice(substitute_pool_only(config.wall_block));

    for &(cx, cz) in &corners {
        // Party-wall vertices sit against the neighbor and get no framing.
        // A corner block a photograph reaches belongs to the photograph: the
        // quoin would overwrite the one column two ring segments share, which
        // is exactly where a photographed wall meets a normal one.
        if facade.is_party(cx, cz) || config.is_flat_column(cx, cz) {
            continue;
        }
        // When only the street corner qualified (roll failed), frame it alone.
        if !roll_passed && guaranteed_corner != Some((cx, cz)) {
            continue;
        }
        let is_passage = building_passages.contains(cx, cz);
        let start_h = if is_passage {
            passage_h + 1
        } else {
            config.start_y_offset + 1
        };
        for h in start_h..=top_h {
            editor.set_block_absolute(
                quoin_block,
                cx,
                h + config.abs_terrain_offset,
                cz,
                Some(&wall_family),
                None,
            );
        }
    }
}

/// Adds wall depth features (pilasters, columns, ledges, cornices, buttresses)
/// to building facades. Blocks are placed 1+ block(s) outward from the wall
/// plane, making windows appear recessed by contrast.
///
/// Each `WallDepthStyle` produces a distinct visual effect appropriate for
/// the building's category. All outward placements use an AIR whitelist to
/// avoid overwriting neighboring buildings or existing decorations.
fn generate_wall_depth_features(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    has_sloped_roof: bool,
    building_passages: &CoordinateBitmap,
    facade: &FacadePlan,
    part_probe: Option<(&CoordinateBitmap, &FnvHashSet<(i32, i32)>)>,
) {
    if config.wall_depth_style == WallDepthStyle::None {
        return;
    }

    // Skip buildings that are too small for depth features
    let bounds = BuildingBounds::from_nodes(&element.nodes);
    if bounds.width() < 4 || bounds.length() < 4 {
        return;
    }

    // Skip buildings with fewer than 2 floors for most styles
    if config.building_height < config.floor_cycle + 2
        && !matches!(
            config.wall_depth_style,
            WallDepthStyle::HistoricOrnate | WallDepthStyle::ReligiousButtress
        )
    {
        return;
    }

    let outward = outward_side(&element.nodes);

    // Per-building deterministic roll for probability-gated styles. Seeded on
    // the shared style seed (== element id for standalone buildings) so
    // identically-tagged parts of one building agree.
    let mut bldg_rng = element_rng(config.style_seed.wrapping_add(7919));
    let depth_roll: u32 = bldg_rng.random_range(0..100);

    // SubtlePilasters: 60% of eligible buildings
    if config.wall_depth_style == WallDepthStyle::SubtlePilasters && depth_roll >= 60 {
        return;
    }
    // GlassCurtain: 40% of eligible buildings
    if config.wall_depth_style == WallDepthStyle::GlassCurtain && depth_roll >= 40 {
        return;
    }

    // Resolve material blocks for depth features
    let slab_block = get_slab_block_for_material(config.wall_block);
    let sill_block = make_top_slab(slab_block);

    // For sloped roofs with overhangs, stop depth features 2 blocks short
    // so protruding pilasters don't visually break the clean eave/overhang line.
    // 2 blocks: one for the eave-edge stair row at base_height, one for the
    // overhang stair placed 1 block outward at base_height - 1.
    let height_reduction = if has_sloped_roof { 2 } else { 0 };

    let mut previous_node: Option<(i32, i32)> = None;

    for (node_idx, node) in element.nodes.iter().enumerate() {
        let (x2, z2) = (node.x, node.z);
        if let Some((x1, z1)) = previous_node {
            let (out_nx, out_nz) = compute_outward_normal(x1, z1, x2, z2, outward);

            if out_nx == 0 && out_nz == 0 {
                previous_node = Some((x2, z2));
                continue;
            }

            let facing = facing_for_normal(out_nx, out_nz);

            let seg_axis_x = segment_axis_x(x1, z1, x2, z2);
            let start_axis_x = segment_start_axis_x(&element.nodes, node_idx, seg_axis_x);

            let points =
                bresenham_line(x1, config.start_y_offset, z1, x2, config.start_y_offset, z2);

            let num_points = points.len();

            for (idx, (bx, _, bz)) in points.iter().enumerate() {
                let bx = *bx;
                let bz = *bz;

                // Skip decorative features at passage openings - the road
                // passes through here so no pilasters/buttresses/etc.
                if building_passages.contains(bx, bz)
                    || facade.is_party(bx, bz)
                    || facade.is_door(bx, bz)
                    || config.is_flat_column(bx, bz)
                {
                    continue;
                }

                // Part protrusions stay out of any other building's cells.
                if let Some((footprints, own)) = part_probe {
                    let blocked =
                        |cx: i32, cz: i32| footprints.contains(cx, cz) && !own.contains(&(cx, cz));
                    if blocked(bx + out_nx, bz + out_nz)
                        || blocked(bx + 2 * out_nx, bz + 2 * out_nz)
                    {
                        continue;
                    }
                }

                // The wall carries a foundation down to the local terrain, so on
                // sloping ground the vertical details have to follow it down: to
                // the ground under the protrusion itself, which one cell out
                // from the wall can be a block lower still.
                let descent = if config.is_ground_level {
                    feature_descent(editor, config, bx, bz, bx + out_nx, bz + out_nz)
                } else {
                    0
                };

                let wu = wall_ordinate(idx, start_axis_x, seg_axis_x, bx, bz);
                let mod6 = config.window_col(wu);

                match config.wall_depth_style {
                    WallDepthStyle::SubtlePilasters => {
                        place_subtle_pilasters(
                            editor,
                            config,
                            bx,
                            bz,
                            mod6,
                            out_nx,
                            out_nz,
                            height_reduction,
                            descent,
                        );
                    }
                    WallDepthStyle::ModernPillars => {
                        place_modern_pillars(
                            editor,
                            config,
                            bx,
                            bz,
                            mod6,
                            out_nx,
                            out_nz,
                            &sill_block,
                            height_reduction,
                            descent,
                        );
                    }
                    WallDepthStyle::InstitutionalBands => {
                        place_institutional_bands(
                            editor,
                            config,
                            bx,
                            bz,
                            mod6,
                            out_nx,
                            out_nz,
                            facing,
                            height_reduction,
                            descent,
                        );
                    }
                    WallDepthStyle::IndustrialBeams => {
                        // Only at segment endpoints (first 2 and last 2 points)
                        if idx < 2 || idx >= num_points.saturating_sub(2) {
                            place_industrial_beams(
                                editor,
                                config,
                                bx,
                                bz,
                                out_nx,
                                out_nz,
                                height_reduction,
                                descent,
                            );
                        }
                    }
                    WallDepthStyle::HistoricOrnate => {
                        place_historic_ornate(
                            editor,
                            config,
                            bx,
                            bz,
                            mod6,
                            out_nx,
                            out_nz,
                            facing,
                            height_reduction,
                            descent,
                        );
                    }
                    WallDepthStyle::ReligiousButtress => {
                        place_religious_buttress(
                            editor,
                            config,
                            bx,
                            bz,
                            mod6,
                            wu,
                            out_nx,
                            out_nz,
                            facing,
                            height_reduction,
                            descent,
                        );
                    }
                    WallDepthStyle::SkyscraperFins => {
                        place_skyscraper_fins(
                            editor,
                            config,
                            bx,
                            bz,
                            mod6,
                            out_nx,
                            out_nz,
                            &sill_block,
                            height_reduction,
                            descent,
                        );
                    }
                    WallDepthStyle::GlassCurtain => {
                        // Only at segment endpoints
                        if idx == 0 || idx == num_points.saturating_sub(1) {
                            place_glass_curtain_corners(
                                editor,
                                config,
                                bx,
                                bz,
                                out_nx,
                                out_nz,
                                height_reduction,
                                descent,
                            );
                        }
                    }
                    WallDepthStyle::None => {}
                }
            }
        }

        previous_node = Some((x2, z2));
    }
}

/// Per-building window frames: flank posts or shutters, band stairs, occasional dressing.
fn generate_window_frames(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    building_passages: &CoordinateBitmap,
    facade: &FacadePlan,
) {
    let Some(style) = config.window_frame else {
        return;
    };
    if config.use_horizontal_windows || config.category == BuildingCategory::Tower {
        return;
    }
    let outward = outward_side(&element.nodes);

    let top_h = config.start_y_offset + config.building_height;
    let post_block = style.post_block();
    let shutter_block = style.shutter_block();
    // A pier on column 3 leaves no room for flank posts.
    let piers_here = wall_depth_piers_active(element, config);

    let mut previous_node: Option<(i32, i32)> = None;
    let mut seg_idx = 0usize;
    for (node_idx, node) in element.nodes.iter().enumerate() {
        let (x2, z2) = (node.x, node.z);
        if let Some((x1, z1)) = previous_node {
            // Rear facades keep the band but get half the dressing.
            let is_rear = facade
                .segments
                .get(seg_idx)
                .and_then(|s| s.as_ref())
                .is_some_and(|s| s.class == FacadeClass::Rear);
            seg_idx += 1;
            let (out_nx, out_nz) = compute_outward_normal(x1, z1, x2, z2, outward);
            if out_nx == 0 && out_nz == 0 {
                previous_node = Some((x2, z2));
                continue;
            }
            let facing = facing_for_normal(out_nx, out_nz);
            let band_stair = make_upside_down_stair(style.band_material(), facing);
            let shutter = shutter_block.map(|b| make_open_trapdoor(b, facing));

            let seg_axis_x = segment_axis_x(x1, z1, x2, z2);
            let start_axis_x = segment_start_axis_x(&element.nodes, node_idx, seg_axis_x);
            let seg_cross = if seg_axis_x { z1 } else { x1 };

            let points =
                bresenham_line(x1, config.start_y_offset, z1, x2, config.start_y_offset, z2);
            for (pt_idx, (bx, _, bz)) in points.iter().enumerate() {
                let (bx, bz) = (*bx, *bz);
                if building_passages.contains(bx, bz)
                    || facade.is_party(bx, bz)
                    || config.is_flat_column(bx, bz)
                {
                    continue;
                }
                let door_column = facade.is_door(bx, bz);
                let wu = wall_ordinate(pt_idx, start_axis_x, seg_axis_x, bx, bz);
                let col = config.window_col(wu);
                let lx = bx + out_nx;
                let lz = bz + out_nz;

                if col < 3 {
                    // Band stair over each window at every floor line, plus occasional dressing.
                    for h in config.ground_floor_top()..=(top_h - 1) {
                        if config.floor_row(h) != 0 {
                            continue;
                        }
                        editor.set_block_with_properties_absolute(
                            band_stair.clone(),
                            lx,
                            h + config.abs_terrain_offset,
                            lz,
                            Some(&[AIR]),
                            None,
                        );

                        if col == 1 {
                            // One partitioned roll decides the centre dressing on the band.
                            let roll = coord_rng(
                                bx,
                                bz.wrapping_add(h),
                                config.element_id ^ 0x00F7_A3E0_D411_0001,
                            )
                            .random_range(0u32..100);
                            let above = h + 1 + config.abs_terrain_offset;
                            let (t_lantern, t_pot, t_trapdoor) =
                                if is_rear { (7, 16, 20) } else { (15, 32, 40) };
                            if h + 1 < top_h {
                                if roll < t_lantern {
                                    if style.has_lanterns() {
                                        editor.set_block_absolute(
                                            LANTERN,
                                            lx,
                                            above,
                                            lz,
                                            Some(&[AIR]),
                                            None,
                                        );
                                    }
                                } else if roll < t_pot {
                                    let mut pot_rng =
                                        coord_rng(bx, bz.wrapping_add(h * 7), config.element_id);
                                    let pot = POTTED_PLANT_OPTIONS
                                        [pot_rng.random_range(0..POTTED_PLANT_OPTIONS.len())];
                                    editor.set_block_absolute(
                                        pot,
                                        lx,
                                        above,
                                        lz,
                                        Some(&[AIR]),
                                        None,
                                    );
                                } else if roll < t_trapdoor {
                                    editor.set_block_with_properties_absolute(
                                        make_closed_trapdoor(
                                            style.detail_trapdoor(),
                                            facing,
                                            "bottom",
                                        ),
                                        lx,
                                        above,
                                        lz,
                                        Some(&[AIR]),
                                        None,
                                    );
                                }
                            }

                            // Under-band corbel shelf under the sill of the window above.
                            if h - 1 > config.start_y_offset + 2 {
                                let shelf_roll = coord_rng(
                                    bx,
                                    bz.wrapping_add(h * 3),
                                    config.element_id ^ 0x0000_5E1F_0000_0002,
                                )
                                .random_range(0u32..100);
                                if shelf_roll < 15 {
                                    editor.set_block_with_properties_absolute(
                                        make_closed_trapdoor(
                                            style.detail_trapdoor(),
                                            facing,
                                            "top",
                                        ),
                                        lx,
                                        h - 1 + config.abs_terrain_offset,
                                        lz,
                                        Some(&[AIR]),
                                        None,
                                    );
                                }
                            }
                        } else if let Some(button) = style.stud_button() {
                            // Button studs on the band front at the window edges.
                            let centre_u = wu + if col == 0 { 1 } else { -1 };
                            let stud_roll = coord_rng(
                                centre_u,
                                seg_cross.wrapping_add(h),
                                config.element_id ^ 0x0000_B417_0000_0004,
                            )
                            .random_range(0u32..100);
                            if stud_roll < 8 {
                                editor.set_block_with_properties_absolute(
                                    make_prop_block(
                                        button,
                                        &[("face", "wall"), ("facing", facing)],
                                    ),
                                    bx + 2 * out_nx,
                                    h + config.abs_terrain_offset,
                                    bz + 2 * out_nz,
                                    Some(&[AIR]),
                                    None,
                                );
                            }
                        }
                    }

                    // Hanging lantern under a band, beside the window top; one side per window.
                    if col != 1 {
                        if let Some(lantern) = style.hanging_lantern() {
                            for h in (config.start_y_offset + 3)..=(top_h - 2) {
                                if config.floor_row(h) != 3 {
                                    continue;
                                }
                                let centre_u = wu + if col == 0 { 1 } else { -1 };
                                let roll = coord_rng(
                                    centre_u,
                                    seg_cross.wrapping_add(h),
                                    config.element_id ^ 0x0000_7A96_0000_0005,
                                )
                                .random_range(0u32..100);
                                if roll < 12 && (roll % 2 == 0) == (col == 0) {
                                    editor.set_block_with_properties_absolute(
                                        make_prop_block(lantern, &[("hanging", "true")]),
                                        lx,
                                        h + config.abs_terrain_offset,
                                        lz,
                                        Some(&[AIR]),
                                        None,
                                    );
                                }
                            }
                        }
                    }
                } else if (col == 3 || col == 5) && !piers_here {
                    // Flank treatment on window rows: posts or shutters.
                    for h in (config.start_y_offset + 2)..=(top_h - 1) {
                        if config.floor_row(h) == 0 || (door_column && config.entrance_row(h)) {
                            continue;
                        }
                        let abs_y = h + config.abs_terrain_offset;
                        if let Some(post) = post_block {
                            editor.set_block_absolute(post, lx, abs_y, lz, Some(&[AIR]), None);
                        } else if let Some(ref trapdoor) = shutter {
                            editor.set_block_with_properties_absolute(
                                trapdoor.clone(),
                                lx,
                                abs_y,
                                lz,
                                Some(&[AIR]),
                                None,
                            );
                        }
                    }
                }
            }
        }
        previous_node = Some((x2, z2));
    }
}

/// String courses, crown cornice or window header trim, for styles without their own banding.
fn generate_facade_cornices(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    has_sloped_roof: bool,
    building_passages: &CoordinateBitmap,
    facade: &FacadePlan,
) {
    if !matches!(
        config.wall_depth_style,
        WallDepthStyle::SubtlePilasters | WallDepthStyle::None
    ) {
        return;
    }
    // Buildings with a window frame style already get banding from it.
    if config.window_frame.is_some() {
        return;
    }
    if config.condition != BuildingCondition::Normal
        || !config.has_windows
        || config.building_height < 2 * config.floor_cycle
    {
        return;
    }
    let bounds = BuildingBounds::from_nodes(&element.nodes);
    if bounds.width() < 4 || bounds.length() < 4 {
        return;
    }
    let outward = outward_side(&element.nodes);

    // 55% string courses, 40% window header trim, 5% plain.
    let roll: u32 = element_rng(config.element_id ^ 0xC0A2_11CE_0000_77AB).random_range(0..100);
    let string_courses = roll < 55;
    let window_trim = (55..95).contains(&roll);
    if !string_courses && !window_trim {
        return;
    }

    let top_h = config.start_y_offset + config.building_height;
    let mut band_whitelist: Vec<Block> = vec![AIR];
    band_whitelist.extend_from_slice(&SILL_SLAB_OPTIONS);

    let mut previous_node: Option<(i32, i32)> = None;
    for (node_idx, node) in element.nodes.iter().enumerate() {
        let (x2, z2) = (node.x, node.z);
        if let Some((x1, z1)) = previous_node {
            let (out_nx, out_nz) = compute_outward_normal(x1, z1, x2, z2, outward);
            if out_nx == 0 && out_nz == 0 {
                previous_node = Some((x2, z2));
                continue;
            }
            let facing = facing_for_normal(out_nx, out_nz);
            let cornice_stair = make_upside_down_stair(config.accent_block, facing);
            let seg_axis_x = segment_axis_x(x1, z1, x2, z2);
            let start_axis_x = segment_start_axis_x(&element.nodes, node_idx, seg_axis_x);

            let points =
                bresenham_line(x1, config.start_y_offset, z1, x2, config.start_y_offset, z2);
            for (pt_idx, (bx, _, bz)) in points.iter().enumerate() {
                let (bx, bz) = (*bx, *bz);
                if building_passages.contains(bx, bz)
                    || facade.is_party(bx, bz)
                    || config.is_flat_column(bx, bz)
                {
                    continue;
                }
                if window_trim
                    && config.window_col(wall_ordinate(pt_idx, start_axis_x, seg_axis_x, bx, bz))
                        >= 3
                {
                    continue;
                }
                let door_column = facade.is_door(bx, bz);
                let lx = bx + out_nx;
                let lz = bz + out_nz;
                for h in config.ground_floor_top()..=top_h {
                    if door_column && config.entrance_row(h) {
                        continue;
                    }
                    // Band rows double as window headers and sills of the floor above.
                    let is_band = config.floor_row(h) == 0 && h < top_h - 1;
                    let is_crown = string_courses && !has_sloped_roof && h == top_h;
                    if is_band || is_crown {
                        // A band runs over the sills placed before it rather
                        // than breaking around them.
                        editor.set_block_with_properties_absolute(
                            cornice_stair.clone(),
                            lx,
                            h + config.abs_terrain_offset,
                            lz,
                            Some(&band_whitelist),
                            None,
                        );
                    }
                }
            }
        }
        previous_node = Some((x2, z2));
    }
}

/// Stair headers over each window top for the ArchedTraditional archetype.
/// HistoricOrnate depth styling already places its own headers.
fn generate_archetype_window_headers(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    building_passages: &CoordinateBitmap,
    facade: &FacadePlan,
) {
    if config.window_archetype != WindowArchetype::ArchedTraditional
        || config.wall_depth_style == WallDepthStyle::HistoricOrnate
        || !config.has_windows
        || config.condition != BuildingCondition::Normal
    {
        return;
    }
    let outward = outward_side(&element.nodes);
    let top_h = config.start_y_offset + config.building_height;

    let mut previous_node: Option<(i32, i32)> = None;
    for (node_idx, node) in element.nodes.iter().enumerate() {
        let (x2, z2) = (node.x, node.z);
        if let Some((x1, z1)) = previous_node {
            let (out_nx, out_nz) = compute_outward_normal(x1, z1, x2, z2, outward);
            if out_nx == 0 && out_nz == 0 {
                previous_node = Some((x2, z2));
                continue;
            }
            let facing = facing_for_normal(out_nx, out_nz);
            let header_stair = make_upside_down_stair(config.wall_block, facing);
            let seg_axis_x = segment_axis_x(x1, z1, x2, z2);
            let start_axis_x = segment_start_axis_x(&element.nodes, node_idx, seg_axis_x);

            let points =
                bresenham_line(x1, config.start_y_offset, z1, x2, config.start_y_offset, z2);
            for (pt_idx, (bx, _, bz)) in points.iter().enumerate() {
                let (bx, bz) = (*bx, *bz);
                if building_passages.contains(bx, bz)
                    || facade.is_party(bx, bz)
                    || config.is_flat_column(bx, bz)
                {
                    continue;
                }
                let mod6 =
                    config.window_col(wall_ordinate(pt_idx, start_axis_x, seg_axis_x, bx, bz));
                // Arch shoulders sit over the window edge columns.
                if mod6 != 0 && mod6 != 2 {
                    continue;
                }
                let door_column = facade.is_door(bx, bz);
                // The storefront awning takes the ground-floor header row.
                let awning_row = config.has_storefront && facade.is_street(bx, bz);
                let lx = bx + out_nx;
                let lz = bz + out_nz;
                for h in (config.start_y_offset + 2)..=top_h {
                    if door_column && config.entrance_row(h) {
                        continue;
                    }
                    if awning_row && h == config.ground_floor_top() {
                        continue;
                    }
                    if config.floor_row(h) == config.floor_cycle - 1 {
                        editor.set_block_with_properties_absolute(
                            header_stair.clone(),
                            lx,
                            h + config.abs_terrain_offset,
                            lz,
                            Some(&[AIR]),
                            None,
                        );
                    }
                }
            }
        }
        previous_node = Some((x2, z2));
    }
}

/// Awning trapdoors over street-facing storefront glass.
fn generate_storefront_awnings(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    building_passages: &CoordinateBitmap,
    facade: &FacadePlan,
) {
    if !config.has_storefront || config.condition != BuildingCondition::Normal {
        return;
    }
    let outward = outward_side(&element.nodes);
    const AWNING_OPTIONS: [Block; 5] = [
        WARPED_TRAPDOOR,
        SPRUCE_TRAPDOOR,
        DARK_OAK_TRAPDOOR,
        JUNGLE_TRAPDOOR,
        ACACIA_TRAPDOOR,
    ];
    let awning = AWNING_OPTIONS[element_rng(config.style_seed ^ 0x0A3B_11B6_0000_000B)
        .random_range(0..AWNING_OPTIONS.len())];
    let awning_y = config.ground_floor_top() + config.abs_terrain_offset;

    let mut previous_node: Option<(i32, i32)> = None;
    for (node_idx, node) in element.nodes.iter().enumerate() {
        let (x2, z2) = (node.x, node.z);
        if let Some((x1, z1)) = previous_node {
            let (out_nx, out_nz) = compute_outward_normal(x1, z1, x2, z2, outward);
            if out_nx == 0 && out_nz == 0 {
                previous_node = Some((x2, z2));
                continue;
            }
            let facing = facing_for_normal(out_nx, out_nz);
            let seg_axis_x = segment_axis_x(x1, z1, x2, z2);
            let start_axis_x = segment_start_axis_x(&element.nodes, node_idx, seg_axis_x);
            let points =
                bresenham_line(x1, config.start_y_offset, z1, x2, config.start_y_offset, z2);
            for (pt_idx, (bx, _, bz)) in points.iter().enumerate() {
                let (bx, bz) = (*bx, *bz);
                if building_passages.contains(bx, bz)
                    || facade.is_party(bx, bz)
                    || config.is_flat_column(bx, bz)
                    || !facade.is_street(bx, bz)
                    || config.window_col(wall_ordinate(pt_idx, start_axis_x, seg_axis_x, bx, bz))
                        >= 4
                {
                    continue;
                }
                editor.set_block_with_properties_absolute(
                    make_closed_trapdoor(awning, facing, "top"),
                    bx + out_nx,
                    awning_y,
                    bz + out_nz,
                    Some(&[AIR]),
                    None,
                );
            }
        }
        previous_node = Some((x2, z2));
    }
}

/// Vertical drainpipe runs hugging two facade corners, a staple of hand-built city blocks.
fn generate_corner_downpipes(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    building_passages: &CoordinateBitmap,
    facade: &FacadePlan,
) {
    if config.building_height < 10
        || config.condition != BuildingCondition::Normal
        || !config.has_windows
    {
        return;
    }
    if !matches!(
        config.category,
        BuildingCategory::Residential
            | BuildingCategory::House
            | BuildingCategory::Commercial
            | BuildingCategory::Hotel
            | BuildingCategory::Historic
    ) {
        return;
    }
    let mut rng = element_rng(config.element_id ^ 0xD0DA_1290_D0FF_AA01);
    if !rng.random_bool(0.35) {
        return;
    }
    let outward = outward_side(&element.nodes);

    // Convex corners of two perpendicular walls, with the pipe cell on the
    // diagonal both walls' outward normals point to. Re-entrant corners
    // would put it indoors and mid-wall nodes are not corners at all.
    let vertices = ring_vertices(&element.nodes);
    let n = vertices.len();
    if n < 3 {
        return;
    }
    let corners: Vec<((i32, i32), (i32, i32))> = (0..n)
        .filter_map(|i| {
            let p = vertices[(i + n - 1) % n];
            let c = vertices[i];
            let q = vertices[(i + 1) % n];
            if !corner_is_convex(p, c, q, outward) {
                return None;
            }
            let (ax, az) = compute_outward_normal(p.0, p.1, c.0, c.1, outward);
            let (bx, bz) = compute_outward_normal(c.0, c.1, q.0, q.1, outward);
            let (dx, dz) = (ax + bx, az + bz);
            (dx != 0 && dz != 0).then_some((c, (dx, dz)))
        })
        .collect();
    if corners.is_empty() {
        return;
    }

    let pipe = get_wall_piece_for_material(config.wall_block);
    let start_idx = rng.random_range(0..corners.len());
    for k in 0..2usize {
        let ((px, pz), (dx, dz)) = corners[(start_idx + k * corners.len() / 2) % corners.len()];
        // A pipe off a photographed corner stands in front of the photograph;
        // one off a party-wall corner stands in front of the neighbour.
        if building_passages.contains(px, pz)
            || config.is_flat_column(px, pz)
            || facade.is_party(px, pz)
        {
            continue;
        }
        let (ox, oz) = (px + dx, pz + dz);
        // Follow the wall foundation down where the ground drops away.
        let descent = if config.is_ground_level {
            feature_descent(editor, config, px, pz, ox, oz)
        } else {
            0
        };
        for h in
            (config.start_y_offset + 1 - descent)..=(config.start_y_offset + config.building_height)
        {
            editor.set_block_absolute(
                pipe,
                ox,
                h + config.abs_terrain_offset,
                oz,
                Some(&[AIR]),
                None,
            );
        }
    }
}

/// SubtlePilasters: thin wall_block columns at mod6==3 positions (between window groups)
/// with an accent_block foundation course at ground level.
#[allow(clippy::too_many_arguments)]
fn place_subtle_pilasters(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    bx: i32,
    bz: i32,
    mod6: i32,
    out_nx: i32,
    out_nz: i32,
    height_reduction: i32,
    descent: i32,
) {
    if mod6 != 3 {
        return;
    }

    let lx = bx + out_nx;
    let lz = bz + out_nz;
    let top_h = config.start_y_offset + config.building_height - height_reduction;

    for h in (config.start_y_offset + 1 - descent)..=top_h {
        let block = if h == config.start_y_offset + 1 {
            config.accent_block // Foundation course
        } else {
            config.wall_block
        };
        editor.set_block_absolute(
            block,
            lx,
            h + config.abs_terrain_offset,
            lz,
            Some(&[AIR]),
            None,
        );
    }
}

/// ModernPillars: paired accent_block columns at mod6==3 and mod6==5,
/// plus horizontal slab bands at floor-separation rows.
#[allow(clippy::too_many_arguments)]
fn place_modern_pillars(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    bx: i32,
    bz: i32,
    mod6: i32,
    out_nx: i32,
    out_nz: i32,
    sill_block: &BlockWithProperties,
    height_reduction: i32,
    descent: i32,
) {
    let lx = bx + out_nx;
    let lz = bz + out_nz;
    let top_h = config.start_y_offset + config.building_height - height_reduction;

    // Pillar columns at edges of window bays
    if mod6 == 3 || mod6 == 5 {
        for h in (config.start_y_offset + 1 - descent)..=top_h {
            editor.set_block_absolute(
                config.accent_block,
                lx,
                h + config.abs_terrain_offset,
                lz,
                Some(&[AIR]),
                None,
            );
        }
        return;
    }

    // Horizontal slab bands at floor-level rows, for non-window positions
    if mod6 >= 3 {
        // Already handled by pillar columns above
        return;
    }

    // Foundation course at ground level
    for h in (config.start_y_offset + 1 - descent)..=(config.start_y_offset + 1) {
        editor.set_block_absolute(
            config.accent_block,
            lx,
            h + config.abs_terrain_offset,
            lz,
            Some(&[AIR]),
            None,
        );
    }

    // Floor-level slab bands (skip the window center at mod6==1 for cleaner look)
    for h in (config.start_y_offset + 2)..=top_h {
        if config.floor_row(h) == 0 {
            editor.set_block_with_properties_absolute(
                sill_block.clone(),
                lx,
                h + config.abs_terrain_offset,
                lz,
                Some(&[AIR]),
                None,
            );
        }
    }
}

/// InstitutionalBands: accent_block columns at mod6==3 + upside-down stair
/// ledges at floor-separation rows for non-window positions.
#[allow(clippy::too_many_arguments)]
fn place_institutional_bands(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    bx: i32,
    bz: i32,
    mod6: i32,
    out_nx: i32,
    out_nz: i32,
    facing: &str,
    height_reduction: i32,
    descent: i32,
) {
    let lx = bx + out_nx;
    let lz = bz + out_nz;
    let top_h = config.start_y_offset + config.building_height - height_reduction;

    // Pillar columns
    if mod6 == 3 {
        for h in (config.start_y_offset + 1 - descent)..=top_h {
            editor.set_block_absolute(
                config.accent_block,
                lx,
                h + config.abs_terrain_offset,
                lz,
                Some(&[AIR]),
                None,
            );
        }
        return;
    }

    // Foundation course
    for h in (config.start_y_offset + 1 - descent)..=(config.start_y_offset + 1) {
        editor.set_block_absolute(
            config.accent_block,
            lx,
            h + config.abs_terrain_offset,
            lz,
            Some(&[AIR]),
            None,
        );
    }

    // Stair ledges at floor-separation rows (non-window positions only)
    if mod6 >= 3 {
        return;
    }
    for h in (config.start_y_offset + 2)..=top_h {
        if config.floor_row(h) == 0 {
            let stair_bwp = make_upside_down_stair(config.wall_block, facing);
            editor.set_block_with_properties_absolute(
                stair_bwp,
                lx,
                h + config.abs_terrain_offset,
                lz,
                Some(&[AIR]),
                None,
            );
        }
    }
}

/// IndustrialBeams: heavy wall_block columns placed only at wall segment
/// endpoints (corners), running full building height.
#[allow(clippy::too_many_arguments)]
fn place_industrial_beams(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    bx: i32,
    bz: i32,
    out_nx: i32,
    out_nz: i32,
    height_reduction: i32,
    descent: i32,
) {
    let lx = bx + out_nx;
    let lz = bz + out_nz;
    let top_h = config.start_y_offset + config.building_height - height_reduction;

    for h in (config.start_y_offset + 1 - descent)..=top_h {
        editor.set_block_absolute(
            config.wall_block,
            lx,
            h + config.abs_terrain_offset,
            lz,
            Some(&[AIR]),
            None,
        );
    }
}

/// HistoricOrnate: wall_block columns at mod6==3, arched window headers
/// (upside-down stairs at window-top rows), cornice at roof line, and
/// foundation course.
#[allow(clippy::too_many_arguments)]
fn place_historic_ornate(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    bx: i32,
    bz: i32,
    mod6: i32,
    out_nx: i32,
    out_nz: i32,
    facing: &str,
    height_reduction: i32,
    descent: i32,
) {
    let lx = bx + out_nx;
    let lz = bz + out_nz;

    let top_h = config.start_y_offset + config.building_height - height_reduction;

    // Full-height pillar columns between window groups
    if mod6 == 3 {
        for h in (config.start_y_offset + 1 - descent)..=top_h {
            editor.set_block_absolute(
                config.wall_block,
                lx,
                h + config.abs_terrain_offset,
                lz,
                Some(&[AIR]),
                None,
            );
        }
        // Cornice at top (skip for sloped roofs - would conflict with roof)
        if height_reduction == 0 {
            let stair_bwp = make_upside_down_stair(config.wall_block, facing);
            editor.set_block_with_properties_absolute(
                stair_bwp,
                lx,
                top_h + config.abs_terrain_offset + 1,
                lz,
                Some(&[AIR]),
                None,
            );
        }
        return;
    }

    // Foundation course for all positions
    for h in (config.start_y_offset + 1 - descent)..=(config.start_y_offset + 1) {
        editor.set_block_absolute(
            config.accent_block,
            lx,
            h + config.abs_terrain_offset,
            lz,
            Some(&[AIR]),
            None,
        );
    }

    // Arched window headers at window-top rows for window-edge positions
    if mod6 == 0 || mod6 == 2 {
        for h in (config.start_y_offset + 2)..=top_h {
            if config.floor_row(h) == config.floor_cycle - 1 {
                let stair_bwp = make_upside_down_stair(config.wall_block, facing);
                editor.set_block_with_properties_absolute(
                    stair_bwp,
                    lx,
                    h + config.abs_terrain_offset,
                    lz,
                    Some(&[AIR]),
                    None,
                );
            }
        }
    }

    // Cornice along the full roofline (skip for sloped roofs)
    if height_reduction == 0 {
        let stair_bwp = make_upside_down_stair(config.wall_block, facing);
        editor.set_block_with_properties_absolute(
            stair_bwp,
            lx,
            top_h + config.abs_terrain_offset + 1,
            lz,
            Some(&[AIR]),
            None,
        );
    }
}

/// ReligiousButtress: stepped buttresses at every other window group,
/// plus cornice at roof line. Buttresses extend 2 blocks outward at the
/// lower portion and 1 block outward for the full height.
#[allow(clippy::too_many_arguments)]
fn place_religious_buttress(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    bx: i32,
    bz: i32,
    mod6: i32,
    wu: i32,
    out_nx: i32,
    out_nz: i32,
    facing: &str,
    height_reduction: i32,
    descent: i32,
) {
    let lx = bx + out_nx;
    let lz = bz + out_nz;
    let top_h = config.start_y_offset + config.building_height - height_reduction;

    // Every other window bay. Shares window_col's lattice, so the phase term and
    // div_euclid are both needed to land on the same bays.
    let window_group = config.window_bay(wu).rem_euclid(2);
    if mod6 == 0 && window_group == 0 {
        let buttress_cutoff = config.start_y_offset + (config.building_height * 3 / 5);

        // Inner layer (outward+1): full height
        for h in (config.start_y_offset + 1 - descent)..=top_h {
            editor.set_block_absolute(
                config.wall_block,
                lx,
                h + config.abs_terrain_offset,
                lz,
                Some(&[AIR]),
                None,
            );
        }

        // Outer layer (outward+2): lower 60% of height
        let lx2 = bx + out_nx * 2;
        let lz2 = bz + out_nz * 2;
        for h in (config.start_y_offset + 1 - descent)..=buttress_cutoff {
            editor.set_block_absolute(
                config.wall_block,
                lx2,
                h + config.abs_terrain_offset,
                lz2,
                Some(&[AIR]),
                None,
            );
        }
        return;
    }

    // Cornice along the full roofline (skip for sloped roofs)
    if height_reduction == 0 {
        let stair_bwp = make_upside_down_stair(config.wall_block, facing);
        editor.set_block_with_properties_absolute(
            stair_bwp,
            lx,
            top_h + config.abs_terrain_offset + 1,
            lz,
            Some(&[AIR]),
            None,
        );
    }
}

/// SkyscraperFins: continuous accent_block vertical fins at mod6==3,
/// horizontal slab ledge bands at floor-separation rows for other positions,
/// and a foundation course at ground level.
#[allow(clippy::too_many_arguments)]
fn place_skyscraper_fins(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    bx: i32,
    bz: i32,
    mod6: i32,
    out_nx: i32,
    out_nz: i32,
    sill_block: &BlockWithProperties,
    height_reduction: i32,
    descent: i32,
) {
    let lx = bx + out_nx;
    let lz = bz + out_nz;
    let top_h = config.start_y_offset + config.building_height - height_reduction;

    // Foundation course at ground level (all positions)
    for h in (config.start_y_offset + 1 - descent)..=(config.start_y_offset + 1) {
        editor.set_block_absolute(
            config.accent_block,
            lx,
            h + config.abs_terrain_offset,
            lz,
            Some(&[AIR]),
            None,
        );
    }

    if mod6 == 3 {
        // Vertical fin column (existing behavior)
        for h in (config.start_y_offset + 1 - descent)..=top_h {
            editor.set_block_absolute(
                config.accent_block,
                lx,
                h + config.abs_terrain_offset,
                lz,
                Some(&[AIR]),
                None,
            );
        }
        return;
    }

    // Floor-level ledge bands at non-fin positions
    for h in (config.start_y_offset + 2)..=top_h {
        if config.floor_row(h) == 0 {
            editor.set_block_with_properties_absolute(
                sill_block.clone(),
                lx,
                h + config.abs_terrain_offset,
                lz,
                Some(&[AIR]),
                None,
            );
        }
    }
}

/// GlassCurtain: minimal accent_block columns only at wall segment
/// endpoints (corners) for subtle edge definition.
#[allow(clippy::too_many_arguments)]
fn place_glass_curtain_corners(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    bx: i32,
    bz: i32,
    out_nx: i32,
    out_nz: i32,
    height_reduction: i32,
    descent: i32,
) {
    let lx = bx + out_nx;
    let lz = bz + out_nz;
    let top_h = config.start_y_offset + config.building_height - height_reduction;

    for h in (config.start_y_offset + 1 - descent)..=top_h {
        editor.set_block_absolute(
            config.accent_block,
            lx,
            h + config.abs_terrain_offset,
            lz,
            Some(&[AIR]),
            None,
        );
    }
}

// ============================================================================
// Hospital Decorations
// ============================================================================

/// Hospital green-cross wall banners on segments >= 5 blocks long.
fn generate_hospital_green_cross(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
) {
    if element.nodes.len() < 3 {
        return;
    }

    // Green cross on white background - universal pharmacy/hospital symbol.
    // Layer the full cross, then paint over the top/bottom edges with white
    // so the vertical arm doesn't stretch the full banner height.
    const GREEN_CROSS_PATTERNS: &[(&str, &str)] = &[
        ("green", "minecraft:straight_cross"),
        ("white", "minecraft:stripe_top"),
        ("white", "minecraft:stripe_bottom"),
        ("white", "minecraft:border"),
    ];

    let banner_y =
        config.start_y_offset + (config.building_height * 2 / 3).max(2) + config.abs_terrain_offset;

    let bounds = BuildingBounds::from_nodes(&element.nodes);
    let center_x = (bounds.min_x + bounds.max_x) / 2;
    let center_z = (bounds.min_z + bounds.max_z) / 2;

    let mut previous_node: Option<(i32, i32)> = None;
    for node in &element.nodes {
        let (x2, z2) = (node.x, node.z);
        if let Some((x1, z1)) = previous_node {
            let seg_len = ((x2 - x1).abs()).max((z2 - z1).abs());
            if seg_len < 5 {
                previous_node = Some((x2, z2));
                continue;
            }

            let mid_x = (x1 + x2) / 2;
            let mid_z = (z1 + z2) / 2;

            // Determine outward facing direction.
            // The wall runs from (x1,z1) to (x2,z2).  We pick the cardinal
            // direction that points away from the building centre.
            let dx = x2 - x1;
            let dz = z2 - z1;

            // Normal vector components (perpendicular to the wall segment).
            // Two candidates: (dz, -dx) and (-dz, dx).  Pick the one that
            // points away from the building centre.
            let (nx, nz) = {
                let (n1x, n1z) = (dz, -dx);
                let dot = (mid_x - center_x) * n1x + (mid_z - center_z) * n1z;
                if dot >= 0 {
                    (n1x, n1z)
                } else {
                    (-dz, dx)
                }
            };

            // Convert normal to cardinal facing and banner offset
            let (facing, bx, bz) = if nx.abs() >= nz.abs() {
                if nx > 0 {
                    ("east", mid_x + 1, mid_z) // banner faces east, placed east of wall
                } else {
                    ("west", mid_x - 1, mid_z) // banner faces west, placed west of wall
                }
            } else if nz > 0 {
                ("south", mid_x, mid_z + 1) // banner faces south, placed south of wall
            } else {
                ("north", mid_x, mid_z - 1) // banner faces north, placed north of wall
            };

            editor.place_wall_banner(
                WHITE_WALL_BANNER,
                bx,
                banner_y,
                bz,
                facing,
                "white",
                GREEN_CROSS_PATTERNS,
            );
        }
        previous_node = Some((x2, z2));
    }
}

/// Generates a helipad marking on the flat roof of a hospital.
///
/// Layout (7×7 yellow concrete pad with a 5×5 "H" pattern):
/// The pad is placed near the centre of the roof surface.
fn generate_hospital_helipad(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    floor_area: &[(i32, i32)],
    config: &BuildingConfig,
) {
    if floor_area.is_empty() {
        return;
    }

    let floor_set: HashSet<(i32, i32)> = floor_area.iter().copied().collect();

    // Roof surface Y (on top of the flat roof)
    let roof_y = config.start_y_offset + config.building_height + config.abs_terrain_offset + 1;

    // Find centre of the building footprint
    let bounds = BuildingBounds::from_nodes(&element.nodes);
    let center_x = (bounds.min_x + bounds.max_x) / 2;
    let center_z = (bounds.min_z + bounds.max_z) / 2;

    let pad_half = 3; // 7×7 pad → half-size = 3

    // Verify the 7×7 area fits within the roof
    let pad_fits = (-pad_half..=pad_half).all(|dx| {
        (-pad_half..=pad_half).all(|dz| floor_set.contains(&(center_x + dx, center_z + dz)))
    });

    if !pad_fits {
        return;
    }

    let replace_any: &[Block] = &[];

    // The "H" character in a 5×5 grid (centred inside the 7×7 pad)
    // Rows/cols indexed -2..=2
    let is_h = |col: i32, row: i32| -> bool {
        let ac = col.abs();
        let ar = row.abs();
        // Two vertical bars at col ±2, plus horizontal bar at row 0
        ac == 2 || (ar == 0 && ac <= 2)
    };

    for dx in -pad_half..=pad_half {
        for dz in -pad_half..=pad_half {
            let bx = center_x + dx;
            let bz = center_z + dz;

            // Outer ring is always yellow
            let is_border = dx.abs() == pad_half || dz.abs() == pad_half;

            let block = if is_border {
                YELLOW_CONCRETE
            } else if is_h(dx, dz) {
                WHITE_CONCRETE
            } else {
                YELLOW_CONCRETE
            };

            editor.set_block_absolute(block, bx, roof_y, bz, None, Some(replace_any));
        }
    }
}

/// Generates floors and ceilings for the building interior
#[allow(clippy::too_many_arguments)]
fn generate_floors_and_ceilings(
    editor: &mut WorldEditor,
    cached_floor_area: &[(i32, i32)],
    config: &BuildingConfig,
    generate_non_flat_roof: bool,
    building_passages: &CoordinateBitmap,
    open_hall: bool,
) -> HashSet<(i32, i32)> {
    let mut processed_points: HashSet<(i32, i32)> = HashSet::new();
    let ceiling_light_block = if config.is_abandoned_building {
        COBWEB
    } else {
        GLOWSTONE
    };

    let passage_height = BUILDING_PASSAGE_HEIGHT.min(config.building_height);

    for &(x, z) in cached_floor_area {
        if !processed_points.insert((x, z)) {
            continue;
        }

        let is_passage = building_passages.contains(x, z);

        // Set ground floor - skip in passage zones (the road surface is placed
        // by the highway processor instead).
        if !is_passage {
            editor.set_block_absolute(
                config.floor_block,
                x,
                config.start_y_offset + config.abs_terrain_offset,
                z,
                None,
                None,
            );
        }

        // Set intermediate ceilings with light fixtures; a furnished hall is one room
        let top = config.start_y_offset + config.building_height;
        let mut top_floor = config.start_y_offset;
        if config.building_height > config.floor_cycle && !open_hall {
            for h in (config.start_y_offset + config.grammar_anchor() + config.floor_cycle..top)
                .step_by(config.floor_cycle as usize)
            {
                top_floor = h;
                // Skip intermediate ceilings below passage opening
                if is_passage && h <= config.start_y_offset + passage_height {
                    continue;
                }

                let block = if x % 3 == 0 && z % 3 == 0 {
                    ceiling_light_block
                } else {
                    config.floor_block
                };
                editor.set_block_absolute(block, x, h + config.abs_terrain_offset, z, None, None);
            }
        }
        // The top storey has no slab above for lights, so they hang in its top row.
        let top_headroom = top - top_floor;
        let under_passage = is_passage && top <= config.start_y_offset + passage_height;
        if x % 3 == 0
            && z % 3 == 0
            && !under_passage
            && (top_headroom >= 3 || top_floor == config.start_y_offset)
        {
            editor.set_block_absolute(
                ceiling_light_block,
                x,
                top + config.abs_terrain_offset,
                z,
                None,
                None,
            );
        }

        // Place passage ceiling lintel at the top of the archway
        if is_passage && passage_height < config.building_height {
            editor.set_block_absolute(
                config.floor_block,
                x,
                config.start_y_offset + passage_height + config.abs_terrain_offset,
                z,
                None,
                None,
            );
        }

        // Set top ceiling (only if flat roof or no roof generation)
        // Use the resolved style flag, not just the OSM tag, since auto-gabled roofs
        // may be generated for residential buildings without a roof:shape tag.
        //
        // Construction sites and ruins stay open at the top.
        let has_flat_roof = !generate_non_flat_roof;
        let skip_top = matches!(
            config.condition,
            BuildingCondition::Construction | BuildingCondition::Ruined
        );

        if has_flat_roof && !skip_top {
            editor.set_block_absolute(
                config.floor_block,
                x,
                config.start_y_offset + config.building_height + config.abs_terrain_offset + 1,
                z,
                None,
                None,
            );
        }
    }

    processed_points
}

/// Calculates floor levels for multi-story buildings
fn calculate_floor_levels(
    start_y_offset: i32,
    building_height: i32,
    floor_cycle: i32,
    grammar_anchor: i32,
) -> Vec<i32> {
    let mut floor_levels = vec![start_y_offset];

    if building_height > floor_cycle + 2 {
        let num_upper_floors = (building_height / floor_cycle).max(1);
        for floor in 1..num_upper_floors {
            floor_levels.push(start_y_offset + grammar_anchor + (floor * floor_cycle));
        }
    }

    floor_levels
}

/// Calculates roof peak height for chimney placement
/// Parses roof:shape tag into RoofType enum.
///
/// Tag frequencies from OSM taginfo are used to decide which synonyms
/// deserve a mapping: anything above ~0.1% is handled here so those
/// buildings get a pitched roof instead of falling through to Flat.
fn parse_roof_type(roof_shape: &str) -> RoofType {
    match roof_shape {
        "gabled" | "gable" | "pitched" | "saltbox" | "double_saltbox" | "quadruple_saltbox"
        | "gabled_row" => RoofType::Gabled,
        "hipped" | "hip" | "side_hipped" => RoofType::Hipped,
        "round" | "barrel" | "vault" | "vaulted" => RoofType::Round,
        "mansard" => RoofType::Mansard,
        "gambrel" => RoofType::Gambrel,
        "half-hipped" | "half_hipped" | "side_half-hipped" => RoofType::HalfHipped,
        "skillion" | "shed" | "lean_to" | "monopitch" => RoofType::Skillion,
        "pyramidal" | "pyramid" => RoofType::Pyramidal,
        "dome" | "spherical" => RoofType::Dome,
        "cone" | "conical" | "circular" | "spire" => RoofType::Cone,
        "onion" => RoofType::Onion,
        _ => RoofType::Flat,
    }
}

/// Checks if building type qualifies for automatic gabled roof.
///
/// Single-family/low-rise residential and agricultural buildings should
/// default to a pitched roof in the absence of an explicit roof:shape tag,
/// since real-world buildings of these types almost never have flat roofs.
fn qualifies_for_auto_gabled_roof(building_type: &str) -> bool {
    matches!(
        building_type,
        "apartments"
            | "residential"
            | "house"
            | "yes"
            | "detached"
            | "semidetached_house"
            | "terrace"
            | "bungalow"
            | "villa"
            | "cabin"
            | "hut"
            | "farm"
            | "farm_auxiliary"
            | "barn"
            | "stable"
            | "cowshed"
            | "sty"
            | "sheepfold"
    )
}

// ============================================================================
// Main Building Generation Function
// ============================================================================

#[inline]
#[allow(clippy::too_many_arguments)]
/// Renders one building. None when it rendered as something else (shelter, roof, car park,
/// bridge, tank, pyramid, underground) or has no street-facing wall.
pub fn generate_buildings(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    args: &Args,
    relation_levels: Option<i32>,
    hole_polygons: Option<&[HolePolygon]>,
    ctx: &BuildingContext<'_>,
    group_seed: u64,
) -> Option<FacadeAnchor> {
    let flood_fill_cache = ctx.flood_fill_cache;
    let building_passages = ctx.building_passages;
    // Early return for underground buildings
    if is_underground_building(&element.tags) {
        return None;
    }

    if SKIP_WAY_IDS.contains(&element.id) {
        return None;
    }

    // Tank-style structures route to their own cylindrical renderer.
    if crate::element_processing::man_made::is_tank_structure(element) {
        let processed_element = crate::osm_parser::ProcessedElement::Way(element.clone());
        crate::element_processing::man_made::generate_tank_structure(
            editor,
            &processed_element,
            args,
        );
        return None;
    }

    // Intercept tomb=pyramid: generate a sandstone pyramid instead of a building
    if element.tags.get("tomb").map(|v| v.as_str()) == Some("pyramid") {
        historic::generate_pyramid(editor, element, args, flood_fill_cache);
        return None;
    }

    // Parse vertical offset: min_height (meters) takes priority, then
    // building:min_level (floor count).  This lifts the structure off the
    // ground for elevated building:parts such as observation-wheel capsules.
    let min_level = element
        .tags
        .get("building:min_level")
        .and_then(|s| s.parse::<i32>().ok())
        .unwrap_or(0);

    let scale_factor = args.scale;
    let abs_terrain_offset = if !args.terrain() {
        args.ground_level
    } else {
        0
    };

    // Get building type (tags only; also drives the floor cycle used below)
    let building_type = element
        .tags
        .get("building")
        .or_else(|| element.tags.get("building:part"))
        .map(|s| s.as_str())
        .unwrap_or("yes");
    let floor_cycle = floor_cycle_for(building_type, &element.tags);

    // Architectural era, consumed by palettes, frames, depth styles and
    // weathering. Untagged parts inherit the hint packed into the group seed.
    let mut era = crate::osm_parser::building_arch_era(&element.tags);
    if era == ArchEra::Unknown && element.tags.contains_key("building:part") {
        era = crate::osm_parser::arch_era_from_hint(crate::osm_parser::style_hint_from_seed(
            group_seed,
        ));
    }

    let min_level_offset = if let Some(mh) = element.tags.get("min_height") {
        mh.trim_end_matches('m')
            .trim()
            .parse::<f64>()
            .ok()
            .map(|h| (h * scale_factor) as i32)
            .unwrap_or(0)
    } else if min_level > 0 {
        // Matches the levels height formula (cycle per level + 2) so a skybridge
        // floor lines up with the level tops of the buildings it connects
        multiply_scale(min_level * floor_cycle + GROUND_FLOOR_BONUS, scale_factor)
    } else {
        0
    };

    // Get cached floor area. Hole carving below needs `retain`, which requires
    // ownership, so we materialize a Vec here. Buildings typically have small
    // footprints (tens to hundreds of cells), so the deep copy is cheap - the
    // big Arc wins come from landuse/natural/leisure handlers.
    let mut cached_floor_area: Vec<(i32, i32)> = flood_fill_cache
        .get_or_compute(element, args.timeout.as_ref())
        .as_ref()
        .clone();

    if let Some(holes) = hole_polygons {
        if !holes.is_empty() {
            let outer_area: HashSet<(i32, i32)> = cached_floor_area.iter().copied().collect();
            let mut hole_points: HashSet<(i32, i32)> = HashSet::new();

            for hole in holes {
                if hole.way.nodes.len() < 3 {
                    continue;
                }

                let hole_area = flood_fill_cache.get_or_compute(&hole.way, args.timeout.as_ref());
                if hole_area.is_empty() {
                    continue;
                }

                if !hole_area.iter().any(|pt| outer_area.contains(pt)) {
                    continue;
                }

                for &point in hole_area.iter() {
                    hole_points.insert(point);
                }
            }

            if !hole_points.is_empty() {
                cached_floor_area.retain(|point| !hole_points.contains(point));
            }
        }
    }

    // A ring too thin to enclose a lattice cell, such as a column or a beam
    // mapped as a building:part, stands on its outline cells instead of
    // vanishing.
    // An oversized ring is empty because the fill refused it, not because it is thin.
    if cached_floor_area.is_empty()
        && hole_polygons.is_none_or(|h| h.is_empty())
        && !crate::floodfill_cache::is_oversized_ring(element)
    {
        cached_floor_area = thin_ring_cells(&element.nodes);
    }

    let cached_footprint_size = cached_floor_area.len();
    if cached_footprint_size == 0 {
        return None;
    }

    // Calculate start Y offset
    let start_y_offset = calculate_start_y_offset(editor, element, args, min_level_offset);

    // Calculate building bounds
    let bounds = BuildingBounds::from_nodes(&element.nodes);

    // Handle shelter amenity
    if element.tags.get("amenity").map(String::as_str) == Some("shelter") {
        generate_shelter(editor, element, &cached_floor_area, scale_factor);
        return None;
    }

    // Route building:part="roof" to the roof-only structure generator.
    // This must be checked before the "building" tag match below, since elements
    // with building:part="roof" (but no "building" tag) would otherwise fall
    // through to the full building pipeline and render as small boxy buildings.
    if element.tags.get("building:part").map(|v| v.as_str()) == Some("roof") {
        generate_roof_only_structure(editor, element, &cached_floor_area, args, group_seed);
        return None;
    }

    // Handle special building types with early returns
    if let Some(btype) = element.tags.get("building") {
        match btype.as_str() {
            "shed" if element.tags.contains_key("bicycle_parking") => {
                generate_bicycle_parking_shed(editor, element, &cached_floor_area);
                return None;
            }
            "parking" => {
                let (height, _) = calculate_building_height(
                    element,
                    building_type,
                    min_level,
                    scale_factor,
                    relation_levels,
                    floor_cycle,
                    cached_footprint_size,
                    group_seed,
                );
                crate::element_processing::parking_garage::generate_parking_garage(
                    editor,
                    &cached_floor_area,
                    height,
                    start_y_offset + abs_terrain_offset,
                    group_seed,
                );
                return None;
            }
            "roof" => {
                generate_roof_only_structure(editor, element, &cached_floor_area, args, group_seed);
                return None;
            }
            // Skybridges with elevation data render as normal elevated buildings,
            // the flat deck below is only the fallback for untagged ones
            "bridge"
                if !element.tags.contains_key("min_height")
                    && !element.tags.contains_key("building:min_level") =>
            {
                generate_bridge(editor, element, flood_fill_cache, args.timeout.as_ref());
                return None;
            }
            _ => {}
        }

        // Also check for multi-storey parking
        if element
            .tags
            .get("parking")
            .is_some_and(|p| p == "multi-storey")
        {
            let (height, _) = calculate_building_height(
                element,
                building_type,
                min_level,
                scale_factor,
                relation_levels,
                floor_cycle,
                cached_footprint_size,
                group_seed,
            );
            crate::element_processing::parking_garage::generate_parking_garage(
                editor,
                &cached_floor_area,
                height,
                start_y_offset + abs_terrain_offset,
                group_seed,
            );
            return None;
        }
    }

    // Calculate building height (tags first, per-type inference as fallback)
    let (building_height, is_tall_building) = calculate_building_height(
        element,
        building_type,
        min_level,
        scale_factor,
        relation_levels,
        floor_cycle,
        cached_footprint_size,
        group_seed,
    );
    // Untagged towers read better on the taller commercial rhythm.
    let (floor_cycle, building_height, is_tall_building, min_level_offset) =
        if is_tall_building && building_type == "yes" && floor_cycle == 3 {
            let (h, tall) = calculate_building_height(
                element,
                building_type,
                min_level,
                scale_factor,
                relation_levels,
                4,
                cached_footprint_size,
                group_seed,
            );
            let lift = if element.tags.contains_key("min_height") {
                min_level_offset
            } else if min_level > 0 {
                multiply_scale(min_level * 4 + GROUND_FLOOR_BONUS, scale_factor)
            } else {
                min_level_offset
            };
            (4, h, tall, lift)
        } else {
            (
                floor_cycle,
                building_height,
                is_tall_building,
                min_level_offset,
            )
        };

    // Determine building category and get appropriate style preset
    let category = BuildingCategory::from_element(
        element,
        is_tall_building,
        building_height,
        group_seed,
        scale_factor,
    );
    let preset = BuildingStylePreset::for_category(category);

    // Street/neighbor classification: party walls, fronting streets, corner.
    // Sibling part cells: exempt from party-wall detection and kept clear of
    // part facade depth. Membership check guards against id collisions.
    let mut group_other_cells: FnvHashSet<(i32, i32)> = FnvHashSet::default();
    if let Some(members) = ctx
        .group_members
        .get(&crate::osm_parser::seed_without_hint(group_seed))
    {
        if members.binary_search(&element.id).is_ok() {
            for id in members {
                if *id == element.id {
                    continue;
                }
                if let Some(fill) = ctx.flood_fill_cache.get_cached(*id) {
                    group_other_cells.extend(fill.iter().copied());
                }
            }
        }
    }
    // The building's own footprint, which is what the preset facades measure a
    // neighbour against: a wall of one `building:part` that stands against
    // another part of the same building faces that part all the same, and
    // its panel is hung above that part's roof or not at all. The facade plan
    // keeps counting the group as its own, so the procedural walls between
    // two parts stay as they are.
    let own_fill: FnvHashSet<(i32, i32)> = cached_floor_area.iter().copied().collect();
    let mut facade = if min_level_offset == 0 && cached_footprint_size >= MIN_FACADE_FOOTPRINT {
        let mut own_cells = own_fill.clone();
        own_cells.extend(group_other_cells.iter().copied());
        compute_facade_plan(element, ctx, args.scale, &own_cells)
    } else {
        FacadePlan::empty()
    };

    // Detail budget from prominence and notable tags.
    let detail = compute_detail_tier(
        element,
        category,
        cached_footprint_size,
        building_height,
        facade.has_any_street,
    );

    // Resolve style with deterministic RNG
    let mut rng = element_rng(group_seed);
    let has_multiple_floors = building_height > floor_cycle + 2;
    let climate = editor.climate();
    let style = BuildingStyle::resolve(
        &preset,
        element,
        building_type,
        category,
        era,
        climate,
        detail,
        building_height,
        has_multiple_floors,
        cached_footprint_size,
        group_seed,
        &mut rng,
    );

    let condition = BuildingCondition::from_tags(&element.tags);
    let is_abandoned_building = matches!(
        condition,
        BuildingCondition::Abandoned | BuildingCondition::Ruined
    );

    let mut wall_block = style.wall_block;
    // A column has no room for a window or a door.
    let is_thin_ring = cached_footprint_size <= THIN_RING_MAX_CELLS;
    let mut has_windows = style.has_windows && !is_thin_ring;
    let mut has_garage_door = style.has_garage_door && !is_thin_ring;
    let mut has_single_door = style.has_single_door && !is_thin_ring;
    let mut effective_building_height = building_height;
    match condition {
        BuildingCondition::Construction => {
            effective_building_height = (building_height / 2).max(3);
            wall_block = SCAFFOLDING;
            has_windows = false;
            has_garage_door = false;
            has_single_door = false;
        }
        BuildingCondition::Ruined => {
            effective_building_height = ((building_height as f64 * 0.6) as i32).max(3);
            has_windows = false;
            has_garage_door = false;
            has_single_door = false;
        }
        BuildingCondition::Abandoned => {
            has_garage_door = false;
            has_single_door = false;
        }
        BuildingCondition::Disused | BuildingCondition::Normal => {}
    }

    // Whether this building will get a sloped roof (drives the attic band).
    let has_sloped_roof = style.generate_roof
        && style.roof_type != RoofType::Flat
        && !matches!(
            condition,
            BuildingCondition::Construction | BuildingCondition::Ruined
        );

    // Window layout is picked before the config literal so the frame gate
    // below can see it (frames are designed around 3-wide bays).
    let window_archetype = pick_window_archetype(category, era, group_seed);

    // Vertical composition: top-floor and first-floor treatments, seeded on
    // the group seed so building:part groups agree.
    let top_treatment = has_windows
        && effective_building_height >= 4 * floor_cycle
        && !style.use_horizontal_windows
        && !matches!(
            category,
            BuildingCategory::GlassySkyscraper
                | BuildingCategory::GlassCornerSkyscraper
                | BuildingCategory::GridSkyscraper
                | BuildingCategory::Tower
        )
        && element_rng(group_seed ^ 0xF10A_401E_0000_0001).random_bool(0.45);
    let attic_style = has_windows
        && has_sloped_roof
        && effective_building_height >= 3 * floor_cycle
        && matches!(
            category,
            BuildingCategory::House | BuildingCategory::Residential | BuildingCategory::Historic
        )
        && element_rng(group_seed ^ 0xF10A_401E_0000_0002).random_bool(0.55);
    let piano_nobile = has_windows
        && effective_building_height >= 3 * floor_cycle
        && match category {
            BuildingCategory::Historic => {
                element_rng(group_seed ^ 0xF10A_401E_0000_0003).random_bool(0.50)
            }
            BuildingCategory::Hotel => {
                element_rng(group_seed ^ 0xF10A_401E_0000_0003).random_bool(0.20)
            }
            _ => false,
        };

    // Create config struct for cleaner function calls
    let config = BuildingConfig {
        is_ground_level: min_level_offset == 0,
        building_height: effective_building_height,
        floor_cycle,
        is_tall_building,
        start_y_offset,
        abs_terrain_offset,
        wall_block,
        floor_block: style.floor_block,
        window_block: style.window_block,
        accent_block: style.accent_block,
        roof_block: style.roof_block,
        use_vertical_windows: style.use_vertical_windows,
        use_horizontal_windows: style.use_horizontal_windows,
        use_accent_roof_line: style.use_accent_roof_line,
        use_accent_lines: style.use_accent_lines,
        use_vertical_accent: style.use_vertical_accent,
        is_abandoned_building,
        has_windows,
        has_garage_door,
        has_single_door,
        category,
        era,
        detail,
        top_treatment,
        attic_style,
        piano_nobile,
        wall_depth_style: style.wall_depth_style,
        has_parapet: style.has_parapet
            || short_flat_parapet_for(
                group_seed,
                style.roof_type,
                effective_building_height,
                category,
                condition,
            ),
        has_lobby_base: if category == BuildingCategory::ModernSkyscraper {
            element_rng(group_seed.wrapping_add(6143)).random_bool(0.70)
        } else {
            false
        },
        condition,
        element_id: element.id,
        style_seed: group_seed,
        // Parts of one building must share a phase, so they stay world-coord aligned.
        window_phase: if element.tags.contains_key("building:part") {
            0
        } else {
            element_rng(element.id ^ 0x77D0_A3E1_9B1C_5544).random_range(0..6)
        },
        window_archetype,
        balcony_band: pick_balcony_band(
            category,
            effective_building_height,
            floor_cycle,
            facade.has_any_street,
            group_seed,
        ),
        rustication: matches!(
            category,
            BuildingCategory::House
                | BuildingCategory::Residential
                | BuildingCategory::Commercial
                | BuildingCategory::Hotel
                | BuildingCategory::Historic
        ) && min_level_offset == 0
            && condition == BuildingCondition::Normal
            && detail >= DetailTier::Standard
            && match era {
                ArchEra::HistoricOrnate => true,
                ArchEra::TraditionalPreWar => {
                    element_rng(group_seed ^ 0x0BA5_E5A0_0000_000A).random_bool(0.70)
                }
                _ => false,
            },
        base_course_block: {
            let eligible = min_level_offset == 0
                && has_windows
                && condition == BuildingCondition::Normal
                && !matches!(
                    category,
                    BuildingCategory::Greenhouse
                        | BuildingCategory::Shed
                        | BuildingCategory::Garage
                        | BuildingCategory::GlassySkyscraper
                );
            let base = base_course_for_wall(wall_block);
            (eligible
                && base != wall_block
                && element_rng(group_seed ^ 0xBA5E_C0A2_5E11_0001).random_bool(0.70))
            .then_some(base)
        },
        has_storefront: matches!(
            category,
            BuildingCategory::Commercial | BuildingCategory::Hotel
        ) && has_windows
            && condition == BuildingCondition::Normal
            && min_level_offset == 0
            && facade.has_any_street
            && element_rng(group_seed ^ 0x5709_EF90_0000_0002)
                .random_bool(if facade.corner.is_some() { 0.85 } else { 0.60 }),
        window_frame: (has_windows
            && condition == BuildingCondition::Normal
            && !is_tall_building
            && matches!(
                window_archetype,
                WindowArchetype::Standard3
                    | WindowArchetype::PairedNarrow
                    | WindowArchetype::ArchedTraditional
            ))
        .then(|| pick_window_frame(category, era, detail, wall_block, group_seed))
        .flatten(),
        facade_shell: photo_shell_columns(element),
        // Filled in below, once the podium massing has settled the wall height
        // `building_facades::collect` will be given.
        preset_shell: Arc::default(),
    };

    // Passages only apply to ground-level buildings. Elevated building:part
    // elements (min_level > 0) sit above the passage and must keep their
    // walls, floors and decorations intact.
    let empty_passages = CoordinateBitmap::new_empty();
    let empty_facade = FacadePlan::empty();
    let effective_passages: &CoordinateBitmap = if config.is_ground_level {
        building_passages
    } else {
        &empty_passages
    };

    // Podium + tower massing: shell at podium height, tower after the roof pass.
    let podium_tower = plan_podium_tower(
        element,
        &config,
        style.roof_type,
        style.generate_roof,
        cached_footprint_size,
        &cached_floor_area,
        group_seed,
    );
    let config = match &podium_tower {
        Some(plan) => BuildingConfig {
            building_height: plan.podium_height,
            ..config.clone()
        },
        None => config,
    };
    // The preset facades are recorded before the wall is built, not after it:
    // the columns they return are the columns built as a plain shell, so the
    // shell is exactly what the photographs cover and a wall they hang nothing
    // on is built exactly as it is with the feature off. Nothing is written
    // into the world here; the panels are hung once it is finished.
    let config = BuildingConfig {
        preset_shell: crate::building_facades::collect_facing(
            editor,
            &element.nodes,
            config.element_id,
            // The shared style seed, so the parts of one building hang one
            // photograph the way they already share one wall block.
            config.style_seed,
            config.category,
            config.start_y_offset,
            config.abs_terrain_offset,
            config.building_height,
            // A wall column faces into another building when the cell one or
            // two out from it belongs to a footprint that is not this
            // element's own: the party test of `compute_facade_plan`, asked
            // per wall direction so a corner is party along one wall and
            // free along the other, and against the element alone so a part
            // standing against another part of its building counts too. An
            // elevated part stands on the building below it and faces nothing
            // at ground level, so it is not asked.
            &|bx, bz, (ox, oz)| {
                config.is_ground_level
                    && (1..=2).any(|d| {
                        let c = (bx + ox * d, bz + oz * d);
                        ctx.building_footprints.contains(c.0, c.1) && !own_fill.contains(&c)
                    })
            },
        ),
        ..config
    };
    // Interiors must stop at the podium roof or rooms would float.
    let effective_building_height = match &podium_tower {
        Some(plan) => plan.podium_height,
        None => effective_building_height,
    };

    // Interior uses per storey, planned before doors and floors: shared shop floors
    // get a door per shop, open halls lose their storey ceilings.
    let storey_levels = calculate_floor_levels(
        start_y_offset,
        effective_building_height,
        config.floor_cycle,
        config.grammar_anchor(),
    );
    let interior_plan = (args.interior
        && cached_floor_area.len() >= MIN_INTERIOR_CELLS
        && !matches!(
            building_type,
            "garage"
                | "garages"
                | "carport"
                | "shed"
                | "parking"
                | "roof"
                | "bridge"
                | "greenhouse"
                | "glasshouse"
                | "silo"
                | "storage_tank"
                | "transformer_tower"
                | "water_tower"
                | "service"
                | "toilets"
                | "bunker"
                | "container"
                | "outbuilding"
                | "allotment_house"
                | "boathouse"
                | "pavilion"
        )
        && !matches!(
            config.condition,
            BuildingCondition::Construction | BuildingCondition::Ruined
        ))
    .then(|| {
        plan_interior(&PlanInputs {
            tags: &element.tags,
            building_type,
            floors: storey_levels.len(),
            min_level,
            elevated: !config.is_ground_level,
            footprint: cached_floor_area.len(),
            center: (
                (bounds.min_x + bounds.max_x) / 2,
                (bounds.min_z + bounds.max_z) / 2,
            ),
            tenants: ctx.interior_uses.tenants(element.id),
            area: ctx.interior_uses.area(element.id),
        })
    });
    let open_hall = interior_plan.as_ref().is_some_and(|p| p.open_hall);

    // Entrances are planned before the decoration passes so their columns
    // stay clear of shutters, sills and pilasters.
    let mut entrance_plans = plan_mapped_entrances(element, &config, &facade, group_seed);
    if entrance_plans.is_empty() {
        if let Some(plan) =
            plan_synthetic_entrance(element, &config, &facade, effective_passages, group_seed)
        {
            entrance_plans.push(plan);
        }
    }
    // Shops sharing the ground floor each get a street door of their own.
    if let Some(units) = interior_plan
        .as_ref()
        .and_then(|p| p.floors.first())
        .filter(|units| units.len() >= 2)
    {
        let anchors: Vec<(i32, i32)> = units.iter().map(|u| u.anchor).collect();
        let extra = plan_unit_entrances(
            element,
            &config,
            &facade,
            effective_passages,
            group_seed,
            &anchors,
            &entrance_plans,
        );
        entrance_plans.extend(extra);
    }
    for plan in &entrance_plans {
        let leaves = if plan.double { 2 } else { 1 };
        for t in 0..leaves {
            let dx = plan.x + plan.tangent.0 * t;
            let dz = plan.z + plan.tangent.1 * t;
            facade.mark_door_column(dx, dz);
            facade.mark_door_column(dx + plan.normal.0, dz + plan.normal.1);
        }
    }

    let (wall_outline, corner_count, wall_segments) = build_wall_ring(
        editor,
        &element.nodes,
        &config,
        args,
        has_sloped_roof,
        effective_passages,
        &facade,
    );

    if let Some(holes) = hole_polygons {
        for hole in holes {
            if hole.add_walls {
                let _ = build_wall_ring(
                    editor,
                    &hole.way.nodes,
                    &config,
                    args,
                    has_sloped_roof,
                    effective_passages,
                    &empty_facade,
                );
            }
        }
    }

    // Generate special doors (garage doors, shed doors)
    if config.has_garage_door || config.has_single_door {
        generate_special_doors(editor, element, &config, &wall_outline, effective_passages);
    }

    // Entrance doors overwrite the freshly built wall columns.
    for plan in &entrance_plans {
        render_entrance(editor, plan, &config, args);
    }

    // Per-building window frame dressing, then shutters/window boxes for the rest
    if !element.tags.contains_key("building:part") {
        generate_window_frames(editor, element, &config, effective_passages, &facade);
    }
    generate_residential_window_decorations(editor, element, &config, effective_passages, &facade);

    // Add wall depth features (pilasters, columns, ledges, cornices, buttresses).
    // building:part sub-sections get them too, with a footprint probe so
    // protrusions stay out of other buildings' cells (sibling parts count
    // as this building's own).
    let is_part = element.tags.contains_key("building:part");
    let part_own_cells: FnvHashSet<(i32, i32)> = if is_part {
        cached_floor_area
            .iter()
            .copied()
            .chain(group_other_cells.iter().copied())
            .collect()
    } else {
        FnvHashSet::default()
    };
    let part_probe = is_part.then_some((ctx.building_footprints, &part_own_cells));
    generate_wall_depth_features(
        editor,
        element,
        &config,
        has_sloped_roof,
        effective_passages,
        &facade,
        part_probe,
    );

    // Add corner quoins (accent-block columns at building corners)
    if !element.tags.contains_key("building:part") {
        generate_corner_quoins(editor, element, &config, effective_passages, &facade);
        generate_facade_cornices(
            editor,
            element,
            &config,
            has_sloped_roof,
            effective_passages,
            &facade,
        );
        generate_corner_downpipes(editor, element, &config, effective_passages, &facade);
        generate_archetype_window_headers(editor, element, &config, effective_passages, &facade);
        generate_storefront_awnings(editor, element, &config, effective_passages, &facade);
    }

    // Create roof area = floor area + wall outline (so roof covers the walls too)
    let roof_area: Vec<(i32, i32)> = {
        let mut area: HashSet<(i32, i32)> = cached_floor_area.iter().copied().collect();
        area.extend(wall_outline.iter().copied());
        // Sort to ensure deterministic iteration order across runs/platforms
        let mut v: Vec<(i32, i32)> = area.into_iter().collect();
        v.sort_unstable();
        v
    };

    // Generate floors and ceilings
    if corner_count > 0 {
        generate_floors_and_ceilings(
            editor,
            &cached_floor_area,
            &config,
            style.generate_roof,
            effective_passages,
            open_hall,
        );

        // Build tunnel side walls: for each interior coordinate that borders a
        // passage coordinate, place a wall column from ground to passage ceiling.
        // This creates the left/right corridor walls inside the archway.
        // Only applies to ground-level buildings (elevated building:parts are
        // above the passage and should not get corridor walls).
        if !effective_passages.is_empty() {
            let passage_height = BUILDING_PASSAGE_HEIGHT.min(config.building_height);
            let abs = config.abs_terrain_offset;
            for &(x, z) in &cached_floor_area {
                if effective_passages.contains(x, z) {
                    continue; // this is road, not a wall
                }
                // Check 4-connected neighbours for passage adjacency
                let adjacent_to_passage = effective_passages.contains(x - 1, z)
                    || effective_passages.contains(x + 1, z)
                    || effective_passages.contains(x, z - 1)
                    || effective_passages.contains(x, z + 1);
                if adjacent_to_passage {
                    for y in (config.start_y_offset + 1)..=(config.start_y_offset + passage_height)
                    {
                        editor.set_block_absolute(config.wall_block, x, y + abs, z, None, None);
                    }
                }
            }
        }

        // Generate interior features
        if let Some(plan) = &interior_plan {
            let floor_levels = if open_hall {
                vec![start_y_offset]
            } else {
                storey_levels
            };
            // The cell inside each leaf of every ground-level door.
            let entrances: Vec<Entry> = if config.is_ground_level {
                entrance_plans
                    .iter()
                    .flat_map(|p| {
                        let leaves = if p.double { 2 } else { 1 };
                        (0..leaves).map(move |t| Entry {
                            cell: (
                                p.x + p.tangent.0 * t - p.normal.0,
                                p.z + p.tangent.1 * t - p.normal.1,
                            ),
                            inward: (-p.normal.0, -p.normal.1),
                        })
                    })
                    .collect()
            } else {
                Vec::new()
            };
            generate_building_interior(
                editor,
                &InteriorRequest {
                    footprint: &cached_floor_area,
                    floor_levels: &floor_levels,
                    start_y_offset,
                    building_height: effective_building_height,
                    abs_terrain_offset,
                    wall_block: style.wall_block,
                    plan,
                    abandoned: is_abandoned_building,
                    passages: effective_passages,
                    entrances: &entrances,
                    bounds: ((bounds.min_x, bounds.min_z), (bounds.max_x, bounds.max_z)),
                    claims: ctx.interior_uses.claims(element.id),
                    scale: args.scale,
                    floor_block: config.floor_block,
                    seed: group_seed,
                },
            );
        }
    }

    // Construction/Ruined buildings stay roofless.
    let skip_roof = matches!(
        config.condition,
        BuildingCondition::Construction | BuildingCondition::Ruined
    );
    if style.generate_roof && !skip_roof {
        // Terraced fabric prefers its ridge parallel to the fronting street.
        let preferred_ridge_along_x = if matches!(building_type, "terrace" | "semidetached_house") {
            facade
                .front_segment
                .and_then(|i| facade.segments[i].as_ref())
                .map(|seg| seg.normal.0 == 0)
        } else {
            None
        };
        let covered_by_sibling_part = is_part
            && cached_floor_area
                .iter()
                .any(|c| group_other_cells.contains(c));
        generate_building_roof(
            editor,
            element,
            &config,
            &style,
            &bounds,
            &roof_area,
            category,
            preferred_ridge_along_x,
            podium_tower.is_some(),
            covered_by_sibling_part,
            scale_factor,
        );

        // Tower ring above the podium roof; full height so top-floor
        // treatment stays at the actual top.
        if let Some(plan) = &podium_tower {
            let dist = roof_edge_distances(&roof_area);
            let tower = [InsetTier {
                inset: plan.inset,
                height: plan.full_height - plan.podium_height,
                with_ceilings: true,
            }];
            let tower_config = BuildingConfig {
                building_height: plan.full_height,
                ..config.clone()
            };
            generate_inset_tiers(
                editor,
                &tower_config,
                &roof_area,
                &dist,
                config.start_y_offset + config.building_height + 1,
                &tower,
            );
        }
    }

    // After every wall and decoration pass, so the seam audit sees the world
    // the player would.
    report_wall_segments(editor, element, &config, effective_passages, &wall_segments);

    facade_anchor(element, &facade, &config, &entrance_plans)
}

/// Sign anchor: the entrance column, else the middle of the front wall.
fn facade_anchor(
    element: &ProcessedWay,
    facade: &FacadePlan,
    config: &BuildingConfig,
    entrances: &[EntrancePlan],
) -> Option<FacadeAnchor> {
    let abs = config.abs_terrain_offset;
    // First row above the ground floor, clearing the storefront glazing and its awning.
    let fascia_y = config.ground_floor_top() + 1 + abs;
    let door_y = config.start_y_offset + abs + 1;

    if let Some(plan) = entrances.first() {
        return Some(FacadeAnchor {
            x: plan.x,
            z: plan.z,
            normal: plan.normal,
            fascia_y: fascia_y.max(door_y + 3),
            number_y: door_y + 1,
            door: Some((plan.x, plan.z)),
        });
    }

    let front = facade.front_segment?;
    let seg = facade.segments[front].as_ref()?;
    // Segment i spans nodes[i]..nodes[i+1]; hang the plate on the middle of that wall.
    let (a, b) = (element.nodes.get(front)?, element.nodes.get(front + 1)?);
    let cells = bresenham_line(a.x, 0, a.z, b.x, 0, b.z);
    let (x, _, z) = *cells.get(cells.len() / 2)?;
    Some(FacadeAnchor {
        x,
        z,
        normal: seg.normal,
        fascia_y,
        number_y: door_y + 1,
        door: None,
    })
}

/// Generates a parapet (low wall) around the edge of flat-roofed buildings.
///
/// For shorter buildings (< 16 blocks), uses a thin wall piece.
/// For taller buildings, uses a full wall block for a more substantial parapet.
fn generate_parapet(editor: &mut WorldEditor, element: &ProcessedWay, config: &BuildingConfig) {
    if !config.has_parapet {
        return;
    }

    if element.nodes.is_empty() {
        return;
    }

    let wall_piece = get_wall_piece_for_material(config.wall_block);
    // Parapet sits on top of the flat roof surface (roof_y + 1 + abs_terrain_offset)
    let parapet_y = config.start_y_offset + config.building_height + config.abs_terrain_offset + 2;

    let mut previous_node: Option<(i32, i32)> = None;

    for node in &element.nodes {
        let (x2, z2) = (node.x, node.z);
        if let Some((x1, z1)) = previous_node {
            let points =
                bresenham_line(x1, config.start_y_offset, z1, x2, config.start_y_offset, z2);

            for (bx, _, bz) in &points {
                let block = if config.building_height >= 16 {
                    config.wall_block
                } else {
                    wall_piece
                };
                editor.set_block_absolute(block, *bx, parapet_y, *bz, Some(&[AIR]), None);
            }
        }
        previous_node = Some((x2, z2));
    }

    // Enhanced parapet for modern skyscrapers: accent slab cap + corner posts
    if config.category == BuildingCategory::ModernSkyscraper {
        let cap_slab = make_top_slab(get_slab_block_for_material(config.accent_block));
        let cap_y = parapet_y + 1;

        // Cap slabs along wall perimeter
        let mut prev: Option<(i32, i32)> = None;
        for node in &element.nodes {
            let (x2, z2) = (node.x, node.z);
            if let Some((x1, z1)) = prev {
                let points =
                    bresenham_line(x1, config.start_y_offset, z1, x2, config.start_y_offset, z2);
                for (bx, _, bz) in &points {
                    editor.set_block_with_properties_absolute(
                        cap_slab.clone(),
                        *bx,
                        cap_y,
                        *bz,
                        Some(&[AIR]),
                        None,
                    );
                }
            }
            prev = Some((x2, z2));
        }

        // Corner posts: full accent block at polygon vertices
        let mut corners: Vec<(i32, i32)> = Vec::new();
        for node in &element.nodes {
            let pos = (node.x, node.z);
            if corners.last() != Some(&pos) {
                corners.push(pos);
            }
        }
        for &(cx, cz) in &corners {
            editor.set_block_absolute(config.accent_block, cx, cap_y, cz, None, Some(&[]));
        }
    }
}

/// Adds a decorative top edge to flat-roofed residential/generic buildings.
/// Randomly picks one of: raised wall row, slab cap, accent block row, or nothing.
/// Uses deterministic RNG so the result is consistent across region boundaries.
fn generate_flat_roof_edge_variation(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
) {
    if element.nodes.is_empty() {
        return;
    }

    let mut rng = element_rng(element.id);
    // 55% chance to add edge variation
    if !rng.random_bool(0.55) {
        return;
    }

    // Pick variation type: 0 = wall cap (1 block higher), 1 = slab cap, 2 = accent block row
    let variation = rng.random_range(0u32..3);
    let roof_top_y = config.start_y_offset + config.building_height + config.abs_terrain_offset + 2;

    let mut previous_node: Option<(i32, i32)> = None;
    for node in &element.nodes {
        let (x2, z2) = (node.x, node.z);
        if let Some((x1, z1)) = previous_node {
            let points =
                bresenham_line(x1, config.start_y_offset, z1, x2, config.start_y_offset, z2);
            for (bx, _, bz) in &points {
                let block = match variation {
                    0 => config.wall_block,
                    1 => get_slab_block_for_material(config.wall_block),
                    _ => config.accent_block,
                };
                editor.set_block_absolute(block, *bx, roof_top_y, *bz, Some(&[AIR]), None);
            }
        }
        previous_node = Some((x2, z2));
    }
}

/// Handles roof generation including chimney placement and rooftop equipment
#[allow(clippy::too_many_arguments)]
fn generate_building_roof(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    config: &BuildingConfig,
    style: &BuildingStyle,
    bounds: &BuildingBounds,
    roof_area: &[(i32, i32)],
    category: BuildingCategory,
    preferred_ridge_along_x: Option<bool>,
    suppress_flat_extras: bool,
    covered_by_sibling_part: bool,
    scale_factor: f64,
) {
    // Dormers: house/residential pitched roofs, plus historic mansards.
    let add_dormers = config.condition == BuildingCondition::Normal
        && ((matches!(
            category,
            BuildingCategory::House | BuildingCategory::Residential
        ) && matches!(
            style.roof_type,
            RoofType::Gabled | RoofType::Hipped | RoofType::Mansard
        )) || (category == BuildingCategory::Historic && style.roof_type == RoofType::Mansard));

    // Churches carry visibly steeper gables than houses.
    let steep_gable = category == BuildingCategory::Religious;

    // roof:colour/material on a part means the mapper modeled this surface, keep it clean
    let modeled_part_roof = element.tags.contains_key("building:part")
        && (element.tags.contains_key("roof:colour") || element.tags.contains_key("roof:material"));

    // A glass curtain wall is three window rows to one wall row, so a glass
    // roof continuing it takes the window glass, not the band's.
    let curtain_glass = (is_glass_wall(config.wall_block) && is_glass_wall(config.window_block))
        .then_some(config.window_block);

    // Generate the roof using the pre-determined roof type from style
    generate_roof(
        editor,
        element,
        config.start_y_offset,
        config.building_height,
        config.floor_block,
        config.wall_block,
        curtain_glass,
        config.roof_block,
        style.roof_type,
        roof_area,
        config.abs_terrain_offset,
        add_dormers,
        config.style_seed,
        steep_gable,
        preferred_ridge_along_x,
        scale_factor,
    );

    // Add parapet on flat-roofed buildings. A roof another part stands on
    // is a floor, and gets no parapet in the part above's facade.
    if config.has_parapet && style.roof_type == RoofType::Flat && !covered_by_sibling_part {
        generate_parapet(editor, element, config);
    }

    // Add decorative roofline variation on flat-roofed residential/generic buildings
    // (those that don't already have a parapet or non-flat roof)
    if !config.has_parapet
        && style.roof_type == RoofType::Flat
        && !modeled_part_roof
        && !covered_by_sibling_part
    {
        generate_flat_roof_edge_variation(editor, element, config);
    }

    // Stepped setback crowns and wooden water towers on flat roofs.
    // A planned tower rises from this roof, so it gets neither.
    let mut has_crown = suppress_flat_extras;
    let mut water_tower_at: Option<(i32, i32)> = None;
    if !suppress_flat_extras
        && style.roof_type == RoofType::Flat
        && !element.tags.contains_key("building:part")
    {
        has_crown = generate_setback_crown(editor, config, roof_area);
        if !has_crown {
            water_tower_at = generate_water_tower(editor, config, roof_area, category);
        }
    }

    // chimneys only on pitched roofs, presets cannot force one onto flat
    if style.has_chimney
        && matches!(
            style.roof_type,
            RoofType::Gabled
                | RoofType::Hipped
                | RoofType::Mansard
                | RoofType::Gambrel
                | RoofType::HalfHipped
        )
    {
        generate_chimney(
            editor,
            roof_area,
            bounds.min_x,
            bounds.max_x,
            bounds.min_z,
            bounds.max_z,
            config.start_y_offset + config.building_height + 1,
            config.abs_terrain_offset,
            element.id,
        );
    }

    // no rooftop extras when a sibling part is stacked on top
    let has_terrace = !modeled_part_roof
        && !covered_by_sibling_part
        && should_generate_roof_terrace(element, config, style.roof_type);
    if has_terrace {
        let roof_y = config.start_y_offset + config.building_height;
        generate_roof_terrace(
            editor,
            element,
            roof_area,
            bounds,
            roof_y,
            config.abs_terrain_offset,
        );
    }

    if !has_crown
        && !has_terrace
        && !modeled_part_roof
        && !covered_by_sibling_part
        && (should_generate_rooftop_equipment(config, style.roof_type, category)
            || short_flat_rooftop_bits_for(
                element.id,
                style.roof_type,
                config.building_height,
                category,
                config.condition,
                config.detail,
            ))
    {
        let roof_y = config.start_y_offset + config.building_height;
        generate_rooftop_equipment(
            editor,
            element,
            roof_area,
            roof_y,
            config.abs_terrain_offset,
            water_tower_at,
        );
    }

    // Lightning rod on peaked residential houses, 5% chance.
    if matches!(category, BuildingCategory::House)
        && config.condition == BuildingCondition::Normal
        && matches!(
            style.roof_type,
            RoofType::Gabled | RoofType::Hipped | RoofType::Pyramidal
        )
    {
        generate_residential_antenna(editor, element, roof_area, config);
    }

    // Hospital helipad on the flat roof
    if category == BuildingCategory::Hospital && style.roof_type == RoofType::Flat {
        generate_hospital_helipad(editor, element, roof_area, config);
    }

    // Hospital green cross banners on exterior walls
    if category == BuildingCategory::Hospital {
        generate_hospital_green_cross(editor, element, config);
    }
}

/// Compact bbox-indexed distance grid, 4 bytes per cell instead of a hash map.
struct RoofDistanceGrid {
    min_x: i32,
    min_z: i32,
    width: i32,
    height: i32,
    dist: Vec<i32>,
}

impl RoofDistanceGrid {
    /// Distance to the nearest roof edge, -1 outside the roof.
    fn get(&self, x: i32, z: i32) -> i32 {
        let (lx, lz) = (x - self.min_x, z - self.min_z);
        if lx < 0 || lz < 0 || lx >= self.width || lz >= self.height {
            return -1;
        }
        self.dist[(lz * self.width + lx) as usize]
    }
}

/// Per-cell BFS distance to the nearest roof edge.
fn roof_edge_distances(roof_area: &[(i32, i32)]) -> RoofDistanceGrid {
    let (mut min_x, mut max_x, mut min_z, mut max_z) = (i32::MAX, i32::MIN, i32::MAX, i32::MIN);
    for &(x, z) in roof_area {
        min_x = min_x.min(x);
        max_x = max_x.max(x);
        min_z = min_z.min(z);
        max_z = max_z.max(z);
    }
    let width = max_x - min_x + 1;
    let height = max_z - min_z + 1;
    let mut dist = vec![-1i32; (width * height) as usize];
    let idx = |x: i32, z: i32| ((z - min_z) * width + (x - min_x)) as usize;

    for &(x, z) in roof_area {
        dist[idx(x, z)] = i32::MAX;
    }
    let mut queue: VecDeque<(i32, i32)> = VecDeque::new();
    for &(x, z) in roof_area {
        let on_edge = [(1, 0), (-1, 0), (0, 1), (0, -1)].iter().any(|&(dx, dz)| {
            let (nx, nz) = (x + dx, z + dz);
            nx < min_x || nx > max_x || nz < min_z || nz > max_z || dist[idx(nx, nz)] == -1
        });
        if on_edge {
            dist[idx(x, z)] = 0;
            queue.push_back((x, z));
        }
    }
    while let Some((x, z)) = queue.pop_front() {
        let d = dist[idx(x, z)];
        for (dx, dz) in [(1, 0), (-1, 0), (0, 1), (0, -1)] {
            let (nx, nz) = (x + dx, z + dz);
            if nx < min_x || nx > max_x || nz < min_z || nz > max_z {
                continue;
            }
            let i = idx(nx, nz);
            if dist[i] == i32::MAX {
                dist[i] = d + 1;
                queue.push_back((nx, nz));
            }
        }
    }
    RoofDistanceGrid {
        min_x,
        min_z,
        width,
        height,
        dist,
    }
}

/// Stepped setback crown on 35% of tall flat-roofed towers, the classic art deco silhouette.
/// Podium + tower massing for a large tall building mapped as one outline.
struct PodiumTowerPlan {
    podium_height: i32,
    inset: i32,
    full_height: i32,
}

/// Big flat-roofed towers on large footprints read better as a 2-3 storey
/// podium with an inset tower than as one sheer extrusion. Mapped
/// `building:part` massing always wins (parts never take this path).
fn plan_podium_tower(
    element: &ProcessedWay,
    config: &BuildingConfig,
    roof_type: RoofType,
    generate_roof_flag: bool,
    footprint_size: usize,
    floor_area: &[(i32, i32)],
    group_seed: u64,
) -> Option<PodiumTowerPlan> {
    if !config.is_tall_building
        || config.building_height < 30
        || footprint_size < 600
        || roof_type != RoofType::Flat
        || !generate_roof_flag
        || config.condition != BuildingCondition::Normal
        || element.tags.contains_key("building:part")
    {
        return None;
    }
    let mut rng = element_rng(group_seed ^ 0x90D1_0A70_0000_0001);
    if !rng.random_bool(0.40) {
        return None;
    }
    let inset = if footprint_size < 1200 {
        3
    } else {
        4 + rng.random_range(0..2)
    };
    // Validate the tower footprint before committing to the massing.
    let dist = roof_edge_distances(floor_area);
    let tower_cells = floor_area
        .iter()
        .filter(|&&(x, z)| dist.get(x, z) >= inset)
        .count();
    if tower_cells < 150 || tower_cells * 4 < footprint_size {
        return None;
    }
    let podium_floors = 2 + rng.random_range(0..2);
    let podium_height = podium_floors * config.floor_cycle + GROUND_FLOOR_BONUS;
    if config.building_height - podium_height < 2 * config.floor_cycle {
        return None;
    }
    Some(PodiumTowerPlan {
        podium_height,
        inset,
        full_height: config.building_height,
    })
}

/// One inset ring of a tiered top (setback crown tier, or a whole tower).
struct InsetTier {
    inset: i32,
    height: i32,
    /// Lay interior ceiling plates with the usual light grid inside the ring.
    with_ceilings: bool,
}

/// Places stacked inset wall rings above `base_rel` using the building's own
/// facade grammar (window bands continue upward), capping each tier with a
/// floor plate. Returns the relative Y of the top cap, or None when even the
/// first tier is too small.
fn generate_inset_tiers(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    roof_area: &[(i32, i32)],
    dist: &RoofDistanceGrid,
    base_rel: i32,
    tiers: &[InsetTier],
) -> Option<i32> {
    let mut current_base = base_rel;
    let mut placed = false;
    for tier in tiers {
        let tier_cells: Vec<(i32, i32)> = roof_area
            .iter()
            .copied()
            .filter(|&(x, z)| dist.get(x, z) >= tier.inset)
            .collect();
        if tier_cells.len() < 30 {
            break;
        }
        placed = true;

        for &(x, z) in &tier_cells {
            // An open X neighbour means the wall runs along Z, so its ordinate is z.
            // Corners have both open; either pick keeps one run's rhythm and breaks the other.
            let open_x = dist.get(x + 1, z) < tier.inset || dist.get(x - 1, z) < tier.inset;
            let open_z = dist.get(x, z + 1) < tier.inset || dist.get(x, z - 1) < tier.inset;
            if open_x || open_z {
                let col = ColumnFacade {
                    wall_u: if open_x { z } else { x },
                    // Both open is the corner cell, and the outline below
                    // turns its corners on the wall block; a crown that kept
                    // glass there would break the pier at the setback.
                    corner: open_x && open_z,
                    ..ColumnFacade::default()
                };
                // Same wall and window logic as the facade, so bands continue upward.
                let photo = config.is_photo_column(x, z);
                for h in 0..tier.height {
                    let block = determine_wall_block_at_position(
                        x,
                        current_base + h,
                        z,
                        config,
                        col,
                        photo,
                    );
                    editor.set_block_absolute(
                        block,
                        x,
                        current_base + h + config.abs_terrain_offset,
                        z,
                        None,
                        Some(&[]),
                    );
                }
            } else if tier.with_ceilings {
                for h in 0..tier.height {
                    let gy = current_base + h;
                    if config.floor_row(gy) == 0 {
                        let block = if x % 3 == 0 && z % 3 == 0 {
                            GLOWSTONE
                        } else {
                            config.floor_block
                        };
                        editor.set_block_absolute(
                            block,
                            x,
                            gy + config.abs_terrain_offset,
                            z,
                            None,
                            Some(&[]),
                        );
                    }
                }
            }
            editor.set_block_absolute(
                config.floor_block,
                x,
                current_base + tier.height + config.abs_terrain_offset,
                z,
                None,
                Some(&[]),
            );
        }
        current_base += tier.height;
    }
    placed.then_some(current_base)
}

fn generate_setback_crown(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    roof_area: &[(i32, i32)],
) -> bool {
    if !config.is_tall_building
        || config.condition != BuildingCondition::Normal
        || roof_area.len() < 200
    {
        return false;
    }
    let mut rng = element_rng(config.element_id ^ 0x5E7B_AC4C_0000_0001);
    if !rng.random_bool(0.45) {
        return false;
    }

    let dist = roof_edge_distances(roof_area);
    let roof_rel = config.start_y_offset + config.building_height + 1;
    // Masonry towers get the full art-deco wedding cake.
    let tier_count = if config.category == BuildingCategory::MasonrySkyscraper {
        3
    } else {
        2
    };
    let tiers: Vec<InsetTier> = (0..tier_count)
        .map(|t| InsetTier {
            inset: 3 + t * 3,
            height: config.floor_cycle,
            with_ceilings: false,
        })
        .collect();
    let Some(top) = generate_inset_tiers(editor, config, roof_area, &dist, roof_rel, &tiers) else {
        return false;
    };

    // Small mast on the crown centre, on the deepest cell.
    if let Some(&(mx, mz)) = roof_area.iter().max_by_key(|&&(x, z)| dist.get(x, z)) {
        if dist.get(mx, mz) >= 6 {
            let top_abs = top + 1 + config.abs_terrain_offset;
            for h in 0..3 {
                editor.set_block_absolute(IRON_BARS, mx, top_abs + h, mz, None, Some(&[]));
            }
            editor.set_block_absolute(LIGHTNING_ROD, mx, top_abs + 3, mz, None, Some(&[]));
        }
    }

    true
}

/// Wooden rooftop water tank on legs, a staple of brick mid-rises. 18% of eligible flat roofs.
fn generate_water_tower(
    editor: &mut WorldEditor,
    config: &BuildingConfig,
    roof_area: &[(i32, i32)],
    category: BuildingCategory,
) -> Option<(i32, i32)> {
    // Only mid-rises with a real base: 4+ levels and a decent roof area.
    if config.building_height < 16
        || roof_area.len() < 300
        || config.condition != BuildingCondition::Normal
    {
        return None;
    }
    if matches!(
        category,
        BuildingCategory::GlassySkyscraper
            | BuildingCategory::ModernSkyscraper
            | BuildingCategory::Religious
            | BuildingCategory::Hospital
    ) {
        return None;
    }
    let mut rng = element_rng(config.element_id ^ 0x3A7E_12F0_0000_0002);
    if !rng.random_bool(0.18) {
        return None;
    }

    // roof_area is sorted at construction, so membership is a binary search.
    let on_roof = |x: i32, z: i32| roof_area.binary_search(&(x, z)).is_ok();
    let spots: Vec<(i32, i32)> = roof_area
        .iter()
        .copied()
        .filter(|&(x, z)| (-2..=2).all(|dx| (-2..=2).all(|dz| on_roof(x + dx, z + dz))))
        .collect();
    if spots.is_empty() {
        return None;
    }
    let (cx, cz) = spots[rng.random_range(0..spots.len())];
    let base = config.start_y_offset + config.building_height + 2 + config.abs_terrain_offset;
    let replace_any: &[Block] = &[];

    for (lx, lz) in [
        (cx - 1, cz - 1),
        (cx + 1, cz - 1),
        (cx - 1, cz + 1),
        (cx + 1, cz + 1),
    ] {
        for h in 0..2 {
            editor.set_block_absolute(SPRUCE_FENCE, lx, base + h, lz, None, Some(replace_any));
        }
    }
    for dx in -1..=1 {
        for dz in -1..=1 {
            for h in 2..5 {
                editor.set_block_absolute(
                    SPRUCE_PLANKS,
                    cx + dx,
                    base + h,
                    cz + dz,
                    None,
                    Some(replace_any),
                );
            }
            let cap = if dx == 0 && dz == 0 {
                SPRUCE_PLANKS
            } else {
                SPRUCE_SLAB
            };
            editor.set_block_absolute(cap, cx + dx, base + 5, cz + dz, None, Some(replace_any));
        }
    }
    editor.set_block_absolute(SPRUCE_SLAB, cx, base + 6, cz, None, Some(replace_any));
    Some((cx, cz))
}

fn multiply_scale(value: i32, scale_factor: f64) -> i32 {
    // Use bit operations for faster multiplication when possible
    if scale_factor == 1.0 {
        value
    } else if scale_factor == 2.0 {
        value << 1
    } else if scale_factor == 4.0 {
        value << 2
    } else {
        let result = (value as f64) * scale_factor;
        result.floor() as i32
    }
}

/// Generate a chimney on a building roof
///
/// Creates a small brick chimney (1x1) typically found on residential buildings.
/// Chimneys are placed within the actual building footprint near a corner.
#[allow(clippy::too_many_arguments)]
fn generate_chimney(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    min_x: i32,
    max_x: i32,
    min_z: i32,
    max_z: i32,
    roof_base: i32,
    abs_terrain_offset: i32,
    element_id: u64,
) {
    if floor_area.is_empty() {
        return;
    }
    let footprint: HashSet<(i32, i32)> = floor_area.iter().copied().collect();
    // one step inside the edge the surface is low in every roof profile
    let near_eave = |x: i32, z: i32| {
        [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)]
            .iter()
            .all(|n| footprint.contains(n))
            && [(x - 2, z), (x + 2, z), (x, z - 2), (x, z + 2)]
                .iter()
                .any(|n| !footprint.contains(n))
    };

    // Use deterministic RNG based on element ID for consistent placement
    let mut rng = element_rng(element_id);

    // Find a position within the actual floor area near a corner
    // Calculate center point
    let center_x = (min_x + max_x) / 2;
    let center_z = (min_z + max_z) / 2;

    // Choose which quadrant to place the chimney (deterministically)
    let quadrant = rng.random_range(0..4);

    // Filter floor area points to the chosen quadrant and find one that's
    // offset from the edge (so it's actually on the roof, not at the wall)
    let candidate_points: Vec<(i32, i32)> = floor_area
        .iter()
        .filter(|(x, z)| {
            let in_quadrant = match quadrant {
                0 => *x < center_x && *z < center_z,   // NW
                1 => *x >= center_x && *z < center_z,  // NE
                2 => *x < center_x && *z >= center_z,  // SW
                _ => *x >= center_x && *z >= center_z, // SE
            };
            in_quadrant && near_eave(*x, *z)
        })
        .copied()
        .collect();

    // If no good candidates in the quadrant, try any eave-adjacent point
    let final_candidates = if candidate_points.is_empty() {
        floor_area
            .iter()
            .filter(|(x, z)| near_eave(*x, *z))
            .copied()
            .collect::<Vec<_>>()
    } else {
        candidate_points
    };
    // A dormer already stands on the low band of the slope: its glass sits
    // in the rows the shaft would take.
    let final_candidates: Vec<(i32, i32)> = final_candidates
        .into_iter()
        .filter(|&(x, z)| {
            !(roof_base + 1..=roof_base + 3).any(|y| {
                editor
                    .get_block_absolute(x, y + abs_terrain_offset, z)
                    .is_some_and(is_glass_wall)
            })
        })
        .collect();

    if final_candidates.is_empty() {
        return;
    }

    // Pick a point from candidates
    let (chimney_x, chimney_z) = final_candidates[rng.random_range(0..final_candidates.len())];

    // short shaft above the roof base, embedded below and clear on top
    let chimney_base = roof_base + 1;
    let chimney_height = 4;

    // Blocks that the chimney is allowed to replace (roof materials and stairs)
    // We pass None for whitelist and use a blacklist that excludes nothing,
    // which means we ALWAYS overwrite. But set_block_absolute with None, None
    // won't overwrite existing blocks. So we need to specify that ANY existing
    // block should be replaced.
    // Since set_block_absolute only overwrites when whitelist matches or blacklist doesn't,
    // we use an empty blacklist to mean "blacklist nothing" = overwrite everything.
    let replace_any: &[Block] = &[];

    // Build the chimney shaft (1x1 brick column, exactly 3 blocks tall)
    for y in chimney_base..(chimney_base + chimney_height) {
        editor.set_block_absolute(
            BRICK,
            chimney_x,
            y + abs_terrain_offset,
            chimney_z,
            None,
            Some(replace_any), // Empty blacklist = replace any block
        );
    }

    // Cap: 40% get an empty flower pot as a chimney pot, the rest a stone brick slab.
    let cap_y = chimney_base + chimney_height + abs_terrain_offset;
    if rng.random_bool(0.4) {
        editor.set_block_absolute(
            EMPTY_FLOWER_POT,
            chimney_x,
            cap_y,
            chimney_z,
            None,
            Some(replace_any),
        );
    } else {
        editor.set_block_absolute(
            STONE_BRICK_SLAB,
            chimney_x,
            cap_y,
            chimney_z,
            None,
            Some(replace_any), // Empty blacklist = replace any block
        );
    }
}

// ============================================================================
// Roof Terrace Generation
// ============================================================================

/// Generates a roof terrace on top of flat-roofed tall buildings (building:part).
///
/// Includes:
/// - Stone brick railing around the perimeter
/// - Scattered rooftop furniture/equipment (tables, ventilation units, planters, seating, antenna)
#[allow(clippy::too_many_arguments)]
fn generate_roof_terrace(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    floor_area: &[(i32, i32)],
    bounds: &BuildingBounds,
    roof_y: i32,
    abs_terrain_offset: i32,
) {
    if floor_area.is_empty() {
        return;
    }

    let replace_any: &[Block] = &[];
    // Flat roof is placed at (start_y_offset + building_height + 1 + abs_terrain_offset)
    // roof_y = start_y_offset + building_height, so terrace must be at roof_y + 2 to sit ON TOP of the roof
    let terrace_y = roof_y + abs_terrain_offset + 2;

    // Build a set for O(1) lookup of floor positions
    let floor_set: HashSet<(i32, i32)> = floor_area.iter().copied().collect();

    // --- Step 1: Railing around the perimeter ---
    // A perimeter block is one that has at least one cardinal neighbor NOT in the floor set
    for &(x, z) in floor_area {
        let neighbors = [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)];
        let is_edge = neighbors.iter().any(|n| !floor_set.contains(n));

        if is_edge {
            editor.set_block_absolute(STONE_BRICKS, x, terrace_y, z, None, Some(replace_any));
        }
    }

    // --- Step 2: Collect interior positions (non-edge blocks at least 1 from edge) ---
    let interior: Vec<(i32, i32)> = floor_area
        .iter()
        .filter(|&&(x, z)| {
            let neighbors = [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)];
            neighbors.iter().all(|n| floor_set.contains(n))
        })
        .copied()
        .collect();

    if interior.is_empty() {
        return;
    }

    // --- Step 3: Place rooftop furniture deterministically ---
    // Use coord_rng so each position is independently and deterministically decorated.
    // The low placement probability (15%) naturally creates spacing between items.

    // We iterate over interior positions and use coord_rng to decide what goes where.
    // This avoids RNG ordering issues and is fully deterministic per-position.
    for &(x, z) in &interior {
        // Deterministic per-position decision using coord_rng
        let mut rng = coord_rng(x, z, element.id);
        let roll: u32 = rng.random_range(0..100);

        // ~85% of interior tiles are empty (open terrace space)
        if roll >= 15 {
            continue;
        }

        // Among the 15% that get furniture, distribute types
        match roll {
            0..=2 => {
                // Ventilation unit: iron block with a slab on top
                editor.set_block_absolute(IRON_BLOCK, x, terrace_y, z, None, Some(replace_any));
                editor.set_block_absolute(
                    SMOOTH_STONE_SLAB,
                    x,
                    terrace_y + 1,
                    z,
                    None,
                    Some(replace_any),
                );
            }
            3..=5 => {
                // Planter: leaf block on top of cauldron
                editor.set_block_absolute(CAULDRON, x, terrace_y, z, None, Some(replace_any));
                // Vary the leaf type
                let leaf = match rng.random_range(0..3) {
                    0 => OAK_LEAVES,
                    1 => BIRCH_LEAVES,
                    _ => SPRUCE_LEAVES,
                };
                editor.set_block_absolute(leaf, x, terrace_y + 1, z, None, Some(replace_any));
            }
            6..=8 => {
                // Table: oak slab on top of an oak fence
                editor.set_block_absolute(OAK_FENCE, x, terrace_y, z, None, Some(replace_any));
                editor.set_block_absolute(OAK_SLAB, x, terrace_y + 1, z, None, Some(replace_any));
            }
            9..=10 => {
                // Seating: stairs block (looks like a bench/chair)
                editor.set_block_absolute(OAK_STAIRS, x, terrace_y, z, None, Some(replace_any));
            }
            11..=12 => {
                // Antenna / lightning rod
                editor.set_block_absolute(LIGHTNING_ROD, x, terrace_y, z, None, Some(replace_any));
            }
            13 => {
                // Cauldron (rain collector / decorative)
                editor.set_block_absolute(CAULDRON, x, terrace_y, z, None, Some(replace_any));
            }
            _ => {
                // Sea lantern (subtle rooftop light)
                editor.set_block_absolute(SEA_LANTERN, x, terrace_y, z, None, Some(replace_any));
            }
        }
    }

    // --- Step 4: Always place a lightning rod or antenna near the center (if space) ---
    let center_x = (bounds.min_x + bounds.max_x) / 2;
    let center_z = (bounds.min_z + bounds.max_z) / 2;

    // Find the interior point closest to center
    if let Some(&(cx, cz)) = interior
        .iter()
        .min_by_key(|&&(x, z)| (x - center_x).pow(2) + (z - center_z).pow(2))
    {
        // Tall antenna: 6 iron bars + lightning rod on top
        for dy in 0..6 {
            editor.set_block_absolute(IRON_BARS, cx, terrace_y + dy, cz, None, Some(replace_any));
        }
        editor.set_block_absolute(
            LIGHTNING_ROD,
            cx,
            terrace_y + 6,
            cz,
            None,
            Some(replace_any),
        );
    }
}

/// Determines whether a building should get a roof terrace.
///
/// Conditions:
/// - The element is a `building:part` (composite building component)
/// - Has a flat roof
/// - Is tall enough (skyscraper-class or very tall: height >= 28 blocks)
fn should_generate_roof_terrace(
    element: &ProcessedWay,
    config: &BuildingConfig,
    roof_type: RoofType,
) -> bool {
    let is_building_part = element.tags.contains_key("building:part");
    let is_flat = roof_type == RoofType::Flat;
    let is_very_tall = config.building_height >= 28;

    is_building_part && is_flat && is_very_tall
}

/// Determines whether a building should get sparse rooftop equipment (HVAC, solar panels).
///
/// Applies to flat-roofed commercial, office, industrial, warehouse, hospital, and hotel
/// buildings that are at least a few floors tall.
/// Lightning rod on top of peaked-roof houses, 5% chance.
fn generate_residential_antenna(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    roof_area: &[(i32, i32)],
    config: &BuildingConfig,
) {
    if roof_area.len() < 30 {
        return;
    }

    let mut rng = element_rng(element.id ^ 0x04E7_E44A);
    if !rng.random_bool(0.05) {
        return;
    }

    let footprint: HashSet<(i32, i32)> = roof_area.iter().copied().collect();
    let cx = roof_area.iter().map(|p| p.0).sum::<i32>() / roof_area.len() as i32;
    let cz = roof_area.iter().map(|p| p.1).sum::<i32>() / roof_area.len() as i32;

    let interior: Vec<(i32, i32)> = roof_area
        .iter()
        .filter(|&&(x, z)| {
            footprint.contains(&(x - 1, z))
                && footprint.contains(&(x + 1, z))
                && footprint.contains(&(x, z - 1))
                && footprint.contains(&(x, z + 1))
        })
        .copied()
        .collect();
    if interior.is_empty() {
        return;
    }
    let (best_x, best_z) = *interior
        .iter()
        .min_by_key(|&&(x, z)| (x - cx).pow(2) + (z - cz).pow(2))
        .unwrap();

    // The rod stands on the ridge as built, whatever rise the roof got.
    let wall_top = config.start_y_offset + config.building_height + config.abs_terrain_offset;
    let Some(ridge_y) = editor.highest_block_between(best_x, best_z, wall_top, wall_top + 96)
    else {
        return;
    };
    editor.set_block_absolute(LIGHTNING_ROD, best_x, ridge_y + 1, best_z, None, None);
}

fn should_generate_rooftop_equipment(
    config: &BuildingConfig,
    roof_type: RoofType,
    category: BuildingCategory,
) -> bool {
    let is_flat = roof_type == RoofType::Flat;
    let is_multi_floor = config.building_height >= 8;
    // Place rooftop equipment on any flat-roofed multi-floor building
    // except small residential houses, religious, and special types.
    let dominated_by_roof_elements = matches!(
        category,
        BuildingCategory::House
            | BuildingCategory::Farm
            | BuildingCategory::Garage
            | BuildingCategory::Shed
            | BuildingCategory::Greenhouse
            | BuildingCategory::Religious
    );

    is_flat && is_multi_floor && !dominated_by_roof_elements
}

/// Generates sparse rooftop equipment on flat-roofed commercial/institutional buildings.
///
/// Much sparser than the skyscraper roof terrace (~1% of interior tiles).
/// Equipment types:
/// - HVAC / ventilation units (iron block + slab)
/// - Solar panel clusters (daylight detectors in 5×4 fields)
/// - Antenna masts (iron bars + lightning rod)
/// - Water tanks (barrel + cauldron)
/// - Vent stacks (cobblestone wall columns)
/// - Roof access structures (2×2 stone brick box with slab cap)
fn generate_rooftop_equipment(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    floor_area: &[(i32, i32)],
    roof_y: i32,
    abs_terrain_offset: i32,
    reserved: Option<(i32, i32)>,
) {
    if floor_area.is_empty() {
        return;
    }

    let replace_any: &[Block] = &[];
    let equip_y = roof_y + abs_terrain_offset + 2; // On top of the flat roof surface

    // keep equipment off the outline ring where the parapet sits
    let raw_set: HashSet<(i32, i32)> = floor_area.iter().copied().collect();
    let floor_set: HashSet<(i32, i32)> = raw_set
        .iter()
        .filter(|&&(x, z)| {
            [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)]
                .iter()
                .all(|n| raw_set.contains(n))
        })
        .copied()
        .collect();

    // Collect interior positions (skip edge tiles to avoid overhanging equipment)
    let interior: Vec<(i32, i32)> = floor_area
        .iter()
        .filter(|&&(x, z)| {
            let neighbors = [
                (x - 1, z),
                (x + 1, z),
                (x, z - 1),
                (x, z + 1),
                (x - 1, z - 1),
                (x + 1, z + 1),
                (x - 1, z + 1),
                (x + 1, z - 1),
            ];
            neighbors.iter().all(|n| floor_set.contains(n))
        })
        .copied()
        .collect();

    if interior.is_empty() {
        return;
    }

    // Track which positions are already used (for solar panel clusters)
    let mut used: HashSet<(i32, i32)> = HashSet::new();
    if let Some((wx, wz)) = reserved {
        // Keep the water tower footprint and a margin clear.
        for dx in -3..=3 {
            for dz in -3..=3 {
                used.insert((wx + dx, wz + dz));
            }
        }
    }

    for &(x, z) in &interior {
        if used.contains(&(x, z)) {
            continue;
        }

        let mut rng = coord_rng(x, z, element.id ^ 0xE90B_375E_ED00_1001);
        let roll: u32 = rng.random_range(0..1200);

        // ~99% of tiles are empty, very sparse
        if roll >= 12 {
            continue;
        }

        match roll {
            0..=2 => {
                // HVAC / ventilation unit: iron block + smooth stone slab
                editor.set_block_absolute(IRON_BLOCK, x, equip_y, z, None, Some(replace_any));
                editor.set_block_absolute(
                    SMOOTH_STONE_SLAB,
                    x,
                    equip_y + 1,
                    z,
                    None,
                    Some(replace_any),
                );
                used.insert((x, z));
            }
            3..=5 => {
                // Solar panel cluster: four 5×4 fields in a 2×2 grid with 1-block gaps
                // Layout (top view, 11 wide × 9 deep):
                //   SSSSS . SSSSS
                //   SSSSS . SSSSS
                //   SSSSS . SSSSS
                //   SSSSS . SSSSS
                //   ..... . .....
                //   SSSSS . SSSSS
                //   SSSSS . SSSSS
                //   SSSSS . SSSSS
                //   SSSSS . SSSSS
                let quad_offsets: [(i32, i32); 4] = [(0, 0), (6, 0), (0, 5), (6, 5)];
                let quad_panels: Vec<(i32, i32)> = quad_offsets
                    .iter()
                    .flat_map(|&(ox, oz)| {
                        (0..5).flat_map(move |dx| (0..4).map(move |dz| (x + ox + dx, z + oz + dz)))
                    })
                    .collect();
                // Check that the entire 11×9 bounding box fits on the roof
                let bbox: Vec<(i32, i32)> = (0..11)
                    .flat_map(|dx| (0..9).map(move |dz| (x + dx, z + dz)))
                    .collect();
                let quad_ok = bbox
                    .iter()
                    .all(|pos| floor_set.contains(pos) && !used.contains(pos));

                if quad_ok {
                    for &(cx, cz) in &quad_panels {
                        editor.set_block_absolute(
                            DAYLIGHT_DETECTOR,
                            cx,
                            equip_y,
                            cz,
                            None,
                            Some(replace_any),
                        );
                    }
                    // Reserve the whole bounding box so nothing overlaps
                    for &(cx, cz) in &bbox {
                        used.insert((cx, cz));
                    }
                } else {
                    // Fall back to a single 5×4 field
                    let single_field: Vec<(i32, i32)> = (0..5)
                        .flat_map(|dx| (0..4).map(move |dz| (x + dx, z + dz)))
                        .collect();
                    let single_ok = single_field
                        .iter()
                        .all(|pos| floor_set.contains(pos) && !used.contains(pos));

                    if single_ok {
                        for &(cx, cz) in &single_field {
                            editor.set_block_absolute(
                                DAYLIGHT_DETECTOR,
                                cx,
                                equip_y,
                                cz,
                                None,
                                Some(replace_any),
                            );
                            used.insert((cx, cz));
                        }
                    } else {
                        // Not enough room, place a single daylight detector
                        editor.set_block_absolute(
                            DAYLIGHT_DETECTOR,
                            x,
                            equip_y,
                            z,
                            None,
                            Some(replace_any),
                        );
                        used.insert((x, z));
                    }
                }
            }
            6 => {
                // Small antenna mast: 2 iron bars + lightning rod
                editor.set_block_absolute(IRON_BARS, x, equip_y, z, None, Some(replace_any));
                editor.set_block_absolute(IRON_BARS, x, equip_y + 1, z, None, Some(replace_any));
                editor.set_block_absolute(
                    LIGHTNING_ROD,
                    x,
                    equip_y + 2,
                    z,
                    None,
                    Some(replace_any),
                );
                used.insert((x, z));
            }
            7..=8 => {
                // Water tank: barrel with cauldron on top
                editor.set_block_absolute(BARREL, x, equip_y, z, None, Some(replace_any));
                editor.set_block_absolute(CAULDRON, x, equip_y + 1, z, None, Some(replace_any));
                used.insert((x, z));
            }
            9..=10 => {
                // Vent stack: 2-3 cobblestone wall blocks tall
                let stack_h = rng.random_range(2i32..=3);
                for dy in 0..stack_h {
                    editor.set_block_absolute(
                        COBBLESTONE_WALL,
                        x,
                        equip_y + dy,
                        z,
                        None,
                        Some(replace_any),
                    );
                }
                used.insert((x, z));
            }
            _ => {
                // Roof access box: 2×2 stone brick structure (stairwell exit)
                let positions = [(x, z), (x + 1, z), (x, z + 1), (x + 1, z + 1)];
                let all_fit = positions
                    .iter()
                    .all(|pos| floor_set.contains(pos) && !used.contains(pos));
                if all_fit {
                    for &(bx, bz) in &positions {
                        editor.set_block_absolute(
                            STONE_BRICKS,
                            bx,
                            equip_y,
                            bz,
                            None,
                            Some(replace_any),
                        );
                        editor.set_block_absolute(
                            STONE_BRICKS,
                            bx,
                            equip_y + 1,
                            bz,
                            None,
                            Some(replace_any),
                        );
                        editor.set_block_absolute(
                            STONE_BRICK_SLAB,
                            bx,
                            equip_y + 2,
                            bz,
                            None,
                            Some(replace_any),
                        );
                        used.insert((bx, bz));
                    }
                }
            }
        }
    }
}

// ============================================================================
// Roof Generation
// ============================================================================

/// Configuration for roof generation
struct RoofConfig {
    min_x: i32,
    max_x: i32,
    min_z: i32,
    max_z: i32,
    center_x: i32,
    center_z: i32,
    base_height: i32,
    building_height: i32,
    abs_terrain_offset: i32,
    roof_block: Block,
    add_dormers: bool,
    element_id_for_decor: u64,
    /// Roof rise in blocks from a roof:height tag, overriding the heuristics.
    peak_cap: Option<i32>,
}

impl RoofConfig {
    /// Creates RoofConfig from roof area (includes wall outline for proper coverage)
    fn from_roof_area(
        roof_area: &[(i32, i32)],
        element_id: u64,
        start_y_offset: i32,
        building_height: i32,
        wall_block: Block,
        abs_terrain_offset: i32,
    ) -> Self {
        // Calculate bounds from the actual roof area (floor + walls)
        let (min_x, max_x, min_z, max_z) = roof_area.iter().fold(
            (i32::MAX, i32::MIN, i32::MAX, i32::MIN),
            |(min_x, max_x, min_z, max_z), &(x, z)| {
                (min_x.min(x), max_x.max(x), min_z.min(z), max_z.max(z))
            },
        );

        let center_x = (min_x + max_x) >> 1;
        let center_z = (min_z + max_z) >> 1;

        // Roof base_height is always at the roof line level (top of walls + 1)
        // This ensures the roof sits on top of the building consistently
        let base_height = start_y_offset + building_height + 1;

        let mut rng = element_rng(element_id ^ 0xA11E_D700_F1A7_5EED);

        // 15% stone bricks override regardless of wall.
        let mut stone_brick_rng = element_rng(element_id ^ 0x57_4F_E4_8B_1C_42_E0_91);
        let force_stone_bricks = stone_brick_rng.random_bool(0.15);

        // 10% same-family variety from the wall's substitute pool.
        let raw_roof = if force_stone_bricks {
            STONE_BRICKS
        } else if rng.random_bool(0.1) {
            let pool = substitute_pool_only(wall_block);
            if pool.is_empty() {
                wall_block
            } else {
                pool[rng.random_range(0..pool.len())]
            }
        } else {
            wall_block
        };
        let roof_block = roof_friendly_block(raw_roof);

        Self {
            min_x,
            max_x,
            min_z,
            max_z,
            center_x,
            center_z,
            base_height,
            building_height,
            abs_terrain_offset,
            roof_block,
            add_dormers: false,
            element_id_for_decor: element_id,
            peak_cap: None,
        }
    }

    fn width(&self) -> i32 {
        self.max_x - self.min_x
    }

    fn length(&self) -> i32 {
        self.max_z - self.min_z
    }
}

/// Checks if a point has any neighbor with lower height
#[inline]
fn has_lower_neighbor(
    x: i32,
    z: i32,
    roof_height: i32,
    roof_heights: &HashMap<(i32, i32), i32>,
) -> bool {
    [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)]
        .iter()
        .any(|(nx, nz)| {
            roof_heights
                .get(&(*nx, *nz))
                .is_some_and(|&nh| nh < roof_height)
        })
}

/// Drops of more than this many blocks to a lower neighbour are a face, not a
/// slope: a stair on top of such a column reads as a notch, a full block does
/// not. Gambrel bands drop two per cell and keep their stairs.
const MAX_STAIR_DROP: i32 = 2;

/// Whether the top block of a roof column faces a drop too steep for a stair.
#[inline]
fn steep_drop(x: i32, z: i32, roof_height: i32, roof_heights: &HashMap<(i32, i32), i32>) -> bool {
    [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)]
        .iter()
        .any(|(nx, nz)| {
            roof_heights
                .get(&(*nx, *nz))
                .is_some_and(|&nh| roof_height - nh > MAX_STAIR_DROP)
        })
}

/// Places 3-block-wide dormer protrusions along a pitched roof slope.
#[allow(clippy::too_many_arguments)]
fn place_dormer_windows(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    roof_heights: &HashMap<(i32, i32), i32>,
    edge_scans: &HashMap<(i32, i32), (i32, i32)>,
    config: &RoofConfig,
    parallel_to_ridge: (i32, i32),
    footprint: &HashSet<(i32, i32)>,
    mansard_band: Option<i32>,
) {
    if !config.add_dormers {
        return;
    }

    // second row at base+2/base+3, the mansard band comes from the caller
    let target_h = config.base_height + 2;
    let alt_target_h = config.base_height + 3;
    let (px, pz) = parallel_to_ridge;

    let mut candidates: Vec<(i32, i32, i32)> = Vec::new();
    for &(x, z) in floor_area {
        let h = match roof_heights.get(&(x, z)) {
            Some(&h) if h == target_h || h == alt_target_h || mansard_band == Some(h) => h,
            _ => continue,
        };

        let (dm_perp, dp_perp) = match edge_scans.get(&(x, z)) {
            Some(&pair) => pair,
            None => continue,
        };
        let max_perp = dm_perp.max(dp_perp);
        if max_perp < 4 {
            continue;
        }

        let left = (x - px, z - pz);
        let right = (x + px, z + pz);
        let same = roof_heights.get(&left) == Some(&h) && roof_heights.get(&right) == Some(&h);
        if !same {
            continue;
        }

        let further_left = (x - 2 * px, z - 2 * pz);
        let further_right = (x + 2 * px, z + 2 * pz);
        if !footprint.contains(&further_left) || !footprint.contains(&further_right) {
            continue;
        }

        // roof must keep rising inward, else capped flat tops sprout dormers
        let inward = if dm_perp <= dp_perp { 1 } else { -1 };
        let above = (x + pz * inward, z + px * inward);
        if roof_heights.get(&above).is_none_or(|&ah| ah <= h) {
            continue;
        }

        candidates.push((x, z, h));
    }

    if candidates.is_empty() {
        return;
    }

    candidates.sort_unstable();
    let target_count = (candidates.len() / 12).clamp(1, 3);

    let mut rng = element_rng(config.element_id_for_decor ^ 0x000D_04E4_DEC0);
    let mut chosen: Vec<(i32, i32, i32)> = Vec::new();
    let mut attempts = 0;
    while chosen.len() < target_count && attempts < candidates.len() * 4 {
        attempts += 1;
        let idx = rng.random_range(0..candidates.len());
        let pos = candidates[idx];
        // Ridge-axis spacing of at least 4 blocks between dormers.
        let too_close = chosen.iter().any(|&(cx, cz, _)| {
            let d = ((cx - pos.0) * px + (cz - pos.1) * pz).abs();
            d < 4
        });
        if !too_close {
            chosen.push(pos);
        }
    }

    // Cap ridge runs 90° to the main ridge.
    let (left_facing, right_facing) = if px != 0 {
        (StairFacing::East, StairFacing::West)
    } else {
        (StairFacing::South, StairFacing::North)
    };

    let perp_unit: (i32, i32) = if px != 0 { (0, 1) } else { (1, 0) };

    let abs = config.abs_terrain_offset;
    let stair_material = get_stair_block_for_material(config.roof_block);
    let glass = LIGHT_GRAY_STAINED_GLASS;
    let flank = config.roof_block;
    let cap_centre_block = config.roof_block;

    let overwrite_anything: &[Block] = &[];

    for (x, z, h) in chosen {
        let lower_y = h - 1 + abs;
        let face_y = h + abs;
        let cap_y = h + 1 + abs;

        // Outward perpendicular toward the closer eave so the extension hangs over it.
        let (dm_perp, dp_perp) = edge_scans.get(&(x, z)).copied().unwrap_or((1, 1));
        let outward_sign: i32 = if dm_perp <= dp_perp { -1 } else { 1 };
        let ox = perp_unit.0 * outward_sign;
        let oz = perp_unit.1 * outward_sign;

        let ext_x = x + ox;
        let ext_z = z + oz;
        // skip the extension when the outward cell leaves the footprint
        let ext_in = footprint.contains(&(ext_x, ext_z));

        // Lower base row: solid wall at the eave so the dormer reads as flush.
        editor.set_block_absolute(
            flank,
            x - px,
            lower_y,
            z - pz,
            None,
            Some(overwrite_anything),
        );
        editor.set_block_absolute(flank, x, lower_y, z, None, Some(overwrite_anything));
        editor.set_block_absolute(
            flank,
            x + px,
            lower_y,
            z + pz,
            None,
            Some(overwrite_anything),
        );
        if ext_in {
            editor.set_block_absolute(
                flank,
                ext_x - px,
                lower_y,
                ext_z - pz,
                None,
                Some(overwrite_anything),
            );
            editor.set_block_absolute(flank, ext_x, lower_y, ext_z, None, Some(overwrite_anything));
            editor.set_block_absolute(
                flank,
                ext_x + px,
                lower_y,
                ext_z + pz,
                None,
                Some(overwrite_anything),
            );
        }

        // Face row 1: wall+glass+wall, overwrites the slope stair.
        editor.set_block_absolute(
            flank,
            x - px,
            face_y,
            z - pz,
            None,
            Some(overwrite_anything),
        );
        editor.set_block_absolute(glass, x, face_y, z, None, Some(overwrite_anything));
        editor.set_block_absolute(
            flank,
            x + px,
            face_y,
            z + pz,
            None,
            Some(overwrite_anything),
        );

        // Face row 2: extends the dormer body one block outward over the eave.
        if ext_in {
            editor.set_block_absolute(
                flank,
                ext_x - px,
                face_y,
                ext_z - pz,
                None,
                Some(overwrite_anything),
            );
            editor.set_block_absolute(glass, ext_x, face_y, ext_z, None, Some(overwrite_anything));
            editor.set_block_absolute(
                flank,
                ext_x + px,
                face_y,
                ext_z + pz,
                None,
                Some(overwrite_anything),
            );
        }

        // Cap row 1: stair, full block, stair.
        editor.set_block_with_properties_absolute(
            create_stair_with_properties(stair_material, left_facing, StairShape::Straight),
            x - px,
            cap_y,
            z - pz,
            None,
            Some(overwrite_anything),
        );
        editor.set_block_absolute(
            cap_centre_block,
            x,
            cap_y,
            z,
            None,
            Some(overwrite_anything),
        );
        editor.set_block_with_properties_absolute(
            create_stair_with_properties(stair_material, right_facing, StairShape::Straight),
            x + px,
            cap_y,
            z + pz,
            None,
            Some(overwrite_anything),
        );

        // Cap row 2: mirrors row 1 over the extended face.
        if ext_in {
            editor.set_block_with_properties_absolute(
                create_stair_with_properties(stair_material, left_facing, StairShape::Straight),
                ext_x - px,
                cap_y,
                ext_z - pz,
                None,
                Some(overwrite_anything),
            );
            editor.set_block_absolute(
                cap_centre_block,
                ext_x,
                cap_y,
                ext_z,
                None,
                Some(overwrite_anything),
            );
            editor.set_block_with_properties_absolute(
                create_stair_with_properties(stair_material, right_facing, StairShape::Straight),
                ext_x + px,
                cap_y,
                ext_z + pz,
                None,
                Some(overwrite_anything),
            );
        }
    }
}

/// Places roof blocks for a given height map
fn place_roof_blocks_with_stairs(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    roof_heights: &HashMap<(i32, i32), i32>,
    config: &RoofConfig,
    stair_direction_fn: impl Fn(i32, i32, i32) -> BlockWithProperties,
    footprint: Option<&HashSet<(i32, i32)>>,
) {
    // Use empty blacklist to allow overwriting wall/ceiling blocks
    let replace_any: &[Block] = &[];

    for &(x, z) in floor_area {
        let roof_height = roof_heights[&(x, z)];

        for y in config.base_height..=roof_height {
            if y == roof_height {
                // Polygon-edge cells get stairs to continue the eave slope outward.
                let on_polygon_edge = footprint.is_some_and(|fp| {
                    [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)]
                        .iter()
                        .any(|n| !fp.contains(n))
                });
                let has_lower =
                    has_lower_neighbor(x, z, roof_height, roof_heights) || on_polygon_edge;
                if has_lower && !steep_drop(x, z, roof_height, roof_heights) {
                    let stair_block = stair_direction_fn(x, z, roof_height);
                    editor.set_block_with_properties_absolute(
                        stair_block,
                        x,
                        y + config.abs_terrain_offset,
                        z,
                        None,
                        Some(replace_any),
                    );
                } else {
                    editor.set_block_absolute(
                        config.roof_block,
                        x,
                        y + config.abs_terrain_offset,
                        z,
                        None,
                        Some(replace_any),
                    );
                }
            } else {
                editor.set_block_absolute(
                    config.roof_block,
                    x,
                    y + config.abs_terrain_offset,
                    z,
                    None,
                    Some(replace_any),
                );
            }
        }
    }
}

/// Generates a flat roof
fn generate_flat_roof(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    floor_block: Block,
    base_height: i32,
    abs_terrain_offset: i32,
) {
    // Use empty blacklist to allow overwriting wall/ceiling blocks
    let replace_any: &[Block] = &[];
    for &(x, z) in floor_area {
        editor.set_block_absolute(
            floor_block,
            x,
            base_height + abs_terrain_offset,
            z,
            None,
            Some(replace_any),
        );
    }
}

/// Generates a gabled roof
/// Variants of the two-slope roof family sharing the gabled scan.
#[derive(Copy, Clone, PartialEq)]
enum GableProfile {
    /// Classic gable, peak capped at 60% of the wall height.
    Standard,
    /// Steeper church-style gable (90% cap).
    Steep,
    /// Barn roof: 2:1 rise for the first two cells, then 1:1.
    Gambrel,
    /// Gable with hipped ends above half height.
    HalfHipped,
    /// Barrel vault: semi-elliptical section across the ridge.
    Round,
}

/// Feather sentinel for cells whose slope needs no scan clamp.
const NO_FEATHER: i32 = 10_000;

fn generate_gabled_roof(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    config: &RoofConfig,
    profile: GableProfile,
    ridge: &RidgeFrame,
) {
    // Create a HashSet for O(1) footprint lookups, this is the actual building shape
    let footprint: HashSet<(i32, i32)> = floor_area.iter().copied().collect();

    let ridge_runs_along_x = ridge.along_x;
    let tent = ridge.tent;

    // For each footprint position, scan all 4 cardinal directions to
    // find the distance to the nearest polygon edge.  This replaces an
    // older single-axis scan that only measured perpendicular to the
    // ridge, which failed on complex buildings (perimeter buildings,
    // L/U shapes with courtyards) where wings run in both directions.
    //
    // We store the perpendicular-to-ridge (dm_perp, dp_perp) per position
    // for stair facing direction, and also compute the cross-axis span
    // so we can cap roof height by the narrowest local wing width in
    // ANY direction.
    let mut edge_scans: HashMap<(i32, i32), (i32, i32)> = HashMap::new();

    // Helper: scan from (x,z) in a direction until leaving the footprint
    let scan_dir = |mut cx: i32, mut cz: i32, dx: i32, dz: i32| -> i32 {
        let mut dist = 0;
        loop {
            cx += dx;
            cz += dz;
            if !footprint.contains(&(cx, cz)) {
                break;
            }
            dist += 1;
        }
        dist
    };

    let mut roof_heights: HashMap<(i32, i32), i32> = HashMap::new();

    // Hard cap: the roof peak should not exceed a fraction of the wall height.
    let cap_factor = if profile == GableProfile::Steep {
        0.9
    } else {
        0.6
    };
    let wall_cap = config.peak_cap.unwrap_or_else(|| {
        ((config.building_height as f64) * cap_factor)
            .round()
            .max(1.0) as i32
    });

    struct PosData {
        dist_to_edge: i32,
        local_half: i32,
        /// Farthest a cell gets from the eaves across the ridge here: the
        /// half-span, one less on an even span whose middle falls between
        /// two cells.
        perp_reach: i32,
        dm_along: i32,
        dp_along: i32,
        scan_perp_min: i32,
    }
    let mut pos_data: HashMap<(i32, i32), PosData> = HashMap::new();
    let mut max_perp_half: i32 = 0;

    for &(x, z) in floor_area {
        let sm_z = scan_dir(x, z, 0, -1);
        let sp_z = scan_dir(x, z, 0, 1);
        let sm_x = scan_dir(x, z, -1, 0);
        let sp_x = scan_dir(x, z, 1, 0);
        // Tent frame: distances to the turned rectangle's sides, v standing
        // in for z and u for x; the scans still bound the hip ends and trim.
        let (dm_z, dp_z, dm_x, dp_x) = match tent {
            Some(t) => {
                // Whole cells in from each side: the outline cells sit up to
                // half a cell inside the ideal edge and must stay the eave.
                let (u, v) = t.uv(x, z);
                (
                    (v - t.v_min).floor().max(0.0) as i32,
                    (t.v_max - v).floor().max(0.0) as i32,
                    (u - t.u_min).floor().max(0.0) as i32,
                    (t.u_max - u).floor().max(0.0) as i32,
                )
            }
            None => (sm_z, sp_z, sm_x, sp_x),
        };

        let (dm_perp, dp_perp) = if ridge_runs_along_x {
            (dm_z, dp_z)
        } else {
            (dm_x, dp_x)
        };
        edge_scans.insert((x, z), (dm_perp, dp_perp));
        let (dm_along, dp_along) = if ridge_runs_along_x {
            (sm_x, sp_x)
        } else {
            (sm_z, sp_z)
        };
        // The planar tent meets its rectangle's sides on its own.
        let scan_perp_min = if tent.is_some() {
            NO_FEATHER
        } else if ridge_runs_along_x {
            sm_z.min(sp_z)
        } else {
            sm_x.min(sp_x)
        };

        let dist_to_edge = dm_perp.min(dp_perp);

        let half_z = (dm_z + dp_z + 1) / 2;
        let half_x = (dm_x + dp_x + 1) / 2;
        let local_half = half_z.min(half_x);

        let perp_half = (dm_perp + dp_perp + 1) / 2;
        if perp_half > max_perp_half {
            max_perp_half = perp_half;
        }

        pos_data.insert(
            (x, z),
            PosData {
                dist_to_edge,
                local_half,
                perp_reach: (dm_perp + dp_perp) / 2,
                dm_along,
                dp_along,
                scan_perp_min,
            },
        );
    }

    // Half-pitch when the capped flat ridge would be >= 4 blocks wide. Skipped under
    // an explicit cap, which it climbs too slowly to reach.
    let use_half_pitch = config.peak_cap.is_none()
        && !matches!(profile, GableProfile::Gambrel | GableProfile::Round)
        && max_perp_half - wall_cap >= 4;

    // A stated rise sets the pitch: the ridge reaches it at the middle of the
    // span, whether that is a shallow pediment or a steep 2:1 gable, instead
    // of a 1:1 slope cut off into a mesa or capped short of the mapped peak.
    let stated_pitch = config.peak_cap.filter(|_| profile != GableProfile::Gambrel);

    for &(x, z) in floor_area {
        let pd = &pos_data[&(x, z)];
        let (boost, capped_boost, feather) = if profile == GableProfile::Round {
            // Barrel vault: a semi-elliptical section, vertical at the eaves and
            // level at the crown, rising to the mapped roof:height or the cap.
            let cap = config.peak_cap.unwrap_or_else(|| {
                wall_cap.min(((pd.local_half as f64) * 0.85).round().max(1.0) as i32)
            });
            let reach = pd.perp_reach.max(1) as f64;
            let t = (1.0 - pd.dist_to_edge as f64 / reach).clamp(0.0, 1.0);
            let boost = (cap as f64 * (1.0 - t * t).sqrt()).round() as i32;
            (boost, cap.max(1), NO_FEATHER)
        } else if let Some(cap) = stated_pitch {
            let pitch = cap as f64 / pd.perp_reach.max(1) as f64;
            let boost = (pd.dist_to_edge as f64 * pitch).round() as i32;
            // Narrow wings climb at the same pitch and top out lower.
            let local = ((pd.local_half as f64 * pitch).round() as i32).clamp(1, cap.max(1));
            let feather = (pd.scan_perp_min as f64 * pitch).round() as i32;
            (boost, local, feather)
        } else {
            let slope_dist = if use_half_pitch {
                (pd.dist_to_edge + 1) / 2
            } else {
                pd.dist_to_edge
            };
            let boost = if profile == GableProfile::Gambrel {
                // 2 blocks per cell over the steep band, then 1 per cell.
                2 * slope_dist.min(2) + (slope_dist - 2).max(0)
            } else {
                slope_dist
            };
            let local_boost = ((pd.local_half as f64) * 0.85).round().max(1.0) as i32;
            (boost, local_boost.min(wall_cap), pd.scan_perp_min)
        };
        let mut roof_height =
            (config.base_height + boost).min(config.base_height + capped_boost) + 1;
        // no-op for the polygon scan, feathers the snap tent at rotated corners
        roof_height = roof_height.min(config.base_height + feather + 1);
        if profile == GableProfile::HalfHipped {
            // The hip only bites above half the peak near the gable ends.
            let hip_start = (wall_cap / 2).max(2);
            let hip_limit = config.base_height + hip_start + pd.dm_along.min(pd.dp_along) + 1;
            roof_height = roof_height.min(hip_limit);
        }
        roof_heights.insert((x, z), roof_height);
    }

    // median along the ridge evens rasterization wobble, identity when aligned.
    // A tent turned well off the grid has no wobble, only the true staircase
    // of its plane, which a median along a cardinal would erode.
    let smooth_along: (i32, i32) = if ridge_runs_along_x { (1, 0) } else { (0, 1) };
    let smooth = tent.is_none_or(|t| t.angle.to_degrees().abs() <= 12.0);
    let roof_heights: HashMap<(i32, i32), i32> = roof_heights
        .iter()
        .map(|(&(x, z), &h)| {
            let l = roof_heights.get(&(x - smooth_along.0, z - smooth_along.1));
            let r = roof_heights.get(&(x + smooth_along.0, z + smooth_along.1));
            let h = match (l, r) {
                (Some(&a), Some(&b)) if smooth => {
                    let mut t = [a, h, b];
                    t.sort_unstable();
                    t[1]
                }
                _ => h,
            };
            ((x, z), h)
        })
        .collect();

    let stair_block_material = get_stair_block_for_material(config.roof_block);
    let replace_any: &[Block] = &[];

    // Stairs on a slope face the ridge: a cell nearer the minus eave looks
    // toward the plus side. Eave cells are the same case with distance zero.
    // The perpendicular is taken in the ridge frame, so a turned tent's
    // stairs still face the nearest cardinal toward its own ridge.
    let (across_x, across_z) = ridge.across();
    let toward_plus = cardinal_for_vector(across_x, across_z);
    let toward_minus = cardinal_for_vector(-across_x, -across_z);
    let get_slope_stair = |x: i32, z: i32| -> BlockWithProperties {
        let closer_to_minus = edge_scans.get(&(x, z)).is_some_and(|&(dm, dp)| dm <= dp);
        let facing = if closer_to_minus {
            toward_plus
        } else {
            toward_minus
        };
        create_stair_with_properties(stair_block_material, facing, StairShape::Straight)
    };
    let get_outer_edge_stair = get_slope_stair;

    // Eave cells: on the grid, a cell missing its neighbour across the ridge;
    // in a tent, a cell on the turned rectangle's long sides, which is the
    // same test once the gable ends are told apart from the eaves.
    let is_eave_cell = |x: i32, z: i32| -> bool {
        match tent {
            Some(_) => {
                pos_data[&(x, z)].dist_to_edge == 0
                    && [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)]
                        .iter()
                        .any(|n| !footprint.contains(n))
            }
            None if ridge_runs_along_x => {
                !footprint.contains(&(x, z - 1)) || !footprint.contains(&(x, z + 1))
            }
            None => !footprint.contains(&(x - 1, z)) || !footprint.contains(&(x + 1, z)),
        }
    };

    // hip ends descend along the ridge, perp-only stairs would face sideways
    let along_descent_stair = |x: i32, z: i32, h: i32| -> Option<BlockWithProperties> {
        if profile != GableProfile::HalfHipped {
            return None;
        }
        let lower = |nx: i32, nz: i32| roof_heights.get(&(nx, nz)).is_some_and(|&nh| nh < h);
        let (am, ap, pm, pp) = if ridge_runs_along_x {
            (
                lower(x - 1, z),
                lower(x + 1, z),
                lower(x, z - 1),
                lower(x, z + 1),
            )
        } else {
            (
                lower(x, z - 1),
                lower(x, z + 1),
                lower(x - 1, z),
                lower(x + 1, z),
            )
        };
        if pm || pp || am == ap {
            return None;
        }
        let facing = match (ridge_runs_along_x, am) {
            (true, true) => StairFacing::East,
            (true, false) => StairFacing::West,
            (false, true) => StairFacing::South,
            (false, false) => StairFacing::North,
        };
        Some(create_stair_with_properties(
            stair_block_material,
            facing,
            StairShape::Straight,
        ))
    };

    for &(x, z) in floor_area {
        let roof_height = roof_heights[&(x, z)];

        if is_eave_cell(x, z) {
            // Roof_block at base, stair at base+1.
            editor.set_block_absolute(
                config.roof_block,
                x,
                config.base_height + config.abs_terrain_offset,
                z,
                None,
                Some(replace_any),
            );
            editor.set_block_with_properties_absolute(
                get_outer_edge_stair(x, z),
                x,
                config.base_height + 1 + config.abs_terrain_offset,
                z,
                None,
                Some(replace_any),
            );
        } else {
            // Inner positions: fill from base_height to roof_height
            let has_lower_neighbor =
                [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)]
                    .iter()
                    .any(|&(nx, nz)| {
                        roof_heights
                            .get(&(nx, nz))
                            .is_some_and(|&nh| nh < roof_height)
                    });

            let steep = steep_drop(x, z, roof_height, &roof_heights);
            for y in config.base_height..=roof_height {
                if y == roof_height && has_lower_neighbor && !steep {
                    let stair = along_descent_stair(x, z, roof_height)
                        .unwrap_or_else(|| get_slope_stair(x, z));
                    editor.set_block_with_properties_absolute(
                        stair,
                        x,
                        y + config.abs_terrain_offset,
                        z,
                        None,
                        None,
                    );
                } else {
                    editor.set_block_absolute(
                        config.roof_block,
                        x,
                        y + config.abs_terrain_offset,
                        z,
                        None,
                        None,
                    );
                }
            }
        }
    }

    // Gable-end trim: the roof line continues one block past the gable face.
    if profile != GableProfile::HalfHipped {
        let along: (i32, i32) = if ridge_runs_along_x { (1, 0) } else { (0, 1) };
        for &(x, z) in floor_area {
            let pd = &pos_data[&(x, z)];
            if is_eave_cell(x, z) {
                continue;
            }
            let h = roof_heights[&(x, z)];
            // skip flat cap cells only, half-pitch treads pair equal heights
            let (pdx, pdz) = if ridge_runs_along_x { (0, 1) } else { (1, 0) };
            let flat_here = [(x - pdx, z - pdz), (x + pdx, z + pdz)]
                .iter()
                .all(|n| roof_heights.get(n).is_none_or(|&nh| nh == h));
            if flat_here {
                continue;
            }
            for (end_zero, sign) in [(pd.dm_along == 0, -1), (pd.dp_along == 0, 1)] {
                if !end_zero {
                    continue;
                }
                let tx = x + along.0 * sign;
                let tz = z + along.1 * sign;
                if footprint.contains(&(tx, tz)) {
                    continue;
                }
                editor.set_block_with_properties_absolute(
                    get_slope_stair(x, z),
                    tx,
                    h + config.abs_terrain_offset,
                    tz,
                    Some(&[AIR]),
                    None,
                );
            }
        }
    }

    // Dormers step along the grid; past a slight turn they no longer sit
    // on the slope, and a vault has no slope to sit on.
    let dormers_fit =
        profile != GableProfile::Round && tent.is_none_or(|t| t.angle.to_degrees().abs() <= 12.0);
    if dormers_fit {
        let parallel_to_ridge = if ridge_runs_along_x { (1, 0) } else { (0, 1) };
        place_dormer_windows(
            editor,
            floor_area,
            &roof_heights,
            &edge_scans,
            config,
            parallel_to_ridge,
            &footprint,
            None,
        );
    }

    // 2-block eave overhang on the slope sides (perpendicular to the ridge).
    // A turned tent hangs it from its long sides only, not the gable ends.
    let eave_cells: Option<HashSet<(i32, i32)>> = tent.map(|_| {
        floor_area
            .iter()
            .copied()
            .filter(|&(x, z)| is_eave_cell(x, z))
            .collect()
    });
    place_eave_overhang(
        editor,
        floor_area,
        &footprint,
        config,
        stair_block_material,
        ridge_runs_along_x,
        eave_cells.as_ref(),
    );
}

// 2-block-deep eave overhang on slope sides only (gabled).
fn place_eave_overhang(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    footprint: &HashSet<(i32, i32)>,
    config: &RoofConfig,
    stair_block_material: Block,
    ridge_runs_along_x: bool,
    eave_cells: Option<&HashSet<(i32, i32)>>,
) {
    place_eave_overhang_inner(
        editor,
        floor_area,
        footprint,
        config,
        stair_block_material,
        Some(ridge_runs_along_x),
        eave_cells,
    );
}

fn place_eave_overhang_all_sides(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    footprint: &HashSet<(i32, i32)>,
    config: &RoofConfig,
    stair_block_material: Block,
) {
    place_eave_overhang_inner(
        editor,
        floor_area,
        footprint,
        config,
        stair_block_material,
        None,
        None,
    );
}

fn place_eave_overhang_inner(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    footprint: &HashSet<(i32, i32)>,
    config: &RoofConfig,
    stair_block_material: Block,
    ridge_runs_along_x: Option<bool>,
    // Only these cells seed an overhang; None means every edge cell does.
    eave_cells: Option<&HashSet<(i32, i32)>>,
) {
    let abs = config.abs_terrain_offset;
    let y_inner = config.base_height + abs;
    let y_outer = config.base_height - 1 + abs;

    let dirs: &[(i32, i32, StairFacing)] = match ridge_runs_along_x {
        Some(true) => &[(0, -1, StairFacing::South), (0, 1, StairFacing::North)],
        Some(false) => &[(-1, 0, StairFacing::East), (1, 0, StairFacing::West)],
        None => &[
            (-1, 0, StairFacing::East),
            (1, 0, StairFacing::West),
            (0, -1, StairFacing::South),
            (0, 1, StairFacing::North),
        ],
    };

    let mut inner_cells: HashMap<(i32, i32), StairFacing> = HashMap::new();
    let mut outer_cells: HashMap<(i32, i32), StairFacing> = HashMap::new();

    for &(x, z) in floor_area {
        if eave_cells.is_some_and(|cells| !cells.contains(&(x, z))) {
            continue;
        }
        for &(dx, dz, facing) in dirs {
            let n1 = (x + dx, z + dz);
            let n2 = (x + 2 * dx, z + 2 * dz);
            if footprint.contains(&n1) {
                continue;
            }
            inner_cells.entry(n1).or_insert(facing);
            if !footprint.contains(&n2) {
                outer_cells.entry(n2).or_insert(facing);
            }
        }
    }

    // Fill the four diagonal eave cells at each polygon corner (hipped only).
    let mut diag_inner: HashMap<(i32, i32), (StairFacing, StairShape)> = HashMap::new();
    let mut diag_outer: HashMap<(i32, i32), (StairFacing, StairShape)> = HashMap::new();
    let mut diag_l_arm: HashMap<(i32, i32), StairFacing> = HashMap::new();

    if ridge_runs_along_x.is_none() {
        // dx, dz, corner facing+shape, x-arm facing, z-arm facing.
        let corner_dirs: &[(i32, i32, StairFacing, StairShape, StairFacing, StairFacing)] = &[
            (
                -1,
                -1,
                StairFacing::East,
                StairShape::OuterRight,
                StairFacing::East,
                StairFacing::South,
            ),
            (
                1,
                -1,
                StairFacing::South,
                StairShape::OuterRight,
                StairFacing::West,
                StairFacing::South,
            ),
            (
                -1,
                1,
                StairFacing::East,
                StairShape::OuterLeft,
                StairFacing::East,
                StairFacing::North,
            ),
            (
                1,
                1,
                StairFacing::North,
                StairShape::OuterLeft,
                StairFacing::West,
                StairFacing::North,
            ),
        ];

        for &(x, z) in floor_area {
            for &(dx, dz, corner_facing, corner_shape, x_arm_facing, z_arm_facing) in corner_dirs {
                if footprint.contains(&(x + dx, z)) || footprint.contains(&(x, z + dz)) {
                    continue;
                }
                let inner_corner = (x + dx, z + dz);
                let outer_corner = (x + 2 * dx, z + 2 * dz);
                let l_arm_x = (x + 2 * dx, z + dz);
                let l_arm_z = (x + dx, z + 2 * dz);

                diag_inner
                    .entry(inner_corner)
                    .or_insert((corner_facing, corner_shape));
                diag_outer
                    .entry(outer_corner)
                    .or_insert((corner_facing, corner_shape));
                diag_l_arm.entry(l_arm_x).or_insert(x_arm_facing);
                diag_l_arm.entry(l_arm_z).or_insert(z_arm_facing);
            }
        }
    }

    for (cell, facing) in &inner_cells {
        let stair =
            create_stair_with_properties(stair_block_material, *facing, StairShape::Straight);
        editor.set_block_with_properties_absolute(stair, cell.0, y_inner, cell.1, None, None);
    }
    for (cell, (facing, shape)) in &diag_inner {
        if inner_cells.contains_key(cell) {
            continue;
        }
        let stair = create_stair_with_properties(stair_block_material, *facing, *shape);
        editor.set_block_with_properties_absolute(stair, cell.0, y_inner, cell.1, None, None);
    }
    // Outer ring skips cells already claimed by the inner or corner ring.
    for (cell, facing) in &outer_cells {
        if inner_cells.contains_key(cell) || diag_inner.contains_key(cell) {
            continue;
        }
        let stair =
            create_stair_with_properties(stair_block_material, *facing, StairShape::Straight);
        editor.set_block_with_properties_absolute(stair, cell.0, y_outer, cell.1, None, None);
    }
    for (cell, (facing, shape)) in &diag_outer {
        if inner_cells.contains_key(cell)
            || outer_cells.contains_key(cell)
            || diag_inner.contains_key(cell)
        {
            continue;
        }
        let stair = create_stair_with_properties(stair_block_material, *facing, *shape);
        editor.set_block_with_properties_absolute(stair, cell.0, y_outer, cell.1, None, None);
    }
    for (cell, facing) in &diag_l_arm {
        if inner_cells.contains_key(cell)
            || outer_cells.contains_key(cell)
            || diag_inner.contains_key(cell)
            || diag_outer.contains_key(cell)
        {
            continue;
        }
        let stair =
            create_stair_with_properties(stair_block_material, *facing, StairShape::Straight);
        editor.set_block_with_properties_absolute(stair, cell.0, y_outer, cell.1, None, None);
    }
}

/// Hipped roof via polygon-edge scanning, capped at 60% of wall height.
fn generate_hipped_roof(editor: &mut WorldEditor, floor_area: &[(i32, i32)], config: &RoofConfig) {
    generate_hipped_roof_inner(editor, floor_area, config, true, None);
}

/// Mansard roof: the hipped scan with a piecewise profile.
fn generate_mansard_roof(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    config: &RoofConfig,
    steep_h: i32,
) {
    generate_hipped_roof_inner(editor, floor_area, config, true, Some(steep_h));
}

/// Height boost of a mansard profile at `dist_to_edge`: a steep 2-cell band
/// rising to `steep_h`, then a shallow 1:2 slope, capped at `cap`.
fn mansard_boost(dist_to_edge: i32, steep_h: i32, cap: i32) -> i32 {
    const STEEP_RUN: i32 = 2;
    let steep = (dist_to_edge.min(STEEP_RUN) * steep_h + STEEP_RUN - 1) / STEEP_RUN;
    let shallow = (dist_to_edge - STEEP_RUN).max(0) / 2;
    (steep + shallow).min(cap)
}

fn generate_hipped_roof_inner(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    config: &RoofConfig,
    with_overhang: bool,
    mansard_steep_h: Option<i32>,
) {
    let footprint: HashSet<(i32, i32)> = floor_area.iter().copied().collect();

    // Scan from (x,z) in one cardinal direction until leaving the footprint.
    let scan_dir = |mut cx: i32, mut cz: i32, dx: i32, dz: i32| -> i32 {
        let mut dist = 0;
        loop {
            cx += dx;
            cz += dz;
            if !footprint.contains(&(cx, cz)) {
                break;
            }
            dist += 1;
        }
        dist
    };

    let wall_cap = config
        .peak_cap
        .unwrap_or_else(|| ((config.building_height as f64) * 0.6).round().max(1.0) as i32);

    // --- First pass: gather per-position edge distances ---
    struct PosData {
        /// Minimum distance to polygon edge in any of the 4 cardinal dirs
        dist_to_edge: i32,
        /// The narrowest local half-span (min of the two cross-axis halves)
        local_half: i32,
        /// Farthest a cell gets from the eaves here: `local_half`, one less
        /// on an even span whose middle falls between two cells.
        local_reach: i32,
        /// Which cardinal direction had the shortest distance (for stair facing).
        /// 0 = -X, 1 = +X, 2 = -Z, 3 = +Z
        closest_dir: u8,
    }
    let mut pos_data: HashMap<(i32, i32), PosData> = HashMap::new();
    let mut max_full_span: i32 = 0;
    // Perpendicular-to-ridge scans for dormer placement (ridge = longer axis).
    let ridge_runs_along_x = config.width() >= config.length();
    let mut edge_scans: HashMap<(i32, i32), (i32, i32)> = HashMap::new();

    for &(x, z) in floor_area {
        let dm_x = scan_dir(x, z, -1, 0);
        let dp_x = scan_dir(x, z, 1, 0);
        let dm_z = scan_dir(x, z, 0, -1);
        let dp_z = scan_dir(x, z, 0, 1);
        edge_scans.insert(
            (x, z),
            if ridge_runs_along_x {
                (dm_z, dp_z)
            } else {
                (dm_x, dp_x)
            },
        );

        let dists = [dm_x, dp_x, dm_z, dp_z];
        let dist_to_edge = *dists.iter().min().unwrap();

        let closest_dir = if dist_to_edge == dm_x {
            0u8
        } else if dist_to_edge == dp_x {
            1
        } else if dist_to_edge == dm_z {
            2
        } else {
            3
        };

        let half_x = (dm_x + dp_x + 1) / 2;
        let half_z = (dm_z + dp_z + 1) / 2;
        let local_half = half_x.min(half_z);
        let local_reach = ((dm_x + dp_x) / 2).min((dm_z + dp_z) / 2);

        let full_span = half_x.max(half_z);
        if full_span > max_full_span {
            max_full_span = full_span;
        }

        pos_data.insert(
            (x, z),
            PosData {
                dist_to_edge,
                local_half,
                local_reach,
                closest_dir,
            },
        );
    }

    // As in the gabled path. max_full_span is the long half-span while a hip slopes
    // across dist_to_edge, so this gate is doubly unfit for a stated rise.
    let use_half_pitch = config.peak_cap.is_none() && max_full_span - wall_cap >= 4;

    let mut roof_heights: HashMap<(i32, i32), i32> = HashMap::new();

    let lift = if with_overhang { 1 } else { 0 };

    for &(x, z) in floor_area {
        let pd = &pos_data[&(x, z)];
        let roof_height = if let Some(steep_h) = mansard_steep_h {
            // Mansard: piecewise profile with its own cap; the local wing
            // width still caps narrow wings so they don't overshoot.
            let cap = wall_cap.max(steep_h + 2).min(config.building_height.max(3));
            let local_cap = ((pd.local_half as f64) * 0.9).round().max(1.0) as i32 + steep_h;
            config.base_height + mansard_boost(pd.dist_to_edge, steep_h, cap.min(local_cap)) + lift
        } else if let Some(cap) = config.peak_cap {
            // A stated rise sets the pitch across the local half-span, so the
            // ridge reaches it at the middle instead of a 1:1 slope cut into a
            // mesa or capped short of the mapped peak.
            let pitch = cap as f64 / pd.local_reach.max(1) as f64;
            let boost = ((pd.dist_to_edge as f64 * pitch).round() as i32).clamp(0, cap.max(1));
            config.base_height + boost + lift
        } else {
            let slope_dist = if use_half_pitch {
                (pd.dist_to_edge + 1) / 2
            } else {
                pd.dist_to_edge
            };
            let local_boost = ((pd.local_half as f64) * 0.85).round().max(1.0) as i32;
            let capped_boost = local_boost.min(wall_cap);
            (config.base_height + slope_dist).min(config.base_height + capped_boost) + lift
        };
        roof_heights.insert((x, z), roof_height);
    }

    // --- Place blocks with stair facing toward nearest polygon edge ---
    let stair_block_material = get_stair_block_for_material(config.roof_block);

    place_roof_blocks_with_stairs(
        editor,
        floor_area,
        &roof_heights,
        config,
        |x, z, h| {
            let north_h = roof_heights
                .get(&(x, z - 1))
                .copied()
                .unwrap_or(config.base_height);
            let south_h = roof_heights
                .get(&(x, z + 1))
                .copied()
                .unwrap_or(config.base_height);
            let west_h = roof_heights
                .get(&(x - 1, z))
                .copied()
                .unwrap_or(config.base_height);
            let east_h = roof_heights
                .get(&(x + 1, z))
                .copied()
                .unwrap_or(config.base_height);
            let lower_n = north_h < h;
            let lower_s = south_h < h;
            let lower_w = west_h < h;
            let lower_e = east_h < h;
            let lower_count =
                (lower_n as i32) + (lower_s as i32) + (lower_w as i32) + (lower_e as i32);

            // Outer corner - exactly 2 perpendicular sides lower.
            if lower_count == 2 {
                if lower_n && lower_w {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::East,
                        StairShape::OuterRight,
                    );
                }
                if lower_n && lower_e {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::South,
                        StairShape::OuterRight,
                    );
                }
                if lower_s && lower_w {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::East,
                        StairShape::OuterLeft,
                    );
                }
                if lower_s && lower_e {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::North,
                        StairShape::OuterLeft,
                    );
                }
                // 2-opposite (N+S or W+E): on a "ridge" - fall through.
            }

            // Single-sided slope (exactly one lower).
            if lower_count == 1 {
                if lower_n {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::South,
                        StairShape::Straight,
                    );
                }
                if lower_s {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::North,
                        StairShape::Straight,
                    );
                }
                if lower_w {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::East,
                        StairShape::Straight,
                    );
                }
                if lower_e {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::West,
                        StairShape::Straight,
                    );
                }
            }

            // Diamond tip: face the only higher direction.
            if lower_count == 3 {
                if !lower_n {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::North,
                        StairShape::Straight,
                    );
                }
                if !lower_s {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::South,
                        StairShape::Straight,
                    );
                }
                if !lower_w {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::West,
                        StairShape::Straight,
                    );
                }
                if !lower_e {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::East,
                        StairShape::Straight,
                    );
                }
            }

            // Plateau or apex: fall back to the closest-edge heuristic.
            let dir = pos_data.get(&(x, z)).map(|pd| pd.closest_dir).unwrap_or(0);
            match dir {
                0 => {
                    // Closest edge is -X, stair faces east (toward centre)
                    create_stair_with_properties(
                        stair_block_material,
                        StairFacing::East,
                        StairShape::Straight,
                    )
                }
                1 => {
                    // Closest edge is +X, stair faces west
                    create_stair_with_properties(
                        stair_block_material,
                        StairFacing::West,
                        StairShape::Straight,
                    )
                }
                2 => {
                    // Closest edge is -Z, stair faces south
                    create_stair_with_properties(
                        stair_block_material,
                        StairFacing::South,
                        StairShape::Straight,
                    )
                }
                _ => {
                    // Closest edge is +Z, stair faces north
                    create_stair_with_properties(
                        stair_block_material,
                        StairFacing::North,
                        StairShape::Straight,
                    )
                }
            }
        },
        Some(&footprint),
    );

    if with_overhang {
        place_eave_overhang_all_sides(editor, floor_area, &footprint, config, stair_block_material);
    }

    let parallel_to_ridge = if ridge_runs_along_x { (1, 0) } else { (0, 1) };
    let mansard_band = mansard_steep_h.map(|sh| config.base_height + (sh + 1) / 2 + lift);
    place_dormer_windows(
        editor,
        floor_area,
        &roof_heights,
        &edge_scans,
        config,
        parallel_to_ridge,
        &footprint,
        mansard_band,
    );
}

/// Parses `roof:direction` (compass point or degrees) to the nearest cardinal.
/// `roof:direction` as a compass bearing in degrees (0 = north, clockwise),
/// from a compass point or a number.
fn parse_roof_direction_degrees(value: &str) -> Option<f64> {
    let deg = match value.trim().to_ascii_lowercase().as_str() {
        "n" | "north" => 0.0,
        "ne" => 45.0,
        "e" | "east" => 90.0,
        "se" => 135.0,
        "s" | "south" => 180.0,
        "sw" => 225.0,
        "w" | "west" => 270.0,
        "nw" => 315.0,
        other => other.parse::<f64>().ok()?,
    };
    deg.is_finite().then(|| deg.rem_euclid(360.0))
}

/// The cardinal a bearing rounds to; stairs can only face those four.
fn cardinal_for_bearing(deg: f64) -> StairFacing {
    match ((deg / 90.0).round() as i64).rem_euclid(4) {
        0 => StairFacing::North,
        1 => StairFacing::East,
        2 => StairFacing::South,
        _ => StairFacing::West,
    }
}

/// Unit vector along a compass bearing in world coordinates: north is -Z,
/// east is +X.
fn bearing_unit_vector(deg: f64) -> (f64, f64) {
    let rad = deg.to_radians();
    (rad.sin(), -rad.cos())
}

/// Extent of the roof bounding box along a bearing, in cells: what a
/// mono-pitch roof descending that way climbs over.
fn bbox_extent_along_bearing(width: i32, length: i32, deg: f64) -> f64 {
    let (dx, dz) = bearing_unit_vector(deg);
    (width as f64 * dx).abs() + (length as f64 * dz).abs()
}

/// Roof rise in blocks, from roof:height if mapped, else from the roof:angle pitch.
/// Only roof:height is rescaled; the angle applies to a span already in blocks.
fn roof_peak_cap(
    tags: &HashMap<String, String>,
    roof_type: RoofType,
    config: &RoofConfig,
    ridge: &RidgeFrame,
    scale_factor: f64,
) -> Option<i32> {
    if let Some(m) = tags
        .get("roof:height")
        .and_then(|v| v.trim_end_matches('m').trim().parse::<f64>().ok())
        .filter(|m| *m > 0.0)
    {
        return Some(multiply_scale(m.round() as i32, scale_factor).max(1));
    }

    // These shapes never read peak_cap as a pitch.
    if matches!(
        roof_type,
        RoofType::Flat | RoofType::Dome | RoofType::Cone | RoofType::Onion
    ) {
        return None;
    }

    let deg = tags
        .get("roof:angle")
        .and_then(|v| v.trim_end_matches('\u{b0}').trim().parse::<f64>().ok())
        .filter(|d| *d > 0.0 && *d < 90.0)?;

    // width()/length() are bbox extents, one less than the span in cells.
    let w = config.width() + 1;
    let l = config.length() + 1;

    let run = match roof_type {
        // A skillion climbs its whole run along the mapped bearing, as the
        // generator does; untagged it crosses the shorter axis.
        RoofType::Skillion => match tags
            .get("roof:direction")
            .map(|s| s.as_str())
            .and_then(parse_roof_direction_degrees)
        {
            Some(deg) => bbox_extent_along_bearing(w, l, deg).max(1.0),
            None => w.min(l) as f64,
        },
        // These slope over the shorter half-span in every direction.
        RoofType::Hipped | RoofType::Mansard | RoofType::Pyramidal => w.min(l) as f64 / 2.0,
        // Slopes across the ridge, in the frame generate_gabled_roof uses.
        _ => ridge.span_cells(config.width(), config.length()) / 2.0,
    };

    let rise = (deg.to_radians().tan() * run).round().max(1.0) as i32;
    // An inferred rise still stays under the walls, as the mansard path bounds it.
    Some(rise.min(config.building_height.max(3)))
}

/// Skillion (mono-pitch) roof descending toward `roof:direction`, or across the shorter axis.
///
/// The bearing is used as mapped, not snapped to a cardinal: the roof plane
/// is laid along it, so a wing rotated off the grid, or a chamfer whose low
/// corner points diagonally, still meets its neighbours flush. A mapped
/// `roof:height` is the full rise; only the inferred rise is kept shallow.
fn generate_skillion_roof(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    config: &RoofConfig,
    roof_direction: Option<&str>,
) {
    let downhill_deg = roof_direction
        .and_then(parse_roof_direction_degrees)
        .unwrap_or_else(|| {
            let mut rng = element_rng(config.element_id_for_decor ^ 0x5C11_1104_D129_0000);
            let flip = rng.random_bool(0.5);
            if config.width() <= config.length() {
                if flip {
                    270.0
                } else {
                    90.0
                }
            } else if flip {
                0.0
            } else {
                180.0
            }
        });
    let (dx, dz) = bearing_unit_vector(downhill_deg);

    // Cells projected onto the downhill axis: the eave sits at the far end,
    // the ridge at the near end, whatever the footprint's shape.
    let (mut p_min, mut p_max) = (f64::MAX, f64::MIN);
    for &(x, z) in floor_area {
        let p = x as f64 * dx + z as f64 * dz;
        p_min = p_min.min(p);
        p_max = p_max.max(p);
    }
    let run = (p_max - p_min).max(1.0);

    // An inferred rise follows the run and stays below the wall height.
    let max_roof_height = config.peak_cap.map_or_else(
        || {
            (run as i32 / 3)
                .clamp(2, 10)
                .min(((config.building_height as f64) * 0.9).round().max(1.0) as i32)
        },
        |p| p.max(1),
    );

    // Stairs face uphill, opposite the downhill direction.
    let stair_facing = cardinal_for_bearing(downhill_deg + 180.0);

    let mut roof_heights = HashMap::new();
    for &(x, z) in floor_area {
        let p = x as f64 * dx + z as f64 * dz;
        let slope_progress = (p_max - p) / run;
        let roof_height = config.base_height + (slope_progress * max_roof_height as f64) as i32;
        roof_heights.insert((x, z), roof_height);
    }

    let stair_block_material = get_stair_block_for_material(config.roof_block);

    place_roof_blocks_with_stairs(
        editor,
        floor_area,
        &roof_heights,
        config,
        |_, _, _| {
            create_stair_with_properties(stair_block_material, stair_facing, StairShape::Straight)
        },
        None,
    );
}

/// How far a ray may run outside the footprint and still count as having
/// grazed it rather than crossed open ground. Rasterised curves and clipped
/// vertices stay far under one cell; a real notch is several.
const MAX_GRAZE_GAP: f64 = 1.0;

/// Even-odd point-in-polygon test on the polygon's own coordinates.
fn polygon_contains(pts: &[(f64, f64)], x: f64, z: f64) -> bool {
    let mut inside = false;
    let n = pts.len();
    for i in 0..n {
        let (x0, z0) = pts[i];
        let (x1, z1) = pts[(i + 1) % n];
        if (z0 > z) != (z1 > z) {
            let cross = x0 + (z - z0) * (x1 - x0) / (z1 - z0);
            if cross > x {
                inside = !inside;
            }
        }
    }
    inside
}

/// Radial fraction of every roof cell within the footprint polygon: 0 at
/// the area centroid, 1 on the outline, measured along the ray from the
/// centroid through the cell. Its level sets are scaled copies of the
/// outline, so a roof built on it is a pyramid over a rotated square, a cone
/// over a circle, or an ellipsoid over a rotated ellipse, each meeting its
/// eave on every wall. The bounding box the fallbacks use only manages that
/// for axis-aligned rectangles.
///
/// None unless the footprint is star-shaped about that centroid, i.e. every
/// cell is reached by a ray that stays inside it. A courtyard block whose
/// centroid sits in its thick base still hides the inner faces of its wings
/// behind open ground, and a ray that crosses that ground measures the cell
/// against the far side of the wing, so the roof there rides too high and
/// never comes down to the wing's own wall. Those footprints keep the
/// bounding-box profile instead.
fn footprint_radial_fractions(
    nodes: &[ProcessedNode],
    cells: &[(i32, i32)],
) -> Option<HashMap<(i32, i32), f64>> {
    let mut pts: Vec<(f64, f64)> = nodes.iter().map(|n| (n.x as f64, n.z as f64)).collect();
    if pts.len() >= 2 && pts.first() == pts.last() {
        pts.pop();
    }
    pts.dedup();
    if pts.len() < 3 {
        return None;
    }
    let n = pts.len();

    // Area centroid: a run of dense nodes on one wall must not pull it over.
    let (mut area2, mut cx, mut cz) = (0.0f64, 0.0f64, 0.0f64);
    for i in 0..n {
        let (x0, z0) = pts[i];
        let (x1, z1) = pts[(i + 1) % n];
        let cross = x0 * z1 - x1 * z0;
        area2 += cross;
        cx += (x0 + x1) * cross;
        cz += (z0 + z1) * cross;
    }
    if area2.abs() < 1e-9 {
        return None;
    }
    let (cx, cz) = (cx / (3.0 * area2), cz / (3.0 * area2));
    if !polygon_contains(&pts, cx, cz) {
        return None;
    }

    // Edges bucketed by the bearings they cover from the centroid, so a cell
    // tests the few edges its ray can cross rather than the whole outline.
    const BUCKETS: usize = 512;
    let bucket_of = |ang: f64| -> usize {
        (((ang + std::f64::consts::PI) / std::f64::consts::TAU) * BUCKETS as f64) as usize
    };
    let mut buckets: Vec<Vec<usize>> = vec![Vec::new(); BUCKETS];
    for i in 0..n {
        let (ax, az) = pts[i];
        let (bx, bz) = pts[(i + 1) % n];
        let a0 = (az - cz).atan2(ax - cx);
        let a1 = (bz - cz).atan2(bx - cx);
        let (lo, hi) = (a0.min(a1), a0.max(a1));
        // One bucket of slack each side covers rays on a bucket boundary.
        let wraps = hi - lo > std::f64::consts::PI;
        let ranges: Vec<(usize, usize)> = if wraps {
            // The edge crosses the +-180 seam: cover both ends of the circle.
            vec![
                (0, bucket_of(lo) + 1),
                (bucket_of(hi).saturating_sub(1), BUCKETS - 1),
            ]
        } else {
            vec![(bucket_of(lo).saturating_sub(1), bucket_of(hi) + 1)]
        };
        for (from, to) in ranges {
            for bucket in buckets.iter_mut().take(to.min(BUCKETS - 1) + 1).skip(from) {
                bucket.push(i);
            }
        }
    }

    let mut out: HashMap<(i32, i32), f64> = HashMap::with_capacity(cells.len());
    // Scratch for the crossings short of the current cell, reused per cell.
    let mut before: Vec<f64> = Vec::new();
    for &(x, z) in cells {
        let (px, pz) = (x as f64 - cx, z as f64 - cz);
        let dist = (px * px + pz * pz).sqrt();
        if dist < 1e-9 {
            out.insert((x, z), 0.0);
            continue;
        }
        let (ux, uz) = (px / dist, pz / dist);
        // Ray C + t*u against each edge A + s*(B - A). The outline is the first
        // crossing at or beyond the cell; wall cells rasterised a little past
        // it lean on the half-cell slack and land on 1.
        let mut t_hit: Option<f64> = None;
        let mut t_far = 0.0f64;
        before.clear();
        for &i in &buckets[bucket_of(pz.atan2(px)).min(BUCKETS - 1)] {
            let (ax, az) = pts[i];
            let (bx, bz) = pts[(i + 1) % n];
            let (ex, ez) = (bx - ax, bz - az);
            let denom = ux * ez - uz * ex;
            if denom.abs() < 1e-12 {
                continue;
            }
            let (wx, wz) = (ax - cx, az - cz);
            let t = (wx * ez - wz * ex) / denom;
            let sp = (wx * uz - wz * ux) / denom;
            if t <= 0.0 || !(-1e-9..=1.0 + 1e-9).contains(&sp) {
                continue;
            }
            t_far = t_far.max(t);
            if t + 0.5 >= dist {
                t_hit = Some(t_hit.map_or(t, |h: f64| h.min(t)));
            } else {
                before.push(t);
            }
        }
        // Crossings short of the cell come in pairs: the ray leaves the
        // footprint and comes back. A pair that close together is the ray
        // clipping a vertex or a rasterised bump, which costs nothing; a pair
        // a whole cell apart is real open ground, and this footprint is not
        // one the centroid can measure.
        before.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        if before
            .as_chunks::<2>()
            .0
            .iter()
            .any(|pair| pair[1] - pair[0] > MAX_GRAZE_GAP)
        {
            return None;
        }
        let t = t_hit.unwrap_or(t_far);
        let r = if t > 0.0 { (dist / t).min(1.0) } else { 1.0 };
        out.insert((x, z), r);
    }
    Some(out)
}

/// Pyramidal roof: tapers to a single apex above the footprint's centroid.
fn generate_pyramidal_roof(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    config: &RoofConfig,
    nodes: &[ProcessedNode],
) {
    let footprint: HashSet<(i32, i32)> = floor_area.iter().copied().collect();
    // A mapped roof:height is the apex rise, a spire included; an inferred
    // one stays squat against both the footprint and the walls.
    let peak_boost = config.peak_cap.unwrap_or_else(|| {
        let shorter_half = config.width().min(config.length()) / 2;
        let uncapped_boost = ((shorter_half as f64) * 0.85).round().max(1.0) as i32;
        let wall_cap = ((config.building_height as f64) * 0.6).round().max(1.0) as i32;
        uncapped_boost.min(wall_cap)
    });
    // Per-axis halves for the bounding-box fallback, so elongated footprints reach the eave.
    let half_w = (config.width() / 2).max(1) as f64;
    let half_l = (config.length() / 2).max(1) as f64;
    let radial = footprint_radial_fractions(nodes, floor_area);

    let mut roof_heights: HashMap<(i32, i32), i32> = HashMap::new();
    for &(x, z) in floor_area {
        let fraction = radial.as_ref().map_or_else(
            || {
                let dx = (x - config.center_x).abs() as f64;
                let dz = (z - config.center_z).abs() as f64;
                (dx / half_w).max(dz / half_l).min(1.0)
            },
            |m| m[&(x, z)],
        );
        let height_factor = 1.0 - fraction;
        let roof_height = config.base_height + (height_factor * peak_boost as f64) as i32;
        roof_heights.insert((x, z), roof_height);
    }

    let stair_block_material = get_stair_block_for_material(config.roof_block);

    place_roof_blocks_with_stairs(
        editor,
        floor_area,
        &roof_heights,
        config,
        |x, z, h| {
            let north_h = roof_heights
                .get(&(x, z - 1))
                .copied()
                .unwrap_or(config.base_height);
            let south_h = roof_heights
                .get(&(x, z + 1))
                .copied()
                .unwrap_or(config.base_height);
            let west_h = roof_heights
                .get(&(x - 1, z))
                .copied()
                .unwrap_or(config.base_height);
            let east_h = roof_heights
                .get(&(x + 1, z))
                .copied()
                .unwrap_or(config.base_height);
            let lower_n = north_h < h;
            let lower_s = south_h < h;
            let lower_w = west_h < h;
            let lower_e = east_h < h;
            let lower_count =
                (lower_n as i32) + (lower_s as i32) + (lower_w as i32) + (lower_e as i32);

            if lower_count == 2 {
                if lower_n && lower_w {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::East,
                        StairShape::OuterRight,
                    );
                }
                if lower_n && lower_e {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::South,
                        StairShape::OuterRight,
                    );
                }
                if lower_s && lower_w {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::East,
                        StairShape::OuterLeft,
                    );
                }
                if lower_s && lower_e {
                    return create_stair_with_properties(
                        stair_block_material,
                        StairFacing::North,
                        StairShape::OuterLeft,
                    );
                }
            }

            if lower_count == 0 {
                // Plateau ring (common on truncated slopes): face the apex.
                let dx = x - config.center_x;
                let dz = z - config.center_z;
                let facing = if dx.abs() >= dz.abs() {
                    if dx > 0 {
                        StairFacing::West
                    } else {
                        StairFacing::East
                    }
                } else if dz > 0 {
                    StairFacing::North
                } else {
                    StairFacing::South
                };
                return create_stair_with_properties(
                    stair_block_material,
                    facing,
                    StairShape::Straight,
                );
            }

            if lower_n {
                create_stair_with_properties(
                    stair_block_material,
                    StairFacing::South,
                    StairShape::Straight,
                )
            } else if lower_s {
                create_stair_with_properties(
                    stair_block_material,
                    StairFacing::North,
                    StairShape::Straight,
                )
            } else if lower_w {
                create_stair_with_properties(
                    stair_block_material,
                    StairFacing::East,
                    StairShape::Straight,
                )
            } else {
                create_stair_with_properties(
                    stair_block_material,
                    StairFacing::West,
                    StairShape::Straight,
                )
            }
        },
        Some(&footprint),
    );
}

/// Generates a dome roof
fn generate_dome_roof(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    config: &RoofConfig,
    nodes: &[ProcessedNode],
) {
    // elliptical normalization so the shell meets the eave on every wall
    let half_w = (config.width() as f64 / 2.0).max(1.0);
    let half_l = (config.length() as f64 / 2.0).max(1.0);
    // A mapped roof:height is the crown rise; inferred domes stay squat.
    let rise = config
        .peak_cap
        .map_or_else(|| (half_w.min(half_l) * 0.8).max(1.0), |p| p.max(1) as f64);
    let radial = footprint_radial_fractions(nodes, floor_area);
    // Use empty blacklist to allow overwriting wall/ceiling blocks
    let replace_any: &[Block] = &[];
    let mut surface: HashMap<(i32, i32), i32> = HashMap::with_capacity(floor_area.len());

    for &(x, z) in floor_area {
        let normalized_distance = radial.as_ref().map_or_else(
            || {
                let nx = (x - config.center_x) as f64 / half_w;
                let nz = (z - config.center_z) as f64 / half_l;
                (nx * nx + nz * nz).sqrt().min(1.0)
            },
            |m| m[&(x, z)],
        );

        let height_factor = (1.0 - normalized_distance * normalized_distance).sqrt();
        surface.insert((x, z), config.base_height + (height_factor * rise) as i32);
    }
    fill_roof_shell(editor, floor_area, &surface, config, replace_any);
}

/// Places a rounded roof as a shell over its surface heights: every column
/// runs from one below its lowest neighbour's surface up to its own, so the
/// shell is watertight and two blocks thick at the crown, and the space
/// beneath a dome or cone stays a hall instead of a solid mass.
fn fill_roof_shell(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    surface: &HashMap<(i32, i32), i32>,
    config: &RoofConfig,
    replace_any: &[Block],
) {
    for &(x, z) in floor_area {
        let top = surface[&(x, z)];
        let lowest_neighbour = [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)]
            .iter()
            .map(|n| surface.get(n).copied().unwrap_or(config.base_height))
            .min()
            .unwrap_or(config.base_height);
        let bottom = (lowest_neighbour - 1).max(config.base_height);
        for y in bottom..=top {
            editor.set_block_absolute(
                config.roof_block,
                x,
                y + config.abs_terrain_offset,
                z,
                None,
                Some(replace_any),
            );
        }
    }
}

/// Conical roof: circular base tapering linearly to a point.
fn generate_cone_roof(
    editor: &mut WorldEditor,
    floor_area: &[(i32, i32)],
    config: &RoofConfig,
    nodes: &[ProcessedNode],
) {
    let half_w = (config.width() as f64 / 2.0).max(1.0);
    let half_l = (config.length() as f64 / 2.0).max(1.0);
    let replace_any: &[Block] = &[];

    // A mapped roof:height is the apex rise, a spire included.
    let peak_height = config.peak_cap.map_or_else(
        || {
            ((half_w.min(half_l) * 1.2) as i32)
                .max(2)
                .min(config.building_height * 2)
        },
        |p| p.max(1),
    );
    let radial = footprint_radial_fractions(nodes, floor_area);
    let mut surface: HashMap<(i32, i32), i32> = HashMap::with_capacity(floor_area.len());

    for &(x, z) in floor_area {
        let normalized = radial.as_ref().map_or_else(
            || {
                let dx = (x - config.center_x) as f64;
                let dz = (z - config.center_z) as f64;
                ((dx / half_w).powi(2) + (dz / half_l).powi(2))
                    .sqrt()
                    .min(1.0)
            },
            |m| m[&(x, z)],
        );

        surface.insert(
            (x, z),
            config.base_height + ((1.0 - normalized) * peak_height as f64) as i32,
        );
    }
    fill_roof_shell(editor, floor_area, &surface, config, replace_any);
}

/// Onion roof: bulbous Russian-Orthodox / Bavarian profile.
fn generate_onion_roof(editor: &mut WorldEditor, floor_area: &[(i32, i32)], config: &RoofConfig) {
    // shorter axis, the bulb bulges a little instead of half the long axis
    let base_radius = (config.width().min(config.length()) / 2) as f64;
    let replace_any: &[Block] = &[];

    // A mapped roof:height is the tip; the bulb profile scales with it.
    let total_height = config.peak_cap.map_or_else(
        || {
            ((base_radius * 1.8) as i32)
                .max(6)
                .min(config.building_height * 2)
        },
        |p| p.max(1),
    );

    let footprint: HashSet<(i32, i32)> = floor_area.iter().copied().collect();

    // Bulb extends up to 1.25x the base radius.
    let max_search = (base_radius * 1.25).ceil() as i32 + 1;

    for layer in 0..=total_height {
        let t = layer as f64 / total_height as f64;
        let radius_factor = onion_profile_radius(t);
        let layer_radius = base_radius * radius_factor;
        let abs_y = config.base_height + layer + config.abs_terrain_offset;

        // Apex: collapse to a single block to give the spire a clean point.
        if layer_radius < 0.6 && t > 0.85 {
            editor.set_block_absolute(
                config.roof_block,
                config.center_x,
                abs_y,
                config.center_z,
                None,
                Some(replace_any),
            );
            continue;
        }

        // Base plate: full footprint regardless of radius.
        if t < 0.05 {
            for &(x, z) in floor_area {
                editor.set_block_absolute(config.roof_block, x, abs_y, z, None, Some(replace_any));
            }
            continue;
        }

        let r2 = layer_radius * layer_radius;
        for dz in -max_search..=max_search {
            for dx in -max_search..=max_search {
                if (dx as f64).powi(2) + (dz as f64).powi(2) > r2 {
                    continue;
                }
                let x = config.center_x + dx;
                let z = config.center_z + dz;
                // Drum: clip to footprint. Above the drum the bulb may bulge out.
                if t < 0.15 && !footprint.contains(&(x, z)) {
                    continue;
                }
                editor.set_block_absolute(config.roof_block, x, abs_y, z, None, Some(replace_any));
            }
        }
    }
}

/// Onion-roof radius factor at relative height `t ∈ [0, 1]`.
#[inline]
fn onion_profile_radius(t: f64) -> f64 {
    if t < 0.05 {
        // Base plate - full coverage.
        1.0
    } else if t < 0.15 {
        // Drum: taper 1.00 → 0.55.
        let local = (t - 0.05) / 0.10;
        1.0 - local * 0.45
    } else if t < 0.55 {
        // Bulb: smooth sin-curve swell 0.55 → 1.20 → 0.55, peak at t≈0.35.
        let local = (t - 0.15) / 0.40;
        let peak = (local * std::f64::consts::PI).sin();
        0.55 + peak * 0.65
    } else if t < 0.78 {
        // Neck: pinch from 0.55 to 0.18 - creates the onion waist.
        let local = (t - 0.55) / 0.23;
        0.55 - local * 0.37
    } else {
        // Spire: 0.18 down to 0 across the top fifth of the height.
        let local = (t - 0.78) / 0.22;
        (0.18 * (1.0 - local)).max(0.0)
    }
}

/// Unified function to generate various roof types
#[inline]
#[allow(clippy::too_many_arguments)]
fn generate_roof(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    start_y_offset: i32,
    building_height: i32,
    floor_block: Block,
    wall_block: Block,
    curtain_glass: Option<Block>,
    roof_block_override: Option<Block>,
    roof_type: RoofType,
    roof_area: &[(i32, i32)],
    abs_terrain_offset: i32,
    add_dormers: bool,
    style_seed: u64,
    steep_gable: bool,
    preferred_ridge_along_x: Option<bool>,
    scale_factor: f64,
) {
    if roof_area.is_empty() {
        return;
    }

    let mut config = RoofConfig::from_roof_area(
        roof_area,
        style_seed,
        start_y_offset,
        building_height,
        wall_block,
        abs_terrain_offset,
    );

    // OSM roof:material / roof:colour override the preset.
    let mut roof_rng = element_rng(style_seed ^ 0xF00F_C010_BA5E_F00D);
    let osm_roof_block = element
        .tags
        .get("roof:material")
        .and_then(|m| get_roof_block_for_material(m, &mut roof_rng))
        .or_else(|| {
            element
                .tags
                .get("roof:colour")
                .and_then(|c| color_text_to_rgb_tuple(c))
                .map(|rgb| crate::block_palette::roof_block_for_color(rgb, &mut roof_rng))
        });

    if let Some(block) = osm_roof_block {
        // A glass roof over a glass wall carries the curtain wall on: a
        // sloped face mapped as a roof must not change tint at the seam.
        config.roof_block = if !is_glass_wall(block) {
            block
        } else if let Some(glass) = curtain_glass {
            glass
        } else if is_glass_wall(wall_block) {
            wall_block
        } else {
            block
        };
    } else if let Some(override_block) = roof_block_override {
        config.roof_block = override_block;
    }

    config.add_dormers = add_dormers;

    let roof_orientation = element.tags.get("roof:orientation").map(|s| s.as_str());
    let roof_direction = element.tags.get("roof:direction").map(|s| s.as_str());
    let ridge = ridge_frame(
        &element.nodes,
        config.width(),
        config.length(),
        roof_orientation,
        roof_direction,
        preferred_ridge_along_x,
    );
    // A mapped roof:height, else a roof:angle pitch, overrides the heuristic caps.
    let peak_cap = roof_peak_cap(&element.tags, roof_type, &config, &ridge, scale_factor);
    config.peak_cap = peak_cap;

    // For flat roofs: OSM tags override > preset override > floor block default.
    let flat_roof_block = osm_roof_block
        .or(roof_block_override)
        .unwrap_or(floor_block);

    match roof_type {
        RoofType::Flat => {
            generate_flat_roof(
                editor,
                roof_area,
                flat_roof_block,
                config.base_height,
                abs_terrain_offset,
            );
        }

        RoofType::Gabled => {
            let profile = if steep_gable {
                GableProfile::Steep
            } else {
                GableProfile::Standard
            };
            generate_gabled_roof(editor, roof_area, &config, profile, &ridge);
        }

        RoofType::Gambrel => {
            generate_gabled_roof(editor, roof_area, &config, GableProfile::Gambrel, &ridge);
        }

        RoofType::HalfHipped => {
            generate_gabled_roof(editor, roof_area, &config, GableProfile::HalfHipped, &ridge);
        }

        RoofType::Round => {
            generate_gabled_roof(editor, roof_area, &config, GableProfile::Round, &ridge);
        }

        RoofType::Hipped => {
            generate_hipped_roof(editor, roof_area, &config);
        }

        RoofType::Mansard => {
            // roof:levels hints how tall the steep band is (3 blocks per level).
            let steep_h = element
                .tags
                .get("roof:levels")
                .and_then(|v| v.trim().parse::<f64>().ok())
                .map(|l| ((l * 3.0).round() as i32).clamp(3, 6))
                .unwrap_or(4);
            generate_mansard_roof(editor, roof_area, &config, steep_h);
        }

        RoofType::Skillion => {
            generate_skillion_roof(editor, roof_area, &config, roof_direction);
        }

        RoofType::Pyramidal => {
            generate_pyramidal_roof(editor, roof_area, &config, &element.nodes);
        }

        RoofType::Dome => {
            generate_dome_roof(editor, roof_area, &config, &element.nodes);
        }

        RoofType::Cone => {
            generate_cone_roof(editor, roof_area, &config, &element.nodes);
        }

        RoofType::Onion => {
            generate_onion_roof(editor, roof_area, &config);
        }
    }
}

/// Synthetic way id a relation's `ring_idx`-th outer ring is built under.
/// Bit 63 keeps it out of the real way id range, so it cannot collide in the
/// flood fill cache or the deterministic RNG seeded by element id; the hole
/// rings use the same scheme with bit 15 of the ring slot set.
pub(crate) fn relation_ring_id(relation_id: u64, ring_idx: usize) -> u64 {
    (1u64 << 63) | (relation_id << 16) | (ring_idx as u64 & 0xFFFF)
}

/// Merges member way segments into rings, clips them to the world and keeps
/// the closed ones.
///
/// Multipolygon relations commonly split the outline across many short way
/// segments that share endpoints. Without merging, each segment would be
/// processed individually, producing degenerate polygons and empty flood
/// fills (only wall outlines, no filled floors, ceilings or roofs). Member
/// ways were kept unclipped during parsing to allow that assembly, so the
/// merged rings may extend beyond the requested area and are clipped here;
/// clipping prevents oversized flood fills and unnecessary block placement.
/// Rings whose ends are within one block are closed, the rest are dropped.
fn assemble_relation_rings(
    mut rings: Vec<Vec<ProcessedNode>>,
    xzbbox: &crate::coordinate_system::cartesian::XZBBox,
) -> Vec<Vec<ProcessedNode>> {
    super::merge_way_segments(&mut rings);

    let mut rings: Vec<Vec<ProcessedNode>> = rings
        .into_iter()
        .map(|ring| clip_way_to_bbox(&ring, xzbbox))
        .filter(|ring| ring.len() >= 4)
        .collect();

    // Close rings that are nearly closed (endpoints within 1 block)
    for ring in &mut rings {
        if ring.len() >= 3 {
            let first = &ring[0];
            let last = ring.last().unwrap();
            if first.id != last.id {
                let dx = (first.x - last.x).abs();
                let dz = (first.z - last.z).abs();
                if dx <= 1 && dz <= 1 {
                    let close_node = ring[0].clone();
                    ring.push(close_node);
                }
            }
        }
    }

    // Discard rings that are still open or too small
    rings.retain(|ring| {
        if ring.len() < 4 {
            return false;
        }
        let first = &ring[0];
        let last = ring.last().unwrap();
        first.id == last.id || ((first.x - last.x).abs() <= 1 && (first.z - last.z).abs() <= 1)
    });
    rings
}

/// The closed outer rings a building relation is generated from, each with
/// the synthetic way id `generate_buildings` runs under for it, in generation
/// order. Empty when the relation builds nothing of its own: it is
/// underground, it is a type=building relation whose parts render standalone,
/// or its outer members are closed building:part rings that render on their
/// own. The facade textures use this to key a relation's walls the way the
/// wall builder will ask for them.
pub(crate) fn relation_outer_rings(
    relation: &ProcessedRelation,
    xzbbox: &crate::coordinate_system::cartesian::XZBBox,
) -> Vec<(u64, Vec<ProcessedNode>)> {
    if is_underground_building(&relation.tags) {
        return Vec::new();
    }

    // Check if this is a type=building relation with part members.
    // Only type=building relations use Part roles; type=multipolygon relations
    // should always render their Outer members normally.
    let is_building_type = relation.tags.get("type").map(|t| t.as_str()) == Some("building");
    let has_parts = is_building_type
        && relation
            .members
            .iter()
            .any(|m| m.role == ProcessedMemberRole::Part);
    if has_parts {
        // Parts are rendered as standalone ways from the elements list. The
        // outline way is suppressed in data_processing to avoid overlaying the parts.
        return Vec::new();
    }

    // Closed building:part outer rings render standalone with their own
    // height tags; rendering the relation too would stack a box on top
    let mut outer_iter = relation
        .members
        .iter()
        .filter(|m| m.role == ProcessedMemberRole::Outer)
        .peekable();
    if outer_iter.peek().is_some()
        && outer_iter.all(|m| {
            m.way
                .tags
                .get("building:part")
                .is_some_and(|v| !v.eq_ignore_ascii_case("no"))
                && m.way.nodes.len() >= 4
                && m.way.nodes.first().map(|n| n.id) == m.way.nodes.last().map(|n| n.id)
        })
    {
        return Vec::new();
    }

    let outer_rings: Vec<Vec<ProcessedNode>> = relation
        .members
        .iter()
        .filter(|m| m.role == ProcessedMemberRole::Outer && !SKIP_WAY_IDS.contains(&m.way.id))
        .map(|m| m.way.nodes.clone())
        .collect();
    assemble_relation_rings(outer_rings, xzbbox)
        .into_iter()
        .enumerate()
        .map(|(ring_idx, ring)| (relation_ring_id(relation.id, ring_idx), ring))
        .collect()
}

pub fn generate_building_from_relation(
    editor: &mut WorldEditor,
    relation: &ProcessedRelation,
    args: &Args,
    ctx: &BuildingContext<'_>,
    xzbbox: &crate::coordinate_system::cartesian::XZBBox,
) {
    // Skip underground buildings/building parts
    if is_underground_building(&relation.tags) {
        return;
    }

    // Landmark: a Starship parked on the Starbase Pad 2 launch mount.
    for member in &relation.members {
        if member.way.id == crate::structures::starship::STARBASE_PAD2_INNER_RING_WAY
            && member.role == ProcessedMemberRole::Inner
        {
            crate::structures::starship::place_on_launch_mount(editor, &member.way);
        }
    }

    // Extract levels from relation tags. Untagged relations get no fixed
    // default; the synthetic outline ways carry the relation tags, so the
    // per-type height inference applies to them like to any way.
    let relation_levels = relation
        .tags
        .get("building:levels")
        .and_then(|l: &String| l.trim().parse::<f64>().ok())
        .map(|l| l.round() as i32);

    // The closed outer rings this relation is built from, with the ids the
    // buildings are generated under. Nothing when the relation renders no
    // building of its own (see `relation_outer_rings`).
    let outer_rings = relation_outer_rings(relation, xzbbox);
    if outer_rings.is_empty() {
        return;
    }

    // Collect and assemble inner rings for courtyards/holes.
    let inner_rings = assemble_relation_rings(
        relation
            .members
            .iter()
            .filter(|m| m.role == ProcessedMemberRole::Inner)
            .map(|m| m.way.nodes.clone())
            .collect(),
        xzbbox,
    );

    let hole_polygons: Option<Vec<HolePolygon>> = if inner_rings.is_empty() {
        None
    } else {
        Some(
            inner_rings
                .into_iter()
                .enumerate()
                .map(|(ring_idx, ring)| {
                    // Use a different index range from outer rings to avoid cache collisions.
                    let ring_slot = 0x8000 | (ring_idx & 0x7FFF);
                    HolePolygon {
                        way: ProcessedWay {
                            id: relation_ring_id(relation.id, ring_slot),
                            tags: HashMap::new(),
                            nodes: ring,
                        },
                        add_walls: true,
                    }
                })
                .collect(),
        )
    };

    // Build a synthetic ProcessedWay for each assembled ring and render it.
    // The relation tags are applied so that building type, levels, and roof
    // shape from the relation are honoured.
    for (synthetic_id, ring) in outer_rings {
        let merged_way = ProcessedWay {
            id: synthetic_id,
            tags: relation.tags.clone(),
            nodes: ring,
        };
        generate_buildings(
            editor,
            &merged_way,
            args,
            relation_levels,
            hole_polygons.as_deref(),
            ctx,
            merged_way.id,
        );
    }
}

/// Generates a bridge structure, paying attention to the "level" tag.
/// Bridge deck is interpolated between start and end point elevations to avoid
/// being dragged down by valleys underneath.
fn generate_bridge(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    flood_fill_cache: &FloodFillCache,
    floodfill_timeout: Option<&Duration>,
) {
    let floor_block: Block = STONE;
    let railing_block: Block = STONE_BRICKS;

    // Calculate bridge level offset based on the "level" tag, layer as fallback
    let bridge_y_offset = if let Some(level) = element
        .tags
        .get("level")
        .and_then(|s| s.parse::<i32>().ok())
    {
        (level * 3) + 1
    } else if let Some(layer) = element
        .tags
        .get("layer")
        .and_then(|s| s.parse::<i32>().ok())
        .filter(|l| *l > 0)
    {
        layer * 4 + 2
    } else {
        1 // Default elevation
    };

    // Need at least 2 nodes to form a bridge
    if element.nodes.len() < 2 {
        return;
    }

    // Get start and end node elevations and use MAX for level bridge deck
    // Using MAX ensures bridges don't dip when multiple bridge ways meet in a valley
    let start_node = &element.nodes[0];
    let end_node = &element.nodes[element.nodes.len() - 1];
    let start_y = editor.get_ground_level(start_node.x, start_node.z);
    let end_y = editor.get_ground_level(end_node.x, end_node.z);
    let bridge_deck_ground_y = start_y.max(end_y);

    // Process the nodes to create bridge pathways and railings
    let mut previous_node: Option<(i32, i32)> = None;

    for node in &element.nodes {
        let x: i32 = node.x;
        let z: i32 = node.z;

        // Create bridge path using Bresenham's line
        if let Some(prev) = previous_node {
            let bridge_points: Vec<(i32, i32, i32)> = bresenham_line(prev.0, 0, prev.1, x, 0, z);

            for (bx, _, bz) in bridge_points.iter() {
                // Use fixed bridge deck height (max of endpoints)
                let bridge_y = bridge_deck_ground_y + bridge_y_offset;

                // Place railing blocks
                editor.set_block_absolute(railing_block, *bx, bridge_y + 1, *bz, None, None);
                editor.set_block_absolute(railing_block, *bx, bridge_y, *bz, None, None);
            }
        }

        previous_node = Some((x, z));
    }

    // Flood fill the area between the bridge path nodes (uses cache)
    let bridge_area = flood_fill_cache.get_or_compute(element, floodfill_timeout);

    // Use the same level bridge deck height for filled areas
    let floor_y = bridge_deck_ground_y + bridge_y_offset;

    // Place floor blocks
    for &(x, z) in bridge_area.iter() {
        editor.set_block_absolute(floor_block, x, floor_y, z, None, None);
    }
}

#[cfg(test)]
mod height_tests {
    use super::*;

    fn ring(points: &[(i32, i32)]) -> Vec<ProcessedNode> {
        let mut nodes: Vec<ProcessedNode> = points
            .iter()
            .enumerate()
            .map(|(i, &(x, z))| ProcessedNode {
                id: i as u64 + 1,
                tags: HashMap::new(),
                x,
                z,
            })
            .collect();
        nodes.push(nodes[0].clone());
        nodes
    }

    fn rotated_rect(w: f64, l: f64, deg: f64) -> Vec<ProcessedNode> {
        let (c, sn) = (deg.to_radians().cos(), deg.to_radians().sin());
        let pts: Vec<(i32, i32)> = [(0.0, 0.0), (l, 0.0), (l, w), (0.0, w)]
            .iter()
            .map(|&(u, v)| {
                (
                    (u * c - v * sn).round() as i32,
                    (u * sn + v * c).round() as i32,
                )
            })
            .collect();
        ring(&pts)
    }

    #[test]
    fn tent_frame_catches_any_rotation_of_a_rectangle() {
        for deg in [4.0, 8.0, 20.0, 44.0] {
            let frame = tent_frame(&rotated_rect(12.0, 30.0, deg))
                .unwrap_or_else(|| panic!("{deg} deg rectangle should get a tent"));
            assert!(
                (frame.angle.to_degrees() - deg).abs() < 3.0,
                "{deg} deg: frame angle {}",
                frame.angle.to_degrees()
            );
            // The frame's long axis is the rectangle's 30 side.
            assert!((frame.u_max - frame.u_min - 30.0).abs() < 2.5);
            assert!((frame.v_max - frame.v_min - 12.0).abs() < 2.5);
        }
    }

    #[test]
    fn tent_frame_leaves_aligned_rectangles_alone() {
        assert!(tent_frame(&rotated_rect(12.0, 30.0, 0.0)).is_none());
    }

    #[test]
    fn axis_snap_skips_l_shapes() {
        // L-shape rotated ~8 deg: rectangle-likeness gate must reject it.
        let (c, sn) = (8.0f64.to_radians().cos(), 8.0f64.to_radians().sin());
        let pts: Vec<(i32, i32)> = [
            (0.0, 0.0),
            (30.0, 0.0),
            (30.0, 10.0),
            (12.0, 10.0),
            (12.0, 26.0),
            (0.0, 26.0),
        ]
        .iter()
        .map(|&(u, v): &(f64, f64)| {
            (
                (u * c - v * sn).round() as i32,
                (u * sn + v * c).round() as i32,
            )
        })
        .collect();
        assert!(tent_frame(&ring(&pts)).is_none());
    }

    fn way_with_tags(tags: &[(&str, &str)]) -> ProcessedWay {
        ProcessedWay {
            id: 1,
            tags: tags
                .iter()
                .map(|(k, v)| (k.to_string(), v.to_string()))
                .collect(),
            nodes: Vec::new(),
        }
    }

    // height=89 min_height=60 levels=19: the 29m height span wins over the levels estimate
    #[test]
    fn explicit_height_beats_relation_levels() {
        let way = way_with_tags(&[
            ("height", "89"),
            ("min_height", "60"),
            ("building:levels", "19"),
        ]);
        let (h, _) = calculate_building_height(&way, "yes", 0, 1.0, Some(19), 4, 100, 1);
        assert_eq!(h, 29);
    }

    #[test]
    fn relation_levels_apply_without_height_tag() {
        let way = way_with_tags(&[]);
        let (h, _) = calculate_building_height(&way, "yes", 0, 1.0, Some(5), 3, 100, 1);
        assert_eq!(h, 17); // 5 levels * 3 + 2
    }

    // height spans walls plus roof; roof:height comes off the wall span
    #[test]
    fn roof_height_reduces_wall_span() {
        let way = way_with_tags(&[
            ("height", "12"),
            ("roof:height", "4"),
            ("roof:shape", "gabled"),
        ]);
        let (h, _) = calculate_building_height(&way, "house", 0, 1.0, None, 3, 100, 1);
        assert_eq!(h, 8);
        // flat roofs keep the full span
        let way = way_with_tags(&[
            ("height", "12"),
            ("roof:height", "4"),
            ("roof:shape", "flat"),
        ]);
        let (h, _) = calculate_building_height(&way, "house", 0, 1.0, None, 3, 100, 1);
        assert_eq!(h, 12);
    }

    // A 5cm roof plate stays a thin slab instead of a 3-block band
    #[test]
    fn elevated_thin_part_is_not_fattened() {
        let way = way_with_tags(&[("height", "19.05"), ("min_height", "19")]);
        let (h, _) = calculate_building_height(&way, "yes", 0, 1.0, None, 4, 100, 1);
        assert_eq!(h, 1);
    }

    // height=96 min_height=94 spans exactly 2 blocks
    #[test]
    fn elevated_part_keeps_exact_span() {
        let way = way_with_tags(&[("height", "96"), ("min_height", "94")]);
        let (h, _) = calculate_building_height(&way, "yes", 0, 1.0, None, 4, 100, 1);
        assert_eq!(h, 2);
    }

    // Ground-level buildings keep the 3-block interior minimum
    #[test]
    fn ground_level_building_keeps_minimum() {
        let way = way_with_tags(&[("height", "2")]);
        let (h, _) = calculate_building_height(&way, "yes", 0, 1.0, None, 4, 100, 1);
        assert_eq!(h, 3);
    }

    // min_height=0 is not an elevated part, the minimum still applies
    #[test]
    fn zero_min_height_is_ground_level() {
        let way = way_with_tags(&[("height", "2"), ("min_height", "0")]);
        let (h, _) = calculate_building_height(&way, "yes", 0, 1.0, None, 4, 100, 1);
        assert_eq!(h, 3);
    }

    // An elevation mapped as height (e.g. an alpine hut with height=1640)
    // is ignored, levels still apply
    #[test]
    fn implausible_height_is_ignored() {
        let way = way_with_tags(&[("height", "1640"), ("building:levels", "2")]);
        let (h, tall) = calculate_building_height(&way, "yes", 0, 1.0, None, 4, 100, 1);
        assert_eq!(h, 10);
        assert!(!tall);

        let way = way_with_tags(&[("height", "828")]);
        let (h, _) = calculate_building_height(&way, "yes", 0, 1.0, None, 4, 100, 1);
        assert_eq!(h, 828);
    }

    #[test]
    fn fractional_levels_parse() {
        let way = way_with_tags(&[("building:levels", "2.5")]);
        let (h, _) = calculate_building_height(&way, "yes", 0, 1.0, None, 3, 100, 1);
        assert_eq!(h, 9); // 2.5 levels * 3 + 2
    }

    // The +2 moved into the min_level offset, wall span is exactly 4 per level
    #[test]
    fn min_level_walls_span_remaining_levels() {
        let way = way_with_tags(&[("building:levels", "4"), ("building:min_level", "2")]);
        let (h, _) = calculate_building_height(&way, "yes", 2, 1.0, None, 3, 100, 1);
        assert_eq!(h, 6);
    }

    // layer=-1 is treated as underground unless an explicit surface/overground/roof location is set
    #[test]
    fn surface_location_overrides_negative_layer() {
        let way = way_with_tags(&[("building", "office"), ("layer", "-1")]);
        assert!(is_underground_building(&way.tags));
        let way = way_with_tags(&[
            ("building", "office"),
            ("layer", "-1"),
            ("location", "surface"),
        ]);
        assert!(!is_underground_building(&way.tags));
    }

    // height with building:min_level but no min_height: the level-based lift
    // comes off the wall span, matching the offset the part is raised by
    #[test]
    fn height_minus_min_level_offset() {
        let way = way_with_tags(&[
            ("height", "30"),
            ("building:levels", "9"),
            ("building:min_level", "5"),
        ]);
        let (h, _) = calculate_building_height(&way, "yes", 5, 1.0, None, 3, 100, 1);
        // offset = 5*3+2 = 17; wall span = 30-17 = 13
        assert_eq!(h, 13);
    }

    // Sibling parts must infer identical heights regardless of footprint
    #[test]
    fn part_inference_ignores_footprint() {
        let way = way_with_tags(&[("building:part", "yes")]);
        for seed in 0..20u64 {
            let (small, _) = calculate_building_height(&way, "yes", 0, 1.0, None, 4, 30, seed);
            let (large, _) = calculate_building_height(&way, "yes", 0, 1.0, None, 4, 900, seed);
            assert_eq!(small, large, "seed {seed}");
        }
    }

    // Inference: same seed → same height, and values stay inside the type table
    #[test]
    fn inferred_house_heights_are_deterministic_and_in_range() {
        for seed in 0..40u64 {
            let way = way_with_tags(&[("building", "house")]);
            let (h1, tall1) = calculate_building_height(&way, "house", 0, 1.0, None, 3, 100, seed);
            let (h2, _) = calculate_building_height(&way, "house", 0, 1.0, None, 3, 100, seed);
            assert_eq!(h1, h2);
            assert!(!tall1);
            // 1-3 storeys → 5/8/11 blocks at the 3-block cycle
            assert!(matches!(h1, 5 | 8 | 11), "unexpected house height {h1}");
        }
    }

    #[test]
    fn inferred_garage_is_a_low_hall() {
        let way = way_with_tags(&[("building", "garage")]);
        let (h, tall) = calculate_building_height(&way, "garage", 0, 1.0, None, 4, 40, 7);
        assert_eq!(h, 3);
        assert!(!tall);
    }

    // A garage with explicit levels honours the mapper, not the type default
    #[test]
    fn tags_override_inference() {
        let way = way_with_tags(&[("building", "garage"), ("building:levels", "3")]);
        let (h, _) = calculate_building_height(&way, "garage", 0, 1.0, None, 3, 40, 7);
        assert_eq!(h, 11);
    }

    #[test]
    fn generic_yes_scales_with_footprint() {
        let way = way_with_tags(&[("building", "yes")]);
        for seed in 0..40u64 {
            let (small, _) = calculate_building_height(&way, "yes", 0, 1.0, None, 3, 30, seed);
            assert!(matches!(small, 3 | 5), "tiny yes-building got {small}");
            let (large, _) = calculate_building_height(&way, "yes", 0, 1.0, None, 3, 900, seed);
            assert!(
                matches!(large, 7 | 11 | 14),
                "large yes-building got {large}"
            );
        }
    }

    #[test]
    fn inferred_apartments_reach_midrise() {
        let way = way_with_tags(&[("building", "apartments")]);
        for seed in 0..40u64 {
            let (h, _) = calculate_building_height(&way, "apartments", 0, 1.0, None, 3, 400, seed);
            assert!(matches!(h, 11 | 14 | 17 | 20), "apartments got {h}");
        }
    }
}

#[cfg(test)]
mod style_tests {
    use super::*;

    #[test]
    fn archetype_truth_table() {
        use WindowArchetype::*;
        // Standard3: cols 0-2 on all open rows
        assert!(archetype_allows_window(Standard3, 0, 1, 4));
        assert!(archetype_allows_window(Standard3, 2, 3, 4));
        assert!(!archetype_allows_window(Standard3, 3, 2, 4));
        // PairedNarrow: cols 0 and 2 only, top open row is a lintel
        assert!(archetype_allows_window(PairedNarrow, 0, 1, 4));
        assert!(!archetype_allows_window(PairedNarrow, 1, 1, 4));
        assert!(archetype_allows_window(PairedNarrow, 2, 2, 4));
        assert!(!archetype_allows_window(PairedNarrow, 0, 3, 4));
        // VerticalStrip: col 1 only
        assert!(archetype_allows_window(VerticalStrip, 1, 3, 4));
        assert!(!archetype_allows_window(VerticalStrip, 0, 2, 4));
        // WideHorizontal: cols 0-3, bottom open row is a sill
        assert!(archetype_allows_window(WideHorizontal, 3, 2, 4));
        assert!(!archetype_allows_window(WideHorizontal, 3, 1, 4));
        assert!(!archetype_allows_window(WideHorizontal, 4, 2, 4));
    }

    #[test]
    fn archetype_choice_is_deterministic_and_defaults_hold() {
        for seed in 0..30u64 {
            let a = pick_window_archetype(BuildingCategory::House, ArchEra::Unknown, seed);
            let b = pick_window_archetype(BuildingCategory::House, ArchEra::Unknown, seed);
            assert_eq!(a, b);
        }
        // Unhandled categories stay on the classic layout
        assert_eq!(
            pick_window_archetype(BuildingCategory::Religious, ArchEra::Unknown, 7),
            WindowArchetype::Standard3
        );
        assert_eq!(
            pick_window_archetype(BuildingCategory::GlassySkyscraper, ArchEra::Unknown, 7),
            WindowArchetype::Standard3
        );
    }

    #[test]
    fn houses_vary_archetypes_across_seeds() {
        let mut seen = std::collections::HashSet::new();
        for seed in 0..60u64 {
            seen.insert(format!(
                "{:?}",
                pick_window_archetype(BuildingCategory::House, ArchEra::Unknown, seed)
            ));
        }
        assert!(seen.len() >= 3, "expected variety, got {seen:?}");
    }

    #[test]
    fn era_shifts_archetypes_and_walls() {
        // Ornate era pushes houses toward arched bays
        let mut arched = 0;
        for seed in 0..60u64 {
            if pick_window_archetype(BuildingCategory::House, ArchEra::HistoricOrnate, seed)
                == WindowArchetype::ArchedTraditional
            {
                arched += 1;
            }
        }
        assert!(
            arched >= 20,
            "ornate era should favor arches, got {arched}/60"
        );
        // Panel-era residential walls stay inside the era allow-list
        for seed in 0..40u64 {
            let mut rng = element_rng(seed);
            let b = get_wall_block_for_category(
                BuildingCategory::Residential,
                ArchEra::PostWarPanel,
                Climate::Temperate,
                &mut rng,
            );
            assert!(
                era_allow_list(ArchEra::PostWarPanel).unwrap().contains(&b),
                "panel era picked {b:?}"
            );
        }
        // Unknown era keeps the full palette reachable (no filtering)
        assert!(era_allow_list(ArchEra::Unknown).is_none());
    }

    #[test]
    fn climate_reweights_walls() {
        // Desert houses stay inside the desert-weighted pool and lean sandy
        let mut sandy = 0;
        for seed in 0..60u64 {
            let mut rng = element_rng(seed);
            let b = get_wall_block_for_category(
                BuildingCategory::House,
                ArchEra::Unknown,
                Climate::HotDesert,
                &mut rng,
            );
            assert!(
                climate_wall_weight(Climate::HotDesert, BuildingCategory::House, b) > 0,
                "desert picked excluded {b:?}"
            );
            if matches!(
                b,
                SANDSTONE | SMOOTH_SANDSTONE | MUD_BRICKS | WHITE_TERRACOTTA
            ) {
                sandy += 1;
            }
        }
        assert!(sandy >= 15, "desert should lean sandy, got {sandy}/60");
        // Boreal houses can be wood, which the base palette never yields
        let mut wood = 0;
        for seed in 0..60u64 {
            let mut rng = element_rng(seed);
            let b = get_wall_block_for_category(
                BuildingCategory::House,
                ArchEra::Unknown,
                Climate::Boreal,
                &mut rng,
            );
            if NORDIC_WOOD_ADDITIONS.contains(&b) {
                wood += 1;
            }
        }
        assert!(wood >= 10, "boreal should often be wood, got {wood}/60");
    }

    #[test]
    fn climate_gable_probabilities_ordered() {
        assert!(
            climate_gable_probability(Climate::HotDesert)
                < climate_gable_probability(Climate::Temperate)
        );
        assert!(
            climate_gable_probability(Climate::Boreal)
                > climate_gable_probability(Climate::Temperate)
        );
    }

    #[test]
    fn sahara_bbox_editor_reports_hot_desert() {
        use crate::coordinate_system::cartesian::XZBBox;
        use crate::coordinate_system::geographic::LLBBox;
        use crate::element_processing::building_test_support::test_editor_at;
        let xz = XZBBox::rect_from_xz_lengths(50.0, 50.0).unwrap();
        let editor = test_editor_at(&xz, LLBBox::new(22.9, 12.9, 23.1, 13.1).unwrap());
        assert_eq!(editor.climate(), Climate::HotDesert);
    }

    fn test_config(height: i32, attic: bool, top: bool) -> BuildingConfig {
        BuildingConfig {
            is_ground_level: true,
            building_height: height,
            floor_cycle: 4,
            is_tall_building: false,
            start_y_offset: 0,
            abs_terrain_offset: 0,
            wall_block: BRICK,
            floor_block: OAK_PLANKS,
            window_block: GLASS,
            accent_block: SMOOTH_STONE,
            roof_block: None,
            use_vertical_windows: false,
            use_horizontal_windows: false,
            use_accent_roof_line: false,
            use_accent_lines: false,
            use_vertical_accent: false,
            is_abandoned_building: false,
            has_windows: true,
            has_garage_door: false,
            has_single_door: false,
            category: BuildingCategory::House,
            era: ArchEra::Unknown,
            detail: DetailTier::Standard,
            top_treatment: top,
            attic_style: attic,
            piano_nobile: false,
            wall_depth_style: WallDepthStyle::None,
            has_parapet: false,
            has_lobby_base: false,
            condition: BuildingCondition::Normal,
            element_id: 1,
            style_seed: 1,
            window_phase: 0,
            window_archetype: WindowArchetype::Standard3,
            balcony_band: BalconyBand::Scattered,
            rustication: false,
            base_course_block: None,
            has_storefront: false,
            window_frame: None,
            facade_shell: Arc::default(),
            preset_shell: Arc::default(),
        }
    }

    /// Every glass tower turns its corner on something solid, whether the glass
    /// is the wall itself or a band running round it.
    #[test]
    fn a_glass_tower_turns_its_corner_on_a_pier() {
        use crate::element_processing::building_facade::ColumnFacade;
        let corner = ColumnFacade {
            wall_u: 0,
            corner: true,
            ..Default::default()
        };
        let middle = ColumnFacade {
            wall_u: 3,
            ..Default::default()
        };

        // Walled in glass, with a glass accent: the pier falls back to concrete.
        let mut glassy = test_config(30, false, false);
        glassy.category = BuildingCategory::GlassySkyscraper;
        glassy.has_windows = false;
        glassy.wall_block = BLUE_STAINED_GLASS;
        glassy.accent_block = WHITE_STAINED_GLASS;
        assert_eq!(
            determine_wall_block_at_position_pristine(12, &glassy, corner),
            LIGHT_GRAY_CONCRETE
        );
        assert_eq!(
            determine_wall_block_at_position_pristine(12, &glassy, middle),
            BLUE_STAINED_GLASS
        );

        // A solid accent is the pier.
        glassy.accent_block = BLACKSTONE;
        assert_eq!(
            determine_wall_block_at_position_pristine(12, &glassy, corner),
            BLACKSTONE
        );

        // The party wall of a glass tower keeps its plain treatment.
        let party = ColumnFacade {
            wall_u: 0,
            corner: true,
            party: true,
            ..Default::default()
        };
        assert_eq!(
            determine_wall_block_at_position_pristine(12, &glassy, party),
            BLUE_STAINED_GLASS
        );

        // Horizontal bands: the pier runs unbroken past every storey line.
        let mut banded = test_config(30, false, false);
        banded.category = BuildingCategory::ModernSkyscraper;
        banded.use_horizontal_windows = true;
        banded.wall_block = GRAY_CONCRETE;
        banded.window_block = GLASS;
        banded.accent_block = SMOOTH_STONE;
        for h in [9, 12, 13] {
            assert_eq!(
                determine_wall_block_at_position_pristine(h, &banded, corner),
                GRAY_CONCRETE,
                "row {h} of the corner pier"
            );
        }
        assert_eq!(
            determine_wall_block_at_position_pristine(13, &banded, middle),
            GLASS,
            "the band itself is still glass"
        );

        // A windowless brick shed is not a glass tower and keeps its corners.
        let mut shed = test_config(6, false, false);
        shed.has_windows = false;
        assert_eq!(
            determine_wall_block_at_position_pristine(3, &shed, corner),
            BRICK
        );

        // Nor is a greenhouse, which is glass walled for its own reasons.
        let mut greenhouse = test_config(6, false, false);
        greenhouse.category = BuildingCategory::Greenhouse;
        greenhouse.has_windows = false;
        greenhouse.wall_block = GLASS;
        assert_eq!(
            determine_wall_block_at_position_pristine(3, &greenhouse, corner),
            GLASS
        );
    }

    #[test]
    fn floor_role_boundaries() {
        // 3 storeys at cycle 4: height = 3*4 + 2 = 14.
        let config = test_config(14, false, false);
        assert_eq!(config.floor_role(1), FloorRole::Ground);
        assert_eq!(config.floor_role(5), FloorRole::Ground);
        assert_eq!(config.floor_role(6), FloorRole::Body);
        assert_eq!(config.floor_role(10), FloorRole::Body);
        assert_eq!(config.floor_role(11), FloorRole::Top);
        assert_eq!(config.floor_role(14), FloorRole::Top);
    }

    #[test]
    fn attic_band_is_solid_with_small_lights() {
        use crate::element_processing::building_facade::ColumnFacade;
        let config = test_config(14, true, false);
        // Middle of the attic band: window only at the single light position.
        let light = determine_wall_block_at_position_pristine(
            12,
            &config,
            ColumnFacade {
                wall_u: 1,
                ..Default::default()
            },
        );
        assert_eq!(light, GLASS, "attic light at window_col 1, floor_row 2");
        let wall = determine_wall_block_at_position_pristine(
            12,
            &config,
            ColumnFacade {
                wall_u: 0,
                ..Default::default()
            },
        );
        assert_eq!(wall, BRICK, "attic band is otherwise solid");
        // Body floors keep full 3-wide windows.
        let body = determine_wall_block_at_position_pristine(
            7,
            &config,
            ColumnFacade {
                wall_u: 0,
                ..Default::default()
            },
        );
        assert_eq!(body, GLASS);
    }

    #[test]
    fn top_treatment_narrows_windows_and_adds_band() {
        use crate::element_processing::building_facade::ColumnFacade;
        let config = test_config(14, false, true);
        // Band below the treated top floor (h = height - cycle = 10, row 0).
        let band = determine_wall_block_at_position_pristine(
            10,
            &config,
            ColumnFacade {
                wall_u: 0,
                ..Default::default()
            },
        );
        assert_eq!(band, SMOOTH_STONE);
        // Top floor loses its third window column…
        let narrowed = determine_wall_block_at_position_pristine(
            12,
            &config,
            ColumnFacade {
                wall_u: 2,
                ..Default::default()
            },
        );
        assert_eq!(narrowed, BRICK);
        // …but keeps the first two.
        let kept = determine_wall_block_at_position_pristine(
            12,
            &config,
            ColumnFacade {
                wall_u: 1,
                ..Default::default()
            },
        );
        assert_eq!(kept, GLASS);
    }

    // A 3-column glass strip must stay 3 columns wide at any angle. bx + bz was
    // constant along a 135-degree wall, turning the facade into one band.
    #[test]
    fn window_rhythm_period_is_six_at_any_wall_angle() {
        use crate::bresenham::bresenham_line;
        let config = test_config(14, false, false);
        // 0, 90, 45 and 135 degrees, plus shallow angles both ways.
        for &(x2, z2) in &[
            (40, 0),
            (0, 40),
            (40, 40),
            (-40, 40),
            (40, 13),
            (13, 40),
            (40, -13),
        ] {
            let axis_x = segment_axis_x(0, 0, x2, z2);
            let mut prev_u: Option<i32> = None;
            let (mut glass_run, mut max_glass_run) = (0, 0);
            for (bx, _, bz) in bresenham_line(0, 0, 0, x2, 0, z2) {
                let u = if axis_x { bx } else { bz };
                if let Some(p) = prev_u {
                    assert_eq!(
                        (u - p).abs(),
                        1,
                        "ordinate must step by one per column at {:?}",
                        (x2, z2)
                    );
                }
                prev_u = Some(u);
                if config.window_col(u) < 3 {
                    glass_run += 1;
                    max_glass_run = max_glass_run.max(glass_run);
                } else {
                    glass_run = 0;
                }
            }
            assert_eq!(
                max_glass_run,
                3,
                "window strip must stay 3 columns wide at {:?}",
                (x2, z2)
            );
        }
    }

    fn peak_cap_config(w: i32, l: i32) -> RoofConfig {
        RoofConfig {
            min_x: 0,
            max_x: w - 1,
            min_z: 0,
            max_z: l - 1,
            center_x: (w - 1) / 2,
            center_z: (l - 1) / 2,
            base_height: 10,
            building_height: 40,
            abs_terrain_offset: 0,
            roof_block: BRICK,
            add_dormers: false,
            element_id_for_decor: 1,
            peak_cap: None,
        }
    }

    fn cap(
        pairs: &[(&str, &str)],
        rt: RoofType,
        w: i32,
        l: i32,
        orient: Option<&str>,
    ) -> Option<i32> {
        let tags: HashMap<String, String> = pairs
            .iter()
            .map(|(k, v)| (k.to_string(), v.to_string()))
            .collect();
        let nodes: Vec<ProcessedNode> = [(0, 0), (w - 1, 0), (w - 1, l - 1), (0, l - 1), (0, 0)]
            .iter()
            .enumerate()
            .map(|(i, &(x, z))| ProcessedNode {
                id: i as u64,
                tags: HashMap::new(),
                x,
                z,
            })
            .collect();
        let ridge = ridge_frame(&nodes, w - 1, l - 1, orient, None, None);
        roof_peak_cap(&tags, rt, &peak_cap_config(w, l), &ridge, 1.0)
    }

    // roof:angle is a stated pitch, previously read by nothing at all.
    #[test]
    fn roof_angle_drives_the_ridge_rise() {
        // 45 degrees on a 20x18 gable: the ridge runs along 20, so the slope crosses 9.
        assert_eq!(
            cap(&[("roof:angle", "45")], RoofType::Gabled, 20, 18, None),
            Some(9)
        );
        // Shallower pitch, same span.
        assert_eq!(
            cap(&[("roof:angle", "30")], RoofType::Gabled, 20, 18, None),
            Some(5)
        );
        // A mapped roof:height still wins outright.
        assert_eq!(
            cap(
                &[("roof:angle", "45"), ("roof:height", "3")],
                RoofType::Gabled,
                20,
                18,
                None
            ),
            Some(3)
        );
    }

    #[test]
    fn roof_angle_uses_the_span_the_roof_actually_crosses() {
        // 20 wide x 8 long, 45 degrees. Default ridge runs along the LONG axis,
        // so the slope crosses the 8 axis: rise 4.
        assert_eq!(
            cap(&[("roof:angle", "45")], RoofType::Gabled, 20, 8, None),
            Some(4)
        );
        // `roof:orientation=across` flips the ridge onto the short axis, so the
        // slope now crosses the 20 axis: rise 10.
        assert_eq!(
            cap(
                &[("roof:angle", "45")],
                RoofType::Gabled,
                20,
                8,
                Some("across")
            ),
            Some(10)
        );
        // A skillion climbs its whole run, not a half-span, and picks the axis
        // from roof:direction. East -> the 20 axis.
        assert_eq!(
            cap(
                &[("roof:angle", "45"), ("roof:direction", "90")],
                RoofType::Skillion,
                20,
                8,
                None
            ),
            Some(20)
        );
        // Untagged direction falls back to the shorter axis, like the generator.
        assert_eq!(
            cap(&[("roof:angle", "45")], RoofType::Skillion, 20, 8, None),
            Some(8)
        );
    }

    #[test]
    fn implausible_or_irrelevant_roof_angles_are_ignored() {
        for bad in ["0", "90", "-10", "flat", ""] {
            assert_eq!(
                cap(&[("roof:angle", bad)], RoofType::Gabled, 20, 18, None),
                None,
                "roof:angle={bad:?} must not produce a rise"
            );
        }
        // Shapes that never read peak_cap as a pitch stay on their own paths.
        for rt in [
            RoofType::Flat,
            RoofType::Dome,
            RoofType::Cone,
            RoofType::Onion,
        ] {
            assert_eq!(cap(&[("roof:angle", "45")], rt, 20, 18, None), None);
        }
        // A steep pitch on a wide footprint is still bounded by the walls.
        assert_eq!(
            cap(&[("roof:angle", "80")], RoofType::Gabled, 200, 200, None),
            Some(40),
            "rise is clamped to building_height"
        );
    }

    // Each ring vertex is walked twice and the axis flips at most corners, so every
    // pass must agree on its ordinate or decorations land in front of solid wall.
    #[test]
    fn shared_ring_vertices_resolve_to_one_ordinate() {
        let rings: [&[(i32, i32)]; 6] = [
            // Axis-aligned rectangle: the axis flips at all four corners.
            &[(0, 0), (20, 0), (20, 10), (0, 10), (0, 0)],
            // Shallow/steep mix: the axis flips mid-polyline, not just at
            // right angles.
            &[(0, 0), (25, 7), (30, 30), (5, 26), (0, 0)],
            // Reflex corner.
            &[(0, 0), (18, 0), (18, 9), (9, 9), (9, 18), (0, 18), (0, 0)],
            // 45-degree ties on every edge.
            &[(0, 0), (16, 16), (32, 0), (16, -16), (0, 0)],
            // Duplicate vertex: low --scale collapses these and rotation re-rounds nodes.
            &[(0, 0), (0, 10), (0, 10), (10, 10), (0, 0)],
            // Duplicate on the seam vertex, where the walk-back has to wrap.
            &[(0, 0), (0, 0), (14, 0), (14, 8), (0, 0)],
        ];

        for ring in rings {
            let nodes: Vec<ProcessedNode> = ring
                .iter()
                .enumerate()
                .map(|(i, &(x, z))| ProcessedNode {
                    id: i as u64,
                    tags: HashMap::new(),
                    x,
                    z,
                })
                .collect();

            let mut seen: HashMap<(i32, i32), i32> = HashMap::new();
            for i in 1..nodes.len() {
                let (x1, z1) = (nodes[i - 1].x, nodes[i - 1].z);
                let (x2, z2) = (nodes[i].x, nodes[i].z);
                let seg_axis_x = segment_axis_x(x1, z1, x2, z2);
                let start_axis_x = segment_start_axis_x(&nodes, i, seg_axis_x);
                for (idx, (bx, _, bz)) in bresenham_line(x1, 0, z1, x2, 0, z2).iter().enumerate() {
                    let u = wall_ordinate(idx, start_axis_x, seg_axis_x, *bx, *bz);
                    if let Some(prev) = seen.insert((*bx, *bz), u) {
                        assert_eq!(
                            prev,
                            u,
                            "column {:?} got two ordinates on ring {ring:?}",
                            (*bx, *bz)
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn mansard_profile_shape() {
        // Steep 2-cell band to steep_h, then shallow 1:2, capped.
        assert_eq!(mansard_boost(0, 4, 10), 0);
        assert_eq!(mansard_boost(1, 4, 10), 2);
        assert_eq!(mansard_boost(2, 4, 10), 4);
        assert_eq!(mansard_boost(3, 4, 10), 4);
        assert_eq!(mansard_boost(4, 4, 10), 5);
        assert_eq!(mansard_boost(8, 4, 6), 6); // capped
        for d in 0..20 {
            assert!(mansard_boost(d + 1, 4, 12) >= mansard_boost(d, 4, 12));
        }
    }

    #[test]
    fn new_roof_shapes_parse_distinctly() {
        assert_eq!(parse_roof_type("mansard"), RoofType::Mansard);
        assert_eq!(parse_roof_type("gambrel"), RoofType::Gambrel);
        assert_eq!(parse_roof_type("half-hipped"), RoofType::HalfHipped);
        assert_eq!(parse_roof_type("hipped"), RoofType::Hipped);
        assert_eq!(parse_roof_type("round"), RoofType::Round);
        assert_eq!(parse_roof_type("gabled"), RoofType::Gabled);
    }

    #[test]
    fn podium_tower_planning_is_bounded_and_deterministic() {
        let mut config = test_config(50, false, false);
        config.is_tall_building = true;
        let way = ProcessedWay {
            id: 9,
            nodes: Vec::new(),
            tags: std::iter::once(("building".to_string(), "office".to_string())).collect(),
        };
        let mut floor_area: Vec<(i32, i32)> = Vec::new();
        for x in 20..=50 {
            for z in 20..=44 {
                floor_area.push((x, z));
            }
        }
        let footprint = floor_area.len();

        let mut any_plan = false;
        for seed in 0..30u64 {
            let a = plan_podium_tower(
                &way,
                &config,
                RoofType::Flat,
                true,
                footprint,
                &floor_area,
                seed,
            );
            let b = plan_podium_tower(
                &way,
                &config,
                RoofType::Flat,
                true,
                footprint,
                &floor_area,
                seed,
            );
            assert_eq!(a.is_some(), b.is_some());
            if let (Some(a), Some(b)) = (a, b) {
                any_plan = true;
                assert_eq!(a.podium_height, b.podium_height);
                assert!(a.podium_height == 10 || a.podium_height == 14);
                assert_eq!(a.full_height, 50);
                assert!(a.inset >= 3);
                assert!(config.building_height - a.podium_height >= 2 * config.floor_cycle);
            }
        }
        assert!(any_plan, "the 40% roll should hit within 30 seeds");

        // Small footprints never get a podium split.
        let small: Vec<(i32, i32)> = floor_area.iter().copied().take(300).collect();
        for seed in 0..30u64 {
            assert!(
                plan_podium_tower(&way, &config, RoofType::Flat, true, 300, &small, seed).is_none()
            );
        }
        // Pitched roofs never do either.
        for seed in 0..30u64 {
            assert!(plan_podium_tower(
                &way,
                &config,
                RoofType::Gabled,
                true,
                footprint,
                &floor_area,
                seed
            )
            .is_none());
        }
    }

    // The Luanti stone fallback would silently break the export.
    #[test]
    fn every_reachable_building_block_maps_to_luanti() {
        use crate::luanti_block_map::{to_luanti_node, LuantiGame};
        let mut blocks: Vec<Block> = Vec::new();
        blocks.extend(crate::block_palette::all_building_palette_blocks());
        blocks.extend_from_slice(&RESIDENTIAL_WALL_OPTIONS);
        blocks.extend_from_slice(&COMMERCIAL_WALL_OPTIONS);
        blocks.extend_from_slice(&INDUSTRIAL_WALL_OPTIONS);
        blocks.extend_from_slice(&RELIGIOUS_WALL_OPTIONS);
        blocks.extend_from_slice(&INSTITUTIONAL_WALL_OPTIONS);
        blocks.extend_from_slice(&FARM_WALL_OPTIONS);
        blocks.extend_from_slice(&HISTORIC_WALL_OPTIONS);
        blocks.extend_from_slice(&GARAGE_WALL_OPTIONS);
        blocks.extend_from_slice(&NORDIC_WOOD_ADDITIONS);
        blocks.extend_from_slice(&ACCENT_BLOCK_OPTIONS);
        blocks.extend_from_slice(&WINDOW_VARIATIONS);
        blocks.extend_from_slice(&RESIDENTIAL_WINDOW_OPTIONS);
        blocks.extend_from_slice(&FARM_WINDOW_OPTIONS);
        blocks.extend_from_slice(&HISTORIC_WINDOW_OPTIONS);
        blocks.extend_from_slice(&FLOOR_BLOCK_OPTIONS);
        for style in [
            DoorStyle::Oak,
            DoorStyle::Spruce,
            DoorStyle::DarkOak,
            DoorStyle::Birch,
        ] {
            blocks.push(style.base_block());
        }
        let base: Vec<Block> = blocks.clone();
        for b in base {
            blocks.extend_from_slice(substitute_pool_only(b));
        }
        for b in blocks {
            if b == STONE {
                continue;
            }
            let node = to_luanti_node(b, LuantiGame::Mineclonia, None);
            assert_ne!(
                node.name,
                "mcl_core:stone",
                "{} falls back to stone on Luanti",
                b.name()
            );
        }
    }

    // Identically-tagged parts of one group must resolve the same style.
    #[test]
    fn identically_tagged_parts_resolve_one_shared_style() {
        use crate::element_processing::building_test_support::rect_way;
        let tags: &[(&str, &str)] = &[("building:part", "yes"), ("height", "40")];
        let way_a = rect_way(500, 20, 20, 30, 30, tags);
        let way_b = rect_way(501, 31, 20, 41, 30, tags);
        let group_seed = 4242u64;

        let style_for = |way: &ProcessedWay| {
            let (h, tall) = calculate_building_height(way, "yes", 0, 1.0, None, 4, 100, group_seed);
            let category = BuildingCategory::from_element(way, tall, h, group_seed, 1.0);
            let preset = BuildingStylePreset::for_category(category);
            let era = crate::osm_parser::building_arch_era(&way.tags);
            let detail = compute_detail_tier(way, category, 100, h, false);
            let mut rng = element_rng(group_seed);
            (
                category,
                BuildingStyle::resolve(
                    &preset,
                    way,
                    "yes",
                    category,
                    era,
                    Climate::Temperate,
                    detail,
                    h,
                    h > 6,
                    100,
                    group_seed,
                    &mut rng,
                ),
            )
        };
        let (cat_a, a) = style_for(&way_a);
        let (cat_b, b) = style_for(&way_b);
        assert_eq!(cat_a, cat_b);
        assert_eq!(a.wall_block, b.wall_block);
        assert_eq!(a.window_block, b.window_block);
        assert_eq!(a.accent_block, b.accent_block);
        assert_eq!(a.roof_block, b.roof_block);
        assert_eq!(a.wall_depth_style, b.wall_depth_style);
        assert_eq!(a.roof_type, b.roof_type);
        assert_eq!(
            pick_window_archetype(cat_a, ArchEra::Unknown, group_seed),
            pick_window_archetype(cat_b, ArchEra::Unknown, group_seed)
        );
    }

    // An inferred elevated part ends flush with its ground-level sibling
    #[test]
    fn inferred_elevated_part_tops_flush() {
        let tagged = |pairs: &[(&str, &str)]| ProcessedWay {
            id: 1,
            nodes: Vec::new(),
            tags: pairs
                .iter()
                .map(|(k, v)| (k.to_string(), v.to_string()))
                .collect(),
        };
        let ground = tagged(&[("building:part", "yes")]);
        let lifted = tagged(&[("building:part", "yes"), ("building:min_level", "1")]);
        for seed in 1..20u64 {
            let (hg, _) = calculate_building_height(&ground, "yes", 0, 1.0, None, 4, 400, seed);
            let (hl, _) = calculate_building_height(&lifted, "yes", 1, 1.0, None, 4, 400, seed);
            let lift = 4 + GROUND_FLOOR_BONUS;
            assert_eq!(hl + lift, hg, "seed {seed}");
        }
    }

    // Parts without roof:shape stay flat instead of rolling the gable lottery.
    #[test]
    fn untagged_parts_never_infer_pitched_roofs() {
        use crate::element_processing::building_test_support::rect_way;
        for seed in 1..30u64 {
            let tags: &[(&str, &str)] = &[("building:part", "yes"), ("height", "12")];
            let way = rect_way(seed * 7 + 1, 20, 20, 32, 32, tags);
            let (h, tall) = calculate_building_height(&way, "yes", 0, 1.0, None, 4, 144, seed);
            let category = BuildingCategory::from_element(&way, tall, h, seed, 1.0);
            let preset = BuildingStylePreset::for_category(category);
            let era = crate::osm_parser::building_arch_era(&way.tags);
            let detail = compute_detail_tier(&way, category, 144, h, false);
            let mut rng = element_rng(seed);
            let style = BuildingStyle::resolve(
                &preset,
                &way,
                "yes",
                category,
                era,
                Climate::Temperate,
                detail,
                h,
                h > 6,
                144,
                seed,
                &mut rng,
            );
            assert_eq!(style.roof_type, RoofType::Flat, "seed {seed}");
            assert!(!style.generate_roof, "seed {seed}");
        }
    }

    #[test]
    fn detail_tier_boundaries() {
        let tagged = |pairs: &[(&str, &str)]| ProcessedWay {
            id: 1,
            nodes: Vec::new(),
            tags: pairs
                .iter()
                .map(|(k, v)| (k.to_string(), v.to_string()))
                .collect(),
        };
        let plain = tagged(&[]);
        assert_eq!(
            compute_detail_tier(&plain, BuildingCategory::Garage, 30, 3, false),
            DetailTier::Minimal
        );
        assert_eq!(
            compute_detail_tier(&plain, BuildingCategory::House, 100, 10, true),
            DetailTier::Standard
        );
        assert_eq!(
            compute_detail_tier(&plain, BuildingCategory::Commercial, 800, 20, true),
            DetailTier::Enhanced
        );
        let notable = tagged(&[("historic", "yes"), ("heritage", "2"), ("wikidata", "Q42")]);
        assert_eq!(
            compute_detail_tier(&notable, BuildingCategory::Historic, 600, 20, true),
            DetailTier::Landmark
        );
    }

    #[test]
    fn detail_tier_height_score_does_not_overflow() {
        let way = ProcessedWay {
            id: 1,
            nodes: Vec::new(),
            tags: std::collections::HashMap::new(),
        };
        assert_eq!(
            compute_detail_tier(&way, BuildingCategory::House, 100, i32::MAX, false),
            DetailTier::Standard
        );
    }

    #[test]
    fn window_pools_cover_previously_generic_categories() {
        assert_eq!(
            window_pool_for_category(BuildingCategory::Farm),
            &FARM_WINDOW_OPTIONS[..]
        );
        assert_eq!(
            window_pool_for_category(BuildingCategory::Office),
            &INSTITUTIONAL_WINDOW_OPTIONS[..]
        );
        assert_eq!(
            window_pool_for_category(BuildingCategory::Historic),
            &HISTORIC_WINDOW_OPTIONS[..]
        );
    }

    #[test]
    fn dark_wall_or_dark_accent_gets_dark_glass() {
        // dark wall
        assert_eq!(
            coordinated_window_block(BLACK_CONCRETE, SMOOTH_STONE, LIGHT_BLUE_STAINED_GLASS),
            GRAY_STAINED_GLASS
        );
        // light wall but dark accent band (the blackstone-line modern tower)
        assert_eq!(
            coordinated_window_block(WHITE_CONCRETE, BLACKSTONE, LIGHT_BLUE_STAINED_GLASS),
            GRAY_STAINED_GLASS
        );
        assert_eq!(
            coordinated_window_block(GRAY_CONCRETE, SMOOTH_STONE, LIGHT_BLUE_STAINED_GLASS),
            GRAY_STAINED_GLASS
        );
    }

    #[test]
    fn light_wall_and_light_accent_keep_the_light_window() {
        assert_eq!(
            coordinated_window_block(WHITE_CONCRETE, SMOOTH_STONE, LIGHT_BLUE_STAINED_GLASS),
            LIGHT_BLUE_STAINED_GLASS
        );
        assert_eq!(
            coordinated_window_block(QUARTZ_BLOCK, POLISHED_ANDESITE, LIGHT_BLUE_STAINED_GLASS),
            LIGHT_BLUE_STAINED_GLASS
        );
    }

    #[test]
    fn glass_family_variant_is_always_glass_family() {
        for seed in 0u64..300 {
            assert!(matches!(
                BuildingCategory::glass_family_variant(seed),
                BuildingCategory::GlassySkyscraper
                    | BuildingCategory::GridSkyscraper
                    | BuildingCategory::GlassCornerSkyscraper
            ));
        }
    }
}

#[cfg(test)]
mod facade_integration_tests {
    use super::*;
    use crate::coordinate_system::cartesian::XZBBox;
    use crate::element_processing::building_test_support::{
        bitmap_with_rect, rect_way, test_editor,
    };
    use clap::Parser as _;
    use fnv::FnvHashMap;

    const DOOR_BLOCKS: &[Block] = &[OAK_DOOR, SPRUCE_DOOR_LOWER, DARK_OAK_DOOR_LOWER, BIRCH_DOOR];

    fn flat_args() -> Args {
        Args::parse_from([
            "arnis",
            "--bbox",
            "1,2,3,4",
            "--mode",
            "geo-only",
            "--ground-level",
            "0",
        ])
    }

    /// `flat_args` at a chosen world scale. The facade export applies as a
    /// block grid from two blocks per metre up, which is where the shell is.
    fn scaled_args(scale: &str) -> Args {
        Args::parse_from([
            "arnis",
            "--bbox",
            "1,2,3,4",
            "--mode",
            "geo-only",
            "--ground-level",
            "0",
            "--scale",
            scale,
        ])
    }

    fn run_building(
        editor: &mut WorldEditor,
        way: &ProcessedWay,
        road: &CoordinateBitmap,
        footprints: &CoordinateBitmap,
    ) {
        run_building_with(editor, way, road, footprints, &flat_args());
    }

    fn run_building_with(
        editor: &mut WorldEditor,
        way: &ProcessedWay,
        road: &CoordinateBitmap,
        footprints: &CoordinateBitmap,
        args: &Args,
    ) {
        let cache = FloodFillCache::new();
        let passages = CoordinateBitmap::new_empty();
        let groups: FnvHashMap<u64, Vec<u64>> = FnvHashMap::default();
        let ctx = BuildingContext {
            flood_fill_cache: &cache,
            building_passages: &passages,
            road_mask: road,
            building_footprints: footprints,
            group_members: &groups,
            interior_uses:
                crate::element_processing::subprocessor::interior::InteriorUseIndex::empty(),
        };
        generate_buildings(editor, way, args, None, None, &ctx, way.id);
    }

    // A roof-only canopy mapped `roof:shape=round` is a barrel vault: level
    // along the ridge, curved across it. A dome falls away in both directions.
    #[test]
    fn a_round_canopy_vaults_instead_of_doming() {
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let road = CoordinateBitmap::new(&xz);
        let footprints = CoordinateBitmap::new(&xz);
        let way = rect_way(
            77,
            10,
            20,
            39,
            31,
            &[("building", "roof"), ("roof:shape", "round")],
        );
        let mut editor = test_editor(&xz);
        run_building(&mut editor, &way, &road, &footprints);

        let top = |e: &WorldEditor, x: i32, z: i32| e.highest_block_between(x, z, 0, 200);
        let crown_mid = top(&editor, 25, 25).expect("a vault over the middle");
        // Level along the ridge (the 30-cell axis).
        for x in [15, 20, 30, 35] {
            assert_eq!(
                top(&editor, x, 25),
                Some(crown_mid),
                "the ridge is level at x={x}"
            );
        }
        // Curved across it: the flank sits below the crown.
        let flank = top(&editor, 25, 21).expect("a vault over the flank");
        assert!(
            flank < crown_mid,
            "flank {flank} should sit below crown {crown_mid}"
        );
    }

    #[test]
    fn synthetic_door_lands_on_the_street_wall() {
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let road = bitmap_with_rect(&xz, 0, 12, 59, 14);
        let footprints = CoordinateBitmap::new(&xz);
        let way = rect_way(
            42,
            20,
            20,
            40,
            32,
            &[("building", "house"), ("building:levels", "2")],
        );
        let mut editor = test_editor(&xz);
        run_building(&mut editor, &way, &road, &footprints);

        let door_on =
            |e: &WorldEditor, x: i32, z: i32| e.check_for_block(x, 1, z, Some(DOOR_BLOCKS));
        let street_wall = (20..=40).any(|x| door_on(&editor, x, 20));
        let other_walls = (20..=40).any(|x| door_on(&editor, x, 32))
            || (20..=32).any(|z| door_on(&editor, 20, z) || door_on(&editor, 40, z));
        assert!(street_wall, "door should be on the street-facing wall");
        assert!(!other_walls, "no doors on the other walls");
    }

    #[test]
    fn mapped_entrance_suppresses_the_synthetic_door() {
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let road = bitmap_with_rect(&xz, 0, 12, 59, 14);
        let footprints = CoordinateBitmap::new(&xz);
        let mut way = rect_way(
            44,
            20,
            20,
            40,
            32,
            &[("building", "house"), ("building:levels", "2")],
        );
        // Mapped entrance in the middle of the rear wall.
        let mut tags = HashMap::new();
        tags.insert("entrance".to_string(), "yes".to_string());
        way.nodes.insert(
            3,
            ProcessedNode {
                id: 4444,
                tags,
                x: 30,
                z: 32,
            },
        );
        let mut editor = test_editor(&xz);
        run_building(&mut editor, &way, &road, &footprints);

        assert!(
            editor.check_for_block(30, 1, 32, Some(DOOR_BLOCKS)),
            "mapped entrance gets an oriented door"
        );
        let street_doors = (20..=40).any(|x| editor.check_for_block(x, 1, 20, Some(DOOR_BLOCKS)));
        assert!(
            !street_doors,
            "no synthetic door once an entrance is mapped"
        );
    }

    #[test]
    fn party_wall_has_no_windows_but_free_wall_does() {
        // The two facade tests install a process-global picture source while
        // they run, and a dressed ring has no windows at all, so this one has
        // to take the same lock rather than race them.
        let _guard = crate::mapillary::facades::TEST_GLOBALS
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let road = bitmap_with_rect(&xz, 0, 12, 59, 14);
        // Attached neighbor east of the house.
        let footprints = bitmap_with_rect(&xz, 41, 20, 52, 32);
        let way = rect_way(
            43,
            20,
            20,
            40,
            32,
            &[("building", "house"), ("building:levels", "2")],
        );
        let mut editor = test_editor(&xz);
        run_building(&mut editor, &way, &road, &footprints);

        let glass = |e: &WorldEditor, x: i32, z: i32, y: i32| {
            e.check_for_block(x, y, z, Some(&RESIDENTIAL_WINDOW_OPTIONS))
        };
        let east_has_glass = (21..32).any(|z| (2..=9).any(|y| glass(&editor, 40, z, y)));
        let west_has_glass = (21..32).any(|z| (2..=9).any(|y| glass(&editor, 20, z, y)));
        assert!(
            !east_has_glass,
            "party wall must not glaze into the neighbor"
        );
        assert!(west_has_glass, "free wall keeps its windows");
    }

    #[test]
    fn mansard_and_gambrel_roofs_build_above_the_walls() {
        const SLATE: &[Block] = &[POLISHED_BLACKSTONE, DEEPSLATE_BRICKS, BLACKSTONE];
        for shape in ["mansard", "gambrel"] {
            let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
            let road = bitmap_with_rect(&xz, 0, 12, 59, 14);
            let footprints = CoordinateBitmap::new(&xz);
            let way = rect_way(
                46,
                20,
                20,
                40,
                32,
                &[
                    ("building", "house"),
                    ("building:levels", "2"),
                    ("roof:shape", shape),
                    ("roof:material", "slate"),
                ],
            );
            let mut editor = test_editor(&xz);
            run_building(&mut editor, &way, &road, &footprints);

            // Slate roof mass above the 10-block walls near the footprint centre.
            let roofed =
                (11..=18).any(|y| (24..=28).any(|z| editor.check_for_block(30, y, z, Some(SLATE))));
            assert!(roofed, "{shape} roof should rise above the walls");
        }
    }

    /// Every block the residential window pass can leave on a wall: the
    /// category's own pool plus the dark-wall substitution.
    const WINDOW_BLOCKS: &[Block] = &[
        GLASS,
        WHITE_STAINED_GLASS,
        LIGHT_GRAY_STAINED_GLASS,
        BROWN_STAINED_GLASS,
        TINTED_GLASS,
        LIGHT_BLUE_STAINED_GLASS,
        GRAY_STAINED_GLASS,
    ];

    /// Whether any block of the wall column at `(x, z)` is a window.
    fn column_has_window(editor: &WorldEditor, x: i32, z: i32) -> bool {
        (1..80).any(|y| {
            editor
                .get_block_absolute(x, y, z)
                .is_some_and(|b| WINDOW_BLOCKS.iter().any(|w| w.id() == b.id()))
        })
    }

    /// Only the walls a photograph covers are built as a plain shell. The rest
    /// of the ring stays a normal Arnis building, and the corner column where
    /// the two meet carries neither a gap nor a window of its own.
    #[test]
    fn only_the_photographed_wall_loses_its_windows() {
        let _guard = crate::mapillary::facades::TEST_GLOBALS
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        const WAY: u64 = 4711;
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        // The street runs south of the building, so the synthetic entrance
        // lands on the wall without a photograph and cannot be mistaken for a
        // hole in the shell.
        let road = bitmap_with_rect(&xz, 0, 38, 59, 40);
        let footprints = CoordinateBitmap::new(&xz);
        let way = rect_way(
            WAY,
            20,
            20,
            40,
            32,
            &[
                ("building", "apartments"),
                ("building:levels", "4"),
                ("roof:shape", "flat"),
            ],
        );
        let args = scaled_args("2");

        // The same building twice: once with one photographed wall, the north
        // edge from node (20, 20) to node (40, 20), and once with no export at
        // all, which is what the other three walls have to end up looking like.
        let elements = vec![crate::osm_parser::ProcessedElement::Way(way.clone())];
        crate::mapillary::facades::install_wall_blocks_for_test(
            // 11 metre columns over the edge's 21 blocks at two blocks per
            // metre, and 20 metres of rows, taller than the building, so every
            // wall row of it has a cell.
            &[(WAY, WAY * 100, WAY * 100 + 1, 11, 20)],
            &elements,
            &xz,
            2.0,
        );
        // The export numbers its columns in metres, so the block at the far
        // end of the edge falls exactly on column 11 of 11 and carries no
        // cell. That is the corner the seam runs through.
        assert!(crate::mapillary::facades::photo_column(20, 20, WAY));
        assert!(!crate::mapillary::facades::photo_column(40, 20, WAY));
        let mut facaded = test_editor(&xz);
        run_building_with(&mut facaded, &way, &road, &footprints, &args);
        crate::mapillary::facades::clear();
        let mut plain = test_editor(&xz);
        run_building_with(&mut plain, &way, &road, &footprints, &args);

        // Without the export this building glazes both walls, so the north
        // wall losing its windows is the shell and not the style.
        assert!(
            (21..40).any(|x| column_has_window(&plain, x, 20)),
            "the test building has to glaze its north wall without an export"
        );
        assert!(
            (21..40).any(|x| column_has_window(&plain, x, 32)),
            "and its south wall"
        );

        for x in 20..=40 {
            assert!(
                !column_has_window(&facaded, x, 20),
                "column {x} of the photographed wall kept a procedural window"
            );
        }
        assert!(
            (21..40).any(|x| column_has_window(&facaded, x, 32)),
            "the wall with no photograph must still be a normal building"
        );

        // The photograph reaches the wall: its cells are one flat colour, so
        // the block they resolve to has to be on that wall and nowhere else.
        let shell =
            crate::block_palette::facade_block_for_color(crate::mapillary::facades::TEST_WALL_RGB);
        let carries_shell = |e: &WorldEditor, x: i32, z: i32| {
            (1..80).any(|y| {
                e.get_block_absolute(x, y, z)
                    .is_some_and(|b| b.id() == shell.id())
            })
        };
        assert!(carries_shell(&facaded, 30, 20), "no texture on the wall");
        assert!(
            !carries_shell(&facaded, 30, 32),
            "the texture must not reach the wall it was not taken of"
        );

        // The seam. The corner the projection drops is still built as shell,
        // so a photographed wall cannot end in a lone procedural window, and
        // the column two ring segments both write is solid from the ground to
        // the roof line whichever of them wrote it last.
        for &(x, z) in &[(20, 20), (40, 20)] {
            let top = (1..80)
                .rev()
                .find(|&y| facaded.get_block_absolute(x, y, z).is_some())
                .expect("corner column is empty");
            assert!(
                (1..=top).all(|y| facaded.get_block_absolute(x, y, z).is_some()),
                "gap in the corner column at ({x}, {z})"
            );
        }
    }

    /// A preset facade covers a building's whole ring, so the whole ring is
    /// built as a plain shell, which is the same flattening a photographed
    /// wall gets and for the same reason: the panel hangs a fraction of a
    /// block in front of the wall, so a sill, a quoin or a cornice stands
    /// between the viewer and the picture. Measured on Leipzig, this is the
    /// difference between a fifth of the average panel being hidden by the
    /// building's own blocks and a tenth.
    #[test]
    fn a_preset_facade_flattens_the_whole_ring() {
        let _guard = crate::mapillary::facades::TEST_GLOBALS
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let road = bitmap_with_rect(&xz, 0, 38, 59, 40);
        let footprints = CoordinateBitmap::new(&xz);
        let way = rect_way(
            4712,
            20,
            20,
            40,
            32,
            &[
                ("building", "apartments"),
                ("building:levels", "4"),
                ("roof:shape", "flat"),
            ],
        );
        let args = scaled_args("1");

        // The same building twice: once with no preset set, which is what the
        // dressed one has to stop looking like, and once with one installed.
        crate::building_facades::reset(false, None, 16, 1.0);
        let mut plain = test_editor(&xz);
        run_building_with(&mut plain, &way, &road, &footprints, &args);

        let dir = tempfile::tempdir().unwrap();
        // An empty file is enough: the loader only checks that the picture the
        // manifest names is there, and the panels are never hung here because
        // the test editor writes no hanging entities.
        std::fs::write(dir.path().join("wall.png"), b"").unwrap();
        std::fs::write(
            dir.path()
                .join(crate::building_facades::manifest::MANIFEST_NAME),
            br#"{"version": 1, "textures": [{"file": "wall.png",
                 "categories": ["Default"], "metres_wide": 20.0,
                 "metres_tall": 12.0, "storeys": 4,
                 "tiles_horizontally": true, "has_ground_floor": true}]}"#,
        )
        .unwrap();
        crate::building_facades::reset(true, Some(dir.path()), 16, 1.0);
        assert!(crate::building_facades::enabled());
        let mut dressed = test_editor(&xz);
        // The shell is only as wide as the panels are, and a world that hangs
        // no display entities gets no panels, so the flattening has to be asked
        // for on an editor that would hang them.
        dressed.set_map_decals(true);
        run_building_with(&mut dressed, &way, &road, &footprints, &args);
        crate::building_facades::reset(false, None, 16, 1.0);

        // Windows first, so a shell that flattened nothing cannot pass.
        assert!(
            (21..40).any(|x| column_has_window(&plain, x, 20)),
            "the test building has to glaze its walls without a preset set"
        );
        for x in 20..=40 {
            for z in [20, 32] {
                assert!(
                    !column_has_window(&dressed, x, z),
                    "column ({x}, {z}) of a dressed ring kept a procedural window"
                );
            }
        }
        for z in 20..=32 {
            for x in [20, 40] {
                assert!(
                    !column_has_window(&dressed, x, z),
                    "column ({x}, {z}) of a dressed ring kept a procedural window"
                );
            }
        }

        // And nothing of the building's own stands in the cells the panels
        // hang in, all the way round, below the roof line.
        let outside = |e: &WorldEditor| {
            let mut n = 0;
            for y in 1..=10 {
                for x in 19..=41 {
                    n += usize::from(e.get_block_absolute(x, y, 19).is_some());
                    n += usize::from(e.get_block_absolute(x, y, 33).is_some());
                }
                for z in 19..=33 {
                    n += usize::from(e.get_block_absolute(19, y, z).is_some());
                    n += usize::from(e.get_block_absolute(41, y, z).is_some());
                }
            }
            n
        };
        assert!(
            outside(&plain) > 0,
            "the test building has to stick something out without a preset set"
        );
        assert_eq!(
            outside(&dressed),
            0,
            "a dressed ring left {} blocks standing in front of its panels",
            outside(&dressed)
        );
    }

    /// Writes a one-texture preset set into `dir` and switches it on.
    fn install_preset_set(dir: &std::path::Path) {
        // An empty file is enough for the loader, which only checks that the
        // picture the manifest names is there.
        std::fs::write(dir.join("wall.png"), b"").unwrap();
        std::fs::write(
            dir.join(crate::building_facades::manifest::MANIFEST_NAME),
            br#"{"version": 1, "textures": [{"file": "wall.png",
                 "categories": ["Default"], "metres_wide": 20.0,
                 "metres_tall": 12.0, "storeys": 4,
                 "tiles_horizontally": true, "has_ground_floor": true}]}"#,
        )
        .unwrap();
        crate::building_facades::reset(true, Some(dir), 16, 1.0);
        assert!(crate::building_facades::enabled());
    }

    /// A wall the presets hang nothing on is built exactly as it is with the
    /// feature off.
    ///
    /// The courtyard ring of a building with a hole is the case that shows it:
    /// `building_facades::collect` claims a building once, from its outer ring,
    /// so the inner ring never records a candidate and no panel is ever hung
    /// there. Flattening it anyway costs the courtyard every window, plinth and
    /// accent line it would have had and gives it nothing back, which is how a
    /// building ends up a featureless box of its own wall material.
    #[test]
    fn a_courtyard_ring_the_presets_never_reach_keeps_its_windows() {
        let _guard = crate::mapillary::facades::TEST_GLOBALS
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let xz = XZBBox::rect_from_xz_lengths(70.0, 70.0).unwrap();
        let road = bitmap_with_rect(&xz, 0, 52, 69, 54);
        let footprints = CoordinateBitmap::new(&xz);
        let way = rect_way(
            4713,
            16,
            16,
            48,
            48,
            &[
                ("building", "apartments"),
                ("building:levels", "4"),
                ("roof:shape", "flat"),
            ],
        );
        let hole = [HolePolygon {
            way: rect_way(4714, 26, 26, 38, 38, &[]),
            add_walls: true,
        }];
        let args = scaled_args("1");

        let build = |editor: &mut WorldEditor| {
            let cache = FloodFillCache::new();
            let passages = CoordinateBitmap::new_empty();
            let groups: FnvHashMap<u64, Vec<u64>> = FnvHashMap::default();
            let ctx = BuildingContext {
                flood_fill_cache: &cache,
                building_passages: &passages,
                road_mask: &road,
                building_footprints: &footprints,
                group_members: &groups,
                interior_uses:
                    crate::element_processing::subprocessor::interior::InteriorUseIndex::empty(),
            };
            generate_buildings(editor, &way, &args, None, Some(&hole), &ctx, way.id);
        };

        crate::building_facades::reset(false, None, 16, 1.0);
        let mut plain = test_editor(&xz);
        plain.set_map_decals(true);
        build(&mut plain);

        let dir = tempfile::tempdir().unwrap();
        install_preset_set(dir.path());
        let mut dressed = test_editor(&xz);
        dressed.set_map_decals(true);
        build(&mut dressed);
        crate::building_facades::reset(false, None, 16, 1.0);

        // The courtyard walls, whose four corners are the hole's.
        let courtyard: Vec<(i32, i32)> = (26..=38)
            .flat_map(|i| [(i, 26), (i, 38), (26, i), (38, i)])
            .collect();
        let glazed = |e: &WorldEditor| {
            courtyard
                .iter()
                .filter(|&&(x, z)| column_has_window(e, x, z))
                .count()
        };
        assert!(
            glazed(&plain) > 0,
            "the test courtyard has to glaze its walls without a preset set"
        );
        assert_eq!(
            glazed(&dressed),
            glazed(&plain),
            "the courtyard ring lost windows to a photograph that never comes"
        );

        // And the outer ring, which does get panels, is still flattened.
        assert!(
            (17..48).any(|x| column_has_window(&plain, x, 16)),
            "the test building has to glaze its outer wall without a preset set"
        );
        assert!(
            !(16..=48).any(|x| column_has_window(&dressed, x, 16)),
            "the photographed outer wall kept a procedural window"
        );
    }

    #[test]
    fn street_aware_generation_is_deterministic() {
        // The two facade tests install a process-global picture source while
        // they run, and a dressed ring has no windows at all, so this one has
        // to take the same lock rather than race them.
        let _guard = crate::mapillary::facades::TEST_GLOBALS
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let road = bitmap_with_rect(&xz, 0, 12, 59, 14);
        let footprints = bitmap_with_rect(&xz, 41, 20, 52, 32);
        let way = rect_way(
            45,
            20,
            20,
            40,
            32,
            &[("building", "apartments"), ("building:levels", "3")],
        );
        let mut a = test_editor(&xz);
        run_building(&mut a, &way, &road, &footprints);
        let mut b = test_editor(&xz);
        run_building(&mut b, &way, &road, &footprints);
        assert_eq!(a.content_hash(), b.content_hash());
    }
}

#[cfg(test)]
mod facade_dump {
    use super::*;
    use crate::coordinate_system::cartesian::XZBBox;
    use crate::element_processing::building_test_support::{
        bitmap_with_rect, rect_way, test_editor,
    };
    use clap::Parser as _;
    use fnv::FnvHashMap;

    fn glyph(block: Option<Block>) -> char {
        let Some(b) = block else { return ' ' };
        let name = b.name();
        if name.contains("glass") {
            'o'
        } else if name.contains("trapdoor") {
            '^'
        } else if name.contains("door") {
            'D'
        } else if name.contains("stair") {
            '/'
        } else if name.contains("slab") {
            '_'
        } else if name.contains("fence") || name.contains("bars") {
            '+'
        } else if name.contains("lantern") || name.contains("potted") || name.contains("pot") {
            '*'
        } else if name == "air" {
            ' '
        } else {
            '#'
        }
    }

    // Renders the street facade of a synthetic building as ASCII for manual
    // dial tuning: cargo test facade_dump -- --ignored --nocapture
    #[test]
    #[ignore]
    fn dump_street_facades() {
        // Same reason as the tests above: this dump reads wall blocks, and a
        // facade test running beside it would flatten them.
        let _guard = crate::mapillary::facades::TEST_GLOBALS
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        for (label, tags) in [
            (
                "apartments 4 levels, pre-war",
                vec![
                    ("building", "apartments"),
                    ("building:levels", "4"),
                    ("start_date", "1905"),
                ],
            ),
            (
                "commercial 3 levels (storefront)",
                vec![("building", "commercial"), ("building:levels", "3")],
            ),
            ("plain house, no tags", vec![("building", "house")]),
        ] {
            let xz = XZBBox::rect_from_xz_lengths(70.0, 60.0).unwrap();
            let road = bitmap_with_rect(&xz, 0, 12, 69, 14);
            let footprints = CoordinateBitmap::new(&xz);
            let way = rect_way(4242, 22, 20, 52, 34, &tags);
            let mut editor = test_editor(&xz);
            let args = Args::parse_from([
                "arnis",
                "--bbox",
                "1,2,3,4",
                "--mode",
                "geo-only",
                "--ground-level",
                "0",
            ]);
            let cache = FloodFillCache::new();
            let passages = CoordinateBitmap::new_empty();
            let groups: FnvHashMap<u64, Vec<u64>> = FnvHashMap::default();
            let ctx = BuildingContext {
                flood_fill_cache: &cache,
                building_passages: &passages,
                road_mask: &road,
                building_footprints: &footprints,
                group_members: &groups,
                interior_uses:
                    crate::element_processing::subprocessor::interior::InteriorUseIndex::empty(),
            };
            generate_buildings(&mut editor, &way, &args, None, None, &ctx, way.id);

            println!("\n=== {label} ===");
            println!("street wall plane (z=20) with outward layer (z=19) overlaid:");
            for y in (0..=22).rev() {
                let mut line = String::new();
                for x in 20..=54 {
                    let outward = editor.get_block_absolute(x, y, 19);
                    let wall = editor.get_block_absolute(x, y, 20);
                    let c = if outward.is_some() {
                        glyph(outward).to_ascii_uppercase()
                    } else {
                        glyph(wall)
                    };
                    line.push(c);
                }
                println!("y{y:>2} |{line}|");
            }
        }
    }
}

#[cfg(test)]
mod start_y_tests {
    use super::*;
    use crate::coordinate_system::cartesian::XZBBox;
    use crate::element_processing::building_test_support::{rect_way, test_editor};
    use clap::Parser as _;

    fn offset_for(terrain_y: i32) -> i32 {
        let xzbbox = XZBBox::rect_from_xz_lengths(64.0, 64.0).unwrap();
        let mut editor = test_editor(&xzbbox);
        editor.set_ground(std::sync::Arc::new(crate::ground::Ground::new_flat(
            terrain_y,
        )));
        let way = rect_way(1, 10, 10, 20, 20, &[("building", "yes")]);
        let args = Args::parse_from(["arnis", "--bbox", "1,2,3,4"].iter());
        calculate_start_y_offset(&editor, &way, &args, 0)
    }

    /// With the extended floor the scaler sinks the terrain base far below the default
    /// -62, and buildings must follow it down instead of floating at the old level.
    #[test]
    fn sunk_terrain_base_does_not_strand_buildings() {
        assert_eq!(offset_for(-1500), -1500);
    }

    #[test]
    fn vanilla_terrain_is_unchanged() {
        assert_eq!(offset_for(-62), -62);
        assert_eq!(offset_for(80), 80);
    }
}

#[cfg(test)]
mod doorstep_tests {
    use super::*;
    use crate::coordinate_system::cartesian::XZBBox;
    use crate::element_processing::building_test_support::{
        bitmap_with_rect, rect_way, test_editor,
    };
    use clap::Parser as _;
    use fnv::FnvHashMap;
    use std::sync::Arc;

    /// World bounds are inclusive, and the elevation grid is one cell per
    /// block, so that `terrain_level` returns the fixture's own numbers
    /// instead of a bilinear blend of them.
    const MAX_X: i32 = 70;
    const MAX_Z: i32 = 60;
    const WORLD_W: usize = MAX_X as usize + 1;
    const WORLD_L: usize = MAX_Z as usize + 1;
    /// The house's north wall. The street in these fixtures runs north of it,
    /// so this is the side `plan_synthetic_entrance` puts the door on.
    const WALL_Z: i32 = 20;
    /// How far out `render_entrance` can reach: the threshold cell plus the
    /// steps behind it. Spelled out rather than taken from the constant, so
    /// this reads the same against the code before and after the fix.
    const REACH: i32 = 3;

    /// One cell of the doorstep run, read back out of the generated world.
    #[derive(Debug, PartialEq, Eq)]
    struct RunCell {
        /// Distance out from the door, 1 being the threshold cell.
        step: i32,
        /// The block found there, if any.
        block: Option<String>,
        y: i32,
        /// Terrain top under it. A block rests on the ground when this is
        /// exactly one below it; anything lower and it hangs in the air.
        ground: i32,
    }

    impl RunCell {
        fn is_stair(&self) -> bool {
            self.block
                .as_deref()
                .is_some_and(|n| n.ends_with("_stairs"))
        }

        fn hangs(&self) -> bool {
            self.ground < self.y - 1
        }
    }

    struct Fixture {
        /// The door column found in the north wall, if the building got one.
        door: Option<(i32, i32)>,
        floor: i32,
        run: Vec<RunCell>,
        /// Glass anywhere in the north wall, which a flattened facade removes.
        wall_has_glass: bool,
    }

    /// Generates one house over terrain that steps from `outside_y` in front of
    /// the north wall up to `inside_y` under the building, then reads the door
    /// and the cells of its doorstep run back out of the world.
    ///
    /// The floor follows the *highest* terrain under the outline, so
    /// `inside_y - outside_y` is exactly the drop the run has to bridge.
    fn build(inside_y: i32, outside_y: i32, presets: bool) -> Fixture {
        let xz = XZBBox::rect_from_min_max(0, 0, MAX_X, MAX_Z).unwrap();
        let road = bitmap_with_rect(&xz, 0, 12, MAX_X, 14);
        let footprints = CoordinateBitmap::new(&xz);
        let way = rect_way(4242, 22, WALL_Z, 52, 34, &[("building", "house")]);
        let mut editor = test_editor(&xz);
        editor.set_map_decals(presets);
        let heights: Vec<Vec<f32>> = (0..WORLD_L)
            .map(|z| {
                let y = if (z as i32) < WALL_Z {
                    outside_y
                } else {
                    inside_y
                };
                vec![y as f32; WORLD_W]
            })
            .collect();
        editor.set_ground(Arc::new(crate::ground::Ground::new_elevation_test(
            heights, WORLD_W, WORLD_L,
        )));
        let args = Args::parse_from(["arnis", "--bbox", "1,2,3,4", "--ground-level", "0"]);
        let cache = FloodFillCache::new();
        let passages = CoordinateBitmap::new_empty();
        let groups: FnvHashMap<u64, Vec<u64>> = FnvHashMap::default();
        let ctx = BuildingContext {
            flood_fill_cache: &cache,
            building_passages: &passages,
            road_mask: &road,
            building_footprints: &footprints,
            group_members: &groups,
            interior_uses:
                crate::element_processing::subprocessor::interior::InteriorUseIndex::empty(),
        };
        generate_buildings(&mut editor, &way, &args, None, None, &ctx, way.id);

        // Every outline node stands on the inside terrace, and the floor is the
        // highest terrain under the outline, so the floor is `inside_y` even
        // when the ground outside is higher.
        let floor = inside_y;
        let door = (22..=52).find(|&x| {
            editor
                .get_block_absolute(x, floor + 1, WALL_Z)
                .is_some_and(|b| b.name().ends_with("_door"))
        });
        let run = door
            .map(|dx| {
                (1..=REACH)
                    .map(|step| {
                        let z = WALL_Z - step;
                        let y = floor - step + 1;
                        RunCell {
                            step,
                            block: editor
                                .get_block_absolute(dx, y, z)
                                .map(|b| b.name().to_string()),
                            y,
                            ground: editor.terrain_level(dx, z).unwrap(),
                        }
                    })
                    .collect()
            })
            .unwrap_or_default();
        let wall_has_glass = (22..=52).any(|x| {
            (floor..=floor + 8).any(|y| {
                editor
                    .get_block_absolute(x, y, WALL_Z)
                    .is_some_and(|b| b.name().contains("glass"))
            })
        });
        Fixture {
            door: door.map(|x| (x, WALL_Z)),
            floor,
            run,
            wall_has_glass,
        }
    }

    fn plain(inside_y: i32, outside_y: i32) -> Fixture {
        let _guard = crate::mapillary::facades::TEST_GLOBALS
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        build(inside_y, outside_y, false)
    }

    /// The owner's report: a building whose floor is six blocks above the
    /// ground in front of its door used to get a run of steps that stopped in
    /// mid air, because the run was clamped to three steps and never asked
    /// whether the third one had landed.
    #[test]
    fn a_drop_the_run_cannot_reach_gets_no_steps() {
        let f = plain(6, 0);
        assert!(f.door.is_some(), "the fixture has to produce a door");
        let hanging: Vec<&RunCell> = f.run.iter().filter(|c| c.is_stair() && c.hangs()).collect();
        assert!(
            hanging.is_empty(),
            "steps left hanging over a 6 block drop: {hanging:?}"
        );
        assert!(
            f.run.iter().all(|c| !c.is_stair()),
            "a drop this deep must get no steps at all: {:?}",
            f.run
        );
    }

    /// The same building one block deeper than the run's three step reach.
    #[test]
    fn a_drop_one_deeper_than_the_reach_gets_no_steps() {
        let f = plain(4, 0);
        assert!(
            f.run.iter().all(|c| !c.is_stair()),
            "a 4 block drop is past the run's reach: {:?}",
            f.run
        );
    }

    /// The case the steps exist for: the run lands, so it is still built.
    #[test]
    fn a_drop_the_run_reaches_keeps_its_steps() {
        let f = plain(2, 0);
        let steps: Vec<&RunCell> = f.run.iter().filter(|c| c.is_stair()).collect();
        assert_eq!(steps.len(), 1, "expected one step, got {:?}", f.run);
        assert!(!steps[0].hangs(), "the step has to rest on the ground");
        assert_eq!(steps[0].step, 2, "the step sits behind the threshold");
    }

    /// Flat ground: no drop, so nothing but the threshold, before and after.
    #[test]
    fn flat_ground_gets_a_threshold_and_no_steps() {
        let f = plain(0, 0);
        assert!(f.door.is_some());
        assert!(
            f.run.iter().all(|c| !c.is_stair()),
            "flat ground must not get steps: {:?}",
            f.run
        );
        let threshold = &f.run[0];
        assert_eq!(threshold.y, f.floor);
        assert!(
            threshold.block.is_some() && !threshold.hangs(),
            "the threshold sits on the ground in front of the door: {threshold:?}"
        );
    }

    /// Ground higher than the floor: there is nothing to step down to.
    #[test]
    fn ground_above_the_floor_gets_no_steps() {
        let f = plain(0, 3);
        assert!(f.door.is_some());
        assert!(
            f.run.iter().all(|c| !c.is_stair()),
            "an uphill door must not get steps: {:?}",
            f.run
        );
    }

    /// A preset facade flattens the wall it hangs on but leaves the door, so
    /// the doorstep rule has to hold there too.
    #[test]
    fn a_preset_flattened_wall_follows_the_same_rule() {
        let _guard = crate::mapillary::facades::TEST_GLOBALS
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(dir.path().join("r00.png"), b"").unwrap();
        std::fs::write(
            dir.path()
                .join(crate::building_facades::manifest::MANIFEST_NAME),
            r#"{"version": 1, "textures": [{"file": "r00.png", "categories": ["Default"],
                "metres_wide": 12.0, "metres_tall": 12.4, "storeys": 4,
                "tiles_horizontally": true, "has_ground_floor": true}]}"#,
        )
        .unwrap();
        crate::building_facades::reset(true, Some(dir.path()), 16, 1.0);
        let deep = build(6, 0, true);
        let shallow = build(2, 0, true);
        crate::building_facades::reset(false, None, 16, 1.0);
        let unflattened = build(6, 0, false);

        assert!(
            unflattened.wall_has_glass && !deep.wall_has_glass,
            "the fixture has to actually flatten the wall"
        );
        assert!(deep.door.is_some(), "a flattened wall still gets its door");
        assert!(
            deep.run.iter().all(|c| !c.is_stair()),
            "a flattened wall must not get hanging steps: {:?}",
            deep.run
        );
        let steps: Vec<&RunCell> = shallow.run.iter().filter(|c| c.is_stair()).collect();
        assert_eq!(steps.len(), 1, "and keeps the ones that land");
        assert!(!steps[0].hangs());
    }
}

#[cfg(test)]
mod roof_geometry_tests {
    use super::*;
    use crate::coordinate_system::cartesian::XZBBox;
    use crate::element_processing::building_test_support::{tag_map, test_editor};

    const BASE: i32 = 10;

    fn roof_config(cells: &[(i32, i32)]) -> RoofConfig {
        let mut config = RoofConfig::from_roof_area(cells, 7, BASE - 1, 0, BRICK, 0);
        config.roof_block = BRICK;
        config.building_height = 40;
        config
    }

    fn ring(pts: &[(i32, i32)]) -> Vec<ProcessedNode> {
        pts.iter()
            .chain(pts.first())
            .enumerate()
            .map(|(i, &(x, z))| ProcessedNode {
                id: i as u64,
                tags: HashMap::new(),
                x,
                z,
            })
            .collect()
    }

    /// Lattice cells inside a polygon (even-odd), plus its outline cells.
    fn fill(nodes: &[ProcessedNode]) -> Vec<(i32, i32)> {
        let pts: Vec<(f64, f64)> = nodes.iter().map(|n| (n.x as f64, n.z as f64)).collect();
        let (min_x, max_x) = (
            nodes.iter().map(|n| n.x).min().unwrap(),
            nodes.iter().map(|n| n.x).max().unwrap(),
        );
        let (min_z, max_z) = (
            nodes.iter().map(|n| n.z).min().unwrap(),
            nodes.iter().map(|n| n.z).max().unwrap(),
        );
        let mut cells: Vec<(i32, i32)> = (min_z..=max_z)
            .flat_map(|z| (min_x..=max_x).map(move |x| (x, z)))
            .filter(|&(x, z)| polygon_contains(&pts, x as f64, z as f64))
            .collect();
        cells.extend(thin_ring_cells(nodes));
        cells.sort_unstable();
        cells.dedup();
        cells
    }

    fn rect_cells(w: i32, l: i32) -> Vec<(i32, i32)> {
        (0..l).flat_map(|z| (0..w).map(move |x| (x, z))).collect()
    }

    fn top(editor: &WorldEditor, x: i32, z: i32) -> i32 {
        editor
            .highest_block_between(x, z, 0, 400)
            .unwrap_or_else(|| panic!("no roof at {x},{z}"))
    }

    #[test]
    fn roof_direction_parses_points_and_bearings() {
        assert_eq!(parse_roof_direction_degrees("ne"), Some(45.0));
        assert_eq!(parse_roof_direction_degrees("164"), Some(164.0));
        assert_eq!(parse_roof_direction_degrees("-90"), Some(270.0));
        assert_eq!(parse_roof_direction_degrees("uphill"), None);
        assert_eq!(cardinal_for_bearing(164.0), StairFacing::South);
        assert_eq!(cardinal_for_bearing(344.0), StairFacing::North);
        let (dx, dz) = bearing_unit_vector(90.0);
        assert!((dx - 1.0).abs() < 1e-9 && dz.abs() < 1e-9, "east is +X");
        let (dx, dz) = bearing_unit_vector(0.0);
        assert!(dx.abs() < 1e-9 && (dz + 1.0).abs() < 1e-9, "north is -Z");
    }

    // A chamfer or a rotated wing slopes along its mapped bearing, not the
    // nearest cardinal: cells on one line across the bearing share a height.
    #[test]
    fn skillion_slopes_along_a_diagonal_bearing() {
        let xz = XZBBox::rect_from_xz_lengths(40.0, 40.0).unwrap();
        let mut editor = test_editor(&xz);
        let cells = rect_cells(20, 20);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(19);
        // Downhill to the north-east: the south-west corner is the ridge.
        generate_skillion_roof(&mut editor, &cells, &config, Some("45"));

        let sw = top(&editor, 0, 19);
        let ne = top(&editor, 19, 0);
        assert_eq!(sw - ne, 19, "full mapped rise from ridge to eave");
        // Lines of constant x - z run across the bearing.
        assert_eq!(top(&editor, 2, 2), top(&editor, 10, 10));
        assert_eq!(top(&editor, 10, 10), top(&editor, 17, 17));
        assert_eq!(top(&editor, 0, 10), top(&editor, 9, 19));
        // Along the bearing it descends monotonically.
        let along: Vec<i32> = (0..20).map(|i| top(&editor, i, 19 - i)).collect();
        assert!(along.windows(2).all(|w| w[0] >= w[1]), "{along:?}");
    }

    #[test]
    fn skillion_keeps_a_mapped_rise_above_twelve_blocks() {
        let xz = XZBBox::rect_from_xz_lengths(40.0, 40.0).unwrap();
        let mut editor = test_editor(&xz);
        let cells = rect_cells(10, 10);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(30);
        generate_skillion_roof(&mut editor, &cells, &config, Some("south"));
        assert_eq!(top(&editor, 5, 0) - top(&editor, 5, 9), 30);
        // A face that steep is built of full blocks, not stairs.
        let y = top(&editor, 5, 4);
        assert_eq!(editor.get_block_absolute(5, y, 4), Some(BRICK));
    }

    #[test]
    fn skillion_cardinal_bearing_matches_the_bbox_slope() {
        let xz = XZBBox::rect_from_xz_lengths(40.0, 40.0).unwrap();
        let mut editor = test_editor(&xz);
        let cells = rect_cells(12, 6);
        let config = roof_config(&cells);
        generate_skillion_roof(&mut editor, &cells, &config, Some("west"));
        // Descends toward -X, one height per column.
        for z in 0..6 {
            assert_eq!(top(&editor, 0, z), top(&editor, 0, 0));
        }
        assert!(top(&editor, 11, 3) > top(&editor, 0, 3));
    }

    #[test]
    fn roof_angle_run_follows_a_diagonal_skillion_bearing() {
        let tags = tag_map(&[("roof:angle", "45"), ("roof:direction", "45")]);
        let cells = rect_cells(20, 20);
        let config = roof_config(&cells);
        // The bbox spans 20 cells each way, so the diagonal run is 20 * sqrt 2.
        let cap = roof_peak_cap(
            &tags,
            RoofType::Skillion,
            &config,
            &RidgeFrame::grid(true),
            1.0,
        );
        assert_eq!(cap, Some(28));
    }

    // The apex sits over the centroid and the faces follow the outline, so a
    // 45-degree square gets a pyramid with ridges on its own diagonals.
    #[test]
    fn pyramid_follows_a_rotated_square() {
        let nodes = ring(&[(10, 0), (20, 10), (10, 20), (0, 10)]);
        let cells = fill(&nodes);
        let xz = XZBBox::rect_from_xz_lengths(40.0, 40.0).unwrap();
        let mut editor = test_editor(&xz);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(10);
        generate_pyramidal_roof(&mut editor, &cells, &config, &nodes);

        assert_eq!(
            top(&editor, 10, 10),
            BASE + 10,
            "apex carries the mapped rise"
        );
        // Equal L1 distance from the centre means equal height on the diamond.
        assert_eq!(top(&editor, 13, 7), top(&editor, 10, 4));
        assert_eq!(top(&editor, 13, 7), top(&editor, 16, 10));
        // Halfway out along a face the rise is half; the bbox rule gave 7 here.
        assert_eq!(top(&editor, 13, 7), BASE + 4);
        // The outline is the eave.
        assert_eq!(top(&editor, 15, 5), BASE);
    }

    #[test]
    fn pyramid_on_an_axis_aligned_rectangle_is_unchanged() {
        let nodes = ring(&[(0, 0), (20, 0), (20, 10), (0, 10)]);
        let cells = fill(&nodes);
        let xz = XZBBox::rect_from_xz_lengths(40.0, 40.0).unwrap();
        let mut editor = test_editor(&xz);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(5);
        generate_pyramidal_roof(&mut editor, &cells, &config, &nodes);
        assert_eq!(top(&editor, 10, 5), BASE + 5);
        // Single apex: the long axis climbs at half the pitch of the short one.
        assert_eq!(top(&editor, 5, 5), BASE + 2);
        assert_eq!(top(&editor, 10, 2), BASE + 2);
    }

    #[test]
    fn dome_meets_the_eave_all_round_a_rotated_ellipse() {
        // Semi-axes 18 and 7, rotated 30 degrees.
        let (a, b, rot) = (18.0f64, 7.0f64, 30.0f64.to_radians());
        let pts: Vec<(i32, i32)> = (0..48)
            .map(|i| {
                let t = i as f64 / 48.0 * std::f64::consts::TAU;
                let (ex, ez) = (a * t.cos(), b * t.sin());
                let x = 30.0 + ex * rot.cos() - ez * rot.sin();
                let z = 30.0 + ex * rot.sin() + ez * rot.cos();
                (x.round() as i32, z.round() as i32)
            })
            .collect();
        let mut pts_dedup = pts.clone();
        pts_dedup.dedup();
        let nodes = ring(&pts_dedup);
        let cells = fill(&nodes);
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let mut editor = test_editor(&xz);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(12);
        generate_dome_roof(&mut editor, &cells, &config, &nodes);

        assert_eq!(
            top(&editor, 30, 30),
            BASE + 12,
            "crown carries the mapped rise"
        );
        let footprint: HashSet<(i32, i32)> = cells.iter().copied().collect();
        let mut worst = 0;
        for &(x, z) in &cells {
            let on_edge = [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)]
                .iter()
                .any(|n| !footprint.contains(n));
            if on_edge {
                worst = worst.max(top(&editor, x, z) - BASE);
            }
        }
        // A hemisphere is steep at its rim, so the half cell an outline cell
        // sits inside the polygon is worth a few blocks. The bbox rule left a
        // wall of ten along the flanks.
        assert!(
            worst <= 4,
            "eave cells rise {worst} blocks above the wall top"
        );
    }

    #[test]
    fn radial_fractions_bail_out_on_a_footprint_the_centroid_cannot_see() {
        // A courtyard block: a thick base with two wings. The area centroid
        // lands in the base, inside the footprint, but the inner face of each
        // wing sits behind the open courtyard, so no single ray fan measures
        // the wings against their own walls.
        let nodes = ring(&[
            (0, 0),
            (30, 0),
            (30, 30),
            (18, 30),
            (18, 20),
            (12, 20),
            (12, 30),
            (0, 30),
        ]);
        let cells = fill(&nodes);
        let pts: Vec<(f64, f64)> = nodes.iter().map(|n| (n.x as f64, n.z as f64)).collect();
        assert!(polygon_contains(&pts, 15.0, 14.0), "the centroid is inside");
        assert!(footprint_radial_fractions(&nodes, &cells).is_none());
    }

    // A plus is concave but every cell is still visible from its centre, so it
    // keeps the radial profile rather than falling back to the bounding box.
    #[test]
    fn radial_fractions_keep_a_concave_but_visible_footprint() {
        let nodes = ring(&[
            (10, 0),
            (20, 0),
            (20, 10),
            (30, 10),
            (30, 20),
            (20, 20),
            (20, 30),
            (10, 30),
            (10, 20),
            (0, 20),
            (0, 10),
            (10, 10),
        ]);
        let cells = fill(&nodes);
        let radial =
            footprint_radial_fractions(&nodes, &cells).expect("a plus is star-shaped from centre");
        assert!(radial[&(15, 15)] < 0.2, "the middle reads as the apex");
        assert!(radial[&(15, 29)] > 0.9, "an arm tip reads as the eave");
    }

    #[test]
    fn radial_fractions_survive_a_convex_footprint() {
        // A rotated octagon: concave nowhere, so every cell stays visible.
        let nodes = ring(&[
            (10, 0),
            (20, 4),
            (24, 14),
            (20, 24),
            (10, 28),
            (0, 24),
            (-4, 14),
            (0, 4),
        ]);
        let cells = fill(&nodes);
        let radial = footprint_radial_fractions(&nodes, &cells).expect("convex ring keeps its fan");
        assert_eq!(radial.len(), cells.len());
        // The rim reads as the eave, the middle as the apex.
        assert!(radial[&(10, 0)] > 0.9);
        assert!(radial[&(10, 14)] < 0.2);
    }

    #[test]
    fn radial_fractions_bail_out_when_the_centroid_is_outside() {
        // A thin L: its centroid lies in the empty quadrant.
        let nodes = ring(&[(0, 0), (30, 0), (30, 4), (4, 4), (4, 30), (0, 30)]);
        let cells = fill(&nodes);
        assert!(footprint_radial_fractions(&nodes, &cells).is_none());
    }

    // A mapped roof:height fixes the pitch: a 3 m rise across a 12-wide span
    // is a shallow pediment, not a 1:1 slope cut off into a mesa.
    #[test]
    fn gable_pitch_follows_a_stated_rise() {
        let cells = rect_cells(30, 12);
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let mut editor = test_editor(&xz);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(3);
        generate_gabled_roof(
            &mut editor,
            &cells,
            &config,
            GableProfile::Standard,
            &RidgeFrame::grid(true),
        );
        let eave = top(&editor, 15, 0);
        let ridge = top(&editor, 15, 5);
        assert_eq!(ridge - eave, 3, "ridge reaches the mapped rise");
        let mid = top(&editor, 15, 3);
        assert!(
            mid > eave && mid < ridge,
            "eave {eave} mid {mid} ridge {ridge}"
        );
    }

    #[test]
    fn gable_reaches_a_stated_rise_steeper_than_one_to_one() {
        let cells = rect_cells(30, 12);
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let mut editor = test_editor(&xz);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(10);
        generate_gabled_roof(
            &mut editor,
            &cells,
            &config,
            GableProfile::Standard,
            &RidgeFrame::grid(true),
        );
        // Previously capped at 85% of the half-span (5).
        assert_eq!(top(&editor, 15, 5) - top(&editor, 15, 0), 10);
    }

    #[test]
    fn hip_pitch_follows_a_stated_rise() {
        let cells = rect_cells(30, 12);
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let mut editor = test_editor(&xz);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(3);
        generate_hipped_roof(&mut editor, &cells, &config);
        let eave = top(&editor, 15, 0);
        let ridge = top(&editor, 15, 5);
        assert_eq!(ridge - eave, 3);
        let mid = top(&editor, 15, 3);
        assert!(
            mid > eave && mid < ridge,
            "eave {eave} mid {mid} ridge {ridge}"
        );
    }

    #[test]
    fn roof_direction_turns_the_ridge_across_the_slope() {
        // 30 x 12: the ridge would run along X. A slope facing east means the
        // ridge runs along Z instead, so heights vary with X and not with Z.
        let nodes = ring(&[(0, 0), (29, 0), (29, 11), (0, 11)]);
        let ridge = ridge_frame(&nodes, 29, 11, None, Some("90"), None);
        assert!(!ridge.along_x);
        let ridge = ridge_frame(&nodes, 29, 11, None, Some("north"), None);
        assert!(ridge.along_x);
        // roof:direction wins over the longer side, roof:orientation still
        // applies when it is absent.
        let ridge = ridge_frame(&nodes, 29, 11, Some("across"), None, None);
        assert!(!ridge.along_x);
    }

    #[test]
    fn turned_rectangle_gets_a_planar_tent_on_its_own_axis() {
        // A 30 x 12 rectangle turned 30 degrees.
        let (c, sn) = (30.0f64.to_radians().cos(), 30.0f64.to_radians().sin());
        let pts: Vec<(i32, i32)> = [(0.0, 0.0), (30.0, 0.0), (30.0, 12.0), (0.0, 12.0)]
            .iter()
            .map(|&(u, v): &(f64, f64)| {
                (
                    (20.0 + u * c - v * sn).round() as i32,
                    (5.0 + u * sn + v * c).round() as i32,
                )
            })
            .collect();
        let nodes = ring(&pts);
        let cells = fill(&nodes);
        let xz = XZBBox::rect_from_xz_lengths(70.0, 70.0).unwrap();
        let mut editor = test_editor(&xz);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(5);
        let ridge = ridge_frame(&nodes, config.width(), config.length(), None, None, None);
        let tent = ridge.tent.expect("turned rectangle gets a tent");
        assert!(ridge.along_x, "ridge follows the 30 side, nearest X");
        generate_gabled_roof(&mut editor, &cells, &config, GableProfile::Standard, &ridge);
        // Two cells on the ridge line (v at mid-span), a third of the way in
        // and two thirds of the way in, share the crown height; a cell near
        // the long side sits at the eave.
        let at = |u: f64, v: f64| -> (i32, i32) {
            (
                (20.0 + u * c - v * sn).round() as i32,
                (5.0 + u * sn + v * c).round() as i32,
            )
        };
        let (rx, rz) = at(10.0, 6.0);
        let (sx, sz) = at(20.0, 6.0);
        let (ex, ez) = at(15.0, 0.0);
        assert!(tent.angle.to_degrees() > 25.0 && tent.angle.to_degrees() < 35.0);

        assert_eq!(top(&editor, rx, rz), top(&editor, sx, sz));
        assert_eq!(top(&editor, rx, rz) - top(&editor, ex, ez), 5);
        // A cell on the gable end is not treated as an eave.
        let (gx, gz) = at(0.5, 6.0);
        assert!(top(&editor, gx, gz) >= top(&editor, ex, ez) + 3);
    }

    #[test]
    fn round_roof_is_a_barrel_vault() {
        assert_eq!(parse_roof_type("round"), RoofType::Round);
        let cells = rect_cells(30, 12);
        let xz = XZBBox::rect_from_xz_lengths(60.0, 60.0).unwrap();
        let mut editor = test_editor(&xz);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(5);
        generate_gabled_roof(
            &mut editor,
            &cells,
            &config,
            GableProfile::Round,
            &RidgeFrame::grid(true),
        );
        let eave = top(&editor, 15, 0);
        let crown = top(&editor, 15, 5);
        assert_eq!(crown - eave, 5);
        // Convex section: a quarter of the way in it is already above the
        // straight line from eave to crown (which would be 2 there, 3 at half).
        assert!(top(&editor, 15, 2) - eave >= 3);
        assert_eq!(top(&editor, 15, 3), top(&editor, 15, 4));
    }

    #[test]
    fn domes_are_shells_over_a_hall() {
        let nodes = ring(&[(0, 0), (30, 0), (30, 30), (0, 30)]);
        let cells = fill(&nodes);
        let xz = XZBBox::rect_from_xz_lengths(40.0, 40.0).unwrap();
        let mut editor = test_editor(&xz);
        let mut config = roof_config(&cells);
        config.peak_cap = Some(12);
        generate_dome_roof(&mut editor, &cells, &config, &nodes);
        let crown = top(&editor, 15, 15);
        assert_eq!(crown, BASE + 12);
        assert_eq!(editor.get_block_absolute(15, crown - 1, 15), Some(BRICK));
        // The hall under the crown is open.
        assert_eq!(editor.get_block_absolute(15, BASE + 4, 15), None);
        // The rim runs down to the wall top.
        assert_eq!(editor.get_block_absolute(15, BASE, 0), Some(BRICK));
    }

    #[test]
    fn parts_keep_thin_walls_under_a_pitched_roof() {
        let part = ProcessedWay {
            id: 1,
            nodes: vec![],
            tags: tag_map(&[
                ("building:part", "yes"),
                ("height", "4"),
                ("roof:height", "3"),
                ("roof:shape", "gabled"),
            ]),
        };
        let (h, _) = calculate_building_height(&part, "yes", 0, 1.0, None, 4, 100, 1);
        assert_eq!(h, 1);
    }

    #[test]
    fn outward_normals_point_out_of_every_wall_of_an_l_shape() {
        // Bar 0..20 x 0..4 plus a leg 0..4 x 0..20. The centroid of the
        // vertices lies in the notch, which used to flip the two inner walls.
        let nodes = ring(&[(0, 0), (20, 0), (20, 4), (4, 4), (4, 20), (0, 20)]);
        let pts: Vec<(f64, f64)> = nodes.iter().map(|n| (n.x as f64, n.z as f64)).collect();
        let outward = outward_side(&nodes);
        for pair in nodes.windows(2) {
            let (x1, z1, x2, z2) = (pair[0].x, pair[0].z, pair[1].x, pair[1].z);
            let (nx, nz) = compute_outward_normal(x1, z1, x2, z2, outward);
            let (mx, mz) = ((x1 + x2) as f64 / 2.0, (z1 + z2) as f64 / 2.0);
            assert!(
                !polygon_contains(&pts, mx + nx as f64 * 0.5, mz + nz as f64 * 0.5),
                "wall ({x1},{z1})-({x2},{z2}) normal ({nx},{nz}) points inside"
            );
        }
        // The other winding gives the same answer.
        let reversed: Vec<ProcessedNode> = nodes.iter().rev().cloned().collect();
        let outward = outward_side(&reversed);
        let (nx, nz) = compute_outward_normal(4, 4, 20, 4, outward);
        assert_eq!((nx, nz), (0, 1));
    }

    #[test]
    fn corners_are_convex_turns_only() {
        let nodes = ring(&[(0, 0), (10, 0), (20, 0), (20, 4), (4, 4), (4, 20), (0, 20)]);
        let outward = outward_side(&nodes);
        assert!(corner_is_convex((0, 0), (20, 0), (20, 4), outward));
        // Mid-wall node.
        assert!(!corner_is_convex((0, 0), (10, 0), (20, 0), outward));
        // Re-entrant corner of the L.
        assert!(!corner_is_convex((20, 4), (4, 4), (4, 20), outward));
        assert_eq!(ring_vertices(&nodes).len(), 7);
    }

    #[test]
    fn thin_rings_stand_on_their_outline() {
        // A one-metre column: every node lands on one or two cells.
        let column = ring(&[(5, 5), (6, 5), (6, 6), (5, 6)]);
        let cells = thin_ring_cells(&column);
        assert!(!cells.is_empty());
        assert!(cells.len() <= THIN_RING_MAX_CELLS);
        // A degenerate ring on a single cell still stands.
        let dot = ring(&[(5, 5), (5, 5), (5, 5)]);
        assert_eq!(thin_ring_cells(&dot), vec![(5, 5)]);
        // Open ways are not footprints.
        let open: Vec<ProcessedNode> = column[..3].to_vec();
        assert!(thin_ring_cells(&open).is_empty());
    }

    #[test]
    fn ground_level_parts_keep_a_thin_mapped_height() {
        let plinth = ProcessedWay {
            id: 1,
            nodes: vec![],
            tags: tag_map(&[("building:part", "yes"), ("height", "1")]),
        };
        let (h, _) = calculate_building_height(&plinth, "yes", 0, 1.0, None, 4, 100, 1);
        assert_eq!(h, 1);
        // A whole building still gets the interior minimum.
        let hut = ProcessedWay {
            id: 2,
            nodes: vec![],
            tags: tag_map(&[("building", "yes"), ("height", "1")]),
        };
        let (h, _) = calculate_building_height(&hut, "yes", 0, 1.0, None, 3, 100, 1);
        assert_eq!(h, 3);
    }
}
