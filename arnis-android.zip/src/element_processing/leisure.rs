use crate::args::Args;
use crate::block_definitions::*;
use crate::bresenham::bresenham_line;
use crate::deterministic_rng::element_rng;
use crate::element_processing::bridges::BridgeSurfaceMap;
use crate::element_processing::surfaces::get_blocks_for_surface;
use crate::element_processing::tree::Tree;
use crate::floodfill_cache::{is_oversized_ring, BuildingFootprintBitmap, FloodFillCache};
use crate::osm_parser::{ProcessedMemberRole, ProcessedRelation, ProcessedWay};
use crate::world_editor::WorldEditor;
use rand::Rng;

pub fn generate_leisure(
    editor: &mut WorldEditor,
    element: &ProcessedWay,
    args: &Args,
    flood_fill_cache: &FloodFillCache,
    building_footprints: &BuildingFootprintBitmap,
    bridge_surface: &BridgeSurfaceMap,
) {
    if let Some(leisure_type) = element.tags.get("leisure") {
        let mut previous_node: Option<(i32, i32)> = None;
        let mut corner_count: i32 = 0;
        let mut current_leisure: Vec<(i32, i32)> = vec![];

        // Determine block type based on leisure type
        let mut block_type: Block = match leisure_type.as_str() {
            "park" | "nature_reserve" | "garden" | "disc_golf_course" | "golf_course" => {
                GRASS_BLOCK
            }
            "schoolyard" => BLACK_CONCRETE,
            "playground" | "recreation_ground" | "pitch" | "beach_resort" | "dog_park" => {
                GREEN_STAINED_HARDENED_CLAY
            }
            "swimming_pool" | "swimming_area" => WATER, // Swimming area: Area in a larger body of water for swimming
            "marina" => WATER, // A sort of parking lot for small watercraft
            "bathing_place" => SMOOTH_SANDSTONE, // Could be sand or concrete
            "outdoor_seating" => SMOOTH_STONE, //Usually stone or stone bricks
            "water_park" | "slipway" => LIGHT_GRAY_CONCRETE, // Water park area, not the pool. Usually is concrete
            "ice_rink" => PACKED_ICE, // TODO: Ice for Ice Rink, needs building defined
            _ => GRASS_BLOCK,
        };
        // Explicit surface=* overrides the category default. Leave
        // `block_type` untouched for unknown surface values so existing
        // behaviour is preserved.
        if let Some(surface) = element.tags.get("surface") {
            if let Some(blocks) = get_blocks_for_surface(surface) {
                block_type = blocks[0];
            }
        }

        // Resolve the fill before painting the edge, for the same reason as in natural.rs:
        // a closed ring the fill refused must not leave a border around unfilled ground.
        let filled_area = flood_fill_cache.get_or_compute(element, args.timeout.as_ref());
        if filled_area.is_empty() && is_oversized_ring(element) {
            return;
        }

        // Process leisure area nodes
        for node in &element.nodes {
            if let Some(prev) = previous_node {
                // Draw a line between the current and previous node
                let bresenham_points: Vec<(i32, i32, i32)> =
                    bresenham_line(prev.0, 0, prev.1, node.x, 0, node.z);
                for (bx, _, bz) in bresenham_points {
                    editor.set_block(
                        block_type,
                        bx,
                        0,
                        bz,
                        Some(&[
                            GRASS_BLOCK,
                            STONE_BRICKS,
                            SMOOTH_STONE,
                            LIGHT_GRAY_CONCRETE,
                            COBBLESTONE,
                            GRAY_CONCRETE,
                        ]),
                        None,
                    );
                }

                current_leisure.push((node.x, node.z));
                corner_count += 1;
            }
            previous_node = Some((node.x, node.z));
        }

        // Flood-fill the interior of the leisure area using cache
        if corner_count > 0 {
            // Use deterministic RNG seeded by element ID for consistent results across region boundaries
            let mut rng = element_rng(element.id);

            for &(x, z) in filled_area.iter() {
                if leisure_type == "schoolyard" && editor.nested_area_owns(x, z) {
                    continue;
                }
                editor.set_block(block_type, x, 0, z, Some(&[GRASS_BLOCK]), None);

                // Land-cover water is skipped because a park often spans its
                // own lake, and the carve after this leaves plants floating. A pitch
                // or path inside the park is drawn after it, so its columns still
                // read as grass here and only the mask tells them apart. Halo cells
                // are left to the tile that owns them, whose own random sequence
                // decides what grows there.
                if matches!(leisure_type.as_str(), "park" | "garden" | "nature_reserve")
                    && editor.owns(x, z)
                    && editor.check_for_block(x, 0, z, Some(&[GRASS_BLOCK]))
                    && !editor.surface_is_sealed(x, z)
                    && !editor.is_lc_water(x, z)
                {
                    let random_choice: i32 = rng.random_range(0..1000);

                    match random_choice {
                        0..30 => {
                            // Plants
                            let setting = if leisure_type == "nature_reserve" {
                                crate::ground_decoration::FlowerSetting::Meadow
                            } else {
                                crate::ground_decoration::FlowerSetting::Garden
                            };
                            if random_choice < 22 {
                                crate::ground_decoration::place_scattered_flower(
                                    editor, x, z, setting,
                                );
                            } else {
                                editor.set_block(FERN, x, 1, z, None, None);
                            }
                        }
                        30..90 => {
                            // Grass
                            editor.set_block(GRASS, x, 1, z, None, None);
                        }
                        90..105 => {
                            crate::element_processing::bush::place_bush(
                                editor,
                                x,
                                z,
                                crate::element_processing::bush::BushKind::Garden,
                            );
                        }
                        105..120 => {
                            // Only where land cover says woody, else a park
                            // canopies its own meadows.
                            if editor.land_cover_backs_trees(x, z) {
                                Tree::create(
                                    editor,
                                    (x, 1, z),
                                    Some(building_footprints),
                                    Some(bridge_surface),
                                );
                            } else {
                                editor.set_block(GRASS, x, 1, z, None, None);
                            }
                        }
                        _ => {}
                    }
                }
            }

            // Stamp bundled playground structures (replaces the old procedural props).
            if matches!(leisure_type.as_str(), "playground" | "recreation_ground") {
                crate::structures::playground::scatter_playgrounds(editor, filled_area.as_slice());
            }

            if leisure_type == "pitch" {
                // Clear park/ground vegetation scattered onto the pitch before marking.
                for &(x, z) in filled_area.iter() {
                    editor.set_block(
                        AIR,
                        x,
                        1,
                        z,
                        Some(crate::ground_decoration::LOOSE_PLANTS),
                        None,
                    );
                }
                crate::element_processing::sport_pitches::draw_pitch_markings(
                    editor,
                    element,
                    filled_area.as_slice(),
                    block_type,
                );
            }
        }
    }
}

pub fn generate_leisure_from_relation(
    editor: &mut WorldEditor,
    rel: &ProcessedRelation,
    args: &Args,
    flood_fill_cache: &FloodFillCache,
    building_footprints: &BuildingFootprintBitmap,
    bridge_surface: &BridgeSurfaceMap,
) {
    if rel.tags.get("leisure").map(String::as_str) == Some("park") {
        // Process each outer member way individually using cached flood fill.
        // We intentionally do not combine all outer nodes into one mega-way,
        // because that creates a nonsensical polygon spanning the whole relation
        // extent, misses the flood fill cache, and can cause multi-GB allocations.
        for member in &rel.members {
            if member.role == ProcessedMemberRole::Outer {
                // Use relation tags so the member inherits the relation's leisure=* type
                let way_with_rel_tags = ProcessedWay {
                    id: member.way.id,
                    nodes: member.way.nodes.clone(),
                    tags: rel.tags.clone(),
                };
                generate_leisure(
                    editor,
                    &way_with_rel_tags,
                    args,
                    flood_fill_cache,
                    building_footprints,
                    bridge_surface,
                );
            }
        }
    }
}
