//! Processing of emergency infrastructure elements.
//!
//! This module handles emergency-related OSM elements including:
//! - `emergency=fire_hydrant` - Fire hydrants

use crate::block_definitions::*;
use crate::osm_parser::ProcessedNode;
use crate::world_editor::WorldEditor;

/// Generate emergency infrastructure from node elements
pub fn generate_emergency(editor: &mut WorldEditor, node: &ProcessedNode) {
    // Skip if 'layer' or 'level' is negative in the tags
    if let Some(layer) = node.tags.get("layer") {
        if layer.parse::<i32>().unwrap_or(0) < 0 {
            return;
        }
    }

    if let Some(level) = node.tags.get("level") {
        if level.parse::<i32>().unwrap_or(0) < 0 {
            return;
        }
    }

    if let Some(emergency_type) = node.tags.get("emergency") {
        if emergency_type.as_str() == "fire_hydrant" {
            generate_fire_hydrant(editor, node)
        }
    }
}

/// Generate a fire hydrant
///
/// Creates a simple fire hydrant structure using brick wall with redstone block on top.
/// Skips underground, wall-mounted, and pond hydrant types.
fn generate_fire_hydrant(editor: &mut WorldEditor, node: &ProcessedNode) {
    let x = node.x;
    let z = node.z;

    // Get hydrant type - skip underground, wall, and pond types
    let hydrant_type = node
        .tags
        .get("fire_hydrant:type")
        .map(|s| s.as_str())
        .unwrap_or("pillar");

    // Skip non-visible hydrant types
    if matches!(hydrant_type, "underground" | "wall" | "pond") {
        return;
    }

    // Simple hydrant: a single redstone block at ground level.
    editor.set_block(REDSTONE_BLOCK, x, 1, z, None, None);

    let abs_y = editor.get_absolute_y(x, 1, z);

    if let Some(key) = crate::element_processing::signage::furniture_pictogram(&node.tags) {
        if editor.signage().is_some_and(|s| s.registry.contains(&key)) {
            // Hydrant sign on all four sides.
            for facing in [2i8, 3, 4, 5] {
                editor.place_decal(x, abs_y, z, facing, &key);
            }
            return;
        }
    }

    // Non-Java fallback: red banners with an orange flame-like pattern on all four sides.
    const HYDRANT_PATTERNS: &[(&str, &str)] = &[
        ("orange", "minecraft:triangle_top"),
        ("yellow", "minecraft:triangle_bottom"),
        ("red", "minecraft:border"),
    ];
    let banner_faces: [(i32, i32, &str); 4] = [
        (0, 1, "south"),
        (0, -1, "north"),
        (1, 0, "east"),
        (-1, 0, "west"),
    ];
    for (dx, dz, facing) in &banner_faces {
        editor.place_wall_banner(
            RED_WALL_BANNER,
            x + dx,
            abs_y,
            z + dz,
            facing,
            "red",
            HYDRANT_PATTERNS,
        );
    }
}
